# v 2.1
# Good stats
#ALTER TABLE `cpa_cash` CHANGE `order_id` `order_id` MEDIUMINT UNSIGNED NOT NULL;
#ALTER TABLE `cpa_cash` ADD INDEX(`order_id`);
#ALTER TABLE `cpa_order` ADD `cash_wm` MEDIUMINT NOT NULL AFTER `price_total`, ADD `cash_pay` MEDIUMINT NOT NULL AFTER `cash_wm`;
#ALTER TABLE `cpa_site` ADD `site_epc` FLOAT NOT NULL AFTER `site_convert`;
#ALTER TABLE `cpa_offer` ADD `offer_epc` FLOAT NOT NULL AFTER `offer_convert`;
#ALTER TABLE `cpa_click` ADD `ext_id` SMALLINT UNSIGNED NOT NULL AFTER `site_id`, ADD `ext_src` INT NOT NULL AFTER `ext_id`, ADD `click_ip` INT UNSIGNED NOT NULL AFTER `ext_src`, ADD `click_geo` CHAR(2) NOT NULL AFTER `click_ip`, ADD INDEX (`ext_id`);
#ALTER TABLE `cpa_click` ADD `offer_id` SMALLINT UNSIGNED NOT NULL AFTER `click_id`, ADD INDEX (`offer_id`);
#ALTER TABLE `cpa_click` ADD `site_sib` SMALLINT UNSIGNED NOT NULL AFTER `site_id`, ADD INDEX (`site_sib`);
# Offers and split tests
ALTER TABLE `cpa_offer` ADD `offer_recom` TINYINT UNSIGNED NOT NULL AFTER `offer_excl`, ADD INDEX (`offer_recom`);
ALTER TABLE `cpa_click` ADD `test_id` MEDIUMINT UNSIGNED NOT NULL AFTER `flow_id`, ADD INDEX (`test_id`);
ALTER TABLE `cpa_order` ADD `test_id` MEDIUMINT UNSIGNED NOT NULL AFTER `flow_id`, ADD INDEX (`test_id`);
ALTER TABLE `cpa_flow` ADD `flow_mtrk` VARCHAR(30) NOT NULL AFTER `flow_pbu`, ADD `flow_utms` VARCHAR(50) NOT NULL AFTER `flow_mtrk`, ADD `flow_utmc` VARCHAR(50) NOT NULL AFTER `flow_utms`, ADD `flow_utmn` VARCHAR(50) NOT NULL AFTER `flow_utmc`, ADD `flow_utmt` VARCHAR(50) NOT NULL AFTER `flow_utmn`, ADD `flow_utmm` VARCHAR(50) NOT NULL AFTER `flow_utmt`;
ALTER TABLE `cpa_click` ADD `ext_uid` INT NOT NULL AFTER `ext_id`;
ALTER TABLE `cpa_click` ADD `click_time` INT UNSIGNED NOT NULL AFTER `click_date`;
ALTER TABLE `cpa_click` ADD INDEX(`click_time`);
CREATE TABLE IF NOT EXISTS `cpa_split` (
  `split_id` mediumint(8) unsigned NOT NULL,
  `user_id` mediumint(8) unsigned NOT NULL,
  `offer_id` smallint(5) unsigned NOT NULL,
  `split_active` tinyint(3) unsigned NOT NULL,
  `split_name` varchar(100) NOT NULL,
  `split_time` int(10) unsigned NOT NULL,
  `split_last` int(10) unsigned NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `cpa_test` (
  `test_id` mediumint(8) unsigned NOT NULL,
  `split_id` mediumint(8) unsigned NOT NULL,
  `flow_id` mediumint(8) unsigned NOT NULL,
  `test_name` varchar(200) NOT NULL,
  `test_url` varchar(250) NOT NULL,
  `test_pos` smallint(5) unsigned NOT NULL,
  `test_geo` varchar(100) NOT NULL,
  `test_mobile` tinyint(3) unsigned NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
ALTER TABLE `cpa_split` ADD PRIMARY KEY (`split_id`), ADD KEY `user_id` (`user_id`), ADD KEY `split_active` (`split_active`), ADD KEY `split_last` (`split_last`);
ALTER TABLE `cpa_test` ADD PRIMARY KEY (`test_id`), ADD KEY `split_id` (`split_id`);
ALTER TABLE `cpa_split` MODIFY `split_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT;
ALTER TABLE `cpa_test` MODIFY `test_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT;
ALTER TABLE `cpa_test` ADD `test_nogeo` VARCHAR(100) NOT NULL AFTER `test_geo`;
ALTER TABLE `cpa_offer` CHANGE `offer_id` `offer_id` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT;
ALTER TABLE `cpa_order` CHANGE `offer_id` `offer_id` SMALLINT UNSIGNED NOT NULL;
ALTER TABLE `cpa_cash` CHANGE `user_id` `user_id` MEDIUMINT UNSIGNED NOT NULL;
ALTER TABLE `cpa_comp` CHANGE `comp_id` `comp_id` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT;
ALTER TABLE `cpa_ext` CHANGE `ext_id` `ext_id` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT;
ALTER TABLE `cpa_flow` CHANGE `user_id` `user_id` MEDIUMINT UNSIGNED NOT NULL;
ALTER TABLE `cpa_flow` ADD INDEX(`offer_id`);
ALTER TABLE `cpa_offer` CHANGE `offer_id` `offer_id` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT;
ALTER TABLE `cpa_order` CHANGE `offer_id` `offer_id` SMALLINT UNSIGNED NOT NULL, CHANGE `user_id` `user_id` MEDIUMINT UNSIGNED NOT NULL, CHANGE `wm_id` `wm_id` MEDIUMINT UNSIGNED NOT NULL, CHANGE `comp_id` `comp_id` SMALLINT UNSIGNED NOT NULL, CHANGE `cc_id` `cc_id` SMALLINT UNSIGNED NOT NULL, CHANGE `ext_id` `ext_id` SMALLINT UNSIGNED NOT NULL, CHANGE `ext_oid` `ext_oid` VARCHAR(32) NOT NULL;
ALTER TABLE `cpa_stats` CHANGE `user_id` `user_id` MEDIUMINT UNSIGNED NOT NULL;
ALTER TABLE `cpa_team` CHANGE `comp_id` `comp_id` SMALLINT UNSIGNED NOT NULL;
ALTER TABLE `cpa_user` CHANGE `user_id` `user_id` MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT;
# Stats improve 05.04.2017
ALTER TABLE `cpa_click` ADD `user_id` MEDIUMINT UNSIGNED NOT NULL AFTER `click_id`, ADD INDEX (`user_id`);
ALTER TABLE `cpa_stats` ADD `offer_id` SMALLINT UNSIGNED NOT NULL AFTER `stat_id`, ADD INDEX (`offer_id`);
# Integration updates for v 2.1
UPDATE `cpa_comp` SET `int_add_pre` = REPLACE( `int_add_pre`, 'wmsale', 'cpa' );
UPDATE `cpa_comp` SET `int_add_code` = REPLACE( `int_add_code`, 'wmsale', 'cpa' );
UPDATE `cpa_comp` SET `int_acc_pre` = REPLACE( `int_acc_pre`, 'wmsale', 'cpa' );
UPDATE `cpa_comp` SET `int_acc_code` = REPLACE( `int_acc_code`, 'wmsale', 'cpa' );
UPDATE `cpa_comp` SET `int_chk_pre` = REPLACE( `int_chk_pre`, 'wmsale', 'cpa' );
UPDATE `cpa_comp` SET `int_chk_code` = REPLACE( `int_chk_code`, 'wmsale', 'cpa' );
UPDATE `cpa_comp` SET `int_lng_pre` = REPLACE( `int_lng_pre`, 'wmsale', 'cpa' );
UPDATE `cpa_comp` SET `int_lng_code` = REPLACE( `int_lng_code`, 'wmsale', 'cpa' );
# Stats 05.04.2017
UPDATE cpa_click SET user_id = ( SELECT user_id FROM cpa_flow WHERE cpa_flow.flow_id = cpa_click.flow_id LIMIT 1 ) WHERE flow_id != 0;
UPDATE cpa_stats SET user_id = ( SELECT user_id FROM cpa_flow WHERE cpa_stats.flow_id = cpa_flow.flow_id LIMIT 1 ) WHERE user_id = 0 AND flow_id != 0;
UPDATE cpa_stats SET offer_id = ( SELECT offer_id FROM cpa_flow WHERE cpa_stats.flow_id = cpa_flow.flow_id );