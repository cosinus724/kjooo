# Promo codes
ALTER TABLE `cpa_order` ADD `promo_code` BIGINT UNSIGNED NOT NULL AFTER `paid_from`, ADD `promo_status` TINYINT UNSIGNED NOT NULL AFTER `promo_code`, ADD INDEX (`promo_code`), ADD INDEX (`promo_status`);
# Changes for the long-term integration
ALTER TABLE `cpa_comp` ADD `int_lng` TINYINT NOT NULL AFTER `int_chk_code`, ADD `int_lng_url` VARCHAR(200) NOT NULL AFTER `int_lng`, ADD `int_lng_pre` TEXT NOT NULL AFTER `int_lng_url`, ADD `int_lng_field` TEXT NOT NULL AFTER `int_lng_pre`, ADD `int_lng_format` TINYINT UNSIGNED NOT NULL AFTER `int_lng_field`, ADD `int_lng_count` SMALLINT UNSIGNED NOT NULL AFTER `int_lng_format`, ADD `int_lng_code` TEXT NOT NULL AFTER `int_lng_count`, ADD INDEX (`int_lng`);
ALTER TABLE `cpa_order` ADD `ext_check` INT UNSIGNED NOT NULL AFTER `ext_oid`, ADD INDEX (`ext_check`);
# Changes for the good click control
ALTER TABLE `cpa_click` ADD `click_good` TINYINT NOT NULL AFTER `click_space`, ADD INDEX (`click_good`);
ALTER TABLE `cpa_stats` ADD `stat_sgood` INT UNSIGNED NOT NULL AFTER `stat_suni`;
ALTER TABLE `cpa_stats` ADD `stat_good` INT UNSIGNED NOT NULL AFTER `stat_unique`;
# Call-centers
ALTER TABLE `cpa_comp` ADD `comp_type` TINYINT UNSIGNED NOT NULL AFTER `comp_vip`;
ALTER TABLE `cpa_offer` ADD `offer_comps` TEXT NOT NULL AFTER `offer_pars`;
# New pricing table
ALTER TABLE `cpa_offer` CHANGE `offer_wm` `offer_wm` VARCHAR(20) NOT NULL COMMENT 'Отчисления вебмастеру';
ALTER TABLE `cpa_offer` ADD `offer_wmp` SMALLINT UNSIGNED NOT NULL AFTER `offer_wm`;
ALTER TABLE `cpa_order` ADD `order_mobile` TINYINT UNSIGNED NOT NULL AFTER `order_check`, ADD `order_bad` TINYINT UNSIGNED NOT NULL AFTER `order_mobile`;
CREATE TABLE IF NOT EXISTS `cpa_price` (
  `price_id` mediumint(8) unsigned NOT NULL,
  `offer_id` smallint(5) unsigned NOT NULL,
  `price_sort` smallint(5) unsigned NOT NULL,
  `price_name` varchar(100) NOT NULL COMMENT 'Название для вебмастера',
  `price_pub` tinyint(3) unsigned NOT NULL COMMENT 'Виден вебмастеру',
  `price_in` tinyint(3) unsigned NOT NULL COMMENT 'Тип входа (вебмастер, агент)',
  `price_inid` mediumint(8) unsigned NOT NULL COMMENT 'Пользователь на входе',
  `price_out` tinyint(3) unsigned NOT NULL COMMENT 'Тип выхода (компания, колл-центр)',
  `price_outid` mediumint(8) unsigned NOT NULL COMMENT 'Пользователь на выходе',
  `price_mobile` tinyint(3) unsigned NOT NULL COMMENT 'Мобильный трафик',
  `price_promo` tinyint(3) unsigned NOT NULL COMMENT 'Наличие промо-кода',
  `price_geo` varchar(100) NOT NULL COMMENT 'Гео-зоны',
  `price_last` tinyint(3) unsigned NOT NULL,
  `wmset` tinyint(3) unsigned NOT NULL COMMENT 'Установить отчисление по кредиту',
  `wm` smallint(5) unsigned NOT NULL COMMENT 'Отчисление по кредиту',
  `wmup` smallint(5) unsigned NOT NULL COMMENT 'Апсейл по кредиту',
  `wmlim` tinyint(3) unsigned NOT NULL COMMENT 'Лимит апсейла по кредиту',
  `payset` tinyint(3) unsigned NOT NULL COMMENT 'Установить отчисление по дебету',
  `pay` smallint(5) unsigned NOT NULL COMMENT 'Отчисление по дебету',
  `payup` smallint(5) unsigned NOT NULL COMMENT 'Апсейл по дебету',
  `paylim` tinyint(3) unsigned NOT NULL COMMENT 'Лимит апсейла по дебету',
  `parset` tinyint(3) unsigned NOT NULL COMMENT 'Установить отчисление по партнеру',
  `partner` smallint(5) unsigned NOT NULL COMMENT 'Партнёрское отчисление за заказ'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
ALTER TABLE `cpa_price`
  ADD PRIMARY KEY (`price_id`),
  ADD KEY `offer_id` (`offer_id`),
  ADD KEY `price_pub` (`price_pub`),
  ADD KEY `price_sort` (`price_sort`);
ALTER TABLE `cpa_price`
  MODIFY `price_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT;
ALTER TABLE `cpa_price` ADD `price_bad` TINYINT UNSIGNED NOT NULL COMMENT 'Качество трафика' AFTER `price_mobile`;  
ALTER TABLE `cpa_price` ADD `price_deliv` TINYINT UNSIGNED NOT NULL COMMENT 'Доставка' AFTER `price_promo`;
# Offers sorting
ALTER TABLE `cpa_offer` ADD `cat_id` TINYINT UNSIGNED NOT NULL AFTER `offer_id`, ADD `offer_sort` SMALLINT UNSIGNED NOT NULL AFTER `cat_id`, ADD INDEX (`cat_id`), ADD INDEX (`offer_sort`);
# Offer and order prices
ALTER TABLE `cpa_offer` ADD `offer_prtx` TEXT NOT NULL AFTER `offer_info`;
ALTER TABLE `cpa_order` ADD `price_cur` TINYINT UNSIGNED NOT NULL AFTER `order_recall`, ADD `price_base` INT UNSIGNED NOT NULL AFTER `price_cur`, ADD `price_more` INT NOT NULL AFTER `price_base`, ADD `price_delivery` INT UNSIGNED NOT NULL AFTER `price_more`, ADD `price_total` INT UNSIGNED NOT NULL AFTER `price_delivery`;
ALTER TABLE `cpa_vars` CHANGE `var_price` `var_price` TEXT NOT NULL;
ALTER TABLE `cpa_vars` ADD `var_type` TINYINT UNSIGNED NOT NULL AFTER `var_short`, ADD `var_single` TINYINT UNSIGNED NOT NULL AFTER `var_type`;
UPDATE `cpa_order` SET price_total = order_price, price_delivery = 300, price_base = ( order_price - 300 ) / order_count WHERE price_base = 0;
# Home page
ALTER TABLE `cpa_offer` ADD `offer_home` TINYINT UNSIGNED NOT NULL AFTER `offer_active`, ADD INDEX (`offer_home`);
# UTM changes
ALTER TABLE `cpa_click` ADD `utms` VARCHAR(32) NOT NULL AFTER `utm_cn`, ADD `utmc` VARCHAR(32) NOT NULL AFTER `utms`, ADD `utmn` VARCHAR(32) NOT NULL AFTER `utmc`, ADD `utmt` VARCHAR(32) NOT NULL AFTER `utmn`, ADD `utmm` VARCHAR(32) NOT NULL AFTER `utmt`, ADD INDEX (`utms`), ADD INDEX (`utmc`), ADD INDEX (`utmn`), ADD INDEX (`utmt`), ADD INDEX (`utmm`);
ALTER TABLE `cpa_order` ADD `utms` VARCHAR(32) NOT NULL AFTER `utm_cn`, ADD `utmc` VARCHAR(32) NOT NULL AFTER `utms`, ADD `utmn` VARCHAR(32) NOT NULL AFTER `utmc`, ADD `utmt` VARCHAR(32) NOT NULL AFTER `utmn`, ADD `utmm` VARCHAR(32) NOT NULL AFTER `utmt`, ADD INDEX (`utms`), ADD INDEX (`utmc`), ADD INDEX (`utmn`), ADD INDEX (`utmt`), ADD INDEX (`utmm`);
# Tracking
ALTER TABLE `cpa_order` ADD `track_start` INT UNSIGNED NOT NULL AFTER `track_check`;
# Call center
CREATE TABLE IF NOT EXISTS `cpa_call` (
  `call_id` int(10) unsigned NOT NULL,
  `user_id` mediumint(8) unsigned NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  `call_status` tinyint(3) unsigned NOT NULL,
  `call_time` int(10) unsigned NOT NULL,
  `call_next` int(10) unsigned NOT NULL,
  `call_length` smallint(5) unsigned NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
ALTER TABLE `cpa_call` ADD PRIMARY KEY (`call_id`), ADD KEY `user_id` (`user_id`), ADD KEY `order_id` (`order_id`);
ALTER TABLE `cpa_call` MODIFY `call_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
ALTER TABLE `cpa_call` ADD `offer_id` SMALLINT UNSIGNED NOT NULL AFTER `user_id`, ADD INDEX (`offer_id`);
ALTER TABLE `cpa_call` ADD `call_reason` TINYINT UNSIGNED NOT NULL AFTER `call_status`;
# ALTER TABLE cpa_call DROP INDEX call_status;
ALTER TABLE `cpa_user` ADD `user_team` MEDIUMINT UNSIGNED NOT NULL AFTER `user_compad`, ADD `user_teamlead` TINYINT UNSIGNED NOT NULL AFTER `user_team`, ADD INDEX (`user_team`);
ALTER TABLE `cpa_offer` ADD `offer_call` TEXT NOT NULL AFTER `offer_prtx`;
ALTER TABLE `cpa_order` ADD `mark_id` MEDIUMINT UNSIGNED NOT NULL AFTER `promo_status`, ADD `mark_time` INT UNSIGNED NOT NULL AFTER `mark_id`;
ALTER TABLE `cpa_comp` ADD `int_acc` TINYINT(1) NOT NULL AFTER `int_add`, ADD `int_acc_url` VARCHAR(200) NOT NULL AFTER `int_acc`, ADD `int_acc_pre` TEXT NOT NULL AFTER `int_acc_url`, ADD `int_acc_field` TEXT NOT NULL AFTER `int_acc_pre`, ADD `int_acc_code` TEXT NOT NULL AFTER `int_acc_field`, ADD INDEX (`int_acc`);
ALTER TABLE  `cpa_order` ADD INDEX (  `mark_time` ) ;
CREATE TABLE IF NOT EXISTS `cpa_team` (
  `team_id` mediumint(8) unsigned NOT NULL,
  `comp_id` mediumint(8) unsigned NOT NULL,
  `team_name` varchar(50) NOT NULL,
  `team_call` tinyint(3) unsigned NOT NULL,
  `team_pack` tinyint(3) unsigned NOT NULL,
  `team_send` tinyint(3) unsigned NOT NULL,
  `team_delivery` tinyint(3) unsigned NOT NULL,
  `team_mod` tinyint(3) unsigned NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
ALTER TABLE `cpa_team` ADD PRIMARY KEY (`team_id`), ADD KEY `comp_ip` (`comp_id`);
ALTER TABLE `cpa_team` MODIFY `team_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT;
ALTER TABLE `cpa_order` ADD `cc_id` TINYINT UNSIGNED NOT NULL AFTER `comp_id`, ADD INDEX (`cc_id`);
ALTER TABLE `cpa_offer` ADD `offer_excl` TINYINT UNSIGNED NOT NULL AFTER `cat_id`, ADD INDEX (`offer_excl`);
ALTER TABLE `cpa_call` ADD `call_count` SMALLINT UNSIGNED NOT NULL AFTER `call_length`;
ALTER TABLE `cpa_comp` ADD `ccp_day` SMALLINT UNSIGNED NOT NULL AFTER `pay_ymk`, ADD `ccp_night` SMALLINT UNSIGNED NOT NULL AFTER `ccp_day`, ADD `ccp_upsale` VARCHAR(50) NOT NULL AFTER `ccp_night`;
ALTER TABLE `cpa_call` ADD `wm_id` MEDIUMINT UNSIGNED NOT NULL AFTER `user_id`;
ALTER TABLE `cpa_call` ADD `call_accept` TINYINT UNSIGNED NOT NULL AFTER `call_count`, ADD `call_price` MEDIUMINT UNSIGNED NOT NULL AFTER `call_accept`, ADD `call_in` SMALLINT UNSIGNED NOT NULL AFTER `call_price`, ADD `call_out` SMALLINT UNSIGNED NOT NULL AFTER `call_in`, ADD INDEX (`call_accept`);
ALTER TABLE `cpa_call` ADD `comp_id` SMALLINT UNSIGNED NOT NULL AFTER `call_id`;
ALTER TABLE `cpa_call` ADD `cc_id` SMALLINT UNSIGNED NOT NULL AFTER `comp_id`;
ALTER TABLE `cpa_site` ADD `site_name` VARCHAR(100) NOT NULL AFTER `site_url`;
ALTER TABLE `cpa_order` CHANGE  `ext_oid`  `ext_oid` BIGINT UNSIGNED NOT NULL ;
ALTER TABLE  `cpa_call` ADD  `call_cur` TINYINT UNSIGNED NOT NULL AFTER  `call_price`;
CREATE TABLE IF NOT EXISTS `cpa_change` (
  `change_id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  `user_id` mediumint(8) unsigned NOT NULL,
  `change_warn` tinyint(3) unsigned NOT NULL,
  `change_time` int(10) unsigned NOT NULL,
  `change_data` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
ALTER TABLE `cpa_change` ADD PRIMARY KEY (`change_id`), ADD KEY `order_id` (`order_id`),  ADD KEY `change_warn` (`change_warn`);
ALTER TABLE `cpa_change` MODIFY `change_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
# Cleanup
ALTER TABLE `cpa_order` CHANGE `ext_oid` `ext_oid` BIGINT UNSIGNED NOT NULL, CHANGE `ext_check` `ext_check` INT UNSIGNED NOT NULL;
# UTM changes
ALTER TABLE  `cpa_click` CHANGE  `utms`  `utms` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
CHANGE  `utmc`  `utmc` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
CHANGE  `utmn`  `utmn` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
CHANGE  `utmt`  `utmt` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
CHANGE  `utmm`  `utmm` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE  `cpa_order` CHANGE  `utms`  `utms` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
CHANGE  `utmc`  `utmc` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
CHANGE  `utmn`  `utmn` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
CHANGE  `utmt`  `utmt` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
CHANGE  `utmm`  `utmm` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
# Call-Center changes
ALTER TABLE `cpa_offer` ADD  `offer_line` TEXT NOT NULL AFTER  `offer_call`;
ALTER TABLE `cpa_offer` ADD `in_default` MEDIUMINT UNSIGNED NOT NULL AFTER `offer_comps`;
ALTER TABLE `cpa_offer` ADD `in_script` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL AFTER `in_default`;
ALTER TABLE `cpa_offer` ADD `out_default` MEDIUMINT UNSIGNED NOT NULL AFTER `offer_script`, ADD `out_comps` TEXT NOT NULL AFTER `out_default`, ADD `out_script` TEXT NOT NULL AFTER `out_comps`;
ALTER TABLE `cpa_comp` ADD `ccp_sale` SMALLINT UNSIGNED NOT NULL AFTER `ccp_night`;
#ALTER TABLE `cpa_offer` CHANGE `offer_script` `in_script` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
ALTER TABLE `cpa_team` ADD `pay_use` TINYINT UNSIGNED NOT NULL AFTER `team_mod`, ADD `pay_day` SMALLINT UNSIGNED NOT NULL AFTER `pay_use`, ADD `pay_night` SMALLINT UNSIGNED NOT NULL AFTER `pay_day`, ADD `pay_sale` SMALLINT UNSIGNED NOT NULL AFTER `pay_night`, ADD `pay_upsale` VARCHAR(100) NOT NULL AFTER `pay_sale`;
ALTER TABLE `cpa_stats` ADD `stat_stime` INT UNSIGNED NOT NULL AFTER `stat_sgood`;
ALTER TABLE `cpa_stats` ADD `stat_time` INT UNSIGNED NOT NULL AFTER `stat_good`;
# Callcenter
UPDATE cpa_call SET call_accept = 1 WHERE call_count != 0;
UPDATE cpa_call SET offer_id = ( SELECT offer_id FROM cpa_order WHERE cpa_call.order_id = cpa_order.order_id );
UPDATE cpa_call SET wm_id = ( SELECT wm_id FROM cpa_order WHERE cpa_call.order_id = cpa_order.order_id );
UPDATE cpa_call SET comp_id = ( SELECT user_comp FROM cpa_user WHERE cpa_call.user_id = cpa_user.user_id ) WHERE cpa_call.user_id != 0;
UPDATE cpa_call SET comp_id = ( SELECT comp_id FROM cpa_order WHERE cpa_call.order_id = cpa_order.order_id ) WHERE cpa_call.comp_id = 0; 
UPDATE cpa_call SET call_price = ( SELECT price_total FROM cpa_order WHERE cpa_call.order_id = cpa_order.order_id ) WHERE cpa_call.call_accept = 1;
UPDATE cpa_call SET call_in = ( SELECT ABS(SUM( cash_value )) FROM cpa_cash WHERE cash_value < 0 AND cpa_call.order_id = cpa_cash.order_id ) WHERE cpa_call.call_accept = 1;
UPDATE cpa_call SET call_out = ( SELECT SUM( cash_value ) FROM cpa_cash WHERE cash_value > 0 AND cpa_call.order_id = cpa_cash.order_id ) WHERE cpa_call.call_accept = 1;
# Order Cash
UPDATE `cpa_order` SET cash_wm = ( SELECT ABS(cash_value) FROM cpa_cash WHERE cash_type = 3 AND cpa_cash.order_id = cpa_order.order_id LIMIT 1 ) WHERE order_status BETWEEN 6 AND 11;
UPDATE `cpa_order` SET cash_pay = ( SELECT ABS(cash_value) FROM cpa_cash WHERE cash_type = 2 AND cpa_cash.order_id = cpa_order.order_id LIMIT 1 ) WHERE order_status BETWEEN 6 AND 11;
# v 2.0
ALTER TABLE `cpa_comp` DROP `int_add_plain`, DROP `int_chk_plain`;
ALTER TABLE `cpa_offer` DROP `offer_wm_vip`, DROP `offer_wm_ext`, DROP `offer_wmu`, DROP `offer_wmu_vip`, DROP `offer_wmu_ext`, DROP `offer_pay`, DROP `offer_pay_vip`, DROP `offer_pay_ext`, DROP `offer_pyu`, DROP `offer_pyu_vip`, DROP `offer_pyu_ext`, DROP `offer_ref`, DROP `offer_ref_vip`;
ALTER TABLE `cpa_order` DROP `track_spsr`, DROP `track_inspsr`, DROP `order_phone_ok`, DROP `order_present`;
DROP TABLE cpa_bl;
DROP TABLE `cpa_target`;
ALTER TABLE `cpa_click` DROP `target_id`;
ALTER TABLE `cpa_order` DROP `target_id`;
ALTER TABLE `cpa_click` DROP `utm_id`, DROP `utm_src`, DROP `utm_cn`;
ALTER TABLE `cpa_order` DROP `utm_id`, DROP `utm_src`, DROP `utm_cn`;
ALTER TABLE `cpa_offer` DROP `offer_price`, DROP `offer_wm`, DROP `offer_wmp`, DROP `offer_mr`, DROP `offer_mrt`, DROP `offer_comps`;
ALTER TABLE `cpa_stats` DROP `count_accept`, DROP `count_cancel`, DROP `sum_accept`, DROP `sum_cancel`;