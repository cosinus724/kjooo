# 16.01.18 - Click ID in the order
ALTER TABLE `cpa_order` ADD `click_id` INT UNSIGNED NOT NULL DEFAULT '0' AFTER `space_id`, ADD INDEX (`click_id`);
# 23.01.18 - Parked domains in split tests
ALTER TABLE `cpa_split` ADD `domain_id` MEDIUMINT UNSIGNED NOT NULL AFTER `offer_id`;
ALTER TABLE `cpa_flow` ADD `domain_id` MEDIUMINT UNSIGNED NOT NULL AFTER `user_id`;
# 01.02.18 - Taxes in order price
ALTER TABLE `cpa_order` CHANGE `order_discount` `order_discount` TINYINT NOT NULL DEFAULT '0';
# 04.02.18 - News categories
ALTER TABLE `cpa_news` ADD `offer_id` SMALLINT UNSIGNED NOT NULL DEFAULT '0' AFTER `news_id`, ADD `news_cat` TINYINT UNSIGNED NOT NULL DEFAULT '1' AFTER `offer_id`, ADD INDEX (`offer_id`), ADD INDEX (`news_cat`);