<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

/*******************************************************************************
 *
 * 	AlterVision Core Framework - CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright (c) 2005-2015 Anton Reznichenko
 *
 *
 *  File: 			test.php
 *  Description:	Crontab Processing
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *
 *******************************************************************************/
// Loading Site Core
error_reporting(0);
define('IN_ALTERCMS_CORE_ONE', true);
define('INTHEWORK', true);
define('PATH', realpath(dirname(__FILE__) . '/../') . '/');
require_once PATH . 'core/start.php';
require_once PATH_MODS . 'order-cash.php';
$core->db->query("UPDATE " . DB_ORDER . " SET cash_wm = ( SELECT ABS(cash_value) FROM " . DB_CASH . " WHERE cash_type = 3 AND " . DB_CASH . ".order_id = " . DB_ORDER . ".order_id LIMIT 1 ) WHERE order_status BETWEEN 6 AND 11");
$core->db->query("UPDATE " . DB_ORDER . " SET cash_pay = ( SELECT ABS(cash_value) FROM " . DB_CASH . " WHERE cash_type = 2 AND " . DB_CASH . ".order_id = " . DB_ORDER . ".order_id LIMIT 1 ) WHERE order_status BETWEEN 6 AND 11");
$ids = $core->db->col("SELECT order_id FROM " . DB_ORDER . " WHERE cash_wm = 0 AND cash_pay = 0");
foreach ($ids as $i) {
    $o = $core->db->row("SELECT * FROM " . DB_ORDER . " WHERE order_id = '{$i}' LIMIT 1");
    $m = order_cash($core, $o);
    $core->db->edit(DB_ORDER, array('cash_wm' => $m['wmp'], 'cash_pay' => $m['pay']), array('order_id' => $i));
    unset($o, $m);
}

?>