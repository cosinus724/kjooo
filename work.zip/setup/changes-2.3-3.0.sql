# 30.09.2017 - GEO stats
ALTER TABLE `cpa_click` ADD INDEX(`click_geo`);
ALTER TABLE `cpa_order` ADD INDEX(`order_country`);
# 02.10.2017 - GEO analytics
ALTER TABLE `cpa_call` ADD `call_geo` CHAR(2) NOT NULL AFTER `call_cur`, ADD INDEX (`call_geo`);
UPDATE `cpa_call` SET call_geo = ( SELECT order_country FROM cpa_order WHERE cpa_order.order_id = cpa_call.order_id );
ALTER TABLE `cpa_call`  ADD `call_delivery` TINYINT UNSIGNED NOT NULL  AFTER `call_price`,  ADD   INDEX  (`call_delivery`);
UPDATE `cpa_call` SET call_delivery = ( SELECT order_delivery FROM cpa_order WHERE cpa_order.order_id = cpa_call.order_id );
# 02.10.2017 - Flows
ALTER TABLE `cpa_flow` ADD `flow_fb` VARCHAR(100) NOT NULL AFTER `flow_mtrk`, ADD `flow_vk` VARCHAR(100) NOT NULL AFTER `flow_fb`, ADD `flow_ga` VARCHAR(100) NOT NULL AFTER `flow_vk`;
# 03.10.2017 - Payments
ALTER TABLE `cpa_cash` ADD `cash_uid` VARCHAR(32) NOT NULL AFTER `cash_time`, ADD INDEX (`cash_uid`);
# 15.10.2017 - Company blocking
ALTER TABLE `cpa_comp` ADD `comp_block` INT NOT NULL AFTER `comp_name`;
# 19.10.2017 - Extending orders
ALTER TABLE `cpa_order` ADD `order_email` VARCHAR(100) NOT NULL AFTER `order_phone`, ADD `order_pin` MEDIUMINT UNSIGNED NOT NULL AFTER `order_email`;