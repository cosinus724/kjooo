# 07.03.2018 - Configuration table
CREATE TABLE IF NOT EXISTS `cpa_config` (
  `name` varchar(20) NOT NULL,
  `value` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
ALTER TABLE `cpa_config` ADD PRIMARY KEY (`name`);
# 10.03.2018 - Sessions table
CREATE TABLE IF NOT EXISTS `cpa_sess` (
  `sess_id` int(10) unsigned NOT NULL,
  `user_id` mediumint(8) unsigned NOT NULL,
  `sess_uid` char(32) NOT NULL,
  `sess_date` mediumint(8) unsigned NOT NULL,
  `sess_time` int(10) unsigned NOT NULL,
  `sess_ip` int(10) unsigned NOT NULL,
  `sess_ua` text NOT NULL,
  `sess_data` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
ALTER TABLE `cpa_sess` ADD PRIMARY KEY (`sess_id`), ADD UNIQUE KEY `sess_uid` (`sess_uid`), ADD KEY `user_id` (`user_id`), ADD KEY `sess_date` (`sess_date`);
ALTER TABLE `cpa_sess` MODIFY `sess_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
# 10.03.2018 - checking the DB default fields
ALTER TABLE `cpa_order` ADD INDEX(`order_reason`);
ALTER TABLE `cpa_user` CHANGE `user_work` `user_work` TINYINT(4) NOT NULL DEFAULT '0';
ALTER TABLE `cpa_user` CHANGE `user_meta` `user_meta` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '';
ALTER TABLE `cpa_click` CHANGE `click_id` `click_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, CHANGE `user_id` `user_id` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0', CHANGE `offer_id` `offer_id` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0', CHANGE `flow_id` `flow_id` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0', CHANGE `test_id` `test_id` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0', CHANGE `site_id` `site_id` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0', CHANGE `site_sib` `site_sib` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0', CHANGE `ext_id` `ext_id` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0', CHANGE `ext_uid` `ext_uid` INT(11) NOT NULL DEFAULT '0', CHANGE `ext_src` `ext_src` INT(11) NOT NULL DEFAULT '0', CHANGE `click_ip` `click_ip` INT(10) UNSIGNED NOT NULL DEFAULT '0', CHANGE `click_geo` `click_geo` CHAR(2) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'zz', CHANGE `click_date` `click_date` INT(10) UNSIGNED NOT NULL DEFAULT '0', CHANGE `click_time` `click_time` INT(10) UNSIGNED NOT NULL DEFAULT '0', CHANGE `click_hour` `click_hour` TINYINT(3) UNSIGNED NOT NULL DEFAULT '0', CHANGE `click_unique` `click_unique` TINYINT(1) NOT NULL DEFAULT '0', CHANGE `click_space` `click_space` TINYINT(1) NOT NULL DEFAULT '0', CHANGE `click_good` `click_good` TINYINT(4) UNSIGNED NOT NULL DEFAULT '0', CHANGE `utms` `utms` VARCHAR(250) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '', CHANGE `utmc` `utmc` VARCHAR(250) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '', CHANGE `utmn` `utmn` VARCHAR(250) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '', CHANGE `utmt` `utmt` VARCHAR(250) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '', CHANGE `utmm` `utmm` VARCHAR(250) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '', CHANGE `utms32` `utms32` INT(10) UNSIGNED NOT NULL DEFAULT '0', CHANGE `utmc32` `utmc32` INT(10) UNSIGNED NOT NULL DEFAULT '0', CHANGE `utmn32` `utmn32` INT(10) UNSIGNED NOT NULL DEFAULT '0', CHANGE `utmt32` `utmt32` INT(10) UNSIGNED NOT NULL DEFAULT '0', CHANGE `utmm32` `utmm32` INT(10) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE `cpa_comp` CHANGE `comp_name` `comp_name` VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '', CHANGE `comp_block` `comp_block` INT(11) NOT NULL DEFAULT '0', CHANGE `comp_config` `comp_config` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '';
# 10.03.2018 - Payment improvements
ALTER TABLE `cpa_price` ADD `price_eid` INT NOT NULL DEFAULT '0' AFTER `price_geo`;
ALTER TABLE `cpa_price` ADD `wmper` FLOAT UNSIGNED NOT NULL  DEFAULT '0' AFTER `wm`;
ALTER TABLE `cpa_price` ADD `payper` FLOAT UNSIGNED NOT NULL DEFAULT '0' AFTER `pay`;
ALTER TABLE `cpa_price` ADD `partper` FLOAT UNSIGNED NOT NULL DEFAULT '0' AFTER `partner`;
# 11.03.2018 - Phone database 
TRUNCATE TABLE `cpa_pdb`;
ALTER TABLE `cpa_pdb` ADD `country` CHAR(2) NOT NULL DEFAULT 'zz' AFTER `phone`;
# 11.03.2018 - Offer statistics
ALTER TABLE `cpa_offer` ADD `offer_approve` FLOAT UNSIGNED NOT NULL DEFAULT '0' AFTER `offer_epc`;
ALTER TABLE `cpa_offer` ADD `stat_next` INT UNSIGNED NOT NULL DEFAULT '0' AFTER `offer_paramurl`, ADD `stat_info` TEXT NOT NULL DEFAULT '' AFTER `stat_next`, ADD INDEX (`stat_next`);
ALTER TABLE `cpa_order` ADD INDEX(`site_id`);
# 12.03.2018 - Site and flow approve
ALTER TABLE `cpa_site` ADD `site_approve` FLOAT UNSIGNED NOT NULL DEFAULT '0' AFTER `site_default`;
ALTER TABLE `cpa_price` CHANGE `price_eid` `price_wmid` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT 'Список вебмастеров';
ALTER TABLE `cpa_price` CHANGE `wmper` `wmper` DECIMAL(4,2) UNSIGNED NOT NULL DEFAULT '0', CHANGE `payper` `payper` DECIMAL(4,2) UNSIGNED NOT NULL DEFAULT '0', CHANGE `partper` `partper` DECIMAL(4,2) UNSIGNED NOT NULL DEFAULT '0';
UPDATE `cpa_price` SET `price_wmid` = '';