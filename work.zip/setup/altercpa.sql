-- phpMyAdmin SQL Dump
-- version 4.4.15
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Май 20 2018 г., 10:48
-- Версия сервера: 5.5.59
-- Версия PHP: 7.1.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `altercpa`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_ban_ip`
--

CREATE TABLE IF NOT EXISTS `cpa_ban_ip` (
  `ip` int(11) unsigned NOT NULL,
  `times` smallint(5) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_ban_phone`
--

CREATE TABLE IF NOT EXISTS `cpa_ban_phone` (
  `id` int(10) unsigned NOT NULL,
  `phone` char(15) NOT NULL,
  `times` smallint(5) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_call`
--

CREATE TABLE IF NOT EXISTS `cpa_call` (
  `call_id` int(10) unsigned NOT NULL,
  `comp_id` smallint(5) unsigned NOT NULL,
  `cc_id` smallint(5) unsigned NOT NULL,
  `user_id` mediumint(8) unsigned NOT NULL,
  `wm_id` mediumint(8) unsigned NOT NULL,
  `offer_id` smallint(5) unsigned NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  `call_status` tinyint(3) unsigned NOT NULL,
  `call_reason` tinyint(3) unsigned NOT NULL,
  `call_time` int(10) unsigned NOT NULL,
  `call_next` int(10) unsigned NOT NULL,
  `call_length` smallint(5) unsigned NOT NULL,
  `call_count` smallint(5) unsigned NOT NULL,
  `call_accept` tinyint(3) unsigned NOT NULL,
  `call_price` decimal(14,2) unsigned NOT NULL,
  `call_delivery` tinyint(3) unsigned NOT NULL,
  `call_cur` tinyint(3) unsigned NOT NULL,
  `call_geo` char(2) NOT NULL,
  `call_in` decimal(11,2) unsigned NOT NULL,
  `call_out` decimal(11,2) unsigned NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_cash`
--

CREATE TABLE IF NOT EXISTS `cpa_cash` (
  `cash_id` mediumint(8) unsigned NOT NULL,
  `user_id` mediumint(8) unsigned NOT NULL,
  `order_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cash_type` tinyint(3) unsigned NOT NULL,
  `cash_value` decimal(14,2) NOT NULL,
  `cash_descr` text NOT NULL,
  `cash_time` int(10) unsigned NOT NULL,
  `cash_uid` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_change`
--

CREATE TABLE IF NOT EXISTS `cpa_change` (
  `change_id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  `user_id` mediumint(8) unsigned NOT NULL,
  `change_warn` tinyint(3) unsigned NOT NULL,
  `change_time` int(10) unsigned NOT NULL,
  `change_data` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_click`
--

CREATE TABLE IF NOT EXISTS `cpa_click` (
  `click_id` int(10) unsigned NOT NULL,
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `offer_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `flow_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `test_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `site_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `site_sib` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ext_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ext_uid` int(11) NOT NULL DEFAULT '0',
  `ext_src` int(11) NOT NULL DEFAULT '0',
  `click_ip` int(10) unsigned NOT NULL DEFAULT '0',
  `click_geo` char(2) NOT NULL DEFAULT 'zz',
  `click_date` int(10) unsigned NOT NULL DEFAULT '0',
  `click_time` int(10) unsigned NOT NULL DEFAULT '0',
  `click_hour` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `click_unique` tinyint(1) NOT NULL DEFAULT '0',
  `click_space` tinyint(1) NOT NULL DEFAULT '0',
  `click_good` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `utms` varchar(250) NOT NULL DEFAULT '',
  `utmc` varchar(250) NOT NULL DEFAULT '',
  `utmn` varchar(250) NOT NULL DEFAULT '',
  `utmt` varchar(250) NOT NULL DEFAULT '',
  `utmm` varchar(250) NOT NULL DEFAULT '',
  `utms32` int(10) unsigned NOT NULL DEFAULT '0',
  `utmc32` int(10) unsigned NOT NULL DEFAULT '0',
  `utmn32` int(10) unsigned NOT NULL DEFAULT '0',
  `utmt32` int(10) unsigned NOT NULL DEFAULT '0',
  `utmm32` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_comp`
--

CREATE TABLE IF NOT EXISTS `cpa_comp` (
  `comp_id` smallint(5) unsigned NOT NULL,
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `comp_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `comp_name` varchar(100) NOT NULL DEFAULT '',
  `comp_block` int(11) NOT NULL DEFAULT '0',
  `comp_config` text NOT NULL,
  `sms_accept` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sms_post` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `autoaccept` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `callscheme` text NOT NULL,
  `int_add` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `int_acc` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `int_acc_url` text NOT NULL,
  `int_acc_pre` text NOT NULL,
  `int_acc_field` text NOT NULL,
  `int_acc_code` text NOT NULL,
  `int_dlv` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `int_dlv_url` text NOT NULL,
  `int_dlv_pre` text NOT NULL,
  `int_dlv_field` text NOT NULL,
  `int_dlv_code` text NOT NULL,
  `int_add_url` text NOT NULL,
  `int_add_pre` text NOT NULL,
  `int_add_field` text NOT NULL,
  `int_add_code` text NOT NULL,
  `int_chk` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `int_chk_url` text NOT NULL,
  `int_chk_pre` text NOT NULL,
  `int_chk_field` text NOT NULL,
  `int_chk_format` smallint(5) unsigned NOT NULL DEFAULT '1',
  `int_chk_count` tinyint(3) unsigned NOT NULL DEFAULT '20',
  `int_chk_code` text NOT NULL,
  `int_lng` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `int_lng_url` text NOT NULL,
  `int_lng_pre` text NOT NULL,
  `int_lng_field` text NOT NULL,
  `int_lng_format` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `int_lng_count` smallint(5) unsigned NOT NULL DEFAULT '20',
  `int_lng_code` text NOT NULL,
  `int_dlc` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `int_dlc_url` text NOT NULL,
  `int_dlc_pre` text NOT NULL,
  `int_dlc_field` text NOT NULL,
  `int_dlc_format` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `int_dlc_count` smallint(5) unsigned NOT NULL DEFAULT '20',
  `int_dlc_code` text NOT NULL,
  `pay_info` text NOT NULL,
  `pay_wmr` varchar(13) NOT NULL DEFAULT '',
  `pay_wmk` varchar(32) NOT NULL DEFAULT '',
  `pay_ymr` varchar(20) NOT NULL DEFAULT '',
  `pay_ymk` varchar(32) NOT NULL DEFAULT '',
  `ccp_day` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ccp_night` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ccp_sale` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ccp_upsale` varchar(100) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_config`
--

CREATE TABLE IF NOT EXISTS `cpa_config` (
  `name` varchar(20) NOT NULL,
  `value` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_domain`
--

CREATE TABLE IF NOT EXISTS `cpa_domain` (
  `dom_id` mediumint(8) unsigned NOT NULL,
  `user_id` mediumint(8) unsigned NOT NULL,
  `dom_url` varchar(200) NOT NULL,
  `dom_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_ext`
--

CREATE TABLE IF NOT EXISTS `cpa_ext` (
  `ext_id` smallint(5) unsigned NOT NULL,
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ext_name` varchar(50) NOT NULL,
  `url_new` text NOT NULL,
  `url_nc` text NOT NULL,
  `url_rc` text NOT NULL,
  `url_acc` text NOT NULL,
  `url_dec` text NOT NULL,
  `url_pay` text NOT NULL,
  `url_ret` text NOT NULL,
  `url_del` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_flow`
--

CREATE TABLE IF NOT EXISTS `cpa_flow` (
  `flow_id` mediumint(8) unsigned NOT NULL,
  `offer_id` smallint(5) unsigned NOT NULL,
  `user_id` mediumint(8) unsigned NOT NULL,
  `domain_id` mediumint(8) unsigned NOT NULL,
  `flow_name` varchar(100) NOT NULL,
  `flow_convert` decimal(5,2) NOT NULL,
  `flow_epc` decimal(10,2) NOT NULL,
  `flow_total` decimal(14,2) unsigned NOT NULL,
  `flow_site` smallint(5) unsigned NOT NULL,
  `flow_space` smallint(5) unsigned NOT NULL,
  `flow_cb` tinyint(3) unsigned NOT NULL,
  `flow_param` tinyint(3) unsigned NOT NULL,
  `flow_url` varchar(250) NOT NULL,
  `flow_pbu` varchar(250) NOT NULL,
  `flow_mtrk` varchar(30) NOT NULL,
  `flow_fb` varchar(100) NOT NULL,
  `flow_vk` varchar(100) NOT NULL,
  `flow_ga` varchar(100) NOT NULL,
  `flow_utms` varchar(50) NOT NULL,
  `flow_utmc` varchar(50) NOT NULL,
  `flow_utmn` varchar(50) NOT NULL,
  `flow_utmt` varchar(50) NOT NULL,
  `flow_utmm` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_geocity`
--

CREATE TABLE IF NOT EXISTS `cpa_geocity` (
  `id` smallint(5) unsigned NOT NULL,
  `city` varchar(100) NOT NULL,
  `region` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_geoip`
--

CREATE TABLE IF NOT EXISTS `cpa_geoip` (
  `ip` int(10) unsigned NOT NULL,
  `last` int(10) unsigned NOT NULL,
  `country` char(2) NOT NULL,
  `city` smallint(5) unsigned NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_geowork`
--

CREATE TABLE IF NOT EXISTS `cpa_geowork` (
  `ip` int(10) unsigned NOT NULL,
  `last` int(10) unsigned NOT NULL,
  `country` char(2) NOT NULL,
  `city` smallint(5) unsigned NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_inlog`
--

CREATE TABLE IF NOT EXISTS `cpa_inlog` (
  `log_id` int(10) unsigned NOT NULL,
  `comp_id` smallint(5) unsigned NOT NULL,
  `order_id` mediumint(8) unsigned NOT NULL,
  `log_type` tinyint(3) unsigned NOT NULL,
  `log_time` int(10) unsigned NOT NULL,
  `log_url` text NOT NULL,
  `log_post` text NOT NULL,
  `log_reply` text NOT NULL,
  `log_result` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_load`
--

CREATE TABLE IF NOT EXISTS `cpa_load` (
  `load_id` mediumint(8) unsigned NOT NULL,
  `offer_id` smallint(5) unsigned NOT NULL,
  `site_id` smallint(5) unsigned NOT NULL,
  `load_status` tinyint(3) unsigned NOT NULL,
  `load_type` tinyint(3) unsigned NOT NULL,
  `load_url` varchar(250) NOT NULL,
  `load_site` varchar(100) NOT NULL,
  `load_clean` text NOT NULL,
  `load_add` int(10) unsigned NOT NULL,
  `load_last` int(10) unsigned NOT NULL,
  `load_mark` smallint(5) unsigned NOT NULL,
  `load_meta` text NOT NULL,
  `load_proxy` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_news`
--

CREATE TABLE IF NOT EXISTS `cpa_news` (
  `news_id` int(10) unsigned NOT NULL,
  `offer_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `news_cat` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `news_time` int(10) unsigned NOT NULL,
  `news_title` varchar(100) NOT NULL,
  `news_text` text NOT NULL,
  `news_group` tinyint(3) unsigned NOT NULL,
  `news_vip` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_offer`
--

CREATE TABLE IF NOT EXISTS `cpa_offer` (
  `offer_id` smallint(5) unsigned NOT NULL,
  `cat_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `cat_sub` tinyint(3) unsigned NOT NULL,
  `offer_excl` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `offer_recom` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `offer_sort` smallint(5) unsigned NOT NULL DEFAULT '0',
  `offer_active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `offer_block` tinyint(3) unsigned NOT NULL,
  `offer_private` tinyint(3) unsigned NOT NULL,
  `offer_wl` text NOT NULL,
  `offer_bl` text NOT NULL,
  `offer_home` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `offer_name` varchar(100) NOT NULL DEFAULT '',
  `offer_descr` text NOT NULL,
  `offer_country` text NOT NULL,
  `offer_text` text NOT NULL,
  `offer_info` text NOT NULL,
  `offer_call` text NOT NULL,
  `offer_line` text NOT NULL,
  `offer_vars` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `offer_delivery` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `offer_hold` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `offer_convert` decimal(5,2) unsigned NOT NULL DEFAULT '0.00',
  `offer_epc` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `offer_approve` decimal(5,2) unsigned NOT NULL DEFAULT '0.00',
  `offer_prt` text NOT NULL,
  `offer_pars` text NOT NULL,
  `in_default` smallint(5) unsigned NOT NULL DEFAULT '0',
  `in_script` text NOT NULL,
  `out_default` smallint(5) unsigned NOT NULL DEFAULT '0',
  `out_comps` text NOT NULL,
  `out_script` text NOT NULL,
  `bad_script` text NOT NULL,
  `offer_payment` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Оплата: 0 - нельзя, 1 - обязательно, 2 - можно',
  `offer_paramurl` text NOT NULL COMMENT 'URL парсинга параметров',
  `stat_next` int(10) unsigned NOT NULL DEFAULT '0',
  `stat_info` text NOT NULL,
  `stat_m` decimal(5,2) unsigned NOT NULL DEFAULT '0.00',
  `stat_f` decimal(5,2) unsigned NOT NULL DEFAULT '0.00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_order`
--

CREATE TABLE IF NOT EXISTS `cpa_order` (
  `order_id` mediumint(8) unsigned NOT NULL,
  `offer_id` smallint(5) unsigned NOT NULL,
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `wm_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `comp_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `cc_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `flow_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `test_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `site_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `space_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `click_id` int(10) unsigned NOT NULL DEFAULT '0',
  `utms` varchar(250) NOT NULL DEFAULT '',
  `utmc` varchar(250) NOT NULL DEFAULT '',
  `utmn` varchar(250) NOT NULL DEFAULT '',
  `utmt` varchar(250) NOT NULL DEFAULT '',
  `utmm` varchar(250) NOT NULL DEFAULT '',
  `utms32` int(10) unsigned NOT NULL DEFAULT '0',
  `utmc32` int(10) unsigned NOT NULL DEFAULT '0',
  `utmn32` int(10) unsigned NOT NULL DEFAULT '0',
  `utmt32` int(10) unsigned NOT NULL DEFAULT '0',
  `utmm32` int(10) unsigned NOT NULL DEFAULT '0',
  `ext_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ext_uid` varchar(128) NOT NULL DEFAULT '',
  `ext_src` int(10) unsigned NOT NULL DEFAULT '0',
  `ext_oid` varchar(32) NOT NULL DEFAULT '',
  `ext_check` int(10) unsigned NOT NULL DEFAULT '0',
  `ext_dlid` varchar(32) NOT NULL DEFAULT '',
  `ext_track` int(10) unsigned NOT NULL DEFAULT '0',
  `order_status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `order_webstat` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `order_stage` smallint(5) unsigned NOT NULL DEFAULT '0',
  `order_reason` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `order_time` int(10) unsigned NOT NULL DEFAULT '0',
  `order_auto` int(10) unsigned NOT NULL DEFAULT '0',
  `order_check` tinyint(1) NOT NULL DEFAULT '0',
  `order_mobile` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `order_bad` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `order_shave` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `order_ip` int(11) unsigned NOT NULL DEFAULT '0',
  `order_country` char(2) NOT NULL DEFAULT 'ru',
  `order_name` varchar(100) NOT NULL DEFAULT '',
  `order_gender` tinyint(1) NOT NULL DEFAULT '0',
  `order_phone` bigint(20) NOT NULL DEFAULT '0',
  `order_email` varchar(100) NOT NULL DEFAULT '',
  `order_pin` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `order_index` char(6) NOT NULL DEFAULT '',
  `order_addr` varchar(200) NOT NULL DEFAULT '',
  `order_area` varchar(100) NOT NULL DEFAULT '',
  `order_city` varchar(100) NOT NULL DEFAULT '',
  `order_street` varchar(100) NOT NULL DEFAULT '',
  `order_count` smallint(5) unsigned NOT NULL DEFAULT '0',
  `order_items` text NOT NULL,
  `order_meta` text NOT NULL,
  `order_ua` text NOT NULL,
  `order_file` varchar(100) NOT NULL DEFAULT '',
  `order_comment` text NOT NULL,
  `order_discount` tinyint(4) NOT NULL DEFAULT '0',
  `order_delivery` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `order_calls` smallint(5) unsigned NOT NULL DEFAULT '0',
  `order_recall` int(10) unsigned NOT NULL DEFAULT '0',
  `price_cur` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `price_base` decimal(11,2) unsigned NOT NULL DEFAULT '0.00',
  `price_more` decimal(11,2) NOT NULL DEFAULT '0.00',
  `price_delivery` decimal(11,2) unsigned NOT NULL DEFAULT '0.00',
  `price_total` decimal(11,2) unsigned NOT NULL DEFAULT '0.00',
  `cash_wm` decimal(11,2) NOT NULL DEFAULT '0.00',
  `cash_pay` decimal(11,2) NOT NULL DEFAULT '0.00',
  `cash_etc` decimal(11,2) NOT NULL DEFAULT '0.00',
  `track_code` varchar(25) NOT NULL DEFAULT '',
  `track_on` tinyint(1) NOT NULL DEFAULT '0',
  `track_check` int(10) unsigned NOT NULL DEFAULT '0',
  `track_date` int(10) unsigned NOT NULL DEFAULT '0',
  `track_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `track_notify` tinyint(1) NOT NULL DEFAULT '0',
  `track_warn` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `geoip_country` char(2) NOT NULL DEFAULT 'ru',
  `geoip_city` varchar(100) NOT NULL DEFAULT '',
  `geoip_region` varchar(100) NOT NULL DEFAULT '',
  `geoip_district` varchar(200) NOT NULL DEFAULT '',
  `paid_ok` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `paid_time` int(10) unsigned NOT NULL DEFAULT '0',
  `paid_from` text NOT NULL,
  `promo_code` bigint(20) unsigned NOT NULL DEFAULT '0',
  `promo_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `mark_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mark_time` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_pdb`
--

CREATE TABLE IF NOT EXISTS `cpa_pdb` (
  `phone` mediumint(8) unsigned NOT NULL,
  `operator` varchar(100) NOT NULL,
  `country` char(2) NOT NULL DEFAULT 'zz',
  `region` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_price`
--

CREATE TABLE IF NOT EXISTS `cpa_price` (
  `price_id` mediumint(8) unsigned NOT NULL,
  `offer_id` smallint(5) unsigned NOT NULL,
  `price_sort` smallint(5) unsigned NOT NULL DEFAULT '0',
  `price_name` varchar(100) NOT NULL DEFAULT '' COMMENT 'Название для вебмастера',
  `price_pub` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Виден вебмастеру',
  `price_in` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Тип входа (вебмастер, агент)',
  `price_inid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'Пользователь на входе',
  `price_out` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Тип выхода (компания, колл-центр)',
  `price_outid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'Пользователь на выходе',
  `price_mobile` tinyint(3) unsigned NOT NULL COMMENT 'Мобильный трафик',
  `price_bad` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Качество трафика',
  `price_promo` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Наличие промо-кода',
  `price_deliv` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Доставка',
  `price_geo` varchar(100) NOT NULL DEFAULT '' COMMENT 'Гео-зоны',
  `price_wmid` text NOT NULL COMMENT 'Список вебмастеров',
  `price_last` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `price_cur` char(3) NOT NULL,
  `wmset` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Установить отчисление по кредиту',
  `wm` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT 'Отчисление по кредиту',
  `wmper` decimal(5,2) unsigned NOT NULL DEFAULT '0.00',
  `wmup` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT 'Апсейл по кредиту',
  `wmlim` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Лимит апсейла по кредиту',
  `payset` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Установить отчисление по дебету',
  `pay` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT 'Отчисление по дебету',
  `payper` decimal(5,2) unsigned NOT NULL DEFAULT '0.00',
  `payup` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT 'Апсейл по дебету',
  `paylim` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Лимит апсейла по дебету',
  `parset` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Установить отчисление по партнеру',
  `partner` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT 'Партнёрское отчисление за заказ',
  `partper` decimal(5,2) unsigned NOT NULL DEFAULT '0.00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_promo`
--

CREATE TABLE IF NOT EXISTS `cpa_promo` (
  `id` bigint(20) unsigned NOT NULL,
  `pass` mediumint(9) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_sess`
--

CREATE TABLE IF NOT EXISTS `cpa_sess` (
  `sess_id` int(10) unsigned NOT NULL,
  `user_id` mediumint(8) unsigned NOT NULL,
  `sess_uid` char(32) NOT NULL,
  `sess_date` mediumint(8) unsigned NOT NULL,
  `sess_time` int(10) unsigned NOT NULL,
  `sess_ip` int(10) unsigned NOT NULL,
  `sess_ua` text NOT NULL,
  `sess_data` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_site`
--

CREATE TABLE IF NOT EXISTS `cpa_site` (
  `site_id` smallint(5) unsigned NOT NULL,
  `offer_id` smallint(5) unsigned NOT NULL,
  `comp_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `site_url` varchar(100) NOT NULL,
  `site_name` varchar(100) NOT NULL DEFAULT '',
  `site_type` tinyint(1) NOT NULL DEFAULT '0',
  `site_key` varchar(32) NOT NULL DEFAULT '',
  `site_mobile` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `site_default` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `site_approve` decimal(5,2) unsigned NOT NULL DEFAULT '0.00',
  `site_convert` decimal(5,2) unsigned NOT NULL DEFAULT '0.00',
  `site_epc` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `site_comp` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_split`
--

CREATE TABLE IF NOT EXISTS `cpa_split` (
  `split_id` mediumint(8) unsigned NOT NULL,
  `user_id` mediumint(8) unsigned NOT NULL,
  `offer_id` smallint(5) unsigned NOT NULL,
  `domain_id` mediumint(8) unsigned NOT NULL,
  `split_active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `split_name` varchar(100) NOT NULL DEFAULT '',
  `split_time` int(10) unsigned NOT NULL DEFAULT '0',
  `split_last` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_stage`
--

CREATE TABLE IF NOT EXISTS `cpa_stage` (
  `stage_id` smallint(5) unsigned NOT NULL,
  `comp_id` smallint(5) unsigned NOT NULL,
  `stage_slug` varchar(50) NOT NULL,
  `stage_name` varchar(50) NOT NULL,
  `stage_group` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `stage_auto` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stage_from` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stage_to` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stage_why` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_stats`
--

CREATE TABLE IF NOT EXISTS `cpa_stats` (
  `stat_id` int(10) unsigned NOT NULL,
  `offer_id` smallint(5) unsigned NOT NULL,
  `flow_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `stat_date` int(10) unsigned NOT NULL DEFAULT '0',
  `stat_space` int(10) unsigned NOT NULL DEFAULT '0',
  `stat_suni` int(10) unsigned NOT NULL DEFAULT '0',
  `stat_sgood` int(10) unsigned NOT NULL DEFAULT '0',
  `stat_stime` int(10) unsigned NOT NULL DEFAULT '0',
  `stat_click` int(10) unsigned NOT NULL DEFAULT '0',
  `stat_unique` int(10) unsigned NOT NULL DEFAULT '0',
  `stat_good` int(10) unsigned NOT NULL DEFAULT '0',
  `stat_time` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_supp`
--

CREATE TABLE IF NOT EXISTS `cpa_supp` (
  `supp_id` int(10) unsigned NOT NULL,
  `user_id` mediumint(8) unsigned NOT NULL,
  `user_name` varchar(50) NOT NULL DEFAULT '',
  `supp_user` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `supp_type` tinyint(1) NOT NULL DEFAULT '0',
  `supp_time` int(10) unsigned NOT NULL DEFAULT '0',
  `supp_read` tinyint(1) NOT NULL DEFAULT '0',
  `supp_text` text NOT NULL,
  `supp_ip` int(11) unsigned NOT NULL DEFAULT '0',
  `supp_geo` varchar(200) NOT NULL DEFAULT '',
  `supp_req` varchar(50) NOT NULL,
  `supp_data` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_team`
--

CREATE TABLE IF NOT EXISTS `cpa_team` (
  `team_id` mediumint(8) unsigned NOT NULL,
  `comp_id` smallint(5) unsigned NOT NULL,
  `team_name` varchar(50) NOT NULL DEFAULT '',
  `team_call` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `team_pack` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `team_send` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `team_delivery` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `team_mod` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `team_offer` text NOT NULL,
  `pay_use` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `pay_day` smallint(5) unsigned NOT NULL DEFAULT '0',
  `pay_night` smallint(5) unsigned NOT NULL DEFAULT '0',
  `pay_sale` smallint(5) unsigned NOT NULL DEFAULT '0',
  `pay_upsale` varchar(100) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_test`
--

CREATE TABLE IF NOT EXISTS `cpa_test` (
  `test_id` mediumint(8) unsigned NOT NULL,
  `split_id` mediumint(8) unsigned NOT NULL,
  `flow_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `test_name` varchar(200) NOT NULL DEFAULT '',
  `test_url` varchar(250) NOT NULL DEFAULT '',
  `test_pos` smallint(5) unsigned NOT NULL DEFAULT '0',
  `test_geo` varchar(100) NOT NULL DEFAULT '',
  `test_nogeo` varchar(100) NOT NULL DEFAULT '',
  `test_mobile` tinyint(3) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_track`
--

CREATE TABLE IF NOT EXISTS `cpa_track` (
  `track_id` int(10) unsigned NOT NULL,
  `offer_id` smallint(5) unsigned NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  `track_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `track_md5` char(32) NOT NULL DEFAULT '',
  `track_time` int(10) unsigned NOT NULL DEFAULT '0',
  `track_country` char(2) NOT NULL DEFAULT 'ru',
  `track_zip` varchar(10) NOT NULL DEFAULT '',
  `track_city` varchar(100) NOT NULL DEFAULT '',
  `track_comment` varchar(250) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_user`
--

CREATE TABLE IF NOT EXISTS `cpa_user` (
  `user_id` mediumint(8) unsigned NOT NULL,
  `user_mail` varchar(100) NOT NULL,
  `user_pass` varchar(64) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `user_vip` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `user_push` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `user_work` tinyint(4) NOT NULL DEFAULT '0',
  `user_ban` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `user_warn` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `user_cash` decimal(14,2) NOT NULL DEFAULT '0.00',
  `user_wmr` varchar(15) NOT NULL DEFAULT '',
  `user_ref` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `user_got` decimal(11,2) unsigned NOT NULL DEFAULT '0.00',
  `user_man` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `user_ext` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `user_comp` smallint(5) unsigned NOT NULL DEFAULT '0',
  `user_compad` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `user_team` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `user_teamlead` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `user_api` varchar(32) NOT NULL DEFAULT '',
  `user_news` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `user_ip` int(11) unsigned NOT NULL DEFAULT '0',
  `user_date` int(10) unsigned NOT NULL DEFAULT '0',
  `user_cr` float NOT NULL DEFAULT '0',
  `user_epc` float NOT NULL DEFAULT '0',
  `user_meta` text NOT NULL,
  `supp_new` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `supp_notify` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `supp_admin` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `supp_last` int(10) unsigned NOT NULL DEFAULT '0',
  `supp_user` smallint(5) unsigned NOT NULL DEFAULT '0',
  `supp_name` varchar(50) NOT NULL DEFAULT '',
  `supp_type` tinyint(1) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `cpa_user`
--

INSERT INTO `cpa_user` (`user_id`, `user_mail`, `user_pass`, `user_name`, `user_level`, `user_vip`, `user_push`, `user_work`, `user_ban`, `user_warn`, `user_cash`, `user_wmr`, `user_ref`, `user_got`, `user_man`, `user_ext`, `user_comp`, `user_compad`, `user_team`, `user_teamlead`, `user_api`, `user_news`, `user_ip`, `user_date`, `user_cr`, `user_epc`, `user_meta`, `supp_new`, `supp_notify`, `supp_admin`, `supp_last`, `supp_user`, `supp_name`, `supp_type`) VALUES
(1, 'admin@altercms.ru', '5ebe2294ecd0e0f08eab7690d2a6ee69', 'Администратор', 1, 0, 0, 2, 0, 0, '0.00', '', 0, '0.00', 0, 0, 0, 0, 0, 0, '', 1, 2130706433, 20170911, 0, 0, '', 0, 0, 0, 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `cpa_vars`
--

CREATE TABLE IF NOT EXISTS `cpa_vars` (
  `var_id` smallint(5) unsigned NOT NULL,
  `offer_id` smallint(5) unsigned NOT NULL,
  `var_name` varchar(100) NOT NULL DEFAULT '',
  `var_short` varchar(20) NOT NULL DEFAULT '',
  `var_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `var_single` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `var_price` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cpa_ban_ip`
--
ALTER TABLE `cpa_ban_ip`
  ADD PRIMARY KEY (`ip`),
  ADD KEY `status` (`status`);

--
-- Индексы таблицы `cpa_ban_phone`
--
ALTER TABLE `cpa_ban_phone`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD KEY `status` (`status`);

--
-- Индексы таблицы `cpa_call`
--
ALTER TABLE `cpa_call`
  ADD PRIMARY KEY (`call_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `offer_id` (`offer_id`),
  ADD KEY `call_accept` (`call_accept`),
  ADD KEY `call_geo` (`call_geo`),
  ADD KEY `call_delivery` (`call_delivery`);

--
-- Индексы таблицы `cpa_cash`
--
ALTER TABLE `cpa_cash`
  ADD PRIMARY KEY (`cash_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `cash_time` (`cash_time`),
  ADD KEY `cash_type` (`cash_type`),
  ADD KEY `cash_uid` (`cash_uid`),
  ADD KEY `order_id` (`order_id`);

--
-- Индексы таблицы `cpa_change`
--
ALTER TABLE `cpa_change`
  ADD PRIMARY KEY (`change_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `change_warn` (`change_warn`);

--
-- Индексы таблицы `cpa_click`
--
ALTER TABLE `cpa_click`
  ADD PRIMARY KEY (`click_id`),
  ADD KEY `flow_id` (`flow_id`),
  ADD KEY `site_id` (`site_id`),
  ADD KEY `click_date` (`click_date`),
  ADD KEY `click_space` (`click_space`),
  ADD KEY `click_good` (`click_good`),
  ADD KEY `ext_id` (`ext_id`),
  ADD KEY `offer_id` (`offer_id`),
  ADD KEY `site_sib` (`site_sib`),
  ADD KEY `click_time` (`click_time`),
  ADD KEY `test_id` (`test_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `utms32` (`utms32`),
  ADD KEY `utmc32` (`utmc32`),
  ADD KEY `utmn32` (`utmn32`),
  ADD KEY `utmt32` (`utmt32`),
  ADD KEY `utmm32` (`utmm32`),
  ADD KEY `click_geo` (`click_geo`),
  ADD KEY `click_hour` (`click_hour`);

--
-- Индексы таблицы `cpa_comp`
--
ALTER TABLE `cpa_comp`
  ADD PRIMARY KEY (`comp_id`),
  ADD KEY `int_add` (`int_add`),
  ADD KEY `int_chk` (`int_chk`),
  ADD KEY `int_lng` (`int_lng`),
  ADD KEY `int_acc` (`int_acc`),
  ADD KEY `int_dlv` (`int_dlv`),
  ADD KEY `int_dlc` (`int_dlc`);

--
-- Индексы таблицы `cpa_config`
--
ALTER TABLE `cpa_config`
  ADD PRIMARY KEY (`name`);

--
-- Индексы таблицы `cpa_domain`
--
ALTER TABLE `cpa_domain`
  ADD PRIMARY KEY (`dom_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `cpa_ext`
--
ALTER TABLE `cpa_ext`
  ADD PRIMARY KEY (`ext_id`);

--
-- Индексы таблицы `cpa_flow`
--
ALTER TABLE `cpa_flow`
  ADD PRIMARY KEY (`flow_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `offer_id` (`offer_id`);

--
-- Индексы таблицы `cpa_geocity`
--
ALTER TABLE `cpa_geocity`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `cpa_geoip`
--
ALTER TABLE `cpa_geoip`
  ADD PRIMARY KEY (`ip`);

--
-- Индексы таблицы `cpa_geowork`
--
ALTER TABLE `cpa_geowork`
  ADD PRIMARY KEY (`ip`);

--
-- Индексы таблицы `cpa_inlog`
--
ALTER TABLE `cpa_inlog`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `comp_id` (`comp_id`),
  ADD KEY `log_type` (`log_type`),
  ADD KEY `order_id` (`order_id`);

--
-- Индексы таблицы `cpa_load`
--
ALTER TABLE `cpa_load`
  ADD PRIMARY KEY (`load_id`),
  ADD KEY `offer_id` (`offer_id`),
  ADD KEY `load_status` (`load_status`),
  ADD KEY `load_mark` (`load_mark`),
  ADD KEY `load_last` (`load_last`);

--
-- Индексы таблицы `cpa_news`
--
ALTER TABLE `cpa_news`
  ADD PRIMARY KEY (`news_id`),
  ADD KEY `news_group` (`news_group`),
  ADD KEY `news_vip` (`news_vip`),
  ADD KEY `offer_id` (`offer_id`),
  ADD KEY `news_cat` (`news_cat`);

--
-- Индексы таблицы `cpa_offer`
--
ALTER TABLE `cpa_offer`
  ADD PRIMARY KEY (`offer_id`),
  ADD KEY `offer_active` (`offer_active`),
  ADD KEY `cat_id` (`cat_id`),
  ADD KEY `offer_sort` (`offer_sort`),
  ADD KEY `offer_home` (`offer_home`),
  ADD KEY `offer_excl` (`offer_excl`),
  ADD KEY `offer_recom` (`offer_recom`),
  ADD KEY `cat_sub` (`cat_sub`),
  ADD KEY `offer_private` (`offer_private`),
  ADD KEY `stat_next` (`stat_next`),
  ADD FULLTEXT KEY `offer_wl` (`offer_wl`);
ALTER TABLE `cpa_offer`
  ADD FULLTEXT KEY `offer_bl` (`offer_bl`);

--
-- Индексы таблицы `cpa_order`
--
ALTER TABLE `cpa_order`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `order_status` (`order_status`),
  ADD KEY `order_callback` (`order_recall`),
  ADD KEY `track_on` (`track_on`),
  ADD KEY `track_check` (`track_check`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `comp_id` (`comp_id`),
  ADD KEY `order_delivery` (`order_delivery`),
  ADD KEY `order_phone` (`order_phone`),
  ADD KEY `flow_id` (`flow_id`),
  ADD KEY `offer_id` (`offer_id`),
  ADD KEY `order_ip` (`order_ip`),
  ADD KEY `order_gender` (`order_gender`),
  ADD KEY `space_id` (`space_id`),
  ADD KEY `ext_id` (`ext_id`),
  ADD KEY `order_check` (`order_check`),
  ADD KEY `wm_id` (`wm_id`),
  ADD KEY `order_webstat` (`order_webstat`),
  ADD KEY `paid` (`paid_ok`),
  ADD KEY `promo_code` (`promo_code`,`promo_status`),
  ADD KEY `ext_check` (`ext_check`),
  ADD KEY `mark_time` (`mark_time`),
  ADD KEY `cc_id` (`cc_id`),
  ADD KEY `test_id` (`test_id`),
  ADD KEY `utms32` (`utms32`),
  ADD KEY `utmc32` (`utmc32`),
  ADD KEY `utmn32` (`utmn32`),
  ADD KEY `utmt32` (`utmt32`),
  ADD KEY `utmm32` (`utmm32`),
  ADD KEY `order_country` (`order_country`),
  ADD KEY `ext_track` (`ext_track`),
  ADD KEY `track_warn` (`track_warn`),
  ADD KEY `click_id` (`click_id`),
  ADD KEY `order_stage` (`order_stage`),
  ADD KEY `order_reason` (`order_reason`),
  ADD KEY `site_id` (`site_id`),
  ADD KEY `order_auto` (`order_auto`);

--
-- Индексы таблицы `cpa_pdb`
--
ALTER TABLE `cpa_pdb`
  ADD PRIMARY KEY (`phone`);

--
-- Индексы таблицы `cpa_price`
--
ALTER TABLE `cpa_price`
  ADD PRIMARY KEY (`price_id`),
  ADD KEY `offer_id` (`offer_id`),
  ADD KEY `price_pub` (`price_pub`),
  ADD KEY `price_sort` (`price_sort`);

--
-- Индексы таблицы `cpa_promo`
--
ALTER TABLE `cpa_promo`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `cpa_sess`
--
ALTER TABLE `cpa_sess`
  ADD PRIMARY KEY (`sess_id`),
  ADD UNIQUE KEY `sess_uid` (`sess_uid`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `sess_date` (`sess_date`);

--
-- Индексы таблицы `cpa_site`
--
ALTER TABLE `cpa_site`
  ADD PRIMARY KEY (`site_id`),
  ADD UNIQUE KEY `site_url` (`site_url`),
  ADD KEY `offer_id` (`offer_id`),
  ADD KEY `comp_id` (`comp_id`),
  ADD KEY `site_type` (`site_type`),
  ADD KEY `site_default` (`site_default`);

--
-- Индексы таблицы `cpa_split`
--
ALTER TABLE `cpa_split`
  ADD PRIMARY KEY (`split_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `split_active` (`split_active`),
  ADD KEY `split_last` (`split_last`);

--
-- Индексы таблицы `cpa_stage`
--
ALTER TABLE `cpa_stage`
  ADD PRIMARY KEY (`stage_id`),
  ADD KEY `comp_id` (`comp_id`);

--
-- Индексы таблицы `cpa_stats`
--
ALTER TABLE `cpa_stats`
  ADD PRIMARY KEY (`stat_id`),
  ADD KEY `flow_id` (`flow_id`),
  ADD KEY `stat_date` (`stat_date`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `offer_id` (`offer_id`);

--
-- Индексы таблицы `cpa_supp`
--
ALTER TABLE `cpa_supp`
  ADD PRIMARY KEY (`supp_id`),
  ADD KEY `supp_user` (`supp_user`),
  ADD KEY `supp_read` (`supp_read`),
  ADD KEY `supp_type` (`supp_type`);

--
-- Индексы таблицы `cpa_team`
--
ALTER TABLE `cpa_team`
  ADD PRIMARY KEY (`team_id`),
  ADD KEY `comp_ip` (`comp_id`);

--
-- Индексы таблицы `cpa_test`
--
ALTER TABLE `cpa_test`
  ADD PRIMARY KEY (`test_id`),
  ADD KEY `split_id` (`split_id`);

--
-- Индексы таблицы `cpa_track`
--
ALTER TABLE `cpa_track`
  ADD PRIMARY KEY (`track_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Индексы таблицы `cpa_user`
--
ALTER TABLE `cpa_user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_email` (`user_mail`),
  ADD KEY `user_comp` (`user_comp`),
  ADD KEY `supp_notify` (`supp_notify`),
  ADD KEY `supp_new` (`supp_new`),
  ADD KEY `supp_admin` (`supp_admin`),
  ADD KEY `user_news` (`user_news`),
  ADD KEY `user_ext` (`user_ext`),
  ADD KEY `user_ref` (`user_ref`),
  ADD KEY `user_team` (`user_team`),
  ADD KEY `user_man` (`user_man`),
  ADD KEY `user_work` (`user_work`),
  ADD KEY `supp_last` (`supp_last`);

--
-- Индексы таблицы `cpa_vars`
--
ALTER TABLE `cpa_vars`
  ADD PRIMARY KEY (`var_id`),
  ADD KEY `offer_id` (`offer_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cpa_ban_phone`
--
ALTER TABLE `cpa_ban_phone`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_call`
--
ALTER TABLE `cpa_call`
  MODIFY `call_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_cash`
--
ALTER TABLE `cpa_cash`
  MODIFY `cash_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_change`
--
ALTER TABLE `cpa_change`
  MODIFY `change_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_click`
--
ALTER TABLE `cpa_click`
  MODIFY `click_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_comp`
--
ALTER TABLE `cpa_comp`
  MODIFY `comp_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_domain`
--
ALTER TABLE `cpa_domain`
  MODIFY `dom_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_ext`
--
ALTER TABLE `cpa_ext`
  MODIFY `ext_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_flow`
--
ALTER TABLE `cpa_flow`
  MODIFY `flow_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_inlog`
--
ALTER TABLE `cpa_inlog`
  MODIFY `log_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_load`
--
ALTER TABLE `cpa_load`
  MODIFY `load_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_news`
--
ALTER TABLE `cpa_news`
  MODIFY `news_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_offer`
--
ALTER TABLE `cpa_offer`
  MODIFY `offer_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_order`
--
ALTER TABLE `cpa_order`
  MODIFY `order_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_price`
--
ALTER TABLE `cpa_price`
  MODIFY `price_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_sess`
--
ALTER TABLE `cpa_sess`
  MODIFY `sess_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_site`
--
ALTER TABLE `cpa_site`
  MODIFY `site_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_split`
--
ALTER TABLE `cpa_split`
  MODIFY `split_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_stage`
--
ALTER TABLE `cpa_stage`
  MODIFY `stage_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_stats`
--
ALTER TABLE `cpa_stats`
  MODIFY `stat_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_supp`
--
ALTER TABLE `cpa_supp`
  MODIFY `supp_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_team`
--
ALTER TABLE `cpa_team`
  MODIFY `team_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_test`
--
ALTER TABLE `cpa_test`
  MODIFY `test_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_track`
--
ALTER TABLE `cpa_track`
  MODIFY `track_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cpa_user`
--
ALTER TABLE `cpa_user`
  MODIFY `user_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `cpa_vars`
--
ALTER TABLE `cpa_vars`
  MODIFY `var_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
