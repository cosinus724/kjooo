# 19.10.2017 - Offer blocking and ACL
ALTER TABLE `cpa_offer` ADD `offer_block` TINYINT UNSIGNED NOT NULL AFTER `offer_active`, ADD `offer_private` TINYINT UNSIGNED NOT NULL AFTER `offer_block`, ADD `offer_wl` TEXT NOT NULL AFTER `offer_private`, ADD `offer_bl` TEXT NOT NULL AFTER `offer_wl`, ADD INDEX (`offer_private`), ADD FULLTEXT (`offer_wl`), ADD FULLTEXT (`offer_bl`);
# 21.10.2017 - Additional cash in order analytics
ALTER TABLE `cpa_order` ADD `cash_etc` DECIMAL(11,2) NOT NULL DEFAULT '0' AFTER `cash_pay`;
UPDATE `cpa_order` SET cash_etc = ( SELECT SUM(cash_value) FROM cpa_cash WHERE cpa_cash.order_id = cpa_order.order_id AND cash_type IN ( 7, 8 ) ) WHERE order_status BETWEEN 6 AND 11;
# 22.10.2017 - Order stages
ALTER TABLE `cpa_order` ADD `order_stage` SMALLINT UNSIGNED NOT NULL AFTER `order_webstat`, ADD INDEX (`order_stage`);
CREATE TABLE IF NOT EXISTS `cpa_stage` (
  `stage_id` smallint(5) unsigned NOT NULL,
  `comp_id` smallint(5) unsigned NOT NULL,
  `stage_slug` varchar(50) NOT NULL,
  `stage_name` varchar(50) NOT NULL,
  `stage_group` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `stage_auto` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stage_from` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stage_to` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stage_why` text NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
ALTER TABLE `cpa_stage` ADD PRIMARY KEY (`stage_id`), ADD KEY `comp_id` (`comp_id`);
ALTER TABLE `cpa_stage` MODIFY `stage_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT;
# 30.10.2017 - Hourly statistics
ALTER TABLE `cpa_click` ADD `click_hour` TINYINT UNSIGNED NOT NULL AFTER `click_time`, ADD INDEX (`click_hour`);
UPDATE cpa_click SET click_hour = HOUR(FROM_UNIXTIME( click_time ));
# 29.11.2017 - Delivery integration
ALTER TABLE `cpa_comp` ADD `int_dlv` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0' AFTER `int_acc_code`, ADD `int_dlv_url` TEXT NOT NULL DEFAULT '' AFTER `int_dlv`, ADD `int_dlv_pre` TEXT NOT NULL DEFAULT '' AFTER `int_dlv_url`, ADD `int_dlv_field` TEXT NOT NULL DEFAULT '' AFTER `int_dlv_pre`, ADD `int_dlv_code` TEXT NOT NULL DEFAULT '' AFTER `int_dlv_field`, ADD INDEX (`int_dlv`);
ALTER TABLE `cpa_comp` ADD `int_dlc` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0' AFTER `int_lng_code`, ADD `int_dlc_url` TEXT NOT NULL DEFAULT '' AFTER `int_dlc`, ADD `int_dlc_pre` TEXT NOT NULL DEFAULT '' AFTER `int_dlc_url`, ADD `int_dlc_field` TEXT NOT NULL DEFAULT '' AFTER `int_dlc_pre`, ADD `int_dlc_format` TINYINT UNSIGNED NOT NULL DEFAULT '1' AFTER `int_dlc_field`, ADD `int_dlc_count` SMALLINT UNSIGNED NOT NULL DEFAULT '20' AFTER `int_dlc_format`, ADD `int_dlc_code` TEXT NOT NULL DEFAULT '' AFTER `int_dlc_count`, ADD INDEX (`int_dlc`);
ALTER TABLE `cpa_order` ADD `ext_dlid` VARCHAR(32) NOT NULL DEFAULT '' AFTER `ext_check`, ADD `ext_track` INT UNSIGNED NOT NULL DEFAULT '0' AFTER `ext_dlid`, ADD INDEX (`ext_track`);
ALTER TABLE `cpa_order` ADD `track_warn` TINYINT UNSIGNED NOT NULL DEFAULT '0' AFTER `track_notify`, ADD INDEX (`track_warn`);
# 08.12.2017 - Processing cancelled orders
ALTER TABLE `cpa_offer` ADD `bad_script` TEXT NOT NULL AFTER `out_script`;
# 17.12.2017 - Good click data changes
ALTER TABLE `cpa_click` CHANGE `click_good` `click_good` TINYINT(4) UNSIGNED NOT NULL;