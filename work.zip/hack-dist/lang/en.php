<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

$lang = array('offer_cats' => array(1 => 'Casino and Bets', 2 => 'Games', 3 => 'Apps', 4 => 'Financial', 5 => 'Beauty and health', 6 => 'Electronics and gadgets', 7 => 'Home appliances', 8 => 'Car goods', 9 => 'Services', 10 => 'Children', 11 => 'Clothes and accessories', 12 => 'Info', 13 => 'Gifts and fun', 100 => 'Other'));

?>