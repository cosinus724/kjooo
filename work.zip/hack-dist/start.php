<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

/*******************************************************************************
 *
 * 	AlterVision CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright (c) 2014-2018 Anton Reznichenko
 *
 *
 *  File: 			hack-dist / start.php
 *  Description:	Default hacks list
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *
 *******************************************************************************/
// Site control
//define ( 'HTTRACK', 	'/usr/bin/httrack' );
// Active databases
//define ( 'PDB_RU',	true );								// PhoneDatabase: Russian
//define ( 'IPDB_RU',	true );				 				// GeoIP database: Russian
//define ( 'GEOCODE', 	'/var/www/shop/geocode.txt' );		// Full path to the geocode.txt file on landings
// Settings
//define ( 'HOLDISAPPROVE', true );		// Think hold status is approved
//
// Hacks
//
//define ( 'HACK_LANG', true );			// Include hacked language file
//define ( 'HACK_ADD', true );			// Add hack/add.php to new order script
//define ( 'HACK_API', true );			// Add hack/api.php to API interface
//define ( 'HACK_REGISTER', true );		// Add hack/register.php to registration and login
//define ( 'HACK_HOME', true );			// Use hack/home.php for main registragion page
//
// Styling
//
// CSS tricks
//define ( 'HACK_SKIN', 'skin-green' );	// Use specified skin
//define ( 'BOXSKIN', 'success' );		// Change also box skin (success, primary, danger, warning)
//define ( 'HACK_NOSTYLE', true );		// Disable usage of style/style.css
//define ( 'HACK_NOSKIN', true );		// Disable usage of style/skin-*.css
//define ( 'HACK_NOFONTS', true );		// Disable usage of style/fa.css
//define ( 'HACK_NOLAYOUT', true );		// Disable usage of style/layout.css
//define ( 'HACK_MYSTYLE', true );		// Add personal css/style.css
// TPL replacement from style/XXX.tpl to hack/tpl/XXX.tpl
//define ( 'HACK_TPL_404', true );			// 404.tpl
//define ( 'HACK_TPL_ANALYTICS', true );	// analytics-main.tpl
//define ( 'HACK_TPL_ANALDELIV', true );	// analytics-delivery.tpl
//define ( 'HACK_TPL_BAN', true );			// ban.tpl
//define ( 'HACK_TPL_BUSINESS', true );		// business.tpl
//define ( 'HACK_TPL_CALLSTAT', true );		// callstat.tpl
//define ( 'HACK_TPL_COMP', true );			// comps.tpl
//define ( 'HACK_TPL_DOMAIN', true );		// domain.tpl
//define ( 'HACK_TPL_DYNAMICS', true );		// dynamics.tpl
//define ( 'HACK_TPL_ENTER', true );		// login-clean.tpl
//define ( 'HACK_TPL_FINANCE', true );		// finance.tpl
//define ( 'HACK_TPL_FLOWS', true );		// flows.tpl
//define ( 'HACK_TPL_FOOTER', true );		// footer.tpl
//define ( 'HACK_TPL_FORM', true );			// form.tpl
//define ( 'HACK_TPL_HEADER', true );		// header.tpl
//define ( 'HACK_TPL_LEAD', true );			// lead.tpl
//define ( 'HACK_TPL_LIST', true );			// list.tpl
//define ( 'HACK_TPL_LOGIN', true );		// login.tpl
//define ( 'HACK_TPL_MESSAGE', true );		// message.tpl
//define ( 'HACK_TPL_NEWS', true );			// news.tpl
//define ( 'HACK_TPL_OFFER', true );		// offer.tpl
//define ( 'HACK_TPL_OFFERS', true );		// offers.tpl
//define ( 'HACK_TPL_OFLIST', true );		// offerlist.tpl
//define ( 'HACK_TPL_ORDER', true );		// order.tpl
//define ( 'HACK_TPL_ORDERS', true );		// orders.tpl and csv-orders.tpl
//define ( 'HACK_TPL_OUTS', true );			// outs.tpl
//define ( 'HACK_TPL_PARAM', true );		// param.tpl
//define ( 'HACK_TPL_PRICE', true );		// price.tpl
//define ( 'HACK_TPL_REFERAL', true );		// referal.tpl
//define ( 'HACK_TPL_SLIST', true );		// safelist.tpl
//define ( 'HACK_TPL_STATS_CLICK', true );	// stats-click.tpl
//define ( 'HACK_TPL_STATS_DATE', true );	// stats-date.tpl
//define ( 'HACK_TPL_STATS_EXT', true );	// stats-ext.tpl
//define ( 'HACK_TPL_STATS_FLOW', true );	// stats-flow.tpl
//define ( 'HACK_TPL_STATS_GEO', true );	// stats-geo.tpl
//define ( 'HACK_TPL_STATS_LEAD', true );	// stats-lead.tpl
//define ( 'HACK_TPL_STATS_OFFER', true );	// stats-offer.tpl
//define ( 'HACK_TPL_STATS_SPLIT', true );	// stats-split.tpl
//define ( 'HACK_TPL_STATS_UTM', true );	// stats-utm.tpl
//define ( 'HACK_TPL_SUPP', true );			// support.tpl
//define ( 'HACK_TPL_TALK', true );			// talk.tpl
//define ( 'HACK_TPL_TRANS', true );		// trans.tpl
//define ( 'HACK_TPL_USERS', true );		// users.tpl
//
// Misc
//
// Payment
define('WMR', 'R12345667890');
// WebMoney Ruble Purse
define('WMK', '');
// WebMoney Auth Key
// Address Parsing
//define ( 'ADDR_XML',	'http://ahunter.ru/site/check?user=username;output=xml;query=' );	// AHunter XML check url
//define ( 'ADDR_ALT',	'http://ahunter.ru/site/search?user=username;output=xml;query=' );	// AHunter XML search url
define('ADDR_CACHE', PATH . 'data/work/address-%s.txt');
// Support notification email
define('SUPPORT_NOTIFY', 'support@work.cpa');
// Disqus short name
//define( 'DISQUS', 'workcpa' );

?>