<?php


error_reporting(0);
define("IN_ALTERCMS_CORE_ONE", true);
define("PATH", dirname(__FILE__) . "/");
include PATH . "config.php";
setlocale(LC_ALL, "ru_RU.UTF-8");
mb_language("uni");
mb_internal_encoding("utf-8");
if (isset($_GET["g"]) && ($g = (int) $_GET["g"])) {
    $db = mysqli_connect(SQL_HOST, SQL_USER, SQL_PASS, SQL_BASE);
    if ($db) {
        mysqli_query($db, "UPDATE LOW_PRIORITY `" . SQL_PREF . "click` SET `click_good` = `click_good` + 1 WHERE `click_id` = '" . $g . "' AND `click_good` < 179");
        mysqli_close($db);
    }
    exit;
}
$flow = isset($_GET["f"]) ? (int) $_GET["f"] : 0;
$test = isset($_GET["t"]) ? (int) $_GET["t"] : 0;
$site = isset($_GET["s"]) ? (int) $_GET["s"] : 0;
$sib = isset($_GET["b"]) ? (int) $_GET["b"] : 0;
$offer = isset($_GET["o"]) ? (int) $_GET["o"] : 0;
$exti = isset($_GET["ei"]) ? (int) $_GET["ei"] : 0;
$extu = isset($_GET["eu"]) ? (int) $_GET["eu"] : 0;
$exts = isset($_GET["es"]) ? (int) $_GET["es"] : 0;
$ip = isset($_GET["ip"]) ? (int) $_GET["ip"] : 0;
$unique = isset($_GET["u"]) && $_GET["u"] ? 1 : 0;
$space = isset($_GET["p"]) && $_GET["p"] ? 1 : 0;
$date = isset($_GET["tm"]) && is_numeric($_GET["tm"]) && $_GET["tm"] ? date("Ymd", $_GET["tm"]) : date("Ymd");
$time = isset($_GET["tm"]) && is_numeric($_GET["tm"]) && $_GET["tm"] ? $_GET["tm"] : time();
$hour = date("H", $time);
$us = isset($_GET["us"]) ? addslashes(mb_substr(filter_var(stripslashes($_GET["us"]), FILTER_SANITIZE_STRING), 0, 250)) : "";
$uc = isset($_GET["uc"]) ? addslashes(mb_substr(filter_var(stripslashes($_GET["uc"]), FILTER_SANITIZE_STRING), 0, 250)) : "";
$un = isset($_GET["un"]) ? addslashes(mb_substr(filter_var(stripslashes($_GET["un"]), FILTER_SANITIZE_STRING), 0, 250)) : "";
$ut = isset($_GET["ut"]) ? addslashes(mb_substr(filter_var(stripslashes($_GET["ut"]), FILTER_SANITIZE_STRING), 0, 250)) : "";
$um = isset($_GET["um"]) ? addslashes(mb_substr(filter_var(stripslashes($_GET["um"]), FILTER_SANITIZE_STRING), 0, 250)) : "";
$hs = sprintf("%u", crc32($us));
$hc = sprintf("%u", crc32($uc));
$hn = sprintf("%u", crc32($un));
$ht = sprintf("%u", crc32($ut));
$hm = sprintf("%u", crc32($um));
if (($flow || $exti) && $site) {
    $db = mysqli_connect(SQL_HOST, SQL_USER, SQL_PASS, SQL_BASE);
    if (!$db) {
        exit("e");
    }
    mysqli_set_charset($db, "utf8");
    if ($ip) {
        $o = mysqli_query($db, "SELECT `country` FROM `" . SQL_PREF . "geoip` WHERE `ip` < '" . $ip . "' ORDER BY `ip` DESC LIMIT 1");
        if ($o) {
            $g = mysqli_fetch_row($o);
            $geo = $g[0];
        } else {
            $geo = "zz";
        }
    } else {
        $geo = "zz";
    }
    mysqli_query($db, "INSERT INTO `" . SQL_PREF . "click` SET\n\t\t`offer_id`\t\t= '" . $offer . "',\n\t\t`test_id`\t\t= '" . $test . "',\n\t\t`site_id`\t\t= '" . $site . "',\n\t\t`site_sib`\t\t= '" . $sib . "',\n\t\t`flow_id`\t\t= '" . $flow . "',\n\t\t`ext_id`\t\t= '" . $exti . "',\n\t\t`ext_uid`\t\t= '" . $extu . "',\n\t\t`ext_src`\t\t= '" . $exts . "',\n\t\t`click_ip`\t\t= '" . $ip . "',\n\t\t`click_geo`\t\t= '" . $geo . "',\n\t\t`click_date`\t= '" . $date . "',\n\t\t`click_time`\t= '" . $time . "',\n\t\t`click_hour`\t= '" . $hour . "',\n\t\t`click_unique`\t= '" . $unique . "',\n\t\t`click_space`\t= '" . $space . "',\n\t\t`utms`\t\t\t= '" . $us . "',\n\t\t`utmc`\t\t\t= '" . $uc . "',\n\t\t`utmn`\t\t\t= '" . $un . "',\n\t\t`utmt`\t\t\t= '" . $ut . "',\n\t\t`utmm`\t\t\t= '" . $um . "',\n\t\t`utms32`\t\t= '" . $hs . "',\n\t\t`utmc32`\t\t= '" . $hc . "',\n\t\t`utmn32`\t\t= '" . $hn . "',\n\t\t`utmt32`\t\t= '" . $ht . "',\n\t\t`utmm32`\t\t= '" . $hm . "'\n\t");
    $uid = mysqli_insert_id($db);
    mysqli_close($db);
    echo "ok:" . $uid;
    exit;
}
exit("e");

?>