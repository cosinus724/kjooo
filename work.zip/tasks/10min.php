<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

/*******************************************************************************
 *
 * 	AlterVision CPA platform
 * 	Created by AlterVision - altervision.me
 *  Copyright (c) 2014-2018 Anton Reznichenko
 *
 *
 *  File: 			tasks / 10min.php
 *  Description:	Cron tasks launcher: each 10 minutes
 *  Author:			Anton 'AlterVision' Reznichenko - altervision13@gmail.com
 *
 *******************************************************************************/
define('PATH', realpath(dirname(__FILE__) . '/../') . '/');
require_once PATH . 'core/mods/cron.php';
crontab('10min');

?>