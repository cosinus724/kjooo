<?php


error_reporting(0);
define("IN_ALTERCMS_CORE_ONE", true);
define("PATH", dirname(__FILE__) . "/");
require_once PATH . "core/main.php";

?>