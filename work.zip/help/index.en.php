<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

define('PATH', realpath(dirname(__FILE__) . '/../') . '/');
$page = 'index';
$lang = 'en';
require_once 'tpl/header.php';
?>

		<div class="bs-docs-section">

			<div class="page-header"><h1 id="overview"><?php 
echo $core->config('site', 'name');
?> - Automation trade platform</h1></div>
			<p class="lead">We offer quality service for attracting customers and making sales transactions on the Internet.</p>
			<p>We offer webmasters and experts in attracting customers to participate in our partnership program.Service for you: stable payments, advanced analytics, only quality offers from our partners. The affiliate program works according to the CPS model ("cost per sale"), you receive a partner.</p>
			<p>For suppliers: our project helps in finding potential buyers. We offer a ready-made solution for trading business: attracting customers and convenient interface with customers and orders. Service for you: customers SMS-informing, delivery tracking, unlimited number of working managers, analytical tools. You can contact us: <a href="mailto:<?php 
echo $core->config('site', 'mail');
?>"><?php 
echo $core->config('site', 'mail');
?></a></p>

		</div>

		<div class="bs-docs-section">
			<div class="page-header"><h1 id="wm">Webmaster Interface</h1></div>
			<p>The traffic flows are prepared and analyzed using the webmaster interface. To start traffic arbitrage, you need to perform a few simple actions:</p>
			<ul>
				<li>In section «<a href="#offers">Offers</a>» pick up offer you like the most.</li>
				<li>Using the button "Create a flow by the action" add a new flow for this offer. The name of the flow can be chosen arbitrarily.</li>
				<li>In the section «<a href="#flow">Flows</a>» click the button "Generate the flow link" of the corresponding offer or the "Link" button of the required flow to open the link generation form.</li>
				<li>In the opened form choose the landing you liked and, if necessary, the prelanding, and use the received flow link in your ad.</li>
			</ul>
			<p>Information about<a href="#stats">visitors</a> and <a href="#lead">leads</a> is available in relevant statistics sections. The effectiveness of advertising campaigns by ads and sites can be studied using with tool «<a href="#utm">UTM-marks</a>».</p>
			<p class="text-muted small">If you are not satisfied with interface functionality, you can contact <a href="/support">support</a> with ideas for its completion. You can even make your own interface using our <a href="api.en.php">API</a>.</p>

			<h2 id="offers">Offers</h2>
			<p>In this section you can see the list of available offers. About each of the following information is available: landing price, deductions, work region, conversion and last week EPC, buyers' gender statistics for all period. To start working with offer, you need to create at least one flow.</p>
			<p align="center"><a href="/offers"><img src="docs/offers.png" alt="Offers" class="img-responsive" /></a></p>
			<p>Detailed offer information is available on its separate page: a list of available landings and prelanding, their addresses, efficiency and conversion data.</p>

			<h2 id="flow">Flows</h2>
			<p>Work with offers is carried out with flows. You can create an unlimited number of flows for each offer. Each flow and offer statistics is formed separately. You must have at least one flow to get started. To create a flow, you need to select the offer you are interested in. To do this, go to "Offers" section in main menu.</p>
			<p align="center"><a href="/offers"><img src="docs/flow1.png" alt="Go to Offers section" class="img-responsive" /></a></p>
			<p>In offers list you can find offer that suits you. For detailed offer, learn available advertising materials, landings, prelandings and other additional information about the company, click on its name or picture. To create flow, click  "Create new flow" button for the corresponding offer.</p>
			<p align="center"><a href="/offers"><img src="docs/flow2.png" alt="Click Create new flow" class="img-responsive" /></a></p>
			<p>While creating new flow, you will be asked to specify its name for easy analysis. When flow is created, you can generate a link for traffic. Click  "Generate flow link" button of the corresponding offer or "Link" button of the required flow to open the link generation form.</p>
			<p align="center"><a href="/flow"><img src="docs/flowlink.png" alt="Generate flow link" class="img-responsive" /></a></p>
			<p>In the opened form select the flow you are interested in, specify the landing and, if necessary, sapce. The flow link will appear automatically. Under reference box, its expected effectiveness will be shown. You can increase prelanding conversion if you include the ComeBacker script. Some ad networks cut out junction settings that are specified implicitly, or move them by reference. If your link is "damaged" with ad network, you can force parameter<code>flow</code>in link. Flow link can be generated both on the main redirect domain, and on any other domain fixed to our service. If necessary, you can add a link for back traffic. Any traffic for which there are no geo-offers at the specified offer will be redirected to specified address. For each flow landing, prelanding, back traffic, ComeBacker script usage and transition parameters are automatically saved. Target and redirect domain settings are generated for each flow link separately and can be set regardless of flow.</p>
			<p>You can create as many flows as you want and use them to analyze traffic at your discretion.</p>

			<h2 id="stats">Date statistics</h2>
			<p>The number of clicks on landings and prelandings and their effectiveness you can see in Date statistics section. Information about clicks and orders is updated in real time. If you click on the number of orders, you will go to lead statistics for relevant date and status.</p>
			<p align="center"><a href="/stats"><img src="docs/stats.png" alt="Date statistics" class="img-responsive" /></a></p>
			<p class="text-muted">From 0:00 till 0:05 delays and inaccuracies in statistics are possible for technical reasons.</p>

			<h2 id="lead">Lead statistics</h2>
			<p>This section displays a list of the leads you attracted. You can determine the exact source of your order, including prelanding, landing, advertisement and advertising platform from where it was received. The information on the number of calls is for reference only and is not accurate. Call-centers managers do not always mark a repeated lead call like "Missed call" or "Recall".</p>
			<p class="text-muted">For some leads there may be delays in updating the order status to 10 minutes. For some leads the number of calls and reason for failure due to supplier's technical interface are not displayed.</p>
			<p align="center"><a href="/lead"><img src="docs/lead.png" alt="Lead statistics" class="img-responsive" /></a></p>
			<p class="text-danger"><b>Important</b>: we can not provide you any additional order information(full name, address, telephone) except one which is presented in this section. This is due to our company's privacy policy.</p>

			<h2 id="utm">Marks statistics</h2>
			<p>This tool will help you generate statistics on standard UTM tags, identify unsuccessful announcements and sites. It replaces outdated SubID. Statistics are given for 30 days. <b class="text-warning">Yellow</b> indicates transition sources, from which less than 1 item was ordered per 100 clicks, <b class="text-danger">Red</b> - less than 1 item per 1000 clicks. Marks statistics are formed hierarchically, you can change the order of marks parsing at your discretion.</p>
			<p align="center"><a href="/sources"><img src="docs/sources.png" alt="Marks statistics" class="img-responsive" /></a></p>
			<p>To generate statistics, you must configure the transmission of UTM tags in your link. We recognize tags <code>utm_source</code>, <code>utm_content</code>, <code>utm_campaign</code>, <code>utm_term</code> и <code>utm_medium</code>. Tag can contain letters, numbers, symbols <code>()-_</code> and prelanding. Maximum length of mark is 32 symbols.</p>
		</div>

		<div class="bs-docs-section">
			<div class="page-header"><h1 id="sale">Supplier interface</h1></div>
			<p>Using supplier interface, you can process all incoming orders. Unlimited number of managers of your company can deal with orders processing. There is a convenient orders interface for you, there are built-in tools for work with delivery services, warehouse accounting, monitoring the status of orders, analysis of of managers' work and many other functions necessary for successful work in sales.</p>
			<p>System functionality can be easily extended upon your request. Technical specialists of our company implement any tools you need for work.</p>
			<p align="center"><img src="docs/sale.png" alt="Supplier interface" class="img-responsive" /></p>
			<p>If necessary, order processing can be performed not in our system, but in convenient interface. Orders transfer is automatically made using the API system or your interface. To learn more about this interface and join our project as supplier, contact us by mail<a href="mailto:<?php 
echo $core->config('site', 'mail');
?>"><?php 
echo $core->config('site', 'mail');
?></a>.</p>
		</div>

		<div class="bs-docs-section">
			<div class="page-header"><h1 id="common">Common functions</h1></div>
			<p>These interface sections are available to both webmasters and suppliers. They are responsible for basic system functionality, such as technical support, financial transactions, access to site.</p>

			<h2 id="finance">Finance and payments</h2>
			<p>Data on all committed financial transactions, as well as options concerning entering and withdrawing funds from the system, are located in section «<a href="/money">Finance</a>». Before carrying expenditure transactions you need to refill the account. In case of a positive account balance, you can withdraw funds. To do this, apply for funds withdrawal. All calculations are made in WebMoney XXXX. Before sending a withdrawal request, check the purse for withdrawal in the "Profile" section.</p>
			<p align="center"><img src="docs/finance.png" alt="Finance and payments" class="img-responsive" /></p>
			<p>Funds are credited instantly in automatic mode.  Withdrawal funds applications are processed during 5-7 working (banking) days. In the case of a large number of requests for funds withdrawal this period can grow to two weeks.</p>

			<h2 id="support">Support</h2>
			<p>Support is provided on page «<a href="/support">Help</a>». Support service works stably on weekdays from 9 to 18. Rest time we try to respond your requests as fast as possible.</p>
			<p align="center"><img src="docs/support.png" alt="Support" class="img-responsive" /></p>
			<p>Before asking for support, it is recommended to learn <a href="#wm">this guide</a> and read <a href="faq.en.php">FAQ</a>. If answer was not found or it did not suit you, or you just want to communicate with manager - you are welcome to support service!</p>

			<h2 id="profile">User Profile</h2>
			<p>On profile page you can configure the input data for working with site. The display name is used only for support. The e-mail address is used to enter site, recover password and receive notifications and service news.</p>
			<p align="center"><img src="docs/profile.png" alt="User Profile" class="img-responsive" /></p>
			<p>Data needed to work with API is also on this page. For security reasons, API key can be regenerated at any time. You can find information about working with API<a href="api.en.php">in the relevant section</a> of support.</p>

		</div>

    </div>

<?php 
include 'tpl/footer.php';

?>