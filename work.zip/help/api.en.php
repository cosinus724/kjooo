<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

define('PATH', realpath(dirname(__FILE__) . '/../') . '/');
$page = 'api';
$lang = 'en';
require_once 'tpl/header.php';
$api = $core->config('url', 'api') ? $core->config('url', 'api') : $core->config('url', 'base') . 'api/';
?>

		<div class="bs-docs-section">

			<div class="page-header"><h1 id="overview">Overview API-functions  <?php 
echo $core->config('site', 'name');
?></h1></div>
			<p class="lead">API-functions platform interface <?php 
echo $core->config('site', 'name');
?> allows to perform most webmaster's and provider's actions, which are realised on site. To plug API go to <a href="/profile">profile</a> in system.</p>
			<p>Interaction with the service is carried out via the HTTP protocol. The result format is JSON or serialized PHP data. There are no restrictions on the number of requests. The API-functions interface can be extended if necessary. If you lack any function,go to <a href="/support">support</a>.</p>

		</div>

<div class="bs-docs-section"><div class="row">
	
	<div class="col-md-3 col-sm-6"><div class="info-box bg-blue">
		<span class="info-box-icon"><i class="fa fa-cogs"></i></span>
		<div class="info-box-content">
			<div class="info-box-texts">Work principles</div>
			<a href="#principles" class="btn btn-sm btn-block btn-primary">Read more</a>
		</div>
	</div></div>

	<div class="col-md-3 col-sm-6"><div class="info-box bg-aqua">
		<span class="info-box-icon"><i class="fa fa-user-secret"></i></span>
		<div class="info-box-content">
			<div class="info-box-texts">Webmaster</div>
			<a href="#webmaster" class="btn btn-sm btn-block btn-primary">Read more</a>
		</div>
	</div></div>

	<div class="col-md-3 col-sm-6"><div class="info-box bg-green">
		<span class="info-box-icon"><i class="fa fa-shopping-basket"></i></span>
		<div class="info-box-content">
			<div class="info-box-texts">Provider</div>
			<a href="#sale" class="btn btn-sm btn-block btn-success">Read more</a>
		</div>
	</div></div>

	<div class="col-md-3 col-sm-6"><div class="info-box bg-red">
		<span class="info-box-icon"><i class="fa fa-users"></i></span>
		<div class="info-box-content">
			<div class="info-box-texts">Agency</div>
			<a href="#ext" class="btn btn-sm btn-block btn-danger">Read more</a>
		</div>
	</div></div>
	
</div></div>

		<div class="bs-docs-section">

			<div class="page-header"><h1 id="principles">Work principles</h1></div>
			<p>To start work with API-interface, you need to get ID and key. They are avaliable in system paragraph «<a href="/profile">Profile</a>». Further user ID will be denoted <code>{user}</code>, access key - <code>{key}</code>.</p>
			<p>API-interface includes several applications <code>{app}</code> with a set of available functions <code>{func}</code>.</p>
			<p>To adress API-function send POST request to adress type:</p>
			<pre><code><?php 
echo $api;
?>{app}/{func}.{format}?id={user}-{key}</code></pre>
			<p>URL request consists of the following parts:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Parameter</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>{app}</code></td>
                    	<td>Application identifier:
                    		<ul>
                    			<li><code>wm</code> - interface <a href="#webmaster">webmaster</a></li>
                    			<li><code>sale</code> - interface <a href="#sale">provider</a></li>
                    			<li><code>ext</code> - interface<a href="#ext">agency</a></li>
                    		</ul>
                    	</td>
					</tr>
					<tr>
                    	<td><code>{func}</code></td>
                    	<td>Function identifier within the application.</td>
					</tr>
					<tr>
                    	<td><code>{format}</code></td>
                    	<td>Returned result format:
                    		<ul>
                    			<li><code>serial</code> - serial data PHP, Intended for processing with function <code>unserialize</code></li>
                    			<li><code>json</code> - data in JSON format</li>
                    			<li><code>xml</code> - data in XML format</li>
                    			<li><code>text</code> - parameters line data, similar data used in URL: <code>param1=value1&amp;param2=value2</code></li>
                    			<li><code>raw</code> -Raw data (used for some functions)</li>
                    		</ul>
                    	</td>
					</tr>
					<tr>
                    	<td><code>{user}</code></td>
                    	<td>User identifier in system</td>
					</tr>
					<tr>
                    	<td><code>{key}</code></td>
                    	<td>User API-key</td>
					</tr>
            	</tbody>
			</table></div>
			<p>Request data is sent in POST part of request.</p>
			<p>The function for work with our interface in PHP is presented below:</p>

<pre><code class="php"><span style="color: #000000"><span style="color: #0000BB">&lt;?php

</span><span style="color: #FF8000">/**
&nbsp;*&nbsp;Interaction&nbsp;with&nbsp;service&nbsp; <?php 
echo $core->config('site', 'name');
?> 
&nbsp;*&nbsp;@param&nbsp;$id&nbsp;Your&nbsp;ID&nbsp;in&nbsp;system
&nbsp;*&nbsp;@param&nbsp;$key&nbsp;Your&nbsp;API-key
&nbsp;*&nbsp;@param&nbsp;$app&nbsp;Application&nbsp;for&nbsp;intersction&nbsp;(wm,&nbsp;ext&nbsp;or&nbsp;sale)
&nbsp;*&nbsp;@param&nbsp;$func&nbsp;Requested&nbsp;function
&nbsp;*&nbsp;@param&nbsp;$data&nbsp;Array&nbsp;parameters
&nbsp;*&nbsp;@param&nbsp;$format&nbsp;Format&nbsp;returned&nbsp;result&nbsp;(serial,&nbsp;json,&nbsp;raw)
&nbsp;*&nbsp;@return&nbsp;array&nbsp;Result&nbsp;implementation
&nbsp;*/
</span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">apimycpa&nbsp;</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$id</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$key</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$app</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$func</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$data&nbsp;</span><span style="color: #007700">=&nbsp;array(),&nbsp;</span><span style="color: #0000BB">$format&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'serial'&nbsp;</span><span style="color: #007700">)&nbsp;{

&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$url&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'<?php 
echo $api;
?>'&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$app&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">'/'&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$func&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">'.'&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$format&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">'?id='&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$id&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">'-'&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$key</span><span style="color: #007700">;
&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$curl&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">curl_init</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$url&nbsp;</span><span style="color: #007700">);
&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">curl_setopt</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$curl</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">CURLOPT_RETURNTRANSFER</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">true&nbsp;</span><span style="color: #007700">);
&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">curl_setopt</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$curl</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">CURLOPT_TIMEOUT</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">30&nbsp;</span><span style="color: #007700">);
&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">curl_setopt</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$curl</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">CURLOPT_POST</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">1&nbsp;</span><span style="color: #007700">);
&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">curl_setopt</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$curl</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">CURLOPT_POSTFIELDS</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$data&nbsp;</span><span style="color: #007700">);
&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$result&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">curl_exec</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$curl&nbsp;</span><span style="color: #007700">);
&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">curl_close</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$curl&nbsp;</span><span style="color: #007700">);

&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">switch&nbsp;(&nbsp;</span><span style="color: #0000BB">$format&nbsp;</span><span style="color: #007700">)&nbsp;{
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #DD0000">'raw'</span><span style="color: #007700">:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$result</span><span style="color: #007700">;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #DD0000">'json'</span><span style="color: #007700">:&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">json_decode</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$result</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">true&nbsp;</span><span style="color: #007700">);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #DD0000">'text'</span><span style="color: #007700">:&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">parse_str</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$result</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">);&nbsp;return&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;default:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">unserialize</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$result&nbsp;</span><span style="color: #007700">);
&nbsp;&nbsp;&nbsp;&nbsp;}

}</span></code></pre>

		<p>This function receives the following parameters on the input:</p>
		<div class="box"><table class="table table-striped">
           	<thead><tr>
				<th>Parameter</th>
				<th>Type</th>
				<th>Description</th>
           	</tr></thead>
           	<tbody>
				<tr>
                   	<td><code>$id</code></td>
                   	<td><code>int</code></td>
                   	<td>User identifier in system</td>
				</tr>
				<tr>
                   	<td><code>$key</code></td>
                   	<td><code>string</code></td>
                   	<td>User's API-key</td>
				</tr>
				<tr>
                   	<td><code>$app</code></td>
                   	<td><code>string</code></td>
                   	<td>Идентификатор приложения</td>
				</tr>
				<tr>
                   	<td><code>$func</code></td>
                   	<td><code>string</code></td>
                   	<td>Application identifier</td>
				</tr>
				<tr>
                   	<td><code>$data</code></td>
                   	<td><code>array</code></td>
                   	<td>Array of function parameters (optional)</td>
				</tr>
				<tr>
                   	<td><code>$format</code></td>
                   	<td><code>string</code></td>
                   	<td>Format of returned result (optional)</td>
				</tr>
           	</tbody>
		</table></div>
		<p>Function returns result array in case formats<code>json</code>, <code>serial</code> or <code>text</code>, and clear output for format <code>raw</code>.</p>


		</div>

		<div class="bs-docs-section">

			<div class="page-header"><h1 id="webmaster">Webmaster</h1></div>
			<p>Webmaster functions allow you to work with flows and receive statistical information about the account. To work with all functions, you need to access the application<code>wm</code>.</p>
			<p>URL: <code><?php 
echo $api;
?>wm/{function}.json?id={user}-{key}</code></p>

			<h2 id="offers">Offers list</h2>
			<p>URL: <code><?php 
echo $api;
?>wm/offers.json?id={user}-{key}</code></p>
			<p>Funtcion ID- <code>offers</code>. The function allows you to get active offers list, their description and conversion data. This function does not accept any additional parameters.</p>
			<p>The result of the function is an associative array of offers list with the following fields:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>id</code></td>
                    	<td>Offer identifier in system</td>
					</tr>
					<tr>
                    	<td><code>name</code></td>
                    	<td>Offer name</td>
					</tr>
					<tr>
                    	<td><code>descr</code></td>
                    	<td>Offer description</td>
					</tr>
					<tr>
                    	<td><code>price</code></td>
                    	<td>One offer item cost (without delivery)</td>
					</tr>
					<tr>
                    	<td><code>wm</code></td>
                    	<td>Wematers offer deductions</td>
					</tr>
					<tr>
                    	<td><code>geo</code></td>
                    	<td>Supported offer's GEO,  list of ISO country codes separated by commas, in format<code>ru,by,kz</code></td>
					</tr>
					<tr>
                    	<td><code>epc</code></td>
                    	<td>EPC - Earn Per Click, average income per click</td>
					</tr>
					<tr>
                    	<td><code>cr</code></td>
                    	<td>Convert Ratio, correlation of unique visitors to successful orders</td>
					</tr>
					<tr>
                    	<td><code>flows</code></td>
                    	<td>Number of created flows for this offer</td>
					</tr>
					<tr>
                    	<td><code>male</code></td>
                    	<td>Percentage of successful orders made by men</td>
					</tr>
					<tr>
                    	<td><code>female</code></td>
                    	<td>Percentage of successful orders made by women</td>
					</tr>
            	</tbody>
			</table></div>

			<h2 id="offersite">Offer sites</h2>
			<p>URL: <code><?php 
echo $api;
?>wm/sites.json?id={user}-{key}</code></p>
			<p> function ID - <code>sites</code>. Function allows you to get a list of sites attached to the specified offer. At the input function gets one parameter: <code>offer</code> - identifier of offer? for which you want to get a list of sites.</p>
			<p>Function result is an associative array with two fields: <code>land</code> and <code>space</code>. The first contains a list of landings of this offer, the second - a list of available pre-lands. For each of the sites the following information is provided:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>id</code></td>
                    	<td>Site identifier in system</td>
					</tr>
					<tr>
                    	<td><code>url</code></td>
                    	<td>Website full address</td>
					</tr>
					<tr>
                    	<td><code>epc</code></td>
                    	<td>EPC - Earn Per Click, average revenue per click</td>
					</tr>
					<tr>
                    	<td><code>cr</code></td>
                    	<td>Convert Ratio, ratio of unique visitors to the number of successful orders</td>
					</tr>
            	</tbody>
			</table></div>


			<h2 id="flows">Flows list</h2>
			<p>URL: <code><?php 
echo $api;
?>wm/flows.json?id={user}-{key}</code></p>
			<p>function ID - <code>flows</code>. The function returns flows list created by webmaster. At the input, the function gets one parameter: <code>offer</code> - offer identifier, for which it is necessary to get a list of existing flows.</p>
			<p>The result of the function is an associative array with a list of flows:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>id</code></td>
                    	<td>Flow identifier in system</td>
					</tr>
					<tr>
                    	<td><code>offer</code></td>
                    	<td>offer's flow ID</td>
					</tr>
					<tr>
                    	<td><code>offername</code></td>
                    	<td>Offer flow name</td>
					</tr>
					<tr>
                    	<td><code>name</code></td>
                    	<td>Flow name</td>
					</tr>
					<tr>
                    	<td><code>epc</code></td>
                    	<td>EPC - Earn Per Click, average revenue per click</td>
					</tr>
					<tr>
                    	<td><code>cr</code></td>
                    	<td>Convert Ratio, ratio of unique visitors to the number of successful orders</td>
					</tr>
					<tr>
                    	<td><code>total</code></td>
                    	<td>Total earnings by stream</td>
					</tr>
            	</tbody>
			</table></div>

			<h2 id="flowadd">Flow creating</h2>
			<p>URL: <code><?php 
echo $api;
?>wm/add.json?id={user}-{key}</code></p>
			<p>function ID - <code>add</code>. Tunction creates new offel flow.</p>
			<p>At the input, the function gats the following parameters:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>offer</code></td>
                    	<td>offer flow ID (см. <a href="#offers">offer list</a>)</td>
					</tr>
					<tr>
                    	<td><code>name</code></td>
                    	<td>Flow name (optional)</td>
					</tr>
            	</tbody>
			</table></div>
			<p>The result of the function is an associative array:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Operation result: <code>ok</code> if successful, <code>error</code> if mistake</td>
					</tr>
					<tr>
                    	<td><code>id</code></td>
                    	<td>Craeted flow identifier</td>
					</tr>
					<tr>
                    	<td><code>error</code></td>
                    	<td>Error identifier <code>offer-inactive</code> while working with inactive offer, <code>request-error</code> in case of system error</td>
					</tr>
            	</tbody>
			</table></div>

			<h2 id="flowedit">Editing flow</h2>
			<p>URL: <code><?php 
echo $api;
?>wm/edit.json?id={user}-{key}</code></p>
			<p>Function ID - <code>edit</code>. Function allows to rename flow.</p>
			<p>At the input, the function receives the following parameters:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>flow</code></td>
                    	<td>Editing flow ID</td>
					</tr>
					<tr>
                    	<td><code>name</code></td>
                    	<td>New flow name</td>
					</tr>
            	</tbody>
			</table></div>
			<p>The result of the function is an associative array:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Operation result: <code>ok</code> if success, <code>error</code>if error</td>
					</tr>
					<tr>
                    	<td><code>error</code></td>
                    	<td>Error identifier: <code>access-denied</code> while working with denied flow, <code>request-error</code> in case of system error</td>
					</tr>
            	</tbody>
			</table></div>

			<h2 id="flowdel">Deleting flow</h2>
			<p>URL: <code><?php 
echo $api;
?>wm/del.json?id={user}-{key}</code></p>
			<p>function ID - <code>del</code>. Function deletes flow.</p>
			<div class="well text-danger"><b>Important!</b> Before deleting flow make sure all offers "awaiting" are done, otherwise <b> allocations for the order will not be charged</b>!</div>
			<p>At the input, the function receives the following parameters:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>flow</code></td>
                    	<td>Flow for deleting ID</td>
					</tr>
            	</tbody>
			</table></div>
			<p>The result of the function is an associative array:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Operation result: <code>ok</code> if success, <code>error</code>if error</td>
					</tr>
					<tr>
                    	<td><code>error</code></td>
                    	<td>Error identifier: <code>access-denied</code> while working with denied flow, <code>request-error</code> in case of system error</td>
					</tr>
            	</tbody>
			</table></div>

			<h2 id="push">Adding lead</h2>
			<p>URL: <code><?php 
echo $api;
?>wm/push.json?id={user}-{key}</code></p>
			<p>function ID - <code>push</code>. The function allows you to add a new lead on behalf of the webmaster. Data of new lead is sent in  POST request.</p>
			<p class="text-danger"><strong>Attention!</strong> This function is disabled by default, it can be activated for you only on request!</p>
			<p>At the input, the function takes the following data about lead:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>flow</code>*</td>
                    	<td>Offer flow identifier (required)</td>
					</tr>
					<tr>
                    	<td><code>offer</code>*</td>
                    	<td>Offer identifier from <a href="#offers">list</a> (required)</td>
					</tr>
					<tr>
                    	<td><code>ip</code>*</td>
                    	<td>Customer IP (required)</td>
					</tr>
					<tr>
                    	<td><code>name</code></td>
                    	<td>Customer's full name</td>
					</tr>
					<tr>
                    	<td><code>phone</code>*</td>
                    	<td>Customer's phone number in the format +19876543210 (required)</td>
					</tr>
					<tr>
                    	<td><code>email</code></td>
                    	<td>Customer's E-mail address</td>
					</tr>
					<tr>
                    	<td><code>ua</code></td>
                    	<td>Customer's browser User-Agent</td>
					</tr>						
					<tr>
                    	<td><code>country</code></td>
                    	<td>Two-letter code of customer's country, is defined with IP</td>
					</tr>
					<tr>
                    	<td><code>currency</code></td>
                    	<td>Three-letter code customer's currency, for example RUB or BYR, is defined default with country of the customer</td>
					</tr>
					<tr>
                    	<td><code>index</code></td>
                    	<td>Postal address of delivery address in the format 127000</td>
					</tr>
					<tr>
                    	<td><code>addr</code></td>
                    	<td>Delivery address. Can contain a complete address without an index, if fields are not used below. Otherwise, only contains the number of the house, enclosure, apartment or office.</td>
					</tr>
					<tr>
                    	<td><code>area</code></td>
                    	<td>Delivery region, for example, Moscow region.</td>
					</tr>
					<tr>
                    	<td><code>city</code></td>
                    	<td>City of delivery, for example, Moscow</td>
					</tr>
					<tr>
                    	<td><code>street</code></td>
                    	<td>Street at the address of delivery, for example Mira st.</td>
					</tr>
					<tr>
                    	<td><code>count</code></td>
                    	<td>Quantity of items.</td>
					</tr>
					<tr>
                    	<td><code>discount</code></td>
                    	<td>Discount for items in percent.</td>
					</tr>
					<tr>
                    	<td><code>more</code></td>
                    	<td>Additional cost of the order, for example, extra charge for express delivery.</td>
					</tr>
					<tr>
                    	<td><code>comm</code></td>
                    	<td>Additional comment on the order.</td>
					</tr>
					<tr>
                    	<td><code>us</code></td>
                    	<td><code>utm_source</code></td>
					</tr>
					<tr>
                    	<td><code>uc</code></td>
                    	<td><code>utm_campaign</code></td>
					</tr>
					<tr>
                    	<td><code>un</code></td>
                    	<td><code>utm_content</code></td>
					</tr>
					<tr>
                    	<td><code>ut</code></td>
                    	<td><code>utm_term</code></td>
					</tr>
					<tr>
                    	<td><code>um</code></td>
                    	<td><code>utm_medium</code></td>
					</tr>					
					<tr>
                    	<td><code>promo</code></td>
                    	<td>Promo code specified by the customer.</td>
					</tr>
					<tr>
                    	<td><code>mobile</code></td>
                    	<td>Please specify <code>0</code> for desktop traffic and <code>1</code> for mobile traffic</td>
					</tr>
					<tr>
                    	<td><code>bad</code></td>
                    	<td>Please specify <code>0</code> for normal traffic and <code>1</code> for suspicious traffic</td>
					</tr>
            	</tbody>
			</table></div>

			<p>The result of the function is an associative array:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Operation result: <code>ok</code> if success, <code>error</code>if error</td>
					</tr>
					<tr>
                    	<td><code>id</code></td>
                    	<td> Added order identifier (if success)</td>
					</tr>
					<tr>
                    	<td><code>error</code></td>
                    	<td>Error identifier: <code>nooffer</code> if no offer identifier, <code>noflow</code> if no flow identifier,<code>badflow</code> if flow identifier is incorrect, <code>nophone</code> if no phone number, <code>duplicate</code> if orders with same number are already processing, <code>offer</code> if offer is not found, <code>security</code> if customer has ban, <code>ban</code> if phone number or IP-adress are banned, <code>db</code> if error while adding data.</td>
					</tr>
            	</tbody>
			</table></div>
			<p>Example of function response:</p>
			<pre><code>{ "status" : "ok", "id" : 1234 }</code></pre>

			<h2 id="stats">Statistics by date</h2>
			<p>URL: <code><?php 
echo $api;
?>wm/stats.json?id={user}-{key}</code></p>
			<p>function ID - <code>stats</code>. The function provides statistics on clicks and orders, break down by date, similar to the section «<a href="/stats">Statistics</a>».</p>
			<p>At the input, the function receives the following parameters:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>from</code></td>
                    	<td>Statistics beginning date in format<code>YYYY-MM-DD</code>. Optional. The default date is a week ago.</td>
					</tr>
					<tr>
                    	<td><code>to</code></td>
                    	<td>End date of statistics in format <code>YYYY-MM-DD</code>. Optional. The default is today.</td>
					</tr>
					<tr>
                    	<td><code>offer</code></td>
                    	<td>Offer statistics ID. Optional. By default statistics are displayed for all offers.</td>
					</tr>
					<tr>
                    	<td><code>flow</code></td>
                    	<td>Flow statistics ID. Optional. By default, statistics is given for all flows.</td>
					</tr>
            	</tbody>
			</table></div>
			<p>The result of the function is an associative array. Each element identifier is statistics date in format<code>YYYYMMDD</code>. Each element includes the following fields:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>stat_date</code></td>
                    	<td>Statistics date in format <code>YYYYMMDD</code></td>
					</tr>
					<tr>
                    	<td><code>spaces</code></td>
                    	<td>Number of prelanding clicks</td>
					</tr>
					<tr>
                    	<td><code>suni</code></td>
                    	<td>Number of <b>unique</b> prelanding clicks</td>
					</tr>
					<tr>
                    	<td><code>clicks</code></td>
                    	<td>Number of landing clicks</td>
					</tr>
					<tr>
                    	<td><code>unique</code></td>
                    	<td>Number of <b>unique</b> landing clicks</td>
					</tr>
					<tr>
                    	<td><code>ca</code></td>
                    	<td>Number of orders in status «Accepted» <small class="text-muted">(count accepted)</small></td>
					</tr>
					<tr>
                    	<td><code>sa</code></td>
                    	<td>Sum of leads in status «Accepted» <small class="text-muted">(sum accepted)</small></td>
					</tr>
					<tr>
                    	<td><code>cc</code></td>
                    	<td>Number of orders in status «Canceled» <small class="text-muted">(count canceled)</small></td>
					</tr>
					<tr>
                    	<td><code>sc</code></td>
                    	<td>Sum of leads in status «Canceled» <small class="text-muted">(sum canceled)</small></td>
					</tr>
					<tr>
                    	<td><code>cw</code></td>
                    	<td>Number of orders in status «Waiting» <small class="text-muted">(count waiting)</small></td>
					</tr>
					<tr>
                    	<td><code>sw</code></td>
                    	<td>Sum of leads in status «Waiting» <small class="text-muted">(sum waiting)</small></td>
					</tr>
            	</tbody>
			</table></div>

			<h2 id="lead">Leads statistics</h2>
			<p>URL: <code><?php 
echo $api;
?>wm/lead.json?id={user}-{key}</code></p>
			<p>function ID - <code>lead</code>. The function provides a list of leads for the specified date and their status.</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>day</code></td>
                    	<td>Statistics date in format <code>YYYY-MM-DD</code>. Optional. The default is today.</td>
					</tr>
					<tr>
                    	<td><code>offer</code></td>
                    	<td>Statistics offer ID. Optional. By default, statistics are displayed for all offers.</td>
					</tr>
					<tr>
                    	<td><code>flow</code></td>
                    	<td>Statistics flow ID. Optional. By default, statistics is given for all flows</td>
					</tr>
					<tr>
                    	<td><code>site</code></td>
                    	<td>Site identifier. You can get a list of sites using the function <a href="#offersite">offersite</a>.</td>
					</tr>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Order status:
                    		<ul>
                    			<li><code>a</code> - accepted leads</li>
                    			<li><code>w</code> - waiting leads</li>
                    			<li><code>c</code> - canceled leads</li>
                    			<li><code>unknown</code> - all leads</li>
                    		</ul>
                    	</td>
					</tr>
            	</tbody>
			</table></div>
			<p>Function result is leads array. Each element includes the following fields:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>time</code></td>
                    	<td>Order time in format UNIX-timestamp</td>
					</tr>
					<tr>
                    	<td><code>status</code></td>
                    	<td>order status identifier
                    		<ul>
                    			<li><code>1</code> - new order</li>
                    			<li><code>2</code> -  processing order</li>
                    			<li><code>3</code> - recall</li>
                    			<li><code>4</code> - missed call</li>
                    			<li><code>5</code> - order canceled</li>
                    			<li><code>10</code> - order accepted</li>
                    			<li><code>12</code> - order deleted</li>
                    		</ul>
                    	</td>
					</tr>
					<tr>
                    	<td><code>status_text</code></td>
                    	<td>Status text value</td>
					</tr>
					<tr>
                    	<td><code>reason</code></td>
                    	<td>Denied reasons identifier
                    		<ul>
								<li><code>1</code> - Invalid number <i>(trash)</i></li>
								<li><code>2</code> - Client changed his mind</li>
								<li><code>3</code> - Client didn't order <i>(trash)</i></li>
								<li><code>4</code> - Demand certificate</li>
								<li><code>5</code> - Invalid GEO <i>(trash)</i></li>
								<li><code>6</code> - Error or fake <i>(trash)</i></li>
								<li><code>7</code> - Doubled order <i>(trash)</i></li>
								<li><code>8</code> - Ordered in another place <i>(trash)</i></li>
								<li><code>9</code> - Expensive</li>
								<li><code>10</code> - Not satisfied with delivery</li>
								<li><code>11</code> - Missed call</li>
								<li><code>12</code> - Suspicious or fraud <i>(trash)</i></li>
                    		</ul>
                    	</td>
					</tr>
					<tr>
                    	<td><code>reason_text</code></td>
                    	<td>Text value of failure reason</td>
					</tr>
					<tr>
                    	<td><code>offer</code></td>
                    	<td>Offer identifier</td>
					</tr>
					<tr>
                    	<td><code>offer_name</code></td>
                    	<td>Offer name</td>
					</tr>
					<tr>
                    	<td><code>flow</code></td>
                    	<td>Flow identifier</td>
					</tr>
					<tr>
                    	<td><code>site</code></td>
                    	<td>Landing identifier</td>
					</tr>
					<tr>
                    	<td><code>site_url</code></td>
                    	<td>Landing URL</td>
					</tr>
					<tr>
                    	<td><code>space</code></td>
                    	<td>Prelanding identifier</td>
					</tr>
					<tr>
                    	<td><code>space_url</code></td>
                    	<td>Prelanring URL</td>
					</tr>
					<tr>
                    	<td><code>ip</code></td>
                    	<td>client IP</td>
					</tr>
            	</tbody>
			</table></div>

		</div>

		<div class="bs-docs-section">
			<div class="page-header"><h1 id="sale">Provider</h1></div>
			<p>Provider's API-interface allows you to integrate your own interface with our orders processing system. To work with all functions, you need to access the application <code>sale</code>.</p>
			<p>URL: <code><?php 
echo $api;
?>sale/{function}.json?id={user}-{key}</code></p>

			<h2 id="orderlist">Orders list</h2>
			<p>URL: <code><?php 
echo $api;
?>sale/list.json?id={user}-{key}</code></p>
			<p>function ID - <code>list</code>. Function allows to get order list. Selection parameters can be passed in a GET or POST request.</p>
			<p>At the input, the function can use the following parameters for orders selection:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>oid</code></td>
                    	<td>Internal order identifier <?php 
echo $core->config('site', 'name');
?> or identifiers list separated by commas</td>
					</tr>
					<tr>
                    	<td><code>ids[]</code></td>
                    	<td>Array of internal order identifiers <?php 
echo $core->config('site', 'name');
?>.</td>
					</tr>
					<tr>
                    	<td><code>eid</code></td>
                    	<td>External order identifier in provider interface or identifiers list separated by commas</td>
					</tr>
					<tr>
                    	<td><code>eids[]</code></td>
                    	<td>Array of external order identifier from provider interface.</td>
					</tr>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Order status. Besides basic status (see. field<code>status</code> in the table below) can receive additional values:
							<ul>
                    			<li><code>-1</code> - Orders without refusals</li>
	  							<li><code>-2</code> - Orders in processing</li>
	  							<li><code>-3</code> - Confirmed orders</li>
	  						</tr>
                    	</td>
					</tr>
					<tr>
                    	<td><code>from</code><br /><code>to</code></td>
                    	<td>Time selection of orders from<code>from</code> to <code>to</code>.  Time is specified in the UNIX-timestamp format. Can use both both parameters simultaneously, and one of the parameters separately. It is useful for forming order uploads to your interface, but for this task it is recommended to use the field below.</td>
					</tr>
					<tr>
                    	<td><code>after</code></td>
                    	<td>Last got order dentifier, after which issuing starts. It is useful for forming order uploads to your interface - The order list is requested each time with the ID of the last order received, and only the new orders that come after the specified order are displayed.</td>
					</tr>
				</tbody>
			</table></div>
			<p>Function result is an array of elements with following fields:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>id</code></td>
                    	<td>Order identifier orderа within the framework <?php 
echo $core->config('site', 'name');
?></td>
					</tr>
					<tr>
                    	<td><code>ext</code></td>
                    	<td>External order identifier  (in case of interfaces integration)</td>
					</tr>
					<tr>
                    	<td><code>offer</code></td>
                    	<td>Offer dentifier(see <a href="#offers">list</a>)</td>
					</tr>
					<tr>
                    	<td><code>wm</code></td>
                    	<td>Webmaster identifier</td>
					</tr>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Current order status. Accepts one of the following values:
							<ul>
                    			<li><code>1</code> - New order</li>
	  							<li><code>2</code> - Processing</li>
	  							<li><code>3</code> - Recall</li>
	  							<li><code>4</code> - Missed call</li>
	  							<li><code>5</code> - Canceled</li>
	  							<li><code>6</code> - Packaging</li>
	  							<li><code>7</code> - Sending</li>
	  							<li><code>8</code> - On the way</li>
	  							<li><code>9</code> - Delivered</li>
	  							<li><code>10</code> - Paid</li>
	  							<li><code>11</code> - Return</li>
	  							<li><code>12</code> - Test or fraud</li>
                    		</ul>
                    	</td>
					</tr>
					<tr>
                    	<td><code>reason</code></td>
                    	<td>Reason for failure code. Accepts one of the following values:
							<ul>
								<li><code>1</code> - Invalid number <i>(trash)</i></li>
								<li><code>2</code> - Client changed his mind</li>
								<li><code>3</code> - Client didn't order <i>(trash)</i></li>
								<li><code>4</code> - Demand certificate</li>
								<li><code>5</code> - Invalid GEO <i>(trash)</i></li>
								<li><code>6</code> - Error or fake <i>(trash)</i></li>
								<li><code>7</code> - Doubled order <i>(trash)</i></li>
								<li><code>8</code> - Ordered in another place <i>(trash)</i></li>
								<li><code>9</code> - Expensive</li>
								<li><code>10</code> - Not satisfied with delivery</li>
								<li><code>11</code> - Missed call</li>
								<li><code>12</code> - Suspicious or fraud <i>(trash)</i></li>
                    		</ul>
                    	</td>
					</tr>
					<tr>
                    	<td><code>check</code></td>
                    	<td>Order security flag for security review. <code>1</code> - order is suspicious and is on check.</td>
					</tr>
					<tr>
                    	<td><code>calls</code></td>
                    	<td>Number of calls for this offer</td>
					</tr>
					<tr>
                    	<td><code>site</code></td>
                    	<td>Landing address from which order was executed </td>
					</tr>
					<tr>
                    	<td><code>ip</code></td>
                    	<td>client IP</td>
					</tr>
					<tr>
                    	<td><code>time</code></td>
                    	<td>The time of receiving order in the format UNIX-timestamp</td>
					</tr>
					<tr>
                    	<td><code>name</code></td>
                    	<td>Client's full name</td>
					</tr>
					<tr>
                    	<td><code>gender</code></td>
                    	<td>Client's sex. 1 - male, 2 - female. Determined automatically.</td>
					</tr>
					<tr>
                    	<td><code>phone</code></td>
                    	<td>Customer's phone number in the format 79876543210 </td>
					</tr>
					<tr>
                    	<td><code>country</code></td>
                    	<td>Two-letter code of customer's country, is defined with IP</td>
					</tr>
					<tr>
                    	<td><code>index</code></td>
                    	<td>Postal address of delivery address in the format 127000</td>
					</tr>
					<tr>
                    	<td><code>addr</code></td>
                    	<td>Delivery address. Can contain a complete address without an index, if fields are not used below. Otherwise, only contains the number of the house, enclosure, apartment or office.</td>
					</tr>
					<tr>
                    	<td><code>area</code></td>
                    	<td>Delivery region, for example, Moscow region.</td>
					</tr>
					<tr>
                    	<td><code>city</code></td>
                    	<td>City of delivery, for example, Moscow</td>
					</tr>
					<tr>
                    	<td><code>street</code></td>
                    	<td>Street at the address of delivery, for example Mira st.</td>
					</tr>
					<tr>
                    	<td><code>count</code></td>
                    	<td>Quantity of items.</td>
					</tr>
					<tr>
                    	<td><code>items</code></td>
                    	<td>Order set, number of items. An array in which the key is the variant identifier, the value is the quantity of the product of the given type.</td>
					</tr>
					<tr>
                    	<td><code>delivery</code></td>
                    	<td>Used shipping service:
							<ul>
                    			<li><code>1</code> - Default delivery service</li>
								<li><code>2</code> - Express delivery service</li>
							</ul>
                    	</td>
					</tr>
					<tr>
                    	<td><code>discount</code></td>
                    	<td>Discount for items in percent.</td>
					</tr>
					<tr>
                    	<td><code>more</code></td>
                    	<td>Additional cost of the order, for example, extra charge for express delivery.</td>
					</tr>
					<tr>
                    	<td><code>price</code></td>
                    	<td>General order price.</td>
					</tr>
					<tr>
                    	<td><code>comment</code></td>
                    	<td>Additional comment on the order.</td>
					</tr>
            	</tbody>
			</table></div>

			<h2 id="orderedit">Order editing</h2>
			<p>URL: <code><?php 
echo $api;
?>sale/edit.json?id={user}-{key}</code></p>
			<p>function ID - <code>edit</code>. Function allows to edit the fields of existing order, update its status. Part of parameters can be passed to GET part of the request.</p>
			<p>At the input, the function receives the following parameters:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>oid</code> <br /> <code>eid</code></td>
                    	<td>Active order identifier. Field <code>oid</code>  is used to indicate the internal order identifier in the  <?php 
echo $core->config('site', 'name');
?>, field<code>eid</code> used to work with an order ID on the supplier side. Required field of request. Can be transferred to GET.</td>
					</tr>
					<tr>
                    	<td><code>accept</code></td>
                    	<td>Order acception flag. Set to 1 if order is currently approved on the supplier side. Can be transferred to GET.</td>
					</tr>
					<tr>
                    	<td><code>status</code></td>
                    	<td>New status order identifier. Can be transferred to GET. Accepts one of the following values:
							<ul>
                    			<li><code>1</code> - New order</li>
	  							<li><code>2</code> - Processing</li>
	  							<li><code>3</code> - Recall</li>
	  							<li><code>4</code> - Missed call</li>
	  							<li><code>5</code> - Canceled</li>
	  							<li><code>6</code> - Packaging</li>
	  							<li><code>7</code> - Sending</li>
	  							<li><code>8</code> - On the way</li>
	  							<li><code>9</code> - Delivered</li>
	  							<li><code>10</code> - Paid</li>
	  							<li><code>11</code> - Return</li>
	  							<li><code>12</code> - Test or fraud</li>
                    		</ul>
							To cancel order put status 5 and field <code>reason</code>. <br />
							<span class="text-danger"><b>Important!</b> To confirm order use field <code>accept=1</code>, but not changing order status!</span>
                    	</td>
					</tr>
					<tr>
                    	<td><code>reason</code></td>
                    	<td>Reason for failure code is required for indication when setting the status <code>status=5</code>. Can be transferred to GET. Accepts one of the following values:
							<ul>
								<li><code>1</code> - Invalid number <i>(trash)</i></li>
								<li><code>2</code> - Client changed his mind</li>
								<li><code>3</code> - Client didn't order <i>(trash)</i></li>
								<li><code>4</code> - Demand certificate</li>
								<li><code>5</code> - Invalid GEO <i>(trash)</i></li>
								<li><code>6</code> - Error or fake <i>(trash)</i></li>
								<li><code>7</code> - Doubled order <i>(trash)</i></li>
								<li><code>8</code> - Ordered in another place <i>(trash)</i></li>
								<li><code>9</code> - Expensive</li>
								<li><code>10</code> - Not satisfied with delivery</li>
								<li><code>11</code> - Missed call</li>
								<li><code>12</code> - Suspicious or fraud <i>(trash)</i></li>
                    		</ul>
                    	</td>
					</tr>
					<tr>
                    	<td><code>check</code></td>
                    	<td>Flag of the security order. <code>1</code> - send for review, <code>0</code> - remove from cheking. Can be transferred to GET.</td>
					</tr>
					<tr>
                    	<td><code>track</code></td>
                    	<td>Track code of sent shipment. Can be transferred to GET.</td>
					</tr>
					<tr>
                    	<td><code>calls</code></td>
                    	<td>Increase the number of calls made for this order. <b class="text-warning">Important!</b> This field does not indicate the total number of calls, but only its increment. This means that if one call on order has been made since the last update of the number of calls put 1.</td>
					</tr>
					<tr>
                    	<td><code>name</code></td>
                    	<td>Customer's full name</td>
					</tr>
					<tr>
                    	<td><code>phone</code></td>
                    	<td>Customer's phone number in the format 79876543210 (only numbers)</td>
					</tr>
					<tr>
                    	<td><code>index</code></td>
                    	<td>Postal address of delivery address in the format 127000 (only numbers)</td>
					</tr>
					<tr>
                    	<td><code>addr</code></td>
                    	<td>Delivery address. Can contain a complete address without an index, if fields are not used below. Otherwise, only contains the number of the house, enclosure, apartment or office.</td>
					</tr>
					<tr>
                    	<td><code>area</code></td>
                    	<td>Delivery region, for example, Moscow region.</td>
					</tr>
					<tr>
                    	<td><code>city</code></td>
                    	<td>City of delivery, for example, Moscow</td>
					</tr>
					<tr>
                    	<td><code>street</code></td>
                    	<td>Street at the address of delivery, for example Mira st.</td>
					</tr>
					<tr>
                    	<td><code>delivery</code></td>
                    	<td>Used shipping service:
							<ul>
                    			<li><code>1</code> - Почта России</li>
								<li><code>2</code> - СПСР-экспресс</li>
							</ul>
                    	</td>
					</tr>
					<tr>
                    	<td><code>discount</code></td>
                    	<td>Discount for items in percent. Integer from 0 to 99.</td>
					</tr>
					<tr>
                    	<td><code>count</code></td>
                    	<td>Number of items, is used for items without additional design options, size, color, etc.</td>
					</tr>
					<tr>
                    	<td><code>items</code></td>
                    	<td>Composition of the order, the number of these or other variants of items. Accepts an array at the input, in which the key is the variant identifier, the value is the quantity of the product of the given type. Identifiers of options for your product check with the administration during the integration setup. In the case of a field<code>items</code>, passing <code>count</code> is not necessary.</td>
					</tr>
					<tr>
                    	<td><code>more</code></td>
                    	<td>Amount of the additional cost of order, for example, the markup for express delivery. Is added to main order amount after all discounts.</td>
					</tr>
					<tr>
                    	<td><code>comment</code></td>
                    	<td>Additional comment on the order.</td>
					</tr>
            	</tbody>
			</table></div>
			<p>Only order identifier field is required, the remaining fields are used as needed. The result of the function is an associative array:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Operation result: <code>ok</code> if success, <code>error</code>if error</td>
					</tr>
					<tr>
                    	<td><code>error</code></td>
                    	<td>Error identifier: <code>orderid</code> In the absence of order identifier, <code>edit</code> in the absence of fields for updating (for example, if the information was not changed), <code>access-denied</code> when working with an unavailable order, <code>request-error</code> in case of system error.</td>
					</tr>
            	</tbody>
			</table></div>

		</div>

		<div class="bs-docs-section">
			<div class="page-header"><h1 id="ext">Agency</h1></div>
			<p>The API-interface of the agency allows third-party partner networks and arbitration teams to download the leads into the system and check the status of their processing by unloading. To work with all functions, you need to access the application<code>ext</code>.</p>
			<p>URL: <code><?php 
echo $api;
?>ext/{function}.json?id={user}-{key}</code></p>

			<h2 id="extadd">Adding lead</h2>
			<p>URL: <code><?php 
echo $api;
?>ext/add.json?id={user}-{key}</code></p>
			<p>function ID - <code>add</code>. The function allows you to add new lead on behalf of agency. Data of the new lead is sent in the POST request.</p>
			<p>At the input, the function takes the following data about the leader:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>id</code>*</td>
                    	<td><b>Unique </ i> order ID within the agency (required)</td>
					</tr>
					<tr>
                    	<td><code>wm</code></td>
                    	<td>Webmaster identifier or another source on the agency's side</td>
					</tr>
					<tr>
                    	<td><code>offer</code>*</td>
                    	<td>Offer identifier from <a href="#offers">list</a> (required)</td>
					</tr>
					<tr>
                    	<td><code>ip</code>*</td>
                    	<td>Customer's IP (required)</td>
					</tr>
					<tr>
                    	<td><code>name</code></td>
                    	<td>Customer's full name</td>
					</tr>
					<tr>
                    	<td><code>phone</code>*</td>
                    	<td>Customer's phone number in the format 79876543210 (required)</td>
					</tr>
					<tr>
                    	<td><code>email</code></td>
                    	<td>Customer's E-mail address</td>
					</tr>					
					<tr>
                    	<td><code>country</code></td>
                    	<td>Two-letter code of customer's country, is defined with IP</td>
					</tr>
					<tr>
                    	<td><code>currency</code></td>
                    	<td>Three-letter code customer's currency, for example RUB or BYR, is defined default with country of the customer</td>
					</tr>
					<tr>
                    	<td><code>index</code></td>
                    	<td>Postal address of delivery address in the format</td>
					</tr>
					<tr>
                    	<td><code>addr</code></td>
                    	<td>Delivery address. Can contain a complete address without an index, if fields are not used below. Otherwise, only contains the number of the house, enclosure, apartment or office.</td>
					</tr>
					<tr>
                    	<td><code>area</code></td>
                    	<td>Delivery region, for example, Moscow region.</td>
					</tr>
					<tr>
                    	<td><code>city</code></td>
                    	<td>City of delivery, for example, Moscow</td>
					</tr>
					<tr>
                    	<td><code>street</code></td>
                    	<td>Street at the address of delivery, for example Mira st. </td>
					</tr>
					<tr>
                    	<td><code>count</code></td>
                    	<td>Quantity of items.</td>
					</tr>
					<tr>
                    	<td><code>discount</code></td>
                    	<td>Discount for items in percent.</td>
					</tr>
					<tr>
                    	<td><code>more</code></td>
                    	<td>Additional cost of the order, for example, extra charge for express delivery.</td>
					</tr>
					<tr>
                    	<td><code>comm</code></td>
                    	<td>Additional comment on the order.</td>
					</tr>
					<tr>
                    	<td><code>promo</code></td>
                    	<td>Promo code specified by the customer.</td>
					</tr>
					<tr>
                    	<td><code>mobile</code></td>
                    	<td>Please specify <code>0</code> for desktop traffic and <code>1</code> for mobile traffic</td>
					</tr>
					<tr>
                    	<td><code>bad</code></td>
                    	<<td>Please specify <code>0</code> for normal traffic and <code>1</code> for suspicious traffic</td>
					</tr>
            	</tbody>
			</table></div>

			<p>The result of the function is an associative array:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Operation result: <code>ok</code> if success, <code>error</code>if error</td>
					</tr>
					<tr>
                    	<td><code>id</code></td>
                    	<td>Added order identifier (if success)</td>
					</tr>
					<tr>
                    	<td><code>error</code></td>
                    	<td>Error identifier: <code>nooffer</code> if no order identifer, <code>noid</code> in the absence of an order on agency side, <code>nophone</code> if no phone number, <code>duplicate</code> if orders with same number are already processing, <code>offer</code> if offer is not found, <code>security</code> if customer has ban, <code>ban</code> if phone number or IP-adress are banned, <code>db</code> if error while adding data.</td>
					</tr>
            	</tbody>
			</table></div>
			<p>An example of a function response:</p>
			<pre><code>{ "status" : "ok", "id" : 1234 }</code></pre>

			<h2 id="extlist">Checking leads status</h2>
			<p>URL: <code><?php 
echo $api;
?>ext/list.json?id={user}-{key}</code></p>
			<p>function ID - <code>list</code>. Function allows you to get data concerning status of processing sent leades. At the input, the function receives parameter <code>ids</code>, which contains a list of lead IDs on the agency side. The parameter can be passed in the GET or POST request. Identifiers are separated by commas. It is recommended to send no more than 50 identifiers in one query.</p>
			<p>The result of the function is the array of lead statuses. The key parameter is the order ID on the agency side. For each lead, the following parameters are specified:</p>
			<div class="box"><table class="table table-striped">
            	<thead><tr>
					<th>Field</th>
					<th>Description</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>id</code></td>
                    	<td>Order identifier on the agency side</td>
					</tr>
					<tr>
                    	<td><code>uid</code></td>
                    	<td>Order identifier on our system side</td>
					</tr>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Order status identifier. Accepts one of the following values:
							<ul>
                    			<li><code>1</code> - New order</li>
	  							<li><code>2</code> - Processing</li>
	  							<li><code>3</code> - Recall</li>
	  							<li><code>4</code> - Missed call</li>
	  							<li><code>5</code> - Canceled</li>
	  							<li><code>6</code> - Packaging</li>
	  							<li><code>7</code> - Sending</li>
	  							<li><code>8</code> - On the way</li>
	  							<li><code>9</code> - Delivered</li>
	  							<li><code>10</code> - Paid</li>
	  							<li><code>11</code> - Return</li>
	  							<li><code>12</code> - Test or fraud</li>
                    		</ul>
                    	</td>
					</tr>
					<tr>
                    	<td><code>reason</code></td>
                    	<td>Cause of failure code for status 5. Accepts one of the following values:
							<ul>
								<li><code>1</code> - Invalid number <i>(trash)</i></li>
								<li><code>2</code> - Client changed his mind</li>
								<li><code>3</code> - Client didn't order <i>(trash)</i></li>
								<li><code>4</code> - Demand certificate</li>
								<li><code>5</code> - Invalid GEO <i>(trash)</i></li>
								<li><code>6</code> - Error or fake <i>(trash)</i></li>
								<li><code>7</code> - Doubled order <i>(trash)</i></li>
								<li><code>8</code> - Ordered in another place <i>(trash)</i></li>
								<li><code>9</code> - Expensive</li>
								<li><code>10</code> - Not satisfied with delivery</li>
								<li><code>11</code> - Missed call</li>
								<li><code>12</code> - Suspicious or fraud <i>(trash)</i></li>
                    		</ul>
                    	</td>
					</tr>
					<tr>
                    	<td><code>count</code></td>
                    	<td>Number of sold items</td>
					</tr>
					<tr>
                    	<td><code>calls</code></td>
                    	<td>Number of call on that order(Only for some)</td>
					</tr>
					<tr>
                    	<td><code>comment</code></td>
                    	<td>Text comment to order(if available)</td>
					</tr>
            	</tbody>
			</table></div>
			<p>An example of a function response:</p>
			<pre><code>[
 1234 : {
  "id": 1234, // ID order on the agency side
  "uid": 432, // ID order on our system side
  "status": 5, // Order status code
  "reason": 2, // Reason for failure code
  "comment: "mew-mew-mew", // Comment on the order
 },
 2345 : {
  "id": 2345, // ID order on the agency side
  "uid": 543, // ID order on our system side
  "status": 6, // Order status code
  "count: 2, // Number of items in order
 }
]</code></pre>

		</div>

<?php 
include 'tpl/footer.php';

?>