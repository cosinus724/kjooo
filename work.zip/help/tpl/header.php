<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

if (!isset($lang)) {
    $lang = 'ru';
}
switch ($lang) {
    case 'ru':
        $back = 'Вернуться на сайт';
        $menu = 'Меню';
        $help = 'Помощь';
        $ll = '';
        $pages = array('index' => 'Общая информация', 'faq' => 'FAQ', 'api' => 'API');
        break;
    case 'en':
        $back = 'Return to site';
        $menu = 'Menu';
        $help = 'Help';
        $ll = '.en';
        $pages = array('index' => 'General info', 'faq' => 'FAQ', 'api' => 'API');
        break;
}
define('IN_ALTERCMS_CORE_ONE', true);
require_once PATH . 'core/start.php';
$skin = defined('HACK_SKIN') ? HACK_SKIN : 'skin-green';
if (defined('HACK_NOSKIN')) {
    $skin = false;
}
?><!DOCTYPE html>
<html lang="ru">
<head>
	<title><?php 
echo $core->config('site', 'name');
?>: <?php 
echo $pages[$page];
?></title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link type="text/css" href="/core/css/style.css" rel="stylesheet" />
	<link type="text/css" href="/core/css/fa.css" rel="stylesheet" />
	<?php 
if ($skin) {
    ?><link type="text/css" href="/core/css/<?php 
    echo $skin;
    ?>.css" rel="stylesheet" /><?php 
}
?>
	<?php 
if (defined('HACK_MYSTYLE')) {
    ?><link type="text/css" href="/<?php 
    echo HACK;
    ?>/css/style.css" rel="stylesheet" /><?php 
}
?>
	<link type="text/css" href="css/style.css" rel="stylesheet" />
	<script type="text/javascript" src="/core/js/jquery.js"></script>
	<script type="text/javascript" src="/core/js/bootstrap.js"></script>
	<script type="text/javascript" src="/core/js/app.js"></script>
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->	
</head>
	
<body class="hold-transition <?php 
echo $skin;
?> layout-top-nav fixed">
<div class="wrapper">
	
<header class="main-header"><nav class="navbar navbar-static-top"><div class="container">
	
	<div class="navbar-header">
		<a href="/" class="navbar-brand"><?php 
echo $core->config('site', 'nice');
?></a>
		<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse"><i class="fa fa-bars"></i></button>
	</div>

	<div class="collapse navbar-collapse pull-left" id="navbar-collapse">
		<ul class="nav navbar-nav">
<?php 
foreach ($pages as $p => $n) {
    ?>	
		<li<?php 
    echo $p == $page ? ' class="active"' : '';
    ?>><a href="<?php 
    echo $p . $ll;
    ?>.php"><?php 
    echo $n;
    ?></a></li>
<?php 
}
?>
		</ul>
	</div>

	<nav class="navbar-custom-menu">
		<ul class="nav navbar-nav ">
			<li><a href="/"><i class="fa fa-fw fa-angle-double-left"></i> <span class="hidden-xs"><?php 
echo $back;
?></span></a></li>
		</ul>
	</nav>

</div></nav></header>
	
<div class="content-wrapper"><div class="container">

	<section class="content-header hidden-sm hidden-xs">
		<h1><?php 
echo $pages[$page];
?></h1>
		<ol class="breadcrumb">
			<li><a href="/"><i class="fa fa-home"></i> <?php 
echo $core->config('site', 'name');
?></a></li>
			<li><a href="."><?php 
echo $help;
?></a></li>
			<li class="active"><?php 
echo $pages[$page];
?></li>
		</ol>
	</section>

	<section class="content"><?php 

?>