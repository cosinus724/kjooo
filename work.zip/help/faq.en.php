<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

define('PATH', realpath(dirname(__FILE__) . '/../') . '/');
$page = 'faq';
$lang = 'en';
require_once 'tpl/header.php';
?>

	<a name="top"></a>
	<h1>FAQ: Frequently asked questions <?php 
echo $core->config('site', 'name');
?></h1>

	<h3>General questions</h3>
	<ul>
		<li><a href="#referal">Is there a referral program in the system?</a></li>
		<li><a href="#api">Does your service support the API-interface?</a></li>
		<li><a href="#iwant">I would like to see in your system the function...</a></li>
	</ul>

	<h3>Webmaster questions</h3>
	<ul>
		<li><a href="#start">How can I start traffic arbitrage?</a></li>
		<li><a href="#landing">What are the landings for<i>%offername%</i> and which one is the best?</a></li>
		<li><a href="#flowlink">How does a flowlink form?</a></li>
		<li><a href="#subid">How can I use my SubID?</a></li>
		<li><a href="#postback">How to setup PostBack-request?</a></li>
		<li><a href="#calls">How do the calls perform?</a></li>
		<li><a href="#outpay">How are payments made?</a></li>
		<li><a href="#noout">Why do not I get paid?!</a></li>
		<li><a href="#check">What does the caption <code>Order on check</code>mean in the lead statistics?</a></li>
		<li><a href="#getname">I want to know the name / phone / address of the customer</a></li>
	</ul>

	<h3>Supplier questions</h3>
	<ul>
		<li><a href="#newsale">I want to join you as a supplier!</a></li>
		<li><a href="#saleface">I already have an order processing interface and it suits me</a></li>
	</ul>

	<h2 class="qublock">General questions</h2>

	<?php 
if ($core->config('register', 'noref') || $core->config('register', 'hideref')) {
    ?>
	<div class="question">
		<a class="anchor" name="referal"></a>
		<h4>Есть ли в системе реферальная программа?</h4>
		<p>Нет, мы не используем реферальную программу, чтобы иметь возможность давать максимальные отчисления вебмастерам.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Вернуться к списку вопросов</a></p>
	</div>
	<?php 
} else {
    ?>
	<div class="question">
		<a class="anchor" name="referal"></a>
		<h4>Is there a referral program in the system?</h4>
		<p>Yes, it is available in the section «<a href="/referal">Referrals</a>» interface. You can receive a reward for attracting new webmasters to our affiliate program. With each confirmed lead from the involved webmasters, you will receive a partner reward. The amount of remuneration may vary depending on the offer. The exact amount can be found on the page «<a href="/offers">Offers</a>»in "Referral deductions".</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Return to questions list</a></p>
	</div>
	<?php 
}
?>

	<div class="question">
		<a class="anchor" name="api"></a>
		<h4>Does your service support the API-interface?</h4>
		<p>Yes, most of our service functions are implemented as API. More details can be found in <a href="api.en.php">the relevant guide</a>.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Return to questions list</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="iwant"></a>
		<h4>I would like to see in your system the function...</h4>
		<p>Do you need non-standard or new features in the system? New analysis tools? Do you have any ideas? Write us<a href="/support">intechnical support section</a> - we will realize your ideas!</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Return to questions list</a></p>
	</div>

	<h2 class="qublock">Webmaster questions</h2>

	<div class="question">
		<a class="anchor" name="start"></a>
		<h4>How can I start traffic arbitrage?</h4>
		<p>To start traffic arbitrage you need to get the flow link. To do this you must perform the following actions:</p>
		<ul>
			<li>In the section«<a href="/offers">Offers</a>» pick up the required offer for work.</li>
			<li>Using the button "Create a flow by the action" add a new flow for this offer. The name of the flow can be chosen arbitrarily.</li>
			<li>In the section«<a href="/flow">Flows</a>» Click the button "Generate the flow link" of the corresponding offer or the "Link" button of the required flow to open the link generation form.</li>
			<li>In the opened form choose the landing you liked and, if necessary, the prelanding, and use the received flow link.</li>
		</ul>
		<p align="center"><img src="docs/flowlink.png" alt="Generate the flow link" class="img-responsive" /></p>
		<p> Available landings and prelandings you can find on the page of each of the offer <a href="/offers">in the appropriate section</a>.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Return to questions list</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="landing"></a>
		<h4>What are the landings for<i>%offername%</i> and which one is the best?</h4>
		<p>A full list of advertising materials (landings and prelandings) for each of the offers can be viewed on its page. For this, in the section «<a href="/offers">Offers</a>» you need to open interested offer, clicking on its icon or title.</p>
		<p>In addition to the list of sites, the CR and EPC ratings for each of the sites are also presented. The best is the site with the highest EPC. These characteristics of the sites are provided only for reference and are experimental. For new sites they can vary.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Return to questions list</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="flowlink"></a>
		<h4>How does a flowlink form?</h4>
		<p>Flowlink can be formed in three ways:</p>
		<dl>
			<dt>Direct link to landing</dt>
			<dd>
            	Link indicates flow number only: <code>http://landing.com/?{flow}</code>, for example: <code>/?13</code>.
            	To increase conversion a comebacker script can be used, at the end of the link you need to add a parameter <code>cb</code> without meaning, for example: <code>/?13&cb</code>.
            	Some ad networks distort the links in the transfer. To avoid this, the stream parameter can be specified explicitly, using the variable <code>flow</code>, for example: <code>/?flow=13</code>.
			</dd>
			<dt>Link to landing through prelanding</dt>
			<dd>
           		The link can indicate not only the flow number, but also the desired landing: <code>http://<?php 
echo $core->config('space', 'domain');
?>/prelanding/?{flow}-{land}</code>, for example: <code>/prelanding/?13-7</code>.If the Landing number is not specified explicitly, the default lending will be used.
				To increase conversion a comebacker script can be used, at the end of the link you need to add a parameter<code>cb</code> without meaning, for example:<code>/prelanding/?13-7&cb</code>.
            	Some ad networks distort the links in the transfer. To avoid this, the stream parameter can be specified explicitly, using the variable  <code>flow</code>, for example: <code>/prelanding/?flow=13-7</code> or <code>/prelanding/?flow=13&land=7</code>.
			</dd>
			<dt>Link through the redirect domain</dt>
			<dd>
				Link indicates stream identifier only, for example: <code>http://<?php 
echo $core->config('redirect', 'domain') . '/' . $core->config('redirect', 'flow');
?>123</code>. Any domain fixed to <code><?php 
echo $core->config('redirect', 'domain');
?></code>, can be used as redirect domain. Traffic back links always use redirect domain.
			</dd>

		</dl>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Return to questions list</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="subid"></a>
		<h4>How can I use my SubID?</h4>
		<p>You can use up to 5 tags SubID in our system. Here they are set by the following parameters in URL: <code>utm_source</code>, <code>utm_content</code>, <code>utm_campaign</code>, <code>utm_term</code> и <code>utm_medium</code> - you can add these parameters to your flow link and analyze in<a href="/utm">relevant section</a>.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Return to questions list</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="postback"></a>
		<h4>How to setup PostBack-request?</h4>
		<p>You can receive order status updates without using <a href="api.en.php">API</a>. All real-time updates can be sent to you with the PostBack request. A PostBack request is performed in case of <b>any change</b> of order status.</p>
		<p>The URL for the PostBack request is specified in the settings of each flow. In the GET-part of request (URL itself), you can use codes from the table below.</p>
		<p>Only the GET request is sent to the specified address by default. If you need to send parameters to POST, add the PostBack request URL at the beginning<code>POST:</code>. In the POST-part of the request all parameters from the list below are transferred, the parameter names are indicated in the POST column and can not be redefined.</p>
		<p>Simple query sample: <code>http://mydomain.ru/status.php?id={id}&flow={flow}&status={status}&reason={reason}</code></p>
		<p>Query from POST sample: <code>POST:http://mydomain.ru/status.php?id={id}&flow={flow}&status={status}&subid={utms}</code></p>
		<div class="box"><table class="table table-striped">
           	<thead><tr>
				<th>GET-code</th>
				<th>POST</th>
				<th>Description</th>
           	</tr></thead>
           	<tbody>
				<tr>
					<td><code>{id}</code></td>
					<td><code>id</code></td>
					<td>Order ID</td>
				</tr>
				<tr>
					<td><code>{offer}</code></td>
					<td><code>offer</code></td>
					<td>Offer ID. List of available offer IDs can be found using the function <a href="api.en.php#offers">offers</a></td>
				</tr>
				<tr>
					<td><code>{flow}</code></td>
					<td><code>flow</code></td>
					<td>Flow ID. List of available flow IDs can be found using the function<a href="api.en.php#flows">flows</a></td>
				</tr>
				<tr>
					<td><code>{site}</code></td>
					<td><code>site</code></td>
					<td>Site ID. List of available landing IDs can be found using the function<a href="api.en.php#sites">sites</a></td>
				</tr>
				<tr>
					<td><code>{space}</code></td>
					<td><code>space</code></td>
					<td>Space ID. List of available prelanding IDs can be found using the function <a href="api.en.php#sites">sites</a></td>
				</tr>
				<tr>
					<td><code>{target}</code></td>
					<td><code>target</code></td>
					<td>Target ID</td>
				</tr>
				<tr>
					<td><code>{mobile}</code></td>
					<td><code>mobile</code></td>
					<td>Mobile traffic feature (<code>0</code> - desktop, <code>1</code> - mobile)</td>
				</tr>
				<tr>
					<td><code>{ip}</code></td>
					<td><code>ip</code></td>
					<td>user's IP</td>
				</tr>
				<tr>
					<td><code>{geo}</code></td>
					<td><code>geo</code></td>
					<td>Two-letter order country code</td>
				</tr>
				<tr>
					<td><code>{date}</code></td>
					<td><code>date</code></td>
					<td>Time of order in format UNIX Timestamp</td>
				</tr>
				<tr>
					<td><code>{status}</code></td>
					<td><code>status</code></td>
					<td>Order status. The status list is similar to the one described for the function <a href="api.en.php#lead">lead</a></td>
				</tr>
				<tr>
					<td><code>{reason}</code></td>
					<td><code>reason</code></td>
					<td>Failure reason. Failure reason list is similar to the one described for the function <a href="api.en.php#lead">lead</a></td>
				</tr>
				<tr>
					<td><code>{cash}</code></td>
					<td><code>cash</code></td>
					<td>Deductions for accepted order (are sent only when the order is approved)</td>
				</tr>
				<tr>
					<td><code>{price}</code></td>
					<td><code>price</code></td>
					<td>Total price</td>
				</tr>
				<tr>
					<td><code>{count}</code></td>
					<td><code>count</code></td>
					<td>Items amount in order</td>
				</tr>
				<tr>
					<td><code>{utms}</code></td>
					<td><code>utms</code></td>
					<td>UTM-mark: <code>utm_source</code></td>
				</tr>
				<tr>
					<td><code>{utmc}</code></td>
					<td><code>utmc</code></td>
					<td>UTM-mark: <code>utm_campaign</code></td>
				</tr>
				<tr>
					<td><code>{utmn}</code></td>
					<td><code>utmn</code></td>
					<td>UTM-mark: <code>utm_content</code></td>
				</tr>
				<tr>
					<td><code>{utmt}</code></td>
					<td><code>utmt</code></td>
					<td>UTM-mark: <code>utm_term</code></td>
				</tr>
				<tr>
					<td><code>{utmm}</code></td>
					<td><code>utmm</code></td>
					<td>UTM-mark: <code>utm_medium</code></td>
				</tr>
           	</tbody>
		</table></div>
		<p>Variable<code>{status}</code> can get following values:</p>
		<ul>
			<li><code>1</code> - New order (<b class="text-info">waiting</b>)</li>
			<li><code>2</code> - Processing (<b class="text-info">waiting</b>)</li>
			<li><code>3</code> - Recall (<b class="text-info">waiting</b>)</li>
			<li><code>4</code> - Missed call (<b class="text-info">waiting</b>)</li>
			<li><code>5</code> - Canceled (<b class="text-danger">failure</b>)</li>
			<li><code>6</code> - Packaging (<b class="text-success">order accepted</b>)</li>
			<li><code>7</code> - Sending(<b class="text-success">order accepted</b>)</li>
			<li><code>8</code> - On the way (<b class="text-success">order accepted</b>)</li>
			<li><code>9</code> - Delivered (<b class="text-success">order accepted</b>)</li>
			<li><code>10</code> - Paid (<b class="text-success">order accepted</b>)</li>
			<li><code>11</code> - Return(<b class="text-success">order accepted</b>)</li>
			<li><code>12</code> - Removed for fraud (<b class="text-danger">failure</b>)</li>
		</ul>
		<p>If you need to use your status values instead of the specified ones, you can override them using the parameter: <code>{stage:New|Processing | Recall |Missed call|Canceled |Packaging|Sending|On the way|Delivered|Paid|Return|Removed}</code>, parameter
<code>{stage:0|0|0|0|2|1|1|1|1|1|1|2}</code> will give <code>0</code> for processing, <code>1</code> for accepted and <code>2</code> canceled order, and <code>{stage:P|P|P|P|D|A|A|A|A|A|A|D}</code> will suit for OctoTracker.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Return to questions list</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="calls"></a>
		<h4>How do the calls perform?</h4>
		<p>Suppliers perform calls from 10:00 to 22:00 every day. First client call is made within an hour after order's appearance. Possible breaks during holidays.</p>
		<p> "Missed call" orders are processed within a week from starting date. If during this period we could not get through to the buyer, lead is deleted.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Return to questions list</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="outpay"></a>
		<h4>How are payments made?</h4>
		<p>Payments are made on working days. Payout period is 5-7 working days (banking days) from the moment of receiving the request. In the case of a large number of payments in the system, delays of up to 2 weeks are possible.</p>
		<p>Minimum payment is 2000 XXX. Funds withdrawal is carried out on XXXX.</p>
		<p>First payment hold - 6 days. If <a href="#check"> there are suspicious orders</a> payments can be delayed.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Return to questions list</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="noout"></a>
		<h4>Why do not I get paid?!</h4>
		<p>First of all, read the question<a href="#outpay">about payments timing again</a>.</p>
		<p>If you already had to pass by the terms of payment: read section «<a href="/lead">Lead statistics</a>» and check if there is any lead signature «<a href="#check">Order on check</a>».</p>
		<p>If the deadlines are exceeded and there are no orders for verification, <a href="/support">write to support</a>!</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Return to questions list</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="check"></a>
		<h4>What does the caption <code>Order on check</code>mean in the lead statistics?</h4>
		<p>While viewing section «<a href="/lead">Lead statistics</a>», you  may notice that some not-rejected leads have signature «Order on check». It looks like the picture below.</p>
		<p align="center"><img src="docs/check.png" alt="Заказ на проверке" class="img-responsive" /></p>
		<p>This text means that lead was under traffic control because of suspicion in fraud. Payment for this lead will be delayed until item delivery and payment. Checking orders for fraud is performed both in automatic and manual mode. Suspicious orders are further controlled by security service individually.</p>
		<p class="text-success">If you have got more than hundred of leads with such order, do not mind. It will not affect on your payments. All payments will be made on time.</p>
		<p class="text-warning"><b>Important:</b> If you received too many suspicious leads, all payments are blocked before the orders are delivered to customers. In such a situation user can be later blocked for fraud and all orders will be canceled.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Return to questions list</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="getname"></a>
		<h4>I want to know the name / phone / address of the customer</h4>
		<p>Information about customer's name, phone and address is confidential and is not disclosed under any circumstances. Similarly, the webmaster can not know the composition of the order, the number of ordered items of one type or another, total price.</p>
		<p>For each webmaster's lead, the following information is available: item (оffer), data and time, current status, order sourse (IP, site, space), for some orders - number of calls and failure reason.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Return to questions list</a></p>
	</div>

	<h2 class="qublock">Supplier questions</h2>

	<div class="question">
		<a class="anchor" name="newsale"></a>
		<h4>I want to join you as a supplier!</h4>
		<p>To join our project as supplier, contact us by mail <a href="mailto:<?php 
echo $core->config('site', 'mail');
?>"><?php 
echo $core->config('site', 'mail');
?></a>. We will discuss the details of your company's work and prepare the necessary tools for starting work.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Return to questions list</a></p>
	</div>

	<div class="question">
		<a class="anchor" name="saleface"></a>
		<h4>I already have an order processing interface and it suits me</h4>
		<p>We can pass all orders coming to us into your interface with convenient tools or our API. You can discuss all questions with our technical department by mail <a href="mailto:<?php 
echo $core->config('site', 'mail');
?>"><?php 
echo $core->config('site', 'mail');
?></a>.</p>
		<p class="small"><a href="#top"><i class="glyphicon glyphicon-chevron-up"></i> Return to questions list</a></p>
	</div>

<?php 
include 'tpl/footer.php';

?>