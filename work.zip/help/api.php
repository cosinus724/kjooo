<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

define('PATH', realpath(dirname(__FILE__) . '/../') . '/');
$page = 'api';
require_once 'tpl/header.php';
$api = $core->config('url', 'api') ? $core->config('url', 'api') : $core->config('url', 'base') . 'api/';
$user = $core->user->id ? $core->user->id : '{user}';
$akey = $core->user->api ? $core->user->api : '{key}';
?>

<div class="row">
<div class="col-md-3 col-sm-4 hidden-xs">

	<div class="panel panel-<?php 
echo BOXSKIN;
?>">
		<div class="panel-heading">Документация</div>
		<div class="list-group">
			<a href="#webmaster" class="list-group-item">Вебмастер</a>
			<a href="#comp" class="list-group-item">Поставщик</a>
			<a href="#ext" class="list-group-item">Агентство</a>
		</div>
	</div>

	<div class="panel panel-<?php 
echo BOXSKIN;
?>">
		<div class="panel-heading">Вебмастер</div>
		<div class="list-group">
			<a href="#push" class="list-group-item">Добавление лида</a>
			<a href="#lead" class="list-group-item">Статистика по лидам</a>
			<a href="#stats" class="list-group-item">Статистика по датам</a>
			<a href="#click" class="list-group-item">Статистика по кликам</a>
			<a href="#offers" class="list-group-item">Список офферов</a>
			<a href="#offersite" class="list-group-item">Сайты оффера</a>
			<a href="#flows" class="list-group-item">Список потоков</a>
			<a href="#flowadd" class="list-group-item">Создание потока</a>
			<a href="#flowedit" class="list-group-item">Настройка потока</a>
			<a href="#flowdel" class="list-group-item">Удаление потока</a>
		</div>
	</div>

	<div class="panel panel-<?php 
echo BOXSKIN;
?>">
		<div class="panel-heading">Поставщик</div>
		<div class="list-group">
			<a href="#orderlist" class="list-group-item">Список заказов</a>
			<a href="#orderstatus" class="list-group-item">Статус заказа</a>
			<a href="#orderedit" class="list-group-item">Правка заказа</a>
		</div>
	</div>

	<div class="panel panel-<?php 
echo BOXSKIN;
?>">
		<div class="panel-heading">Агентство</div>
		<div class="list-group">
			<a href="#extadd" class="list-group-item">Добавление лида</a>
			<a href="#extlist" class="list-group-item">Проверка статуса</a>
		</div>
	</div>

</div>
<div class="col-md-9 col-sm-8 col-xs-12">

	<p>Интерфейс API-функций <?php 
echo $core->config('site', 'name');
?> позволяет выполнять большую часть действий вебмастера и поставщика, реализованных на самом сайте. Чтобы подключить API, зайдите на страницу своего <a href="/profile">профиля</a> в системе. Взаимодействие с сервисом осуществляется по протоколу HTTP. Формат запроса - чистый POST. Формат результата - JSON или сериализованные данные PHP. Ограничений на количество запросов нет.</p>

	<div class="bs-docs-section">

		<div class="page-header"><h1 id="principles">Принципы работы</h1></div>
		<p>Чтобы начать работу с API-интерфейсом, необходимо получить ID и ключ. Они доступны в разделе «<a href="/profile">Профиль</a>» системы. Далее по тексту пользовательский ID будет обозначаться <code>{user}</code>, а ключ доступа - <code>{key}</code>. <?php 
if (!$core->user->id) {
    ?>Авторизуйтесь на сайте, чтобы видеть свои ИД и ключ API.<?php 
}
?></p>
		<?php 
if ($core->user->id) {
    ?>
		<div class="box box-<?php 
    echo BOXSKIN;
    ?>">
			<div class="box-header"><h3 class="box-title">Ваши данные для использования API</h3></div>
			<div class="box-body no-padding table-responsive"><table class="table table-striped">
				<tr>
					<th nowrap="nowrap" class="text-right" width="13%">API ID</th>
					<td><?php 
    echo $user;
    ?></td>
				</tr>
				<tr>
					<th nowrap="nowrap" class="text-right" width="13%">API-ключ</th>
					<td><?php 
    echo $akey;
    ?></td>
				</tr>
			</table></div>
		</div>
		<?php 
}
?>
		<p>API-интерфейс состоит из нескольких приложений <code>{app}</code> с набором доступных функций <code>{func}</code>.</p>
		<p>Для обращения к API-функции, необходимо отправить POST запрос на адрес вида:</p>
		<pre><code><?php 
echo $api;
?>{app}/{func}.{format}?id={user}-{key}</code></pre>
		<p>URL запроса состоит из следующих частей</p>
		<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
        	<thead><tr>
				<th>Параметр</th>
				<th>Описание</th>
        	</tr></thead>
        	<tbody>
				<tr>
                	<td><code>{app}</code></td>
                	<td>Идентификатор приложения:
                		<ul>
                			<li><code>wm</code> - интерфейс <a href="#webmaster">вебмастера</a></li>
                			<li><code>comp</code> - интерфейс <a href="#comp">поставщика</a></li>
                			<li><code>ext</code> - интерфейс <a href="#ext">агентства</a></li>
                		</ul>
                	</td>
				</tr>
				<tr>
                	<td><code>{func}</code></td>
                	<td>Идентификатор функции в рамках приложения.</td>
				</tr>
				<tr>
                	<td><code>{format}</code></td>
                	<td>Формат возвращаемого результата:
                		<ul>
                			<li><code>json</code> - данные в формате JSON</li>
                			<li><code>serial</code> - сериализованные данные PHP, предназначенные для обработки функцией <code>unserialize</code></li>
                			<li><code>xml</code> - данные в формате XML</li>
                			<li><code>text</code> - данные в виде строки параметров, аналогичной используемым в URL: <code>param1=value1&amp;param2=value2</code></li>
                			<li><code>raw</code> - необработанные данные (используется только для некоторых функций)</li>
                		</ul>
                	</td>
				</tr>
				<tr>
                	<td><code>{user}</code></td>
                	<td>Идентификатор пользователя в системе<?php 
if ($user) {
    echo ": <code>{$user}</code>";
}
?></td>
				</tr>
				<tr>
                	<td><code>{key}</code></td>
                	<td>API-ключ пользователя из профиля<?php 
if ($akey) {
    echo ": <code>{$akey}</code>";
}
?></td>
				</tr>
        	</tbody>
		</table></div></div>
		<p>Данные для запроса передаются в POST-части запроса в чистом виде. Их <b>не нужно</b> каким-либо образом кодировать, <b>не нужно</b> помещать в JSON или XML-представление.</p>
		<p>Функция для работы с нашим интерфейсом на PHP представлена ниже:</p>

<pre><code class="php"><span style="color: #000000"><span style="color: #0000BB">&lt;?php

</span><span style="color: #FF8000">/**
&nbsp;*&nbsp;Взаимодействие&nbsp;с&nbsp;сервисом&nbsp;<?php 
echo $core->config('site', 'name');
?>.
&nbsp;*&nbsp;@param&nbsp;$id&nbsp;Ваш&nbsp;ID&nbsp;в&nbsp;системе
&nbsp;*&nbsp;@param&nbsp;$key&nbsp;Ваш&nbsp;API-ключ
&nbsp;*&nbsp;@param&nbsp;$app&nbsp;Приложение&nbsp;для&nbsp;взаимодействия&nbsp;(wm,&nbsp;ext&nbsp;или&nbsp;comp)
&nbsp;*&nbsp;@param&nbsp;$func&nbsp;Запрашиваемая&nbsp;функция
&nbsp;*&nbsp;@param&nbsp;$data&nbsp;Массив&nbsp;параметров
&nbsp;*&nbsp;@param&nbsp;$format&nbsp;Формат&nbsp;возвращаемого&nbsp;результата&nbsp;(serial,&nbsp;json,&nbsp;raw)
&nbsp;*&nbsp;@return&nbsp;array&nbsp;Результат&nbsp;выполнения
&nbsp;*/
</span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">apirequest&nbsp;</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$id</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$key</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$app</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$func</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$data&nbsp;</span><span style="color: #007700">=&nbsp;array(),&nbsp;</span><span style="color: #0000BB">$format&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'serial'&nbsp;</span><span style="color: #007700">)&nbsp;{

&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$url&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'<?php 
echo $api;
?>'&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$app&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">'/'&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$func&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">'.'&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$format&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">'?id='&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$id&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">'-'&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$key</span><span style="color: #007700">;
&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$curl&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">curl_init</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$url&nbsp;</span><span style="color: #007700">);
&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">curl_setopt</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$curl</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">CURLOPT_RETURNTRANSFER</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">true&nbsp;</span><span style="color: #007700">);
&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">curl_setopt</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$curl</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">CURLOPT_TIMEOUT</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">30&nbsp;</span><span style="color: #007700">);
&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">curl_setopt</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$curl</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">CURLOPT_POST</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">1&nbsp;</span><span style="color: #007700">);
&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">curl_setopt</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$curl</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">CURLOPT_POSTFIELDS</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$data&nbsp;</span><span style="color: #007700">);
&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$result&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">curl_exec</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$curl&nbsp;</span><span style="color: #007700">);
&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">curl_close</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$curl&nbsp;</span><span style="color: #007700">);

&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">switch&nbsp;(&nbsp;</span><span style="color: #0000BB">$format&nbsp;</span><span style="color: #007700">)&nbsp;{
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #DD0000">'raw'</span><span style="color: #007700">:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$result</span><span style="color: #007700">;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #DD0000">'json'</span><span style="color: #007700">:&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">json_decode</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$result</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">true&nbsp;</span><span style="color: #007700">);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #DD0000">'text'</span><span style="color: #007700">:&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">parse_str</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$result</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">);&nbsp;return&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;default:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">unserialize</span><span style="color: #007700">(&nbsp;</span><span style="color: #0000BB">$result&nbsp;</span><span style="color: #007700">);
&nbsp;&nbsp;&nbsp;&nbsp;}

}</span></code></pre>

		<p>Эта функция получает на входе следующие параметры:</p>
		<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
           	<thead><tr>
				<th>Параметр</th>
				<th>Тип</th>
				<th>Описание</th>
           	</tr></thead>
           	<tbody>
				<tr>
                   	<td><code>$id</code></td>
                   	<td><code>int</code></td>
                   	<td>Идентификатор пользователя в системе</td>
				</tr>
				<tr>
                   	<td><code>$key</code></td>
                   	<td><code>string</code></td>
                   	<td>API-ключ пользователя</td>
				</tr>
				<tr>
                   	<td><code>$app</code></td>
                   	<td><code>string</code></td>
                   	<td>Идентификатор приложения</td>
				</tr>
				<tr>
                   	<td><code>$func</code></td>
                   	<td><code>string</code></td>
                   	<td>Идентификатор функции</td>
				</tr>
				<tr>
                   	<td><code>$data</code></td>
                   	<td><code>array</code></td>
                   	<td>Массив параметров функции (необязательный параметр)</td>
				</tr>
				<tr>
                   	<td><code>$format</code></td>
                   	<td><code>string</code></td>
                   	<td>Формат возвращаемого результата (необязательный параметр)</td>
				</tr>
           	</tbody>
		</table></div></div>
		<p>Функция возвращает массив результата в случае форматов <code>json</code>, <code>serial</code> или <code>text</code>, и чистый вывод для формата <code>raw</code>.</p>

	</div>

	<div class="bs-docs-section">

		<div class="page-header"><h1 id="webmaster">Вебмастер</h1></div>
		<p>Функции веб-мастера позволяют работать с потоками и получать статистическую информацию аккаунта. Для работы со всеми функциями необходимо обращаться к приложению <code>wm</code>.</p>
		<p>URL: <code><?php 
echo $api;
?>wm/{function}.json?id=<?php 
echo $user;
?>-<?php 
echo $akey;
?></code></p>

			<h2 id="push">Добавление лида</h2>
			<p>URL: <code><?php 
echo $api;
?>wm/push.json?id=<?php 
echo $user;
?>-<?php 
echo $akey;
?></code></p>
			<p>ID функции - <code>push</code>. Функция позволяет добавить новый лид от имени вебмастера. Данные нового лида передаются в POST-запросе.</p>
			<?php 
if (!$core->user->id) {
    ?>
			<div class="callout callout-warning"><strong>Внимание!</strong> Данная функция по умолчанию отключена для новых пользователей, она может быть активирована по запросу в техническую поддержку.</div>
			<?php 
} elseif (!$core->user->push) {
    ?>
			<div class="callout callout-warning"><strong>Внимание!</strong> Данная функция ещё не активирована для вас, для активации свяжитесь с <a href="/support">технической поддержкой</a>.</div>
			<?php 
} else {
    ?>
			<div class="callout callout-success">Мы активировали для вас функционал добавления лидов по API.</div>
			<?php 
}
?>
			<p>На входе функция принимает следующие данные о лиде:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>flow</code>*</td>
                    	<td>Идентификатор потока, к которому привязывается заказ (обязательный параметр)</td>
					</tr>
					<tr>
                    	<td><code>offer</code>*</td>
                    	<td>Идентификатор оффера из <a href="#offers">списка</a> (обязательный параметр)</td>
					</tr>
					<tr>
                    	<td><code>ip</code>*</td>
                    	<td>IP-адрес заказчика (обязательный параметр)</td>
					</tr>
					<tr>
                    	<td><code>name</code></td>
                    	<td>ФИО заказчика</td>
					</tr>
					<tr>
                    	<td><code>phone</code>*</td>
                    	<td>Телефон заказчика в формате 79876543210 (обязательный параметр)</td>
					</tr>
					<tr>
                    	<td><code>email</code></td>
                    	<td>Электронная почта заказчика</td>
					</tr>
					<tr>
                    	<td><code>ua</code></td>
                    	<td>User-Agent браузера заказчика</td>
					</tr>
					<tr>
                    	<td><code>country</code></td>
                    	<td>Двухбуквенный код страны заказчика, вычисляется на основании IP-адреса</td>
					</tr>
					<tr>
                    	<td><code>currency</code></td>
                    	<td>Трёхбуквенный код валюты заказчика, например RUB или BYR, по умолчанию вычисляется на основании страны заказчика</td>
					</tr>
					<tr>
                    	<td><code>index</code></td>
                    	<td>Почтовый индекс адреса доставки в формате 127000</td>
					</tr>
					<tr>
                    	<td><code>addr</code></td>
                    	<td>Адрес доставки. Может содержать в себе полный адрес без индекса, если не используются поля ниже. В противном случае содержит только номер дома, корпуса, квартиры или офиса.</td>
					</tr>
					<tr>
                    	<td><code>area</code></td>
                    	<td>Регион доставки, например, Московская обл.</td>
					</tr>
					<tr>
                    	<td><code>city</code></td>
                    	<td>Город доставки, например Москва</td>
					</tr>
					<tr>
                    	<td><code>street</code></td>
                    	<td>Улица по адресу доставки, например ул. Мира</td>
					</tr>
					<tr>
                    	<td><code>base</code></td>
                    	<td>Цена единицы товара в валюте заказа.</td>
					</tr>
					<tr>
                    	<td><code>count</code></td>
                    	<td>Количество товара.</td>
					</tr>
					<tr>
                    	<td><code>discount</code></td>
                    	<td>Скидка на товар в процентах.</td>
					</tr>
					<tr>
                    	<td><code>more</code></td>
                    	<td>Сумма добавочной стоимости заказа, например, наценки за экспресс-доставку.</td>
					</tr>
					<tr>
                    	<td><code>comm</code></td>
                    	<td>Дополнительный комментарий по заказу.</td>
					</tr>
					<tr>
                    	<td><code>us</code></td>
                    	<td>Метка <code>utm_source</code></td>
					</tr>
					<tr>
                    	<td><code>uc</code></td>
                    	<td>Метка <code>utm_campaign</code></td>
					</tr>
					<tr>
                    	<td><code>un</code></td>
                    	<td>Метка <code>utm_content</code></td>
					</tr>
					<tr>
                    	<td><code>ut</code></td>
                    	<td>Метка <code>utm_term</code></td>
					</tr>
					<tr>
                    	<td><code>um</code></td>
                    	<td>Метка <code>utm_medium</code></td>
					</tr>
					<tr>
                    	<td><code>promo</code></td>
                    	<td>Промо-код, указанный заказчиком.</td>
					</tr>
					<tr>
                    	<td><code>mobile</code></td>
                    	<td>Укажите <code>0</code> для десктоп-трафика и <code>1</code> для мобильного трафика</td>
					</tr>
					<tr>
                    	<td><code>bad</code></td>
                    	<td>Укажите <code>0</code> для нормального трафика и <code>1</code> для подозрительного трафика</td>
					</tr>
            	</tbody>
			</table></div></div>

			<p>Результатом выполнения функции является ассоциативный массив:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Результат выполнения операции: <code>ok</code> в случае успешного выполнения, <code>error</code> в случае ошибки</td>
					</tr>
					<tr>
                    	<td><code>id</code></td>
                    	<td>Идентификатор добавленного заказа (в случае успеха)</td>
					</tr>
					<tr>
                    	<td><code>error</code></td>
                    	<td>Идентификатор ошибки: <code>nooffer</code> при отсутствии идентификатора оффера, <code>noflow</code> при отсутствии идентификатора потока, <code>badflow</code> при указании некорректного идентификатора потока, <code>nophone</code> при отсутствии номера телефона, <code>duplicate</code> наличии заказа с таким же телефоном, именем и оффером в обработке, <code>offer</code> если не найден указанный оффер, <code>security</code> при бане пользователя, <code>ban</code> при бане телефона или IP-адреса заказчика, <code>traffic</code> при отправке заказа на приватный или заблокированный оффер, <code>db</code> в случае внутренней ошибки добавления данных.</td>
					</tr>
            	</tbody>
			</table></div></div>
			<p>Пример успешного ответа функции:</p>
			<pre><code>{ "status" : "ok", "id" : 1234 }</code></pre>
			<p>Пример ответа функции при возникновении ошибки:</p>
			<pre><code>{ "status" : "error", "error" : "nooffer" }</code></pre>

			<h2 id="lead">Статистика по лидам</h2>
			<p>URL: <code><?php 
echo $api;
?>wm/lead.json?id=<?php 
echo $user;
?>-<?php 
echo $akey;
?></code></p>
			<p>ID функции - <code>lead</code>. Функция предоставляет список лидов и их статус по списку идентификаторов или за указанную дату.</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>ids</code></td>
                    	<td>Список идентификаторов лидов через запятую. Рекомендуется проверять не более 20 лидов за один запрос.</td>
					</tr>
					<tr>
                    	<td><code>day</code></td>
                    	<td>Дата статистики в формате <code>ГГГГ-ММ-ДД</code>. Необязательный параметр. По умолчанию используется сегодняшний день. Игнорируется при указании списка идентификаторов.</td>
					</tr>
					<tr>
                    	<td><code>offer</code></td>
                    	<td>ID оффера для получения статистики. Необязательный параметр. По умолчанию статистика выводится для всех офферов.</td>
					</tr>
					<tr>
                    	<td><code>flow</code></td>
                    	<td>ID потока для получения статистики. Необязательный параметр. По умолчанию статистика выводится для всех потоков.</td>
					</tr>
					<tr>
                    	<td><code>site</code></td>
                    	<td>Идентификатор сайта-источника. Список сайтов можно получить с помощью функции <a href="#offersite">sites</a>.</td>
					</tr>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Статус заказа:
                    		<ul>
                    			<li><code>a</code> - принятые лиды</li>
                    			<li><code>w</code> - лиды в ожидании и на обработке</li>
                    			<li><code>c</code> - отклонённые лиды</li>
                    			<li><code>не указан</code> - все лиды</li>
                    		</ul>
                    	</td>
					</tr>
            	</tbody>
			</table></div></div>
			<p>Результатом выполнения функции является массив лидов. Каждый элемент включает в себя следующие поля:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>id</code></td>
                    	<td>Идентификатор заказа</td>
					</tr>
					<tr>
                    	<td><code>time</code></td>
                    	<td>Время поступления заказа в формате UNIX-timestamp</td>
					</tr>
					<tr>
						<td><code>stage</code></td>
                    	<td>Символьный статус заказа:
                    		<ul>
                    			<li><code>new</code> - новый заказ</li>
                    			<li><code>wait</code> - заказ в обработке</li>
                    			<li><code>hold</code> - холд</li>
                    			<li><code>approve</code> - заказ принят</li>
                    			<li><code>cancel</code> - заказ отменён</li>
                    			<li><code>trash</code> - треш</li>
                    		</ul>
						</td>
					</tr>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Расширенный статус заказа
                    		<ul>
                    			<li><code>1</code> - Новый заказ</li>
	  							<li><code>2</code> - В обработке</li>
	  							<li><code>3</code> - Перезвонить</li>
	  							<li><code>4</code> - Холд</li>
	  							<li><code>5</code> - Отменён</li>
	  							<li><code>6</code> - На упаковке</li>
	  							<li><code>7</code> - Отправка</li>
	  							<li><code>8</code> - В пути</li>
	  							<li><code>9</code> - Доставлен</li>
	  							<li><code>10</code> - Оплачен</li>
	  							<li><code>11</code> - Возврат</li>
	  							<li><code>12</code> - Удалён</li>
                    		</ul>
                    	</td>
					</tr>
					<tr>
                    	<td><code>reason</code></td>
                    	<td>Идентификатор причины отказа
                    		<ul>
								<li><code>1</code> - Некорректный номер <i>(треш)</i></li>
								<li><code>2</code> - Передумал</li>
								<li><code>3</code> - Не заказывал <i>(треш)</i></li>
								<li><code>4</code> - Требует сертификат</li>
								<li><code>5</code> - Неверное ГЕО <i>(треш)</i></li>
								<li><code>6</code> - Ошибки или фэйк <i>(треш)</i></li>
								<li><code>7</code> - Дублированный заказ <i>(треш)</i></li>
								<li><code>8</code> - Заказал в другом месте <i>(треш)</i></li>
								<li><code>9</code> - Дорого</li>
								<li><code>10</code> - Не устраивает доставка</li>
								<li><code>11</code> - Не удалось дозвониться</li>
								<li><code>12</code> - Подозрения на фрод <i>(треш)</i></li>
                    		</ul>
                    	</td>
					</tr>
					<tr>
                    	<td><code>reason_text</code></td>
                    	<td>Текстовое значение причины отказа</td>
					</tr>
					<tr>
                    	<td><code>offer</code></td>
                    	<td>Идентификатор оффера</td>
					</tr>
					<tr>
                    	<td><code>offer_name</code></td>
                    	<td>Название оффера</td>
					</tr>
					<tr>
                    	<td><code>flow</code></td>
                    	<td>Идентификатор потока</td>
					</tr>
					<tr>
                    	<td><code>site</code></td>
                    	<td>Идентификатор лэндинга</td>
					</tr>
					<tr>
                    	<td><code>site_url</code></td>
                    	<td>URL лэндинга</td>
					</tr>
					<tr>
                    	<td><code>space</code></td>
                    	<td>Идентификатор прелэндинга</td>
					</tr>
					<tr>
                    	<td><code>space_url</code></td>
                    	<td>URL прелэндинга</td>
					</tr>
					<tr>
                    	<td><code>ip</code></td>
                    	<td>IP-адрес заказчика</td>
					</tr>
					<tr>
                    	<td><code>utm_*</code></td>
                    	<td>UTM-метки заказа: utm_source, utm_content, utm_campaign, utm_medium, utm_term</td>
					</tr>
            	</tbody>
			</table></div></div>
			<p>Пример ответа функции:</p>
			<pre>[
    {
	"id": 10101,
	"time": "1498127780",
	"stage": "trash",
	"status": 5,
	"reason": 1,
	"reason_text": "Некорректный номер",
	"hold": 0,
	"comment": null,
	"cash": 700,
	"offer": 234,
	"offer_name": "Shiny test offer",
	"flow": 4838,
	"site": 123,
	"site_url": "land.cpa/test-offer",
	"space": 0,
	"space_url": false,
	"ip": "12.34.56.78",
	"utm_source": "google",
	"utm_content": "321012",
	"utm_campaign": "321",
	"utm_medium": "cpc",
	"utm_term": "neverland"
    }
]</pre>

			<h2 id="stats">Статистика по датам</h2>
			<p>URL: <code><?php 
echo $api;
?>wm/stats.json?id=<?php 
echo $user;
?>-<?php 
echo $akey;
?></code></p>
			<p>ID функции - <code>stats</code>. Функция предоставляет статистику по кликам и заказам, разбитую по датам, аналогично разделу «<a href="/stats">Статистика</a>».</p>
			<p>На входе функция получает следующие параметры:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>from</code></td>
                    	<td>Дата начала статистики в формате <code>ГГГГ-ММ-ДД</code>. Необязательный параметр. По умолчанию используется дата неделю назад.</td>
					</tr>
					<tr>
                    	<td><code>to</code></td>
                    	<td>Дата окончания статистики в формате <code>ГГГГ-ММ-ДД</code>. Необязательный параметр. По умолчанию используется сегодняшний день.</td>
					</tr>
					<tr>
                    	<td><code>offer</code></td>
                    	<td>ID оффера для получения статистики. Необязательный параметр. По умолчанию статистика выводится для всех офферов.</td>
					</tr>
					<tr>
                    	<td><code>flow</code></td>
                    	<td>ID потока для получения статистики. Необязательный параметр. По умолчанию статистика выводится для всех потоков.</td>
					</tr>
            	</tbody>
			</table></div></div>
			<p>Результатом выполнения функции является ассоциативный массив. Идентификатором каждого элемента служит дата статистики в формате <code>ГГГГММДД</code>. Каждый элемент включает в себя следующие поля:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>id</code></td>
                    	<td>Дата статистики в формате <code>ГГГГММДД</code></td>
					</tr>
					<tr>
                    	<td><code>spaces</code></td>
                    	<td>Количество кликов по прелэндингам</td>
					</tr>
					<tr>
                    	<td><code>suni</code></td>
                    	<td>Количество <b>уникальных</b> кликов по прелэндингам</td>
					</tr>
					<tr>
                    	<td><code>sgood</code></td>
                    	<td>Количество <b>успешных</b> визитов на прелэндинг</td>
					</tr>
					<tr>
                    	<td><code>stime</code></td>
                    	<td>Среднее время пользователя на прелэндинге в секундах</td>
					</tr>
					<tr>
                    	<td><code>clicks</code></td>
                    	<td>Количество кликов по лэндингам</td>
					</tr>
					<tr>
                    	<td><code>unique</code></td>
                    	<td>Количество <b>уникальных</b> кликов по лэндингам</td>
					</tr>
					<tr>
                    	<td><code>good</code></td>
                    	<td>Количество <b>успешных</b> визитов на лэндинг</td>
					</tr>
					<tr>
                    	<td><code>time</code></td>
                    	<td>Среднее время пользователя на лэндинге в секундах</td>
					</tr>
					<tr>
                    	<td><code>ct</code></td>
                    	<td>Общее количество заказов без учёта треша</td>
					</tr>
					<tr>
                    	<td><code>st</code></td>
                    	<td>Общая сумма по лидам без учёта треша</td>
					</tr>
					<tr>
                    	<td><code>ca</code></td>
                    	<td>Количество заказов в статусе «Принят»</td>
					</tr>
					<tr>
                    	<td><code>sa</code></td>
                    	<td>Сумма по лидам в статусе «Принят»</td>
					</tr>
					<tr>
                    	<td><code>cc</code></td>
                    	<td>Количество заказов в статусе «Отменён» без учёта треша</td>
					</tr>
					<tr>
                    	<td><code>sc</code></td>
                    	<td>Сумма по лидам в статусе «Отменён» без учёта треша</td>
					</tr>
					<tr>
                    	<td><code>cw</code></td>
                    	<td>Количество заказов в статусе «Ожидает»</td>
					</tr>
					<tr>
                    	<td><code>sw</code></td>
                    	<td>Сумма по лидам в статусе «Ожидает»</td>
					</tr>
					<tr>
                    	<td><code>cx</code></td>
                    	<td>Количество невалидных заказов (треш)</td>
					</tr>
					<tr>
                    	<td><code>sx</code></td>
                    	<td>Сумма по невалидным лидам (треш)</td>
					</tr>
            	</tbody>
			</table></div></div>
			<p>Пример ответа функции:</p>
			<pre>{
    "<?php 
echo date('Ymd');
?>": {
	"id": "<?php 
echo date('Ymd');
?>",
	"space": 321,
	"suni": 291,
	"sgood": 153,
	"stime": 23.45,
	"clicks": 113,
	"unique": 93,
	"time": 34.56,
	"good": 80,
	"ct": 13,
	"st": 9100,
	"ca": 5,
	"sa": 3500,
	"cc": 3,
	"sc": 2100,
	"cw": 5,
	"sw": 3500,
	"cx": 2,
	"sx": 1400
    }
}</pre>

			<h2 id="click">Статистика по кликам</h2>
			<p>URL: <code><?php 
echo $api;
?>wm/click.json?id=<?php 
echo $user;
?>-<?php 
echo $akey;
?></code></p>
			<p>ID функции - <code>click</code>. Функция предоставляет статистику по кликам и заказам, сгруппированную по выбранному параметру. Данная функция доступна как веб-мастерам, так и агентствам.</p>
			<p>На входе функция получает следующие параметры:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>item</code>*</td>
                    	<td>Обязательный параметр. Поле, по которому производится группировка статистики:
							<ul>
								<li><code>offer</code> - идентификатор оффера</li>
								<li><code>flow</code> - идентификатор потока</li>
								<li><code>site</code> - идентификатор сайта</li>
								<li><code>utms</code> - метка utm_source</li>
								<li><code>utmc</code> - метка utm_campaing</li>
								<li><code>utmn</code> - метка utm_content</li>
								<li><code>utmt</code> - метка utm_term</li>
								<li><code>utmm</code> - метка utm_medium</li>
								<li><code>extu</code> - идентификатор на стороне агентства</li>
								<li><code>exts</code> - вебмастер на стороне агентства</li>
							</ul>
						</td>
					</tr>

					<tr>
                    	<td><code>from</code></td>
                    	<td>Дата начала статистики в формате <code>ГГГГ-ММ-ДД</code>. По умолчанию используется дата неделю назад.</td>
					</tr>
					<tr>
                    	<td><code>to</code></td>
                    	<td>Дата окончания статистики в формате <code>ГГГГ-ММ-ДД</code>. По умолчанию используется сегодняшний день.</td>
					</tr>
					<tr>
                    	<td><code>offer</code></td>
                    	<td>Фильтрация по ID оффера.</td>
					</tr>
					<tr>
                    	<td><code>flow</code></td>
                    	<td>Фильтрация по ID потока.</td>
					</tr>
					<tr>
                    	<td><code>site</code></td>
                    	<td>Фильтрация по ID сайта.</td>
					</tr>
					<tr>
                    	<td><code>utms</code></td>
                    	<td>Фильтрация по UTM-метке utm_source.</td>
					</tr>
					<tr>
                    	<td><code>utmc</code></td>
                    	<td>Фильтрация по UTM-метке utm_campaign.</td>
					</tr>
					<tr>
                    	<td><code>utmn</code></td>
                    	<td>Фильтрация по UTM-метке utm_content.</td>
					</tr>
					<tr>
                    	<td><code>utmt</code></td>
                    	<td>Фильтрация по UTM-метке utm_term.</td>
					</tr>
					<tr>
                    	<td><code>utmm</code></td>
                    	<td>Фильтрация по UTM-метке utm_medium.</td>
					</tr>
					<tr>
                    	<td><code>extu</code></td>
                    	<td>Фильтрация по внешнему ИД на стороне агентства.</td>
					</tr>
					<tr>
                    	<td><code>exts</code></td>
                    	<td>Фильтрация по ИД вебмастера на стороне агентства.</td>
					</tr>
            	</tbody>
			</table></div></div>
			<p>Результатом выполнения функции является ассоциативный массив. Идентификатором каждого элемента служит идентификатор выбранного элемента группировки. Каждый элемент включает в себя следующие поля:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>id</code></td>
                    	<td>Идентификатор элемента группировки</td>
					</tr>
					<tr>
                    	<td><code>name</code></td>
                    	<td>Название элемента группировки, если применимо</td>
					</tr>
					<tr>
                    	<td><code>spaces</code></td>
                    	<td>Количество кликов по прелэндингам</td>
					</tr>
					<tr>
                    	<td><code>suni</code></td>
                    	<td>Количество <b>уникальных</b> кликов по прелэндингам</td>
					</tr>
					<tr>
                    	<td><code>sgood</code></td>
                    	<td>Количество <b>успешных</b> визитов на прелэндинг</td>
					</tr>
					<tr>
                    	<td><code>stime</code></td>
                    	<td>Среднее время пользователя на прелэндинге в секундах</td>
					</tr>
					<tr>
                    	<td><code>clicks</code></td>
                    	<td>Количество кликов по лэндингам</td>
					</tr>
					<tr>
                    	<td><code>unique</code></td>
                    	<td>Количество <b>уникальных</b> кликов по лэндингам</td>
					</tr>
					<tr>
                    	<td><code>good</code></td>
                    	<td>Количество <b>успешных</b> визитов на лэндинг</td>
					</tr>
					<tr>
                    	<td><code>time</code></td>
                    	<td>Среднее время пользователя на лэндинге в секундах</td>
					</tr>
					<tr>
                    	<td><code>ct</code></td>
                    	<td>Общее количество заказов без учёта треша</td>
					</tr>
					<tr>
                    	<td><code>st</code></td>
                    	<td>Общая сумма по лидам без учёта треша</td>
					</tr>
					<tr>
                    	<td><code>ca</code></td>
                    	<td>Количество заказов в статусе «Принят»</td>
					</tr>
					<tr>
                    	<td><code>sa</code></td>
                    	<td>Сумма по лидам в статусе «Принят»</td>
					</tr>
					<tr>
                    	<td><code>cc</code></td>
                    	<td>Количество заказов в статусе «Отменён» без учёта треша</td>
					</tr>
					<tr>
                    	<td><code>sc</code></td>
                    	<td>Сумма по лидам в статусе «Отменён» без учёта треша</td>
					</tr>
					<tr>
                    	<td><code>cw</code></td>
                    	<td>Количество заказов в статусе «Ожидает»</td>
					</tr>
					<tr>
                    	<td><code>sw</code></td>
                    	<td>Сумма по лидам в статусе «Ожидает»</td>
					</tr>
					<tr>
                    	<td><code>cx</code></td>
                    	<td>Количество невалидных заказов (треш)</td>
					</tr>
					<tr>
                    	<td><code>sx</code></td>
                    	<td>Сумма по невалидным лидам (треш)</td>
					</tr>
            	</tbody>
			</table></div></div>
			<p>Пример ответа функции:</p>
			<pre>{
    "123": {
	"id": "123",
	"name": "Shiny test offer",
	"space": 321,
	"suni": 291,
	"sgood": 153,
	"stime": 23.45,
	"clicks": 113,
	"unique": 93,
	"time": 34.56,
	"good": 80,
	"ct": 13,
	"st": 9100,
	"ca": 5,
	"sa": 3500,
	"cc": 3,
	"sc": 2100,
	"cw": 5,
	"sw": 3500,
	"cx": 2,
	"sx": 1400
    }
}</pre>

			<h2 id="offers">Список офферов</h2>
			<p>URL: <code><?php 
echo $api;
?>wm/offers.json?id=<?php 
echo $user;
?>-<?php 
echo $akey;
?></code></p>
			<p>ID функции - <code>offers</code>. Функция позволяет получить список активных офферов, их описание и данные о конверсии. Чтобы показать информацию только по одному офферу, укажите его идентификатор в параметре <code>offer</code>.</p>
			<p>Результатом выполнения функции является ассоциативный массив списка офферов со следующими полями:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>id</code></td>
                    	<td>Идентификатор оффера в системе</td>
					</tr>
					<tr>
                    	<td><code>name</code></td>
                    	<td>Полное название оффера</td>
					</tr>
					<tr>
                    	<td><code>short</code></td>
                    	<td>Краткое название оффера</td>
					</tr>
					<tr>
                    	<td><code>cid</code></td>
                    	<td>Идентификатор категории оффера</td>
					</tr>
					<tr>
                    	<td><code>cat</code></td>
                    	<td>Название категории оффера</td>
					</tr>
					<tr>
                    	<td><code>epc</code></td>
                    	<td>EPC - цена клика (EPC)</td>
					</tr>
					<tr>
                    	<td><code>cr</code></td>
                    	<td>Convert Ratio, соотношение уникальных посетителей к количеству успешных заказов</td>
					</tr>
					<tr>
                    	<td><code>approve</code></td>
                    	<td>Процент подтверждения заказов с сайта</td>
					</tr>
					<tr>
                    	<td><code>geo</code></td>
                    	<td>Список географических целей по офферу с указанием цен и отчислений, содержит поля:
							<ul>
								<li><code>code</code> - код страны</li>
								<li><code>name</code> - название страны</li>
								<li><code>price</code> - цена на лэндинге</li>
								<li><code>currency</code> - валюта</li>
								<li><code>cr</code> - конверсия</li>
								<li><code>epc</code> - цена клика (EPC)</li>
								<li><code>approve</code> - процент подтверждения</li>
								<li><code>desktop</code> и <code>mobile</code> - суммы отчислений за десктоп и мобайл</li>
							</ul>
							Отчисления содержат следующие поля:
							<ul>
								<li><code>base</code> - базовая часть отчисления</li>
								<li><code>upsale</code> - дополнительное отчисление за единицу апсейла</li>
								<li><code>xsale</code> - дополнительное отчисление за единицу кроссейла</li>
								<li><code>percent</code> - процентное отчисление от суммы заказа</li>
								<li><code>currency</code> - валюта отчисления</li>
							</ul>
						</td>
					</tr>
					<tr>
                    	<td><code>land</code><br /><code>space</code></td>
                    	<td>Список лэндингов и прелэндингов оффера, аналогично <a href="#offersite">списка сайтов</a>:
							<ul>
								<li><code>id</code> - идентификатор сайта</li>
								<li><code>url</code> - URL сайта</li>
								<li><code>epc</code> - цена клика (EPC)</li>
								<li><code>cr</code> - конверсия</li>
								<li><code>approve</code> - процент подтверждённых заказов</li>
								<li><code>mobile</code> - оптимизация сайта под мобильные устройства</li>
								<li><code>default</code> - сайт используется по умолчанию</li>
							</ul>
						</td>
					</tr>

            	</tbody>
			</table></div></div>
			<p>Пример ответа сервера:</p>
			<pre>{
    "31": {
        "id": 31,
        "name": "Shiny test offer",
        "short": "Testing",
        "cid": 2,
        "cat": "Health and beauty",
        "epc": 262.5,
        "cr": 150,
        "appr": 42.9,
        "geo": {
            "ru": {
                "code": "ru",
                "name": "Россия",
                "price": 990,
                "currency": "rub",
                "cr": 6.2,
                "epc": 18.4,
                "approve": 71.2,
                "desktop": {
                    "base": 600,
                    "upsale": 30,
                    "crossale": 30,
                    "percent": 0,
                    "currency": "rub"
                },
                "mobile": {
                    "base": 500,
                    "upsale": 25,
                    "crossale": 25,
                    "percent": 0,
                    "currency": "rub"
                }
            },
        },
        "land": {
            "123": {
                "id": 123,
                "url": "http://land.cpa/test-land/",
                "epc": 23.4,
                "cr": 5.6,
                "approve": 78.9,
                "mobile": 1,
                "default": true
            },
        },
        "space": {
            "234": {
                "id": 234,
                "url": "http://blog.cpa/test-space/",
                "epc": 12.3,
                "cr": 4.5,
                "approve": 67.8,
                "mobile": 0,
                "default": false
            },
        }
    }
}</pre>

			<h2 id="offersite">Сайты оффера</h2>
			<p>URL: <code><?php 
echo $api;
?>wm/sites.json?id=<?php 
echo $user;
?>-<?php 
echo $akey;
?></code></p>
			<p>ID функции - <code>sites</code>. Функция позволяет получить список сайтов, прикреплённых к указанному офферу. На входе функция получает один параметр: <code>offer</code> - идентификатор оффера, для которого требуется получить список сайтов.</p>
			<p>Результатом выполнения функции является ассоциативный массив с двумя полями: <code>land</code> и <code>space</code>. Первое содержит список лэндингов данного оффера, второе - список доступных преленлингов. По каждому из сайтов представлена следующая информация:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>id</code></td>
                    	<td>Идентификатор сайта в системе</td>
					</tr>
					<tr>
                    	<td><code>url</code></td>
                    	<td>Полный адрес сайта</td>
					</tr>
					<tr>
                    	<td><code>epc</code></td>
                    	<td>EPC - Earn Per Click, средний доход за каждый клик</td>
					</tr>
					<tr>
                    	<td><code>cr</code></td>
                    	<td>Convert Ratio, соотношение уникальных посетителей к количеству успешных заказов</td>
					</tr>
					<tr>
                    	<td><code>approve</code></td>
                    	<td>Процент подтверждения заказов с сайта</td>
					</tr>
					<tr>
                    	<td><code>mobile</code></td>
                    	<td>Оптимизация сайта под мобильные устройства:
							<ul>
								<li><code>0</code> - не оптимизирован для мобильных устройств</li>
								<li><code>1</code> - перенаправляет на мобильную версию сайта</li>
								<li><code>2</code> - оптимизирован для мобильных устройств</li>
								<li><code>3</code> - адаптивный дизайн, оптимизирован под любые устройства</li>
							</ul>
						</td>
					</tr>
            	</tbody>
			</table></div></div>
			<p>Пример ответа сервера</p>
			<pre>{
    "land": {
        "123": {
            "id": 123,
            "url": "http://land.cpa/test-land/",
            "epc": 23.4,
            "cr": 5.6,
            "approve": 78.9,
            "mobile": 1
        },
    },
    "space": {
        "234": {
            "id": 234,
            "url": "http://blog.cpa/test-space/",
            "epc": 12.3,
            "cr": 4.5,
            "approve": 67.8,
            "mobile": 0
        },
    }
}</pre>

			<h2 id="flows">Список потоков</h2>
			<p>URL: <code><?php 
echo $api;
?>wm/flows.json?id=<?php 
echo $user;
?>-<?php 
echo $akey;
?></code></p>
			<p>ID функции - <code>flows</code>. Функция возвращает список потоков, созданных веб-мастером. На входе функция получает один параметр: <code>offer</code> - идентификатор оффера, для которого требуется получить список существующих потоков.</p>
			<p>Результатом выполнения функции является ассоциативный массив со списком потоков:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>id</code></td>
                    	<td>Идентификатор потока в системе</td>
					</tr>
					<tr>
                    	<td><code>url</code></td>
                    	<td>Полная ссылка потока</td>
					</tr>
					<tr>
                    	<td><code>offer</code></td>
                    	<td>ID оффера потока</td>
					</tr>
					<tr>
                    	<td><code>offername</code></td>
                    	<td>Название оффера потока</td>
					</tr>
					<tr>
                    	<td><code>name</code></td>
                    	<td>Название потока</td>
					</tr>
					<tr>
                    	<td><code>epc</code></td>
                    	<td>EPC - Earn Per Click, средний доход за каждый клик</td>
					</tr>
					<tr>
                    	<td><code>cr</code></td>
                    	<td>Convert Ratio, соотношение уникальных посетителей к количеству успешных заказов</td>
					</tr>
					<tr>
                    	<td><code>total</code></td>
                    	<td>Общий заработок по потоку</td>
					</tr>
					<tr>
                    	<td><code>site</code></td>
                    	<td>Идентификатор лэндинга</td>
					</tr>
					<tr>
                    	<td><code>siteurl</code></td>
                    	<td>URL лэндинга</td>
					</tr>
					<tr>
                    	<td><code>space</code></td>
                    	<td>Идентификатор прелэндинга (ноль - не используется)</td>
					</tr>
					<tr>
                    	<td><code>spaceurl</code></td>
                    	<td>URL прелэндинга (false - не используется)</td>
					</tr>
					<tr>
                    	<td><code>traffback</code></td>
                    	<td>Ссылка трафбека, куда перенаправляются пользователи, не подходящие по ГЕО</td>
					</tr>
					<tr>
                    	<td><code>postback</code></td>
                    	<td>Ссылка для отправки PostBack-запросов</td>
					</tr>
					<tr>
                    	<td><code>metrika</code></td>
                    	<td>Идентификатор счётчика Яндекс.Метрика</td>
					</tr>
					<tr>
                    	<td><code>google</code></td>
                    	<td>Идентификатор счётчика Google Tag Manager</td>
					</tr>
					<tr>
                    	<td><code>vkcom</code></td>
                    	<td>Идентификатор пикселя VKcom</td>
					</tr>
					<tr>
                    	<td><code>facebook</code></td>
                    	<td>Идентификатор пикселя Facebook</td>
					</tr>
					<tr>
                    	<td><code>utm_*</code></td>
                    	<td>UTM-метки: utm_source, utm_campaign, utm_content, utm_term, utm_medium</td>
					</tr>
            	</tbody>
			</table></div></div>
			<p>Пример ответа функции:</p>
			<pre>{
    "123": {
        "id": 123,
        "url": "http://blog.cpa/test-space/?flow=123&l=234",
        "offer": 45,
        "offername": "Shiny test offer",
        "name": "Still shiny 45",
        "epc": 12.3,
        "cr": 4.5,
        "total": 550,
        "site": 234,
        "siteurl": "land.cpa/test-site",
        "space": 345,
        "spaceurl": "blog.cpa/test-space",
        "traffback": "",
        "postback": "http://help.me/iamtrapped.php?key=inroom&number=5&status={stage}",
        "metrika": "123456789",
        "google": "123-ABDC",
        "vkcom": "VK-ABCD-1234",
        "facebook": "1234-56-7890",
        "utm_source": "google",
        "utm_campaign": "343",
        "utm_content": "987652",
        "utm_term": "helloworld",
        "utm_medium": "cpc"
    },
}</pre>

			<h2 id="flowadd">Создание потока</h2>
			<p>URL: <code><?php 
echo $api;
?>wm/add.json?id=<?php 
echo $user;
?>-<?php 
echo $akey;
?></code></p>
			<p>ID функции - <code>add</code>. Функция создаёт новый поток по офферу.</p>
			<p>На входе функция получает идентификатор оффера, по которому требуется создать поток. Идентификатор оффера передаётся в параметре <code>offer</code>, список идентификаторов можно получить в функции <a href="#offers">offers</a>.</p>
			<p>Результатом выполнения функции является ассоциативный массив:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Результат выполнения операции: <code>ok</code> в случае успешного выполнения, <code>error</code> в случае ошибки</td>
					</tr>
					<tr>
                    	<td><code>id</code></td>
                    	<td>Идентификатор созданного потока</td>
					</tr>
					<tr>
                    	<td><code>error</code></td>
                    	<td>Идентификатор ошибки: <code>offer-inactive</code> при работе с неактивным оффером, <code>request-error</code> в случае внутренней ошибки системы</td>
					</tr>
            	</tbody>
			</table></div></div>
			<p>Пример успешного ответа функции:</p>
			<pre><code>{ "status" : "ok", "id" : 1234 }</code></pre>
			<p>Пример ответа функции при возникновении ошибки:</p>
			<pre><code>{ "status" : "error", "error" : "offer-inactive" }</code></pre>

			<h2 id="flowedit">Редактирование потока</h2>
			<p>URL: <code><?php 
echo $api;
?>wm/edit.json?id=<?php 
echo $user;
?>-<?php 
echo $akey;
?></code></p>
			<p>ID функции - <code>edit</code>. Функция позволяет изменить настройки потока. Идентификатор потока является обязательным параметром, остальные параметры не обязательны для передачи.</p>
			<p>На входе функция получает следующие параметры:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>flow</code>*</td>
                    	<td>ID потока для изменения</td>
					</tr>
					<tr>
                    	<td><code>name</code></td>
                    	<td>Новое название потока</td>
					</tr>
					<tr>
                    	<td><code>site</code></td>
                    	<td>Идентификатор лэндинга</td>
					</tr>
					<tr>
                    	<td><code>space</code></td>
                    	<td>Идентификатор прелэндинга (ноль - не требуется)</td>
					</tr>
					<tr>
                    	<td><code>drt</code></td>
                    	<td>Идентификатор паркованного домена для перенаправления (ноль - не требуется)</td>
					</tr>
					<tr>
                    	<td><code>dst</code></td>
                    	<td>Идентификатор паркованного домена лэндингов (ноль - не требуется)</td>
					</tr>
					<tr>
                    	<td><code>dsp</code></td>
                    	<td>Идентификатор паркованного домена прелэндингов (ноль - не требуется)</td>
					</tr>
					<tr>
                    	<td><code>url</code></td>
                    	<td>Ссылка трафбека, куда перенаправляются пользователи, не подходящие по ГЕО</td>
					</tr>
					<tr>
                    	<td><code>pbu</code></td>
                    	<td>Ссылка для отправки PostBack-запросов</td>
					</tr>
					<tr>
                    	<td><code>mtrk</code></td>
                    	<td>Идентификатор счётчика Яндекс.Метрика</td>
					</tr>
					<tr>
                    	<td><code>ga</code></td>
                    	<td>Идентификатор счётчика Google Tag Manager</td>
					</tr>
					<tr>
                    	<td><code>vk</code></td>
                    	<td>Идентификатор пикселя VKcom</td>
					</tr>
					<tr>
                    	<td><code>fb</code></td>
                    	<td>Идентификатор пикселя Facebook</td>
					</tr>
					<tr>
                    	<td><code>utms</code></td>
                    	<td>UTM-метка utm_source</td>
					</tr>
					<tr>
                    	<td><code>utmc</code></td>
                    	<td>UTM-метка utm_campaign</td>
					</tr>
					<tr>
                    	<td><code>utmn</code></td>
                    	<td>UTM-метка utm_content</td>
					</tr>
					<tr>
                    	<td><code>utmt</code></td>
                    	<td>UTM-метка utm_term</td>
					</tr>
					<tr>
                    	<td><code>utmm</code></td>
                    	<td>UTM-метка utm_medium</td>
					</tr>
            	</tbody>
			</table></div></div>
			<p>Результатом выполнения функции является ассоциативный массив:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Результат выполнения операции: <code>ok</code> в случае успешного выполнения, <code>error</code> в случае ошибки</td>
					</tr>
					<tr>
                    	<td><code>error</code></td>
                    	<td>Идентификатор ошибки: <code>access-denied</code> при работе с недоступным потоком, <code>request-error</code> в случае внутренней ошибки системы</td>
					</tr>
            	</tbody>
			</table></div></div>
			<p>Пример успешного ответа функции:</p>
			<pre><code>{ "status" : "ok" }</code></pre>
			<p>Пример ответа функции при возникновении ошибки:</p>
			<pre><code>{ "status" : "error", "error" : "access-denied" }</code></pre>

			<h2 id="flowdel">Удаление потока</h2>
			<p>URL: <code><?php 
echo $api;
?>wm/del.json?id=<?php 
echo $user;
?>-<?php 
echo $akey;
?></code></p>
			<p>ID функции - <code>del</code>. Функция удаляет поток. На входе она получает идентификатор потока, который требуется удалить. Идентификатор оффера передаётся в параметре <code>flow</code>.</p>
			<p>Результатом выполнения функции является ассоциативный массив:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Результат выполнения операции: <code>ok</code> в случае успешного выполнения, <code>error</code> в случае ошибки</td>
					</tr>
					<tr>
                    	<td><code>error</code></td>
                    	<td>Идентификатор ошибки: <code>access-denied</code> при работе с недоступным потоком, <code>request-error</code> в случае внутренней ошибки системы</td>
					</tr>
            	</tbody>
			</table></div></div>
			<p>Пример успешного ответа функции:</p>
			<pre><code>{ "status" : "ok" }</code></pre>
			<p>Пример ответа функции при возникновении ошибки:</p>
			<pre><code>{ "status" : "error", "error" : "access-denied" }</code></pre>

		</div>

		<div class="bs-docs-section">

			<div class="page-header"><h1 id="comp">Поставщик</h1></div>
			<p>API-интерфейс поставщика позволяет произвести интеграцию вашего собственного интерфейса с нашей системой обработки заказов. Для работы со всеми функциями необходимо обращаться к приложению <code>comp</code>.</p>
			<p>URL: <code><?php 
echo $api;
?>comp/{function}.json?id=<?php 
echo $user;
?>-<?php 
echo $akey;
?></code></p>

			<h2 id="orderlist">Список заказов</h2>
			<p>URL: <code><?php 
echo $api;
?>comp/list.json?id=<?php 
echo $user;
?>-<?php 
echo $akey;
?></code></p>
			<p>ID функции - <code>list</code>. Функция позволяет получить список заказов. Параметры отбора могут передаваться в GET или POST-запросе.</p>
			<p>На входе функция может использовать следующие параметры для отбора заказов:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>oid</code></td>
                    	<td>Внутренний идентификатор заказа <?php 
echo $core->config('site', 'name');
?> или список идентификаторов через запятую</td>
					</tr>
					<tr>
                    	<td><code>ids[]</code></td>
                    	<td>Массив внутренних идентификатор заказа <?php 
echo $core->config('site', 'name');
?>.</td>
					</tr>
					<tr>
                    	<td><code>eid</code></td>
                    	<td>Внешний идентификатор заказа в интерфейсе поставщика или список идентификаторов через запятую</td>
					</tr>
					<tr>
                    	<td><code>eids[]</code></td>
                    	<td>Массив внешних идентификатор заказа из интерфейса поставщика.</td>
					</tr>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Статус заказа. Кроме основных статусов (см. поле <code>status</code> в таблице ниже) может получать дополнительные значения:
							<ul>
                    			<li><code>-1</code> - Заказы без отказов</li>
	  							<li><code>-2</code> - Заказы в обработке</li>
	  							<li><code>-3</code> - Подтверждённые заказы</li>
	  						</tr>
                    	</td>
					</tr>
					<tr>
                    	<td><code>from</code><br /><code>to</code></td>
                    	<td>Отбор заказов по времени с <code>from</code> до <code>to</code>. Время указывается в формате UNIX-timestamp. Могут использоваться как оба параметра одновременно, так и один из параметров по отдельности. Полезно для формирования выгрузки заказов в свой интерфейс, но для этой задачи рекомендуется использовать поле ниже.</td>
					</tr>
					<tr>
                    	<td><code>after</code></td>
                    	<td>Идентификатор последнего полученного заказа, после которого начинать выдачу. Полезно для выгрузки заказов в свой интерфейс - список заказов запрашивается каждый раз с указанием ID последнего полученного заказа, и в результате выводятся только новые заказы, пришедшие после указанного.</td>
					</tr>
				</tbody>
			</table></div></div>
			<p>Результатом выполнения функции является массив элементов со следующими полями:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>id</code></td>
                    	<td>Идентификатор заказа в рамках <?php 
echo $core->config('site', 'name');
?></td>
					</tr>
					<tr>
                    	<td><code>ext</code></td>
                    	<td>Внешний идентификатор заказа (в случае интеграции интерфейсов)</td>
					</tr>
					<tr>
                    	<td><code>offer</code></td>
                    	<td>Идентификатор оффера (см. <a href="#offers">список</a>)</td>
					</tr>
					<tr>
                    	<td><code>wm</code></td>
                    	<td>Идентификатор вебмастера</td>
					</tr>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Текущий статус заказа. Принимает одно из следующих значений:
							<ul>
                    			<li><code>1</code> - Новый заказ</li>
	  							<li><code>2</code> - В обработке</li>
	  							<li><code>3</code> - Перезвонить</li>
	  							<li><code>4</code> - Холд</li>
	  							<li><code>5</code> - Отменён</li>
	  							<li><code>6</code> - На упаковке</li>
	  							<li><code>7</code> - Отправка</li>
	  							<li><code>8</code> - В пути</li>
	  							<li><code>9</code> - Доставлен</li>
	  							<li><code>10</code> - Оплачен</li>
	  							<li><code>11</code> - Возврат</li>
	  							<li><code>12</code> - Удалён за фрод</li>
                    		</ul>
                    	</td>
					</tr>
					<tr>
                    	<td><code>reason</code></td>
                    	<td>Код причины отказа. Принимает одно из следующих значений:
							<ul>
								<li><code>1</code> - Некорректный номер <i>(треш)</i></li>
								<li><code>2</code> - Передумал</li>
								<li><code>3</code> - Не заказывал <i>(треш)</i></li>
								<li><code>4</code> - Требует сертификат</li>
								<li><code>5</code> - Неверное ГЕО <i>(треш)</i></li>
								<li><code>6</code> - Ошибки или фэйк <i>(треш)</i></li>
								<li><code>7</code> - Дублированный заказ <i>(треш)</i></li>
								<li><code>8</code> - Заказал в другом месте <i>(треш)</i></li>
								<li><code>9</code> - Дорого</li>
								<li><code>10</code> - Не устраивает доставка</li>
								<li><code>11</code> - Не удалось дозвониться</li>
								<li><code>12</code> - Подозрения на фрод <i>(треш)</i></li>
                    		</ul>
                    	</td>
					</tr>
					<tr>
                    	<td><code>check</code></td>
                    	<td>Флаг постановки заказа на проверку службой безопасности. <code>1</code> - заказ подозрительный и находится на проверке.</td>
					</tr>
					<tr>
                    	<td><code>calls</code></td>
                    	<td>Количество звонков по данному офферу</td>
					</tr>
					<tr>
                    	<td><code>site</code></td>
                    	<td>Адрес сайта, с которого был выполнен заказ</td>
					</tr>
					<tr>
                    	<td><code>ip</code></td>
                    	<td>IP-адрес заказчика</td>
					</tr>
					<tr>
                    	<td><code>time</code></td>
                    	<td>Время получения заказа в формате UNIX-timestamp</td>
					</tr>
					<tr>
                    	<td><code>name</code></td>
                    	<td>ФИО заказчика</td>
					</tr>
					<tr>
                    	<td><code>gender</code></td>
                    	<td>Пол заказчика. 1 - мужчина, 2 - женщина. Определяется автоматически.</td>
					</tr>
					<tr>
                    	<td><code>phone</code></td>
                    	<td>Телефон заказчика в формате 79876543210 </td>
					</tr>
					<tr>
                    	<td><code>country</code></td>
                    	<td>Двухбуквенный код страны заказчика, вычисляется на основании IP-адреса</td>
					</tr>
					<tr>
                    	<td><code>index</code></td>
                    	<td>Почтовый индекс адреса доставки в формате 127000</td>
					</tr>
					<tr>
                    	<td><code>addr</code></td>
                    	<td>Адрес доставки. Может содержать в себе полный адрес без индекса, если не используются поля ниже. В противном случае содержит только номер дома, корпуса, квартиры или офиса.</td>
					</tr>
					<tr>
                    	<td><code>area</code></td>
                    	<td>Регион доставки, например, Московская обл.</td>
					</tr>
					<tr>
                    	<td><code>city</code></td>
                    	<td>Город доставки, например Москва</td>
					</tr>
					<tr>
                    	<td><code>street</code></td>
                    	<td>Улица по адресу доставки, например ул. Мира</td>
					</tr>
					<tr>
                    	<td><code>count</code></td>
                    	<td>Количество товара.</td>
					</tr>
					<tr>
                    	<td><code>items</code></td>
                    	<td>Состав заказа, количество тех или иных вариантов товара. Массив, в котором ключ - идентификатор варианта, значение - количество товара данного вида и цена за единицу товара.</td>
					</tr>
					<tr>
                    	<td><code>delivery</code></td>
                    	<td>Идентификатор службы доставки</td>
					</tr>
					<tr>
                    	<td><code>discount</code></td>
                    	<td>Скидка на товар в процентах.</td>
					</tr>
					<tr>
                    	<td><code>currency</code></td>
                    	<td>ISO-код валюты товара</td>
					</tr>					
					<tr>
                    	<td><code>base</code></td>
                    	<td>Цена за единицу товара в валюте заказа</td>
					</tr>
					<tr>
                    	<td><code>delpr</code></td>
                    	<td>Цена за доставку в валюте заказа</td>
					</tr>
					<tr>
                    	<td><code>more</code></td>
                    	<td>Сумма добавочной стоимости заказа, например, наценки за экспресс-доставку.</td>
					</tr>
					<tr>
                    	<td><code>price</code></td>
                    	<td>Общая стоимость заказа.</td>
					</tr>
					<tr>
                    	<td><code>comment</code></td>
                    	<td>Дополнительный комментарий по заказу.</td>
					</tr>
            	</tbody>
			</table></div></div>
			<p>Пример ответа функции:</p>
			<pre>[
    {
        "id": 13131,
        "ext": 2424,
        "offer": 15,
        "offername": "Shiny test offer",
        "wm": 59,
        "status": 10,
        "reason": 0,
        "check": 0,
        "calls": 3,
        "site": 12,
        "siteurl": "land.cpa/test-offer",
        "space": 23,
        "spaceurl": "blog.cpa/test-space",
        "ip": "12.34.56.78",
        "time": <?php 
echo time();
?>,
        "name": "John Doe",
        "gender": 0,
        "phone": "123456789000",
        "country": "ru",
        "index": "100000",
        "area": "",
        "city": "Moscow",
        "street": "Lenina street",
        "addr": "1",
        "comment": "Заберет у курьера в течение 2-5  дней",
        "count": 6,
        "items": {
            "12": [ 3, 665 ],
            "23": [ 1, 665 ],
            "34": [ 2, 665 ]
        },
        "delivery": 1,
        "discount": 0,
        "currency": "rub",
        "base": "0.00",
        "more": "0.00",
        "delpr": "350.00",
        "price": "4340.00"
    }
]</pre>

			<h2 id="orderstatus">Смена статуса заказа</h2>
			<p>URL: <code><?php 
echo $api;
?>comp/status.json?id=<?php 
echo $user;
?>-<?php 
echo $akey;
?></code></p>
			<p>ID функции - <code>status</code>. Функция позволяет обновить статус существующего заказа и изменить некоторые его поля. Все параметры могут передаваться как в POST, так и в GET-части запроса. Функция оптимальна для использования в PostBack-запросах.</p>
			<p>На входе функция получает следующие параметры:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>oid</code> <br /> <code>eid</code></td>
                    	<td>Идентификатор заказа, над которым ведётся работа. Поле <code>oid</code> используется для указания внутреннего идентификатора заказа в рамках <?php 
echo $core->config('site', 'name');
?>, поле <code>eid</code> используется для работы с идентификатором заказа на стороне поставщика. Обязательное поле запроса. Может передаваться в GET.</td>
					</tr>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Текстовое поле со статусом заказа, привязанное к параметрам <code>st*</code> или распознаваемое автоматически по списку:
							<ul>
							<li><strong>Принят</strong>: a, accept, accepted, approve, approved, confirm, confirmed, 1</li>
							<li><strong>Холд</strong>: h, hold, holding</li>
							<li><strong>Отмена</strong>: c, d, decline, declined, cancel, cancelled, canceled, reject, rejected, -1</li>
							<li><strong>Треш</strong>: t, trash, error, wrong, bad</li>
							</ul>
                    	</td>
					</tr>
					<tr>
                    	<td><code>sta</code></td>
                    	<td>Значение статуса, которое будет распознано как аппрув</td>
					</tr>
					<tr>
                    	<td><code>stc</code></td>
                    	<td>Значение статуса, которое будет распознано как отмена</td>
					</tr>
					<tr>
                    	<td><code>stt</code></td>
                    	<td>Значение статуса, которое будет распознано как треш</td>
					</tr>
					<tr>
                    	<td><code>sth</code></td>
                    	<td>Значение статуса, которое будет распознано как холд</td>
					</tr>
					<tr>
                    	<td><code>stw</code></td>
                    	<td>Значение статуса, которое будет распознано как заказ в обработке</td>
					</tr>
					<tr>
                    	<td><code>name</code></td>
                    	<td>ФИО заказчика</td>
					</tr>
					<tr>
                    	<td><code>phone</code></td>
                    	<td>Телефон заказчика в формате 79876543210 (только цифры)</td>
					</tr>
					<tr>
                    	<td><code>email</code></td>
                    	<td>Адрес электронной почты заказчика</td>
					</tr>
					<tr>
                    	<td><code>comment</code></td>
                    	<td>Дополнительный комментарий по заказу.</td>
					</tr>
					<tr>
                    	<td><code>country</code></td>
                    	<td>Двухбуквенный ISO-код страны</td>
					</tr>
					<tr>
                    	<td><code>currency</code></td>
                    	<td>Трёхбуквенный ISO-код валюты</td>
					</tr>
					<tr>
                    	<td><code>base</code></td>
                    	<td>Цена за единицу товара или стоимость конверсии в валюте заказа</td>
					</tr>
					<tr>
                    	<td><code>count</code></td>
                    	<td>Количество товара в заказе</td>
					</tr>
					<tr>
                    	<td><code>delpr</code></td>
                    	<td>Стоимость доставки товара в валюте заказа</td>
					</tr>
            	</tbody>
			</table></div></div>
			<p>Обязательным являются только идентификатор заказа и статус, остальные поля используются по мере надобности. Результатом выполнения функции является ассоциативный массив:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Результат выполнения операции: <code>ok</code> в случае успешного выполнения, <code>error</code> в случае ошибки</td>
					</tr>
					<tr>
                    	<td><code>error</code></td>
                    	<td>Идентификатор ошибки: <code>orderid</code> при отсутствии идентификатора заказа, <code>edit</code> в случае отсутствия полей для обновления (например, если информация не изменялась), <code>access-denied</code> при работе с недоступным заказом, <code>request-error</code> в случае внутренней ошибки системы.</td>
					</tr>
            	</tbody>
			</table></div></div>
			<p>Пример успешного ответа функции:</p>
			<pre><code>{ "status" : "ok" }</code></pre>
			<p>Пример ответа функции при возникновении ошибки:</p>
			<pre><code>{ "status" : "error", "error" : "access-denied" }</code></pre>

			<h2 id="orderedit">Редактирование заказа</h2>
			<p>URL: <code><?php 
echo $api;
?>comp/edit.json?id=<?php 
echo $user;
?>-<?php 
echo $akey;
?></code></p>
			<p>ID функции - <code>edit</code>. Функция позволяет отредактировать поля существующего заказа, обновить его статус. Часть параметров может передаваться в GET-части запроса.</p>
			<p>На входе функция получает следующие параметры:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>oid</code> <br /> <code>eid</code></td>
                    	<td>Идентификатор заказа, над которым ведётся работа. Поле <code>oid</code> используется для указания внутреннего идентификатора заказа в рамках <?php 
echo $core->config('site', 'name');
?>, поле <code>eid</code> используется для работы с идентификатором заказа на стороне поставщика. Обязательное поле запроса. Может передаваться в GET.</td>
					</tr>
					<tr>
                    	<td><code>accept</code></td>
                    	<td>Флаг приёма заказа. Устанавливается в 1 если заказ в данный момент одобряется на стороне поставщика. Может передаваться в GET.</td>
					</tr>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Идентификатор нового статуса заказа. Может передаваться в GET. Принимает одно из следующих значений:
							<ul>
                    			<li><code>1</code> - Новый заказ</li>
	  							<li><code>2</code> - В обработке</li>
	  							<li><code>3</code> - Перезвонить</li>
	  							<li><code>4</code> - Холд</li>
	  							<li><code>5</code> - Отменён</li>
	  							<li><code>6</code> - На упаковке</li>
	  							<li><code>7</code> - Отправка</li>
	  							<li><code>8</code> - В пути</li>
	  							<li><code>9</code> - Доставлен</li>
	  							<li><code>10</code> - Оплачен</li>
	  							<li><code>11</code> - Возврат</li>
	  							<li><code>12</code> - Удалён</li>
                    		</ul>
							Для отмены заказа передайте статус 5 и поле <code>reason</code>. <br />
							<span class="text-danger"><b>Важно!</b> Для подтверждения заказа используйте поле <code>accept=1</code>, а не смену статуса заказа!</span>
                    	</td>
					</tr>
					<tr>
                    	<td><code>reason</code></td>
                    	<td>Код причины отказа, обязателен для указания при установке статуса <code>status=5</code>. Может передаваться в GET. Принимает одно из следующих значений:
							<ul>
								<li><code>1</code> - Некорректный номер <i>(треш)</i></li>
								<li><code>2</code> - Передумал</li>
								<li><code>3</code> - Не заказывал <i>(треш)</i></li>
								<li><code>4</code> - Требует сертификат</li>
								<li><code>5</code> - Неверное ГЕО <i>(треш)</i></li>
								<li><code>6</code> - Ошибки или фэйк <i>(треш)</i></li>
								<li><code>7</code> - Дублированный заказ <i>(треш)</i></li>
								<li><code>8</code> - Заказал в другом месте <i>(треш)</i></li>
								<li><code>9</code> - Дорого</li>
								<li><code>10</code> - Не устраивает доставка</li>
								<li><code>11</code> - Не удалось дозвониться</li>
								<li><code>12</code> - Подозрения на фрод <i>(треш)</i></li>
                    		</ul>
                    	</td>
					</tr>
					<tr>
                    	<td><code>check</code></td>
                    	<td>Флаг постановки заказа на проверку службой безопасности. <code>1</code> - отправить на проверку, <code>0</code> - снять с проверки. Может передаваться в GET.</td>
					</tr>
					<tr>
                    	<td><code>track</code></td>
                    	<td>Трек-код отправленной посылки. Может передаваться в GET.</td>
					</tr>
					<tr>
                    	<td><code>calls</code></td>
                    	<td>Увеличить количество выполненных звонков по данному заказу. <b class="text-warning">Важно!</b> В данном поле указывается не общее количество звонков, а только его прирост. Это значит, что если со времени последнего обновления количества звонков был сделан один звонок по заказу, здесь должно быть указано 1.</td>
					</tr>
					<tr>
                    	<td><code>name</code></td>
                    	<td>ФИО заказчика</td>
					</tr>
					<tr>
                    	<td><code>phone</code></td>
                    	<td>Телефон заказчика в формате 79876543210 (только цифры)</td>
					</tr>
					<tr>
                    	<td><code>email</code></td>
                    	<td>E-mail заказчика</td>
					</tr>
					<tr>
                    	<td><code>index</code></td>
                    	<td>Почтовый индекс адреса доставки в формате 127000 (только цифры)</td>
					</tr>
					<tr>
                    	<td><code>addr</code></td>
                    	<td>Адрес доставки. Может содержать в себе полный адрес без индекса, если не используются поля ниже. В противном случае должен содержать только номер дома, корпуса, квартиры или офиса.</td>
					</tr>
					<tr>
                    	<td><code>area</code></td>
                    	<td>Регион доставки, например, Московская обл.</td>
					</tr>
					<tr>
                    	<td><code>city</code></td>
                    	<td>Город доставки, например Москва</td>
					</tr>
					<tr>
                    	<td><code>street</code></td>
                    	<td>Улица по адресу доставки, например ул. Мира</td>
					</tr>
					<tr>
                    	<td><code>delivery</code></td>
                    	<td>Используемая идентификатор службы доставки</td>
					</tr>
					<tr>
                    	<td><code>base</code></td>
                    	<td>Стоимость единицы товара в валюте заказа</td>
					</tr>
					<tr>
                    	<td><code>delpr</code></td>
                    	<td>Стоимость доставки в валюте заказа</td>
					</tr>
					<tr>
                    	<td><code>discount</code></td>
                    	<td>Скидка на товар в процентах. Целое число от 0 до 99.</td>
					</tr>
					<tr>
                    	<td><code>count</code></td>
                    	<td>Количество товара, используется для товаров без дополнительных вариантов оформления, размера, цвета и пр.</td>
					</tr>
					<tr>
                    	<td><code>items</code></td>
                    	<td>Состав заказа, количество тех или иных вариантов товара. Принимает на входе массив, в котором ключ - идентификатор товара, значение - количество товара данного вида и его цена. Идентификаторы вариантов для своего товара уточните у администрации во время настройки интеграции. В случае указания поля <code>items</code>, передавать <code>count</code> не нужно.</td>
					</tr>
					<tr>
                    	<td><code>more</code></td>
                    	<td>Сумма добавочной стоимости заказа, например, наценки за экспресс-доставку. Прибавляется к основной сумме заказа после учёта всех скидок.</td>
					</tr>
					<tr>
                    	<td><code>comment</code></td>
                    	<td>Дополнительный комментарий по заказу.</td>
					</tr>
            	</tbody>
			</table></div></div>
			<p>Обязательным является только поле идентификатора заказа, остальные поля используются по мере надобности. Результатом выполнения функции является ассоциативный массив:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Результат выполнения операции: <code>ok</code> в случае успешного выполнения, <code>error</code> в случае ошибки</td>
					</tr>
					<tr>
                    	<td><code>error</code></td>
                    	<td>Идентификатор ошибки: <code>orderid</code> при отсутствии идентификатора заказа, <code>edit</code> в случае отсутствия полей для обновления (например, если информация не изменялась), <code>access-denied</code> при работе с недоступным заказом, <code>request-error</code> в случае внутренней ошибки системы.</td>
					</tr>
            	</tbody>
			</table></div></div>
			<p>Пример успешного ответа функции:</p>
			<pre><code>{ "status" : "ok" }</code></pre>
			<p>Пример ответа функции при возникновении ошибки:</p>
			<pre><code>{ "status" : "error", "error" : "access-denied" }</code></pre>

		</div>

		<div class="bs-docs-section">
			<div class="page-header"><h1 id="ext">Агентство</h1></div>
			<p>API-интерфейс агентства позволяет сторонним партнёрским сетям и арбитражным командам загружать лиды в систему и проверять статус их обработки с помощью выгрузки. Для работы со всеми функциями необходимо обращаться к приложению <code>ext</code>.</p>
			<p>URL: <code><?php 
echo $api;
?>ext/{function}.json?id=<?php 
echo $user;
?>-<?php 
echo $akey;
?></code></p>

			<h2 id="extadd">Добавление лида</h2>
			<p>URL: <code><?php 
echo $api;
?>ext/add.json?id=<?php 
echo $user;
?>-<?php 
echo $akey;
?></code></p>
			<p>ID функции - <code>add</code>. Функция позволяет добавить новый лид от имени агентства. Данные нового лида передаются в POST-запросе.</p>
			<p>На входе функция принимает следующие данные о лиде:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>id</code>*</td>
                    	<td><b>Уникальный</b> идентификатор заказа в рамках агентства (обязательный параметр)</td>
					</tr>
					<tr>
                    	<td><code>wm</code></td>
                    	<td>Идентификатор вебмастера или другого источника на стороне агентства</td>
					</tr>
					<tr>
                    	<td><code>offer</code>*</td>
                    	<td>Идентификатор оффера из <a href="#offers">списка</a> (обязательный параметр)</td>
					</tr>
					<tr>
                    	<td><code>ip</code>*</td>
                    	<td>IP-адрес заказчика  (обязательный параметр)</td>
					</tr>
					<tr>
                    	<td><code>name</code></td>
                    	<td>ФИО заказчика</td>
					</tr>
					<tr>
                    	<td><code>phone</code>*</td>
                    	<td>Телефон заказчика в формате 79876543210 (обязательный параметр)</td>
					</tr>
					<tr>
                    	<td><code>email</code></td>
                    	<td>Электронная почта заказчика</td>
					</tr>
					<tr>
                    	<td><code>ua</code></td>
                    	<td>User-Agent браузера заказчика</td>
					</tr>
					<tr>
                    	<td><code>country</code></td>
                    	<td>Двухбуквенный код страны заказчика, вычисляется на основании IP-адреса</td>
					</tr>
					<tr>
                    	<td><code>currency</code></td>
                    	<td>Трёхбуквенный код валюты заказчика, например RUB или BYN, по умолчанию вычисляется на основании страны заказчика</td>
					</tr>
					<tr>
                    	<td><code>index</code></td>
                    	<td>Почтовый индекс адреса доставки в формате 127000</td>
					</tr>
					<tr>
                    	<td><code>addr</code></td>
                    	<td>Адрес доставки. Может содержать в себе полный адрес без индекса, если не используются поля ниже. В противном случае содержит только номер дома, корпуса, квартиры или офиса.</td>
					</tr>
					<tr>
                    	<td><code>area</code></td>
                    	<td>Регион доставки, например, Московская обл.</td>
					</tr>
					<tr>
                    	<td><code>city</code></td>
                    	<td>Город доставки, например Москва</td>
					</tr>
					<tr>
                    	<td><code>street</code></td>
                    	<td>Улица по адресу доставки, например ул. Мира</td>
					</tr>
					<tr>
                    	<td><code>base</code></td>
                    	<td>Цена единицы товара в валюте заказа.</td>
					</tr>
					<tr>
                    	<td><code>count</code></td>
                    	<td>Количество товара.</td>
					</tr>
					<tr>
                    	<td><code>discount</code></td>
                    	<td>Скидка на товар в процентах.</td>
					</tr>
					<tr>
                    	<td><code>more</code></td>
                    	<td>Сумма добавочной стоимости заказа, например, наценки за экспресс-доставку.</td>
					</tr>
					<tr>
                    	<td><code>comm</code></td>
                    	<td>Дополнительный комментарий по заказу.</td>
					</tr>
					<tr>
                    	<td><code>promo</code></td>
                    	<td>Промо-код, указанный заказчиком.</td>
					</tr>
					<tr>
                    	<td><code>mobile</code></td>
                    	<td>Укажите <code>0</code> для десктоп-трафика и <code>1</code> для мобильного трафика</td>
					</tr>
					<tr>
                    	<td><code>bad</code></td>
                    	<td>Укажите <code>0</code> для нормального трафика и <code>1</code> для подозрительного трафика</td>
					</tr>
            	</tbody>
			</table></div></div>

			<p>Результатом выполнения функции является ассоциативный массив:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Результат выполнения операции: <code>ok</code> в случае успешного выполнения, <code>error</code> в случае ошибки</td>
					</tr>
					<tr>
                    	<td><code>id</code></td>
                    	<td>Идентификатор добавленного заказа (в случае успеха)</td>
					</tr>
					<tr>
                    	<td><code>error</code></td>
                    	<td>Идентификатор ошибки: <code>nooffer</code> при отсутствии идентификатора оффера, <code>noid</code> при отсутствии идентификатора заказа на стороне агентства, <code>nophone</code> при отсутствии номера телефона, <code>duplicate</code> при наличии заказа с таким же телефоном, именем и оффером в обработке, <code>offer</code> если не найден указанный оффер, <code>traffic</code> если оффер приватный или трафик на него запрещён, <code>security</code> при бане пользователя, <code>ban</code> при бане телефона или IP-адреса заказчика, <code>db</code> в случае внутренней ошибки добавления данных.</td>
					</tr>
            	</tbody>
			</table></div></div>
			<p>Пример ответа функции:</p>
			<pre><code>{ "status" : "ok", "id" : 1234 }</code></pre>

			<h2 id="extlist">Проверка статуса лидов</h2>
			<p>URL: <code><?php 
echo $api;
?>ext/list.json?id=<?php 
echo $user;
?>-<?php 
echo $akey;
?></code></p>
			<p>ID функции - <code>list</code>. Функция позволяет получить информацию о статусе обработки отправленных лидов. На входе функция получает параметр <code>ids</code>, содержащий список идентификаторов лидов на стороне агентства. Параметр может передаваться в GET или POST-запросе. Идентификаторы указываются через запятую. Рекомендуется отправлять не более 50 идентификаторов в одном запросе.</p>
			<p>Результатом выполнения функции является массив статусов лидов. Ключевой параметр - идентификатор заказа на стороне агентства. Для каждого лида указываются следующие параметры:</p>
			<div class="box box-<?php 
echo BOXSKIN;
?>"><div class="box-body no-padding table-responsive"><table class="table table-striped">
            	<thead><tr>
					<th>Поле</th>
					<th>Описание</th>
            	</tr></thead>
            	<tbody>
					<tr>
                    	<td><code>id</code></td>
                    	<td>Идентификатор заказа на стороне агентства</td>
					</tr>
					<tr>
                    	<td><code>src</code></td>
                    	<td>Идентификатор вебмастера (источника) на стороне агентства</td>
					</tr>
					<tr>
                    	<td><code>uid</code></td>
                    	<td>Идентификатор заказа на стороне нашей системы</td>
					</tr>
					<tr>
                    	<td><code>status</code></td>
                    	<td>Идентификатор статуса заказа. Принимает одно из следующих значений:
							<ul>
                    			<li><code>1</code> - Новый заказ</li>
	  							<li><code>2</code> - В обработке</li>
	  							<li><code>3</code> - Перезвонить</li>
	  							<li><code>4</code> - Холд</li>
	  							<li><code>5</code> - Отменён</li>
	  							<li><code>6</code> - На упаковке</li>
	  							<li><code>7</code> - Отправка</li>
	  							<li><code>8</code> - В пути</li>
	  							<li><code>9</code> - Доставлен</li>
	  							<li><code>10</code> - Оплачен</li>
	  							<li><code>11</code> - Возврат</li>
	  							<li><code>12</code> - Удалён за фрод</li>
                    		</ul>
                    	</td>
					</tr>
					<tr>
                    	<td><code>reason</code></td>
                    	<td>Код причины отказа для статуса 5. Принимает одно из следующих значений:
							<ul>
								<li><code>1</code> - Некорректный номер <i>(треш)</i></li>
								<li><code>2</code> - Передумал</li>
								<li><code>3</code> - Не заказывал <i>(треш)</i></li>
								<li><code>4</code> - Требует сертификат</li>
								<li><code>5</code> - Неверное ГЕО <i>(треш)</i></li>
								<li><code>6</code> - Ошибки или фэйк <i>(треш)</i></li>
								<li><code>7</code> - Дублированный заказ <i>(треш)</i></li>
								<li><code>8</code> - Заказал в другом месте <i>(треш)</i></li>
								<li><code>9</code> - Дорого</li>
								<li><code>10</code> - Не устраивает доставка</li>
								<li><code>11</code> - Не удалось дозвониться</li>
								<li><code>12</code> - Подозрения на фрод <i>(треш)</i></li>
                    		</ul>
                    	</td>
					</tr>
					<tr>
                    	<td><code>cash</code></td>
                    	<td>Сумма отчисления по лиду</td>
					</tr>
					<tr>
                    	<td><code>count</code></td>
                    	<td>Количество проданных единиц товара</td>
					</tr>
					<tr>
                    	<td><code>calls</code></td>
                    	<td>Количество звонков по данному заказу (только для некоторых офферов)</td>
					</tr>
					<tr>
                    	<td><code>comment</code></td>
                    	<td>Текстовый комментарий к заказу (при наличии)</td>
					</tr>
            	</tbody>
			</table></div></div>
			<p>Пример ответа функции:</p>
			<pre><code>[
 1234 : {
  "id": 1234, // ID заказа на стороне агентства
  "uid": 432, // ID заказа на стороне нашей системы
  "status": 5, // Код статуса заказа
  "reason": 2, // Код причины отказа
  "comment: "Мур-мур-мур-мур", // Комментарий по заказу
 },
 2345 : {
  "id": 2345, // ID заказа на стороне агентства
  "uid": 543, // ID заказа на стороне нашей системы
  "status": 6, // Код статуса заказа
  "count: 2, // Количество товара в заказе
 }
]</code></pre>

		</div>

    </div>

</div></div>

<?php 
include 'tpl/footer.php';

?>