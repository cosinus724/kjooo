<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

class delivery_rupost
{
    private $core = NULL;
    public function __construct($core)
    {
        $this->core = $core;
    }
    public function __call($a, $b)
    {
        return false;
    }
    public function track($cc, $code)
    {
        if ($cc["rupost_login"] && $cc["rupost_pass"]) {
            $login = $cc["rupost_login"];
            $pass = $cc["rupost_pass"];
        } else {
            if (defined("RUPOST_LOGIN") && defined("RUPOST_PASS")) {
                $login = RUPOST_LOGIN;
                $pass = RUPOST_PASS;
            } else {
                if (defined("RUPOST_LIST")) {
                    $lpl = json_decode(RUPOST_LIST, true);
                    $lpi = array_rand($lpl);
                    $login = $lpl[$lpi][0];
                    $pass = $lpl[$lpi][1];
                } else {
                    return false;
                }
            }
        }
        try {
            $client = new SoapClient("https://tracking.russianpost.ru/rtm34?wsdl", array("trace" => 1, "soap_version" => SOAP_1_2));
            $request = new SoapParam(array("OperationHistoryRequest" => array("Barcode" => $code, "MessageType" => "0", "Language" => "RUS"), "AuthorizationHeader" => array("login" => $login, "password" => $pass)), "OperationHistoryRequest");
            $result = $client->getOperationHistory($request);
        } catch (Exception $ex) {
            return array("next" => time() + 43000);
        }
        $stage = array();
        $tm = $status = 0;
        $hr = $result->OperationHistoryData->historyRecord;
        if (!is_array($hr)) {
            $hr = array($hr);
        }
        foreach ($hr as $r) {
            $st1 = (int) $r->OperationParameters->OperType->Id;
            $st2 = (int) $r->OperationParameters->OperAttr->Id;
            switch ($st1) {
                case 1:
                    $st = 1;
                    break;
                case 2:
                    switch ($st2) {
                        case 2:
                        case 4:
                        case 7:
                        case 9:
                            $st = 6;
                            break;
                        default:
                            $st = 5;
                    }
                    break;
                case 3:
                    $st = 6;
                    break;
                case 4:
                    $st = 2;
                    break;
                case 5:
                    switch ($st2) {
                        case 3:
                        case 8:
                            $st = 2;
                            break;
                        default:
                            $st = 6;
                    }
                    break;
                case 6:
                    $st = 4;
                    break;
                case 7:
                    $st = 4;
                    break;
                case 8:
                    switch ($st2) {
                        case 2:
                        case 9:
                        case 14:
                        case 15:
                        case 18:
                            $st = 4;
                            break;
                        case 27:
                        case 28:
                        case 29:
                        case 10:
                            $st = 3;
                            break;
                        default:
                            $st = 2;
                    }
                    break;
                case 9:
                    $st = 2;
                    break;
                case 10:
                    $st = 2;
                    break;
                case 11:
                    $st = 2;
                    break;
                case 12:
                    $st = 4;
                    break;
                case 13:
                    $st = 1;
                    break;
                case 14:
                    $st = 2;
                    break;
                case 15:
                    $st = 6;
                    break;
                case 16:
                    $st = 6;
                    break;
                case 17:
                    $st = 5;
                    break;
                case 18:
                    $st = 6;
                    break;
                case 19:
                    $st = 2;
                    break;
                case 20:
                    $st = 2;
                    break;
                case 21:
                    $st = 5;
                    break;
                case 22:
                    $st = 3;
                    break;
                case 23:
                    $st = 3;
                    break;
                case 24:
                    $st = 2;
                    break;
                case 25:
                    $st = 3;
                    break;
                case 26:
                    $st = 6;
                    break;
                case 27:
                    $st = 2;
                    break;
                case 28:
                    $st = 2;
                    break;
                case 29:
                    $st = 2;
                    break;
                case 30:
                    $st = 2;
                    break;
                case 31:
                    $st = 2;
                    break;
                case 32:
                    $st = 2;
                    break;
                case 33:
                    $st = 2;
                    break;
                default:
                    $st = 0;
            }
            $s = array("status" => $st, "time" => strtotime($r->OperationParameters->OperDate), "country" => strtolower($r->AddressParameters->CountryOper->Code2A), "zip" => (int) $r->AddressParameters->OperationAddress->Index, "city" => (string) $r->AddressParameters->OperationAddress->Description, "comment" => $r->OperationParameters->OperType->Name . ": " . $r->OperationParameters->OperAttr->Name);
            $tm = $s["time"];
            $status = $s["status"];
            $s["md5"] = md5($s["status"] . $s["time"] . $s["city"] . $s["comment"]);
            $stage[] = $s;
        }
        unset($result);
        unset($request);
        unset($client);
        unset($record);
        return array("next" => time() + 43000, "status" => $status, "time" => $tm, "stage" => $stage);
    }
    public function options($cc, $o)
    {
        $opts = array();
        $opts = $this->core->filter("delivery_rupost_options", $opts, array($cc, $o));
        return $opts;
    }
    public function action($action, $cc, $o)
    {
        $this->core->filter("delivery_rupost_action", $opts, array($action, $cc, $o));
    }
    public function form($c)
    {
        return array(array("type" => "text", "name" => "rupost_login", "head" => $this->core->lang["login"], "value" => $c["rupost_login"]), array("type" => "text", "name" => "rupost_pass", "head" => $this->core->lang["pass"], "value" => $c["rupost_pass"]));
    }
    public function save()
    {
        $core = $this->core;
        return array("rupost_login" => $core->text->line($core->post["rupost_login"]), "rupost_pass" => $core->text->line($core->post["rupost_pass"]));
    }
}

?>