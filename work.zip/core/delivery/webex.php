<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

class delivery_webex
{
    private $core = NULL;
    private $s2s = array("1" => 1, "2" => 1, "3" => 3, "4" => 2, "5" => 2, "6" => 2, "7" => 4, "8" => 3, "9" => 6, "10" => 5, "19" => 6, "20" => 5);
    public function __construct($core)
    {
        $this->core = $core;
    }
    public function __call($a, $b)
    {
        return false;
    }
    public function track($cc, $code)
    {
        $stage = array();
        $tm = $status = 0;
        if ($cc["webex_api"]) {
            $data = json_decode(curl("https://cp.webex.su/api/ipost/info.json?token=" . $cc["webex_api"] . "&id=" . $code), true);
            foreach ($data["history"] as $d) {
                $s = array("status" => $this->s2s[$d["status"]], "time" => $d["time"], "country" => $d["country"], "zip" => false, "city" => $d["city"], "comment" => $d["stage"] . ($d["comment"] ? ": " . $d["comment"] : ""));
                $tm = $s["time"];
                $status = $s["status"];
                $s["md5"] = md5($s["status"] . $s["time"] . $s["city"] . $s["comment"]);
                $stage[] = $s;
            }
        } else {
            $data = json_decode(curl("https://cp.webex.su/api/ipost/track.json?code=" . $code), true);
            if ($data["status"] == "error") {
                return false;
            }
            foreach ($data as $d) {
                $s = array("status" => $this->s2s[$d["status"]], "time" => $d["time"], "country" => $d["country"], "zip" => false, "city" => $d["city"], "comment" => $d["stage"]);
                $tm = $s["time"];
                $status = $s["status"];
                $s["md5"] = md5($s["status"] . $s["time"] . $s["city"] . $s["comment"]);
                $stage[] = $s;
            }
        }
        return array("next" => time() + 43000, "status" => $status, "time" => $tm, "stage" => $stage);
    }
    public function options($cc, $o)
    {
        if ($cc["webex_api"] && $o["track_code"]) {
            $options = array();
            $core = $this->core;
            if ($o["order_status"] < 10) {
                $options[] = array("icon" => "fa-address-card", "url" => $core->url("ia", "order", $o["order_id"], "dlaction") . "&oa=print", "name" => $core->lang["delivery_print"]);
            }
            return $options ? $options : false;
        }
        return false;
    }
    public function action($action, $cc, $o)
    {
        if ($cc["webex_api"]) {
            switch ($action) {
                case "print":
                    if ($o["track_code"]) {
                        $data = json_decode(curl("https://cp.webex.su/api/ipost/print.json?token=" . $cc["webex_api"] . "&ids=" . $o["track_code"]), true);
                        if ($data["status"] == "ok") {
                            $this->core->go($data["url"]);
                        } else {
                            msgo($this->core, "error");
                        }
                    } else {
                        msgo($this->core, "error");
                    }
                    break;
                default:
                    return false;
            }
        } else {
            return false;
        }
    }
    public function form($c)
    {
        return array(array("type" => "text", "name" => "webex_api", "head" => $this->core->lang["delivery_api"], "value" => $c["webex_api"]));
    }
    public function save()
    {
        $core = $this->core;
        return array("webex_api" => $core->text->line($core->post["webex_api"]));
    }
}

?>