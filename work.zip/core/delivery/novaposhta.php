<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

class delivery_novaposhta
{
    private $core = NULL;
    private $s2s = array("1" => 1, "2" => 3, "3" => 0, "4" => 2, "41" => 2, 2, 2, 4, 4, 5, 5, 5, "14" => 3, "101" => 2, "102" => 6, "103" => 6, "104" => 3, "105" => 6, "106" => 5, "107" => 6, "108" => 6);
    public function __construct($core)
    {
        $this->core = $core;
    }
    public function __call($a, $b)
    {
        return false;
    }
    public function track($cc, $code)
    {
        $req = json_decode(curl("https://api.novaposhta.ua/v2.0/json/", "{\"apiKey\":\"\",\"modelName\":\"TrackingDocument\",\"calledMethod\":\"getStatusDocuments\",\"methodProperties\":{\"Documents\":[{\"DocumentNumber\":\"" . $code . "\",\"Phone\":\"\"}]}}"), 1);
        if ($req["data"][0]) {
            $r = $req["data"][0];
            print_r($r);
            $st = $this->s2s[(int) $r["StatusCode"]];
            $s = array("status" => $st, "time" => $r["LastTransactionDateTimeGM"] ? strtotime($r["LastTransactionDateTimeGM"]) : ($r["RecipientDateTime"] ? strtotime($r["RecipientDateTime"]) : strtotime($r["DateCreated"])), "country" => "ua", "comment" => $r["Status"]);
            $s["md5"] = md5($s["status"] . $s["time"] . $s["comment"]);
            return array("next" => time() + 43000, "status" => $s["time"], "time" => $s["status"], "stage" => array($s));
        }
        return array("next" => time() + 43000);
    }
}

?>