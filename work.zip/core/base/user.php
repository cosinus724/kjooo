<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

class User
{
    private $core = NULL;
    public $auth = false;
    public $badlogin = false;
    public $badrec = false;
    public $id = 0;
    public $name = false;
    public $email = false;
    public $level = 0;
    public $work = 0;
    public $ban = false;
    public $cash = 0;
    public $wmr = 0;
    public $ref = 0;
    public $ext = 0;
    public $comp = 0;
    public $compad = false;
    public $team = 0;
    public $teamlead = false;
    public $man = 0;
    public $vip = false;
    public $api = false;
    public $news = false;
    public $supp_new = 0;
    public $meta = array();
    public function __construct($core)
    {
        $this->core = $core;
        $this->logout($core);
        $this->login($core);
    }
    public function login($core)
    {
        if ($ssi = $core->session["ssid"]) {
            $si = hexdec(substr($ssi, 0, -64));
            $sk = substr($ssi, -64);
            $userdata = $this->get($si);
            if ($userdata["user_id"]) {
                if (!$this->checkpass($userdata["user_mail"] . $userdata["user_id"] . $userdata["user_pass"], $sk, 3)) {
                    $userdata = NULL;
                }
            } else {
                $userdata = NULL;
            }
        } else {
            $userdata = NULL;
        }
        if ($core->post["in_user"] && $core->post["in_pass"]) {
            $in_user = $core->text->email($core->post["in_user"]);
            $userdata = $this->getbyname($in_user);
            if (!($userdata["user_id"] && $this->checkpass($core->post["in_pass"], $userdata["user_pass"]))) {
                $userdata = NULL;
            }
            if (!$userdata) {
                $this->badlogin = true;
            }
        }
        if ($core->get["recoverpass"]) {
            $token = $core->text->link($core->get["recoverpass"]);
            $si = hexdec(substr($token, 0, -64));
            $sk = substr($token, -64);
            $userdata = $si ? $this->get($si) : NULL;
            if (!($userdata["user_id"] && $this->checkpass($userdata["user_mail"] . $userdata["user_id"] . $userdata["user_pass"], $sk, 2))) {
                $userdata = NULL;
            }
            if (!$userdata) {
                $this->badrec = true;
            }
        }
        $this->load($userdata);
    }
    public function load($userdata)
    {
        if ($userdata) {
            $core = $this->core;
            $this->auth = true;
            $this->badlogin = false;
            $this->badrec = false;
            $this->id = (int) $userdata["user_id"];
            $this->name = $userdata["user_name"];
            $this->email = $userdata["user_mail"];
            $this->level = (int) $userdata["user_level"];
            $this->work = (int) $userdata["user_work"];
            $this->ban = (bool) $userdata["user_ban"];
            $this->cash = $userdata["user_cash"];
            $this->wmr = $userdata["user_wmr"];
            $this->ref = (int) $userdata["user_ref"];
            $this->ext = (int) $userdata["user_ext"];
            $this->comp = (int) $userdata["user_comp"];
            $this->compad = (bool) $userdata["user_compad"];
            $this->team = (int) $userdata["user_team"];
            $this->teamlead = (bool) $userdata["user_teamlead"];
            $this->man = (int) $userdata["user_man"];
            $this->vip = (bool) $userdata["user_vip"];
            $this->push = (int) $userdata["user_push"];
            $this->api = $userdata["user_api"];
            $this->news = (bool) $userdata["user_news"];
            $this->supp_new = (int) $userdata["supp_new"];
            $this->meta = $userdata["meta"];
            $ip = ip2int(remoteip($core->server));
            $dd = date("Ymd");
            if ($ip != $userdata["user_ip"] || $dd != $userdata["user_date"]) {
                $this->set($userdata["user_id"], array("user_ip" => $ip, "user_date" => $dd));
            }
            if (!defined("APIMODE")) {
                $sc = $this->pass($userdata["user_mail"] . $userdata["user_id"] . $userdata["user_pass"], 3);
                $ssid = dechex($userdata["user_id"]) . $sc;
                if ($core->session["ssid"] != $ssid) {
                    $core->sset("ssid", $ssid);
                }
            }
        } else {
            $this->auth = false;
        }
    }
    public function logout($core)
    {
        if ($core->get["logout"]) {
            $core->sset("ssid", NULL);
            $this->auth = false;
            $this->id = 0;
        }
    }
    public function recoverid($id, $mail, $pass)
    {
        return dechex($id) . $this->pass($mail . $id . $pass, 2);
    }
    public function get($id, $field = false)
    {
        $core = $this->core;
        $data = $core->cache("user.id" . $id);
        if (!$data) {
            $data = $core->db->row("SELECT * FROM " . DB_USER . " WHERE user_id = '" . $id . "' LIMIT 1");
            $data["meta"] = $data["user_meta"] ? unserialize($data["user_meta"]) : array();
            $core->cache("user.id" . $id, $data);
            $core->cache("user.mail" . md5($data["user_mail"]), $data);
        }
        return $field ? $data[$field] : $data;
    }
    public function set($id, $data)
    {
        $core = $this->core;
        $oldmail = $this->get($id, "user_mail");
        if ($core->db->edit(DB_USER, $data, "user_id = '" . $id . "'")) {
            $core->uncache("user.id" . $id);
            $core->uncache("user.mail" . md5($oldmail));
            if ($data["user_mail"] && $data["user_mail"] != $oldmail) {
                $core->uncache("user.mail" . md5($data["user_mail"]));
            }
            return true;
        }
        return false;
    }
    public function reset($id)
    {
        $oldmail = $this->get($id, "user_mail");
        $this->core->uncache("user.id" . $id);
        $this->core->uncache("user.mail" . md5($oldmail));
    }
    public function getbyname($email, $field = false)
    {
        $core = $this->core;
        $name = "user.mail" . md5($email);
        $data = $core->cache($name);
        if (!$data) {
            $data = $core->db->row("SELECT * FROM " . DB_USER . " WHERE user_mail = '" . $email . "' LIMIT 1");
            $data["meta"] = $data["user_meta"] ? unserialize($data["user_meta"]) : array();
            $core->cache("user.id" . $id, $data);
            $core->cache("user.mail" . md5($data["user_mail"]), $data);
        }
        return $field ? $data[$field] : $data;
    }
    public function edit($data)
    {
        $ups = array();
        foreach ($data as $k => $v) {
            $ups["user_" . $k] = $v;
        }
        return $this->set($this->id, $ups);
    }
    public function meta($id, $data)
    {
        $user = $this->get($id);
        $meta = array_merge($user["meta"], $data);
        $meta = addslashes(serialize($meta));
        if ($this->core->db->edit(DB_USER, array("user_meta" => $meta), "user_id = '" . $id . "'")) {
            $this->core->uncache("user.id" . $id);
            $this->core->uncache("user.mail" . md5($user["user_mail"]));
            return true;
        }
        return false;
    }
    public function pass($text, $sid = 1)
    {
        $sn = "SALTKEY" . $sid;
        if (defined($sn)) {
            return hash_hmac("sha256", $text, constant($sn));
        }
        return hash("sha256", $text);
    }
    public function checkpass($input, $check, $sid = 1)
    {
        if (strlen($check) == 32) {
            $pass = md5($input);
            return $pass == $check ? true : false;
        }
        $pass = $this->pass($input, $sid);
        return hash_equals($check, $pass);
    }
}

?>