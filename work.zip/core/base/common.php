<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function params($core, $list)
{
    $p = array();
    foreach ($list as $i => $n) {
        if (is_numeric($i)) {
            if (isset($core->post[$n]) && $core->post[$n] != "") {
                $p[$n] = (int) $core->post[$n];
            } else {
                if (isset($core->get[$n]) && $core->get[$n] != "") {
                    $p[$n] = (int) $core->get[$n];
                } else {
                    $p[$n] = false;
                }
            }
        } else {
            switch ($n) {
                case "date":
                    if (isset($core->post[$i]) && $core->post[$i] != "") {
                        $p[$i] = form2date($core->post[$i]);
                    } else {
                        if (isset($core->get[$i]) && $core->get[$i] != "") {
                            $p[$i] = form2date($core->get[$i]);
                        } else {
                            $p[$i] = false;
                        }
                    }
                    break;
                case "email":
                    if (isset($core->post[$i]) && $core->post[$i] != "") {
                        $p[$i] = $core->text->email($core->post[$i]);
                    } else {
                        if (isset($core->get[$i]) && $core->get[$i] != "") {
                            $p[$i] = $core->text->email($core->get[$i]);
                        } else {
                            $p[$i] = false;
                        }
                    }
                    break;
                default:
                    if (isset($core->post[$i]) && $core->post[$i] != "") {
                        $p[$i] = $core->text->line($core->post[$i]);
                    } else {
                        if (isset($core->get[$i]) && $core->get[$i] != "") {
                            $p[$i] = $core->text->line($core->get[$i]);
                        } else {
                            $p[$i] = false;
                        }
                    }
                    break;
            }
        }
    }
    return $p;
}
function array2xml($array, $prev, $xml = false)
{
    if ($xml === false) {
        $xml = new SimpleXMLElement("<result/>");
    }
    foreach ($array as $key => $value) {
        if (is_array($value)) {
            if (is_numeric($key)) {
                array2xml($value, $prev, $xml->addChild($prev));
            } else {
                array2xml($value, $key, $xml->addChild($key));
            }
        } else {
            $xml->addChild($key, $value);
        }
    }
    return $xml->asXML();
}
function ip2int($ip)
{
    return sprintf("%u", ip2long($ip));
}
function int2ip($ip)
{
    return long2ip($ip);
}
function remoteip($server)
{
    if (goodip($server["HTTP_CLIENT_IP"]) && !privateip($server["HTTP_CLIENT_IP"])) {
        return $server["HTTP_CLIENT_IP"];
    }
    if (goodip($server["HTTP_X_FORWARDED_FOR"]) && !privateip($server["HTTP_X_FORWARDED_FOR"])) {
        return $server["HTTP_X_FORWARDED_FOR"];
    }
    if (goodip($server["HTTP_X_REAL_IP"]) && !privateip($server["HTTP_X_REAL_IP"])) {
        return $server["HTTP_X_REAL_IP"];
    }
    return $server["REMOTE_ADDR"];
}
function goodip($ip)
{
    return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) ? 1 : 0;
}
function publicip($ip)
{
    return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) ? 1 : 0;
}
function privateip($ip)
{
    return publicip($ip) ? 0 : 1;
}
function pages($linkex, $items, $onpage, $page, $f = false)
{
    $qpos = strpos($linkex, "?");
    if ($qpos !== false) {
        $sp = isset($linkex[$qpos + 1]) ? "&" : "";
    } else {
        $sp = "?";
    }
    $pages = ceil($items / $onpage);
    if ($pages < 2) {
        return $f ? $f : "";
    }
    $block1st = 1;
    $block1en = min(2, $pages);
    $block2st = max($block1en + 1, min($page - 2, $pages - 4));
    $block2en = min($pages, $block2st + 4);
    $block3st = max($block2en + 1, $pages - 1);
    $block3en = $pages;
    $pl = 1 < $page ? "<li><a rel=\"prev\" href=\"" . $linkex . $sp . "page=" . ($page - 1) . "\">&laquo;</a></li>" : "";
    for ($i = $block1st; $i <= $block1en; $i++) {
        $linkto = 1 < $i ? $linkex . $sp . "page=" . $i : $linkex;
        $pl .= "<li" . ($i == $page ? " class=\"active\"" : "") . "><a href=\"" . $linkto . "\">" . $i . "</a></li>";
    }
    if ($i < $block2st) {
        $pl .= "<li class=\"disabled\"><a href=\"#\">&hellip;</a></li>";
    }
    for ($i = $block2st; $i <= $block2en; $i++) {
        $pl .= "<li" . ($i == $page ? " class=\"active\"" : "") . "><a href=\"" . $linkex . $sp . "page=" . $i . "\">" . $i . "</a></li>";
    }
    if ($i < $block3st) {
        $pl .= "<li class=\"disabled\"><a href=\"#\">&hellip;</a></li>";
    }
    for ($i = $block3st; $i <= $block3en; $i++) {
        $pl .= "<li" . ($i == $page ? " class=\"active\"" : "") . "><a href=\"" . $linkex . $sp . "page=" . $i . "\">" . $i . "</a></li>";
    }
    if ($page < $pages) {
        $pl .= "<li><a rel=\"next\" href=\"" . $linkex . $sp . "page=" . ($page + 1) . "\">&raquo;</a></li>";
    }
    $pl = trim($pl);
    if ($f) {
        $pl = "<ul class=\"pagination pagination-sm no-margin pull-right\">" . $pl . "</ul><div class=\"shown\">" . $f . "</div>";
    } else {
        if ($pl) {
            $pl = "<ul class=\"pagination\">" . $pl . "</ul>";
        }
    }
    return $pl;
}
function stripslashes_deep($value)
{
    $value = is_array($value) ? array_map("stripslashes_deep", $value) : stripslashes($value);
    return $value;
}
function add_magic_quotes($array)
{
    foreach ((array) $array as $k => $v) {
        if (is_array($v)) {
            $array[$k] = add_magic_quotes($v);
        } else {
            $array[$k] = escape($v);
        }
    }
    return $array;
}
function escape($data)
{
    if (is_array($data)) {
        foreach ((array) $data as $k => $v) {
            if (is_array($v)) {
                $data[$k] = escape($v);
            } else {
                $data[$k] = addslashes($v);
            }
        }
    } else {
        $data = addslashes($data);
    }
    return $data;
}
function mkb($bytes)
{
    if (1024 * 1024 < $bytes) {
        return sprintf("%1.2f Mb", $bytes / 1024 / 1024);
    }
    if (1024 < $bytes) {
        return sprintf("%1.2f kb", $bytes / 1024);
    }
    return $bytes ? $bytes : 0;
}
function smartdate($tim)
{
    global $core;
    if (time() - 60 * 60 * 24 < $tim && date("d", $tim) == date("d", time())) {
        return $core->lang["today"] . date("H:i", $tim);
    }
    if (time() - 2 * 60 * 60 * 24 < $tim && date("d", $tim) == date("d", time()) - 1) {
        return $core->lang["yesterday"] . date("H:i", $tim);
    }
    return date("d.m.y H:i", $tim);
}
function form2date($date)
{
    $date = preg_replace("#([^0-9\\-])+#i", "", $date);
    $date = explode("-", $date);
    return sprintf("%04d%02d%02d", $date[0], $date[1], $date[2]);
}
function date2form($date = "00000000")
{
    $y = (int) substr($date, 0, 4);
    $m = (int) substr($date, 4, 2);
    $d = (int) substr($date, 6, 2);
    return sprintf("%04d-%02d-%02d", $y, $m, $d);
}
function date2show($format, $date)
{
    $y = (int) substr($date, 0, 4);
    $m = (int) substr($date, 4, 2);
    $d = (int) substr($date, 6, 2);
    $date = mktime(0, 0, 0, $m, $d, $y);
    return date($format, $date);
}
function wrand(&$data)
{
    $sm = array_sum($data);
    $rn = rand(0, $sm);
    $cc = 0;
    foreach ($data as $d => $v) {
        if ($cc <= $rn && $rn < $cc + $v) {
            return $d;
        }
        $cc += $v;
    }
    return $d;
}
function randstr($len, $type = 0)
{
    switch ($type) {
        case 1:
            $l = 36;
            $r = "1234567890qwertyuiopasdfghjklzxcvbnm";
            break;
        case 2:
            $l = 74;
            $r = "1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM-_=+!@#\$%^&*";
            break;
        default:
            $l = 62;
            $r = "1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM";
    }
    $s = "";
    for ($i = 0; $i < $len; $i++) {
        $s .= $r[rand(0, $l)];
    }
    return $s;
}
function numinf($l, $n)
{
    if (!$n && isset($l[3])) {
        return $l[3];
    }
    $a = $n % 10;
    $b = $n % 100;
    if ($a == 0 || 4 < $a || 10 < $b && $b < 20) {
        return sprintf($l[2], $n);
    }
    if ($a == 1) {
        return sprintf($l[0], $n);
    }
    return sprintf($l[1], $n);
}
function numinfi($n)
{
    $a = $n % 10;
    $b = $n % 100;
    if ($a == 0 || 5 < $a || 10 < $b && $b < 20) {
        return 2;
    }
    if ($a == 1) {
        return 0;
    }
    return 1;
}
function select($data, $cur = NULL, $fld = NULL)
{
    $result = array();
    foreach ($data as $val => $name) {
        $result[] = array("name" => $fld ? $name[$fld] : $name, "value" => $val, "select" => $cur !== NULL && $cur == $val ? true : false);
    }
    return $result;
}
function parset($params, $p, $v = NULL)
{
    if ($v !== NULL) {
        $params[$p] = $v;
    } else {
        unset($params[$p]);
    }
    return $params ? http_build_query($params) : "";
}
function parmult($params, $ps)
{
    foreach ($ps as $p => $v) {
        $params[$p] = $v;
    }
    return $params ? http_build_query($params) : "";
}
function msgo($core, $msg)
{
    $ref = $core->server["HTTP_REFERER"];
    if (strpos($ref, "message=") !== false) {
        $core->go(preg_replace("#message=([a-z0-9]+)#i", "message=" . $msg, $ref));
    } else {
        $core->go($ref . (strpos($ref, "?") !== false ? "&" : "?") . "message=" . $msg);
    }
}
function cleandir($path)
{
    if (substr($path, -1) != "/") {
        $path .= "/";
    }
    $d = opendir($path);
    while (($f = readdir($d)) !== false) {
        if ($f == "." || $f == "..") {
            continue;
        }
        if (is_dir($path . $f)) {
            cleandir($path . $f . "/");
            @rmdir($path . $f);
        } else {
            @unlink($path . $f);
        }
    }
    closedir($d);
}
function removedir($path)
{
    if (substr($path, -1) != "/") {
        $path .= "/";
    }
    $d = opendir($path);
    while (($f = readdir($d)) !== false) {
        if (is_dir($path . $f)) {
            removedir($path . $f . "/");
        } else {
            @unlink($path . $f);
        }
    }
    closedir($d);
    rmdir($path);
}
function cleancache($path, $timeout)
{
    $tt = time() - $timeout;
    if (substr($path, -1) != "/") {
        $path .= "/";
    }
    $d = opendir($path);
    if (!$d) {
        return false;
    }
    while (($f = readdir($d)) !== false) {
        if ($f == "." || $f == "..") {
            continue;
        }
        if (is_dir($path . $f)) {
            cleancache($path . $f . "/", $timeout);
        } else {
            if (filemtime($path . $f) < $tt) {
                @unlink($path . $f);
            }
        }
    }
    @closedir($d);
}
function money($m)
{
    $cl = $m < 0 ? "text-danger" : ($m ? "text-success" : "text-muted");
    return "<span class=\"" . $cl . "\">" . CURBEFORE . sprintf(CURFORMAT, $m) . CURAFTER . "</span>";
}
function mval($m)
{
    $cl = $m < 0 ? "text-danger" : ($m ? "text-success" : "text-muted");
    return "<span class=\"" . $cl . "\">" . sprintf(CURFORMAT, $m) . "</span>";
}
function curl($url, $post = array(), $config = array())
{
    if ($config["webproxy"]) {
        $result = webcurl($config["webproxy"], $url, $post, $config);
        return $result ? $result["data"] : false;
    }
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:59.0) Gecko/20100101 Firefox/59.0");
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    if (!$config["nofollow"]) {
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
    }
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($curl, CURLOPT_FAILONERROR, false);
    if ($post) {
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $post);
    }
    if ($config["login"] && $config["pass"]) {
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
        curl_setopt($curl, CURLOPT_USERPWD, $config["login"] . ":" . $config["pass"]);
    }
    if ($config["cookie"]) {
        curl_setopt($curl, CURLOPT_COOKIEFILE, $config["cookie"]);
        curl_setopt($curl, CURLOPT_COOKIEJAR, $config["cookie"]);
    }
    if (isset($config["timeout"])) {
        if ($config["timeout"]) {
            curl_setopt($curl, CURLOPT_TIMEOUT, $config["timeout"]);
        }
    } else {
        curl_setopt($curl, CURLOPT_TIMEOUT, 15);
    }
    if ($config["referer"]) {
        curl_setopt($curl, CURLOPT_REFERER, $config["referer"]);
    }
    if ($config["header"]) {
        curl_setopt($curl, CURLOPT_HTTPHEADER, $config["header"]);
    }
    if ($config["showheader"]) {
        curl_setopt($curl, CURLOPT_HEADER, true);
    }
    if ($config["request"]) {
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $config["request"]);
    }
    if ($config["proxy"]) {
        curl_setopt($curl, CURLOPT_PROXY, $config["proxy"]);
    }
    if ($config["pauth"]) {
        curl_setopt($curl, CURLOPT_PROXYUSERPWD, $config["pauth"]);
    }
    $result = curl_exec($curl);
    $code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($config["onlyinfo"]) {
        $result = $config["infopart"] ? curl_getinfo($curl, $config["infopart"]) : curl_getinfo($curl);
    }
    curl_close($curl);
    return $config["onlycode"] ? $code : $result;
}
function webcurl($proxy, $url, $post = false, $config = array())
{
    $request = array("url" => $url);
    $param = $config["timer"] ? array("time" => $config["timer"]) : false;
    if ($post) {
        $request["post"] = serialize($post);
    }
    if ($config["cookie"]) {
        $request["cookie"] = $config["cookie"];
    }
    if ($config["time"]) {
        $request["time"] = $config["time"];
    }
    if ($config["ref"]) {
        $request["ref"] = $config["ref"];
    }
    if ($config["ua"]) {
        $request["ua"] = $config["ua"];
    }
    $result = curl($proxy, $request, $param);
    if ($result == "error") {
        return false;
    }
    $result = unserialize($result);
    return $result["data"];
}
function geoip($core, $ip)
{
    $ip = sprintf("%u", ip2long($ip));
    if (!$ip) {
        return false;
    }
    $ipd = $core->db->row("SELECT * FROM `" . DB_GEOIP . "` WHERE `ip` < '" . $ip . "' ORDER BY `ip` DESC LIMIT 1");
    if (!$ipd) {
        return false;
    }
    $cid = $ipd["city"] ? $core->db->row("SELECT * FROM `" . DB_GEOCITY . "` WHERE `id` = '" . $ipd["city"] . "' LIMIT 1") : false;
    $result = array("status" => "ok", "ip" => long2ip($ip), "from" => long2ip($ipd["ip"]), "to" => long2ip($ipd["last"]), "country" => $ipd["country"]);
    if ($cid["city"]) {
        $result["city"] = $cid["city"];
    }
    if ($cid["region"]) {
        $result["region"] = $cid["region"];
    }
    if ($cid["district"]) {
        $result["district"] = $cid["district"];
    }
    if ($cid["lat"]) {
        $result["lat"] = $cid["lat"];
    }
    if ($cid["lng"]) {
        $result["lng"] = $cid["lng"];
    }
    return $result;
}
function enpromo($phone)
{
    if (!defined("PROMO")) {
        return false;
    }
    $phone = str_replace("#([^0-9]+)#i", "", $phone);
    if ($phone[0] == "8") {
        $phone = "7" . substr($phone, 1);
    }
    if ($phone[0] == "7" && strlen($phone) == 11) {
        $phone = substr($phone, 1);
    }
    $promo = "";
    $prd = PROMO;
    $l = strlen($phone);
    for ($i = 0; $i < $l; $i++) {
        $promo .= ($phone[$i] + $prd[$i]) % 10;
    }
    return $promo;
}
function depromo($promo)
{
    if (!defined("PROMO")) {
        return false;
    }
    $prd = PROMO;
    $l = strlen($promo);
    $phone = $l == 10 ? "7" : "";
    for ($i = 0; $i < $l; $i++) {
        $phone .= (10 + $promo[$i] - $prd[$i]) % 10;
    }
    return $phone;
}

?>