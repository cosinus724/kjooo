<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

class MySQL
{
    private $conid = NULL;
    private $auth = NULL;
    public $status = NULL;
    public $queries = NULL;
    public $log = array();
    public function __construct($sqlserver, $sqluser, $sqlpassword, $database, $charset = NULL, $collate = NULL)
    {
        $this->status = false;
        $this->queries = 0;
        $this->conid = NULL;
        $this->auth = array("server" => $sqlserver, "login" => $sqluser, "pass" => $sqlpassword, "db" => $database, "charset" => $charset, "collate" => $collate);
    }
    public function __destruct()
    {
        if ($this->conid) {
            return @mysqli_close($this->conid);
        }
        return false;
    }
    public function connect($auth = false)
    {
        if ($this->conid) {
            return true;
        }
        if ($auth) {
            $this->auth = $auth;
        }
        $this->conid = mysqli_connect($this->auth["server"], $this->auth["login"], $this->auth["pass"], $this->auth["db"]);
        if ($this->conid) {
            if ($this->auth["charset"] && $this->auth["collate"]) {
                mysqli_query($this->conid, "set character_set_client='" . $this->auth["charset"] . "', character_set_results='" . $this->auth["charset"] . "', collation_connection='" . $this->auth["collate"] . "'");
            } else {
                if ($this->auth["charset"]) {
                    mysqli_query($this->conid, "set character_set_client='" . $this->auth["charset"] . "', character_set_results='" . $this->auth["charset"] . "'");
                } else {
                    if ($this->auth["collate"]) {
                        mysqli_query($this->conid, "set collation_connection='" . $this->auth["collate"] . "'");
                    } else {
                        mysqli_set_charset($this->conid, "utf8");
                    }
                }
            }
            return $this->status = true;
        }
        return false;
    }
    public function query($sql, $use = false)
    {
        if (!$this->status && !$this->connect()) {
            exit("Database connection error!");
        }
        if ($sql) {
            $this->queries++;
            if (defined("SQL_LOG")) {
                list($usec, $sec) = explode(" ", microtime());
                $start = (double) $usec + (double) $sec;
                $result = mysqli_query($this->conid, $sql, $use ? MYSQLI_USE_RESULT : MYSQLI_STORE_RESULT);
                list($usec, $sec) = explode(" ", microtime());
                $end = (double) $usec + (double) $sec;
                $tm = $end - $start;
                $this->log[] = sprintf("%s - %0.4f ms", $sql, $tm);
                return $result;
            }
            return mysqli_query($this->conid, $sql, $use ? MYSQLI_USE_RESULT : MYSQLI_STORE_RESULT);
        }
        return false;
    }
    public function field($sql)
    {
        if ($result = $this->query($sql, true)) {
            $ret = mysqli_fetch_row($result);
            mysqli_free_result($result);
            return $ret[0];
        }
        return false;
    }
    public function col($sql)
    {
        if ($result = $this->query($sql, true)) {
            $ret = array();
            while ($r = mysqli_fetch_row($result)) {
                $ret[] = $r[0];
            }
            mysqli_free_result($result);
            return $ret;
        }
        return false;
    }
    public function icol($sql)
    {
        if ($result = $this->query($sql, true)) {
            $ret = array();
            while ($_r = mysqli_fetch_row($result)) {
                $ret[$_r[0]] = $_r[1];
            }
            mysqli_free_result($result);
            return $ret;
        }
        return false;
    }
    public function row($sql)
    {
        if ($result = $this->query($sql, true)) {
            $ret = mysqli_fetch_assoc($result);
            mysqli_free_result($result);
            return $ret;
        }
        return false;
    }
    public function data($sql)
    {
        if ($result = $this->query($sql, true)) {
            if (!function_exists("mysqli_fetch_all")) {
                $ret = array();
                while ($r = mysqli_fetch_assoc($result)) {
                    $ret[] = $r;
                }
            } else {
                $ret = mysqli_fetch_all($result, MYSQLI_ASSOC);
            }
            @mysqli_free_result($result);
            return $ret;
        }
        return false;
    }
    public function start($sql)
    {
        return $this->query($sql);
    }
    public function one($query)
    {
        if ($query) {
            return mysqli_fetch_assoc($query);
        }
        return false;
    }
    public function stop($query)
    {
        if ($query) {
            return mysqli_free_result($query);
        }
        return false;
    }
    public function get($table, $where)
    {
        $where = $this->where($where);
        $sql = "SELECT * FROM `" . $table . "` WHERE " . $where . " LIMIT 1";
        return $this->row($sql);
    }
    public function all($table, $where = false)
    {
        if ($where) {
            $where = $this->where($where);
            $sql = "SELECT * FROM `" . $table . "` WHERE " . $where;
        } else {
            $sql = "SELECT * FROM `" . $table . "`";
        }
        return $this->data($sql);
    }
    public function add($table, $data)
    {
        $sql = "INSERT INTO `" . $table . "` ( `" . implode("`, `", array_keys($data)) . "` ) VALUES ( '" . implode("', '", $data) . "' )";
        return $this->query($sql);
    }
    public function replace($table, $data)
    {
        $sql = "REPLACE INTO `" . $table . "` ( `" . implode("`, `", array_keys($data)) . "` ) VALUES ( '" . implode("', '", $data) . "' )";
        return $this->query($sql);
    }
    public function edit($table, $data, $where)
    {
        $where = $this->where($where);
        $sql = "UPDATE `" . $table . "` SET ";
        foreach ($data as $i => &$d) {
            $sql .= " `" . $i . "` = '" . $d . "', ";
        }
        unset($d);
        $sql = substr($sql, 0, -2) . " WHERE " . $where;
        return $this->query($sql);
    }
    public function del($table, $where)
    {
        $where = $this->where($where);
        $sql = "DELETE FROM `" . $table . "` WHERE " . $where;
        return $this->query($sql);
    }
    private function where($where)
    {
        if (is_array($where)) {
            $w = array();
            foreach ($where as $i => $v) {
                $w[] = "`" . $i . "` = '" . $v . "'";
            }
            $where = implode(" AND ", $w);
        }
        return $where;
    }
    public function lastid()
    {
        if (!$this->status && !$this->connect()) {
            exit("Database connection error!");
        }
        return mysqli_insert_id($this->conid);
    }
}

?>