<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

class SearchWords
{
    private $text = NULL;
    private $words = array();
    public $strict = false;
    public function __construct($text = false)
    {
        if ($text) {
            $this->set($text);
        }
    }
    public function __destruct()
    {
    }
    public function get()
    {
        return $this->text ? $this->text : false;
    }
    public function __toString()
    {
        return $this->get();
    }
    public function set($request)
    {
        if (mb_strlen($request) < 3) {
            return false;
        }
        $this->words = array();
        $reqs = preg_split("/[\\s,]+/i", $request, -1, PREG_SPLIT_NO_EMPTY);
        foreach ($reqs as &$r) {
            if ($r = $this->clean($r)) {
                $this->words[] = mb_strtolower($r);
            }
        }
        unset($reqs);
        unset($r);
        $this->words = array_unique($this->words);
        if (count($this->words)) {
            return $this->text = implode(" ", $this->words);
        }
        return false;
    }
    public function highlight($text, $tag = "b", $param = NULL)
    {
        if (count($this->words)) {
            $reps = $param ? "<" . $tag . " " . $param . ">\\0</" . $tag . ">" : "<" . $tag . ">\\0</" . $tag . ">";
            foreach ($this->words as &$r) {
                $text = preg_replace("|" . $r . "|uUi", $reps, $text);
            }
            unset($r);
            return $text;
        } else {
            return $text;
        }
    }
    public function field($fields, $ors = false, $both = false)
    {
        if (!is_array($fields)) {
            $fields = array($fields);
        }
        $query = array();
        foreach ($fields as $field) {
            $line = array();
            foreach ($this->words as &$r) {
                $line[] = " `" . $field . "` LIKE '%" . $r . "%' ";
            }
            unset($r);
            $query[] = " ( " . implode($ors ? "OR" : "AND", $line) . " ) ";
        }
        return implode($both ? "AND" : "OR", $query);
    }
    public static function clean($request)
    {
        $unstring = "'\"()&|%\$#@*!^:;?<>,[]{}\\/";
        $unarr = array();
        for ($i = 0; $i < strlen($unstring); $i++) {
            $unarr[$unstring[$i]] = "";
        }
        $request = mb_substr(trim($request), 0, 50);
        $request = strtr($request, $unarr);
        $request = preg_replace("#\\s+#i", " ", $request);
        $request = trim($request);
        return 2 < mb_strlen($request) ? $request : "";
    }
    public static function rutrans($text)
    {
        $ft = array("q" => "й", "w" => "ц", "e" => "у", "r" => "к", "t" => "е", "y" => "н", "u" => "г", "i" => "ш", "o" => "щ", "p" => "з", "[" => "х", "]" => "ъ", "a" => "ф", "s" => "ы", "d" => "в", "f" => "а", "g" => "п", "h" => "р", "j" => "о", "k" => "л", "l" => "д", ";" => "ж", "'" => "э", "z" => "я", "x" => "ч", "c" => "с", "v" => "м", "b" => "и", "n" => "т", "m" => "ь", "," => "б", "." => "ю", "Q" => "Й", "W" => "Ц", "E" => "У", "R" => "К", "T" => "Е", "Y" => "Н", "U" => "Г", "I" => "Ш", "O" => "Щ", "P" => "З", "{" => "Х", "}" => "Ъ", "A" => "Ф", "S" => "Ы", "D" => "В", "F" => "А", "G" => "П", "H" => "Р", "J" => "О", "K" => "Л", "L" => "Д", ":" => "Ж", "\"" => "Э", "Z" => "Я", "X" => "Ч", "C" => "С", "V" => "М", "B" => "И", "N" => "Т", "M" => "Ь", "<" => "Б", ">" => "Ю");
        return strtr($text, $ft);
    }
}

?>