<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

class texter
{
    private $core = NULL;
    private $shortcode = NULL;
    public $maskurl = true;
    private $scinit = false;
    public function __construct($core)
    {
        $this->core = $core;
        $this->shortcode = array();
    }
    public function __destruct()
    {
    }
    public function line($text)
    {
        $text = filter_var($text, FILTER_SANITIZE_STRING);
        $text = trim($text);
        $text = htmlspecialchars($text);
        if ($this->core->cando("texter_line")) {
            return $this->core->filter("texter_line", $text);
        }
        return $text;
    }
    public function anum($text)
    {
        $text = filter_var($text, FILTER_SANITIZE_STRING);
        $text = trim($text);
        $text = preg_replace("#[^\\w\\_\\-\\.]+#iu", " ", $text);
        $text = preg_replace("#([ ]+)#", " ", $text);
        $text = htmlspecialchars($text);
        if ($this->core->cando("texter_line")) {
            return $this->core->filter("texter_line", $text);
        }
        return $text;
    }
    public function code($text)
    {
        if ($this->core->cando("texter_code")) {
            return $this->core->filter("texter_code", $text);
        }
        return $text;
    }
    public function pass($text)
    {
        $core = $this->core;
        if ($core->cando("texter_passfull")) {
            return $core->filter("texter_passfull", $text);
        }
        $text = trim($text);
        $text = md5($text);
        if ($core->cando("texter_pass")) {
            return $core->filter("texter_pass", $text);
        }
        return $text;
    }
    public function link($text)
    {
        $text = trim($text);
        $code = array("Є" => "YE", "І" => "I", "Ѓ" => "G", "і" => "i", "№" => "#", "є" => "ye", "ѓ" => "g", "А" => "A", "Б" => "B", "В" => "V", "Г" => "G", "Д" => "D", "Е" => "E", "Ё" => "YO", "Ж" => "ZH", "З" => "Z", "И" => "I", "Й" => "J", "К" => "K", "Л" => "L", "М" => "M", "Н" => "N", "О" => "O", "П" => "P", "Р" => "R", "С" => "S", "Т" => "T", "У" => "U", "Ф" => "F", "Х" => "X", "Ц" => "C", "Ч" => "CH", "Ш" => "SH", "Щ" => "SHH", "Ъ" => "'", "Ы" => "Y", "Ь" => "", "Э" => "E", "Ю" => "YU", "Я" => "YA", "а" => "a", "б" => "b", "в" => "v", "г" => "g", "д" => "d", "е" => "e", "ё" => "yo", "ж" => "zh", "з" => "z", "и" => "i", "й" => "j", "к" => "k", "л" => "l", "м" => "m", "н" => "n", "о" => "o", "п" => "p", "р" => "r", "с" => "s", "т" => "t", "у" => "u", "ф" => "f", "х" => "x", "ц" => "c", "ч" => "ch", "ш" => "sh", "щ" => "shh", "ъ" => "", "ы" => "y", "ь" => "", "э" => "e", "ю" => "yu", "я" => "ya", "—" => "-");
        $text = strtr($text, $code);
        $text = preg_replace("#([\\s\\-]+)#si", "-", $text);
        $text = trim($text, "-");
        $text = strtolower($text);
        $text = preg_replace("#([^a-z0-9\\-\\_\\.]*)#si", "", $text);
        $text = preg_replace("#([\\-]+)#si", "-", $text);
        $text = trim($text, "-");
        if ($this->core->cando("texter_link")) {
            return $this->core->filter("texter_link", $text);
        }
        return $text;
    }
    public function float($num)
    {
        $num = strtr($num, ",", ".");
        $num = filter_var($num, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        return filter_var($num, FILTER_VALIDATE_FLOAT) !== false ? $num : false;
    }
    public function url($url)
    {
        $url = filter_var($url, FILTER_SANITIZE_URL);
        return filter_var($url, FILTER_VALIDATE_URL) ? $url : false;
    }
    public function email($email)
    {
        $email = filter_var($email, FILTER_SANITIZE_EMAIL);
        return filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : false;
    }
    public function number($num)
    {
        return preg_replace("#([^0-9]+)#", "", $num);
    }
    public function domain($url)
    {
        $url = trim($url, "/");
        if (strpos($url, "://") !== false) {
            $ud = explode("://", $url, 2);
            $url = $ud[1];
            $url = trim($url, "/");
        }
        if (strpos($url, "/") !== false) {
            $ud = explode("/", $url, 2);
            $url = $ud[0];
        }
        if (strpos($url, "?") !== false) {
            $ud = explode("?", $url, 2);
            $url = $ud[0];
        }
        if (substr($url, 0, 4) == "www.") {
            $url = substr($url, 4);
        }
        return $url;
    }
    public function intline($text)
    {
        if (!$text) {
            return "";
        }
        if (!is_array($text)) {
            $text = trim($text);
            $text = explode(",", $text);
        }
        $result = array();
        foreach ($text as $t) {
            if ($t = (int) $t) {
                $result[] = $t;
            }
        }
        $result = array_unique($result);
        return implode(",", $result);
    }
    public function codeline($text)
    {
        if (!$text) {
            return "";
        }
        if (!is_array($text)) {
            $text = trim($text);
            $text = explode(",", $text);
        }
        $result = array();
        foreach ($text as $t) {
            if ($t = $this->link($t)) {
                $result[] = $t;
            }
        }
        $result = array_unique($result);
        return implode(",", $result);
    }
    public function lines($text)
    {
        $text = preg_replace("#\n([\\s]*)\n#si", "</p><p>", $text);
        $text = preg_replace("#<p>([\\s]*)</p>#si", "", $text);
        $text = strtr($text, array("\r" => "", "\n" => "<br />"));
        $text = "<p>" . $text . "</p>";
        $text = $this->links($text);
        if ($this->core->cando("texter_lines")) {
            return $this->core->filter("texter_lines", $text);
        }
        return $text;
    }
    public function links($text)
    {
        $text = preg_replace("#(script|about|applet|activex|chrome):#is", "\\1&#058;", $text);
        $text = " " . $text . " ";
        $text = preg_replace("#(^|[\\s>])([\\w]+?://[\\w\\#\$%&~/.\\-;:=,?@\\[\\]+]*)#is", "\\1<a href=\"\\2\" target=\"_blank\">\\2</a>", $text);
        $text = preg_replace("#(^|[\\s>])((www|ftp)\\.[\\w\\#\$%&~/.\\-;:=,?@\\[\\]+]*)#is", "\\1<a href=\"http://\\2\" target=\"_blank\">\\2</a>", $text);
        $text = preg_replace("#(^|[\\s>])([a-z0-9&\\-_.]+?)@([\\w\\-]+\\.([\\w\\-\\.]+\\.)*[\\w]+)#i", "\\1<a href=\"mailto:\\2@\\3\">\\2@\\3</a>", $text);
        $text = substr($text, 1, -1);
        if ($this->core->cando("texter_links")) {
            return $this->core->filter("texter_links", $text);
        }
        return $text;
    }
    public function shortcodes($text)
    {
        if (!$this->scinit) {
            $this->scinit = true;
            $this->core->handle("shortcodes");
        }
        if (empty($this->shortcode)) {
            return $text;
        }
        $tagnames = array_keys($this->shortcode);
        $tagregexp = join("|", array_map("preg_quote", $tagnames));
        $tagregexp = "(.?)\\[(" . $tagregexp . ")\\b(.*?)(?:(\\/))?\\](?:(.+?)\\[\\/\\2\\])?(.?)";
        return preg_replace_callback("/" . $tagregexp . "/s", "shortcodes", $text);
    }
    public function addcode($code, $func)
    {
        $this->shortcode[$code] = $func;
    }
    public function getcode($code)
    {
        return $this->shortcode[$code];
    }
    public function out($text)
    {
        if (!$this->scinit) {
            $this->scinit = true;
            $this->core->process("shortcodes");
        }
        if ($this->maskurl) {
            $text = $this->unurl($text);
        }
        if ($this->shortcode) {
            $text = $this->shortcodes($text);
        }
        $text = preg_replace("#<p>([\\s]*)</p>#si", "", $text);
        return $text;
    }
    public function untag($text)
    {
        $text = strip_tags($text);
        $text = stripslashes($text);
        $text = html_entity_decode($text, ENT_QUOTES, "UTF-8");
        return $text;
    }
    public function unspec($text)
    {
        $text = stripslashes($text);
        $text = html_entity_decode($text, ENT_QUOTES, "UTF-8");
        return $text;
    }
    public function unquote($text)
    {
        return str_replace("\"", "&quot;", $text);
    }
    public function metasafe($text)
    {
        $text = strip_tags($text);
        $text = html_entity_decode($text, ENT_QUOTES, "UTF-8");
        return str_replace("\"", "&quot;", $text);
    }
    public function unurl($text)
    {
        $host = strtr($this->core->server["HTTP_HOST"], array("." => "\\."));
        $pattern = "/<a (.*?)href=[\\\"']([a-z0-9]+)\\:\\/\\/(?!" . $host . ")(.*?)\\/?(.*?)[\\\"'](.*?)>(.*?)<\\/a>/i";
        $replace = "<a rel=\"nofollow\" \$1href=\"/?goto=\$2:/\$3/\$4\"\$5>\$6</a>";
        return preg_replace($pattern, $replace, $text);
    }
    public function extlink($url)
    {
        $url = trim($url);
        return "/?goto=" . $url;
    }
    public function excerpt($text, $len = 100)
    {
        $text = $this->untag($text);
        if ($len < mb_strlen($text)) {
            $text = mb_substr($text, 0, $len);
            if (mb_strpos($text, " ")) {
                $text = mb_substr($text, 0, mb_strrpos($text, " "));
            }
            $text = trim($text);
            if ($text) {
                $text .= " ...";
            }
        } else {
            $text = trim($text);
        }
        return $text;
    }
    public function cut($text, $len = 35)
    {
        if ($len < mb_strlen($text)) {
            $text = mb_substr($text, 0, $len) . "&hellip;";
        }
        return $text;
    }
    public function smartdate($tm)
    {
        if (time() - $tm < 200000) {
            $day = date("d", $tm);
            if ($day == date("d")) {
                return $this->core->lang["today"] . date("H:i", $tm);
            }
            if ($day == date("d", strtotime("yesterday"))) {
                return $this->core->lang["yesterday"] . date("H:i", $tm);
            }
        }
        return date("d.m.y H:i", $tm);
    }
    public function timeleft($to, $from = false)
    {
        if (!$from) {
            $from = time();
        }
        $to -= $from;
        if (0 < $to) {
            $m = ceil($to / 60);
            $h = floor($m / 60);
            $d = floor($h / 24);
            $m = $m % 60;
            $h = $h % 24;
            if ($d) {
                return numinf($this->core->lang["daysleft"], $d) . ($h || $m ? sprintf("%02d:%02d", $h, $m) : "");
            }
            if ($h) {
                return numinf($this->core->lang["hoursleft"], $h);
            }
            return numinf($this->core->lang["minsleft"], $m);
        }
        return "";
    }
}
function shortcodes($m)
{
    global $core;
    if ($m[1] == "[" && $m[6] == "]") {
        return substr($m[0], 1, -1);
    }
    $process = $core->text->getcode($m[2]);
    $attrtext = $m[3];
    $atts = array();
    $pattern = "/(\\w+)\\s*=\\s*\"([^\"]*)\"(?:\\s|\$)|(\\w+)\\s*=\\s*'([^']*)'(?:\\s|\$)|(\\w+)\\s*=\\s*([^\\s'\"]+)(?:\\s|\$)|\"([^\"]*)\"(?:\\s|\$)|(\\S+)(?:\\s|\$)/";
    $attrtext = preg_replace("/[\\x{00a0}\\x{200b}]+/u", " ", $attrtext);
    if (preg_match_all($pattern, $attrtext, $match, PREG_SET_ORDER)) {
        foreach ($match as $ms) {
            if (!empty($ms[1])) {
                $atts[strtolower($ms[1])] = stripcslashes($ms[2]);
            } else {
                if (!empty($ms[3])) {
                    $atts[strtolower($ms[3])] = stripcslashes($ms[4]);
                } else {
                    if (!empty($ms[5])) {
                        $atts[strtolower($ms[5])] = stripcslashes($ms[6]);
                    } else {
                        if (isset($ms[7]) && strlen($ms[7])) {
                            $atts[] = stripcslashes($ms[7]);
                        } else {
                            if (isset($ms[8])) {
                                $atts[] = stripcslashes($ms[8]);
                            }
                        }
                    }
                }
            }
        }
    } else {
        $atts = ltrim($text);
    }
    if (isset($m[5])) {
        return $m[1] . call_user_func($process, $core, $atts, $m[5]) . $m[6];
    }
    return $m[1] . call_user_func($process, $core, $atts, NULL) . $m[6];
}

?>