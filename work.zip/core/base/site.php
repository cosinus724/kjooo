<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

class SiteElements
{
    private $core = NULL;
    public $headered = false;
    public $page = NULL;
    private $title = array();
    private $bc = array();
    private $css = array();
    private $js = array();
    private $script = array();
    private $meta = array();
    public $menu = array();
    private $messages = array();
    private $mt = array("ok" => "success", "error" => "danger", "info" => "success", "text" => "info");
    private $sets = array("adminlte" => array("js" => array("jquery", "bootstrap", "app")), "select2" => array("js" => array("jquery", "select2"), "css" => array("select2"), "script" => array("\$(\".select2\").select2();")), "tablesorter" => array("js" => array("jquery", "jquery.tablesorter"), "script" => array("\$(\".tablesorter\").tablesorter();")));
    public function __construct($core)
    {
        $this->core = $core;
        $this->title = array($core->config("site", "name"));
        $this->page = $core->config("site", "name");
    }
    public function info($type, $text)
    {
        if (isset($this->core->lang[$text])) {
            $text = $this->core->lang[$text];
        }
        $cls = $this->mt[$type] ? $this->mt[$type] : $type;
        $this->messages[] = array("class" => $cls, "text" => $text);
    }
    public function bc($name, $url = false)
    {
        $this->bc[] = array("name" => $name, "url" => $url);
        $this->title[] = $name;
        $this->page = $name;
    }
    public function ht($name)
    {
        $this->title = array($name);
    }
    public function pt($name)
    {
        $this->page = $name;
    }
    public function header()
    {
        $core = $this->core;
        $core->tpl->load("header", "header", defined("HACK_TPL_HEADER") ? HACK : false);
        if (!defined("HACK_NOSTYLE")) {
            $this->css("style");
        }
        if (!defined("HACK_NOSKIN")) {
            $this->css(defined("HACK_SKIN") ? HACK_SKIN : "skin-green");
        }
        if (!defined("HACK_NOFONTS")) {
            $this->css("fa");
        }
        if (!defined("HACK_NOLAYOUT")) {
            $this->css("layout");
        }
        if (defined("HACK_MYSTYLE")) {
            $this->css(array(HACK, "style"));
        }
        $this->set("adminlte");
        $core->tpl->vars("header", array("site_name" => $core->config("site", "name"), "site_url" => $core->config("url", "base"), "name" => $core->config("site", "nice") ? $core->config("site", "nice") : $core->config("site", "name"), "mininame" => $core->config("site", "short") ? $core->config("site", "short") : ":)", "skin" => defined("HACK_SKIN") ? HACK_SKIN : "skin-green", "title" => implode(" – ", $this->title), "user" => $core->user->name, "user_vip" => $core->user->vip ? true : false, "u_logout" => $core->u("", "logout=site"), "logout" => $core->lang["logout"], "u_profile" => $core->u("profile"), "profile" => $core->lang["profile"], "u_money" => $core->u("money"), "money" => $core->lang["cash"], "cash" => $core->currency->prnt($core->user->cash), "u_hold" => $core->u("money"), "onhold" => $core->lang["hold"], "hold" => 0 < $core->user->meta["hold"] ? $core->currency->prnt($core->user->meta["hold"]) : false, "pagename" => $this->page, "home" => $core->lang["index"]));
        $core->tpl->vars("header", array("u_support" => $core->u("support"), "c_support" => $core->user->supp_new, "support" => $core->lang["support"]));
        if ($core->user->supp_new) {
            $this->info("text", sprintf($core->lang["support_note"], $core->url("m", "support")));
        }
        $ml = $core->get["m"] ? array($core->text->link($core->get["m"])) : array();
        foreach ($this->bc as $bc) {
            $core->tpl->block("header", "bc", $bc);
            $ux = trim($bc["url"], "/");
            $ux = explode("/", $ux);
            if ($ux[0]) {
                $ml[] = $ux[0];
            }
        }
        foreach ($this->messages as $ms) {
            $core->tpl->block("header", "message", $ms);
        }
        $ml = array_unique($ml);
        $gs = false;
        foreach ($this->menu as $m) {
            if ($m["sub"]) {
                foreach ($m["sub"] as $ms) {
                    if (in_array($ms["div"], $ml)) {
                        $ml[] = $m["div"];
                        $gs = $ms["div"];
                    }
                }
            }
        }
        $ml = array_unique($ml);
        foreach ($this->menu as $m) {
            $core->tpl->block("header", "menu", array("link" => $m["link"], "name" => $m["name"], "div" => $m["div"], "active" => in_array($m["div"], $ml), "dropdown" => $m["sub"] ? true : false));
            if (count($m["sub"])) {
                $core->tpl->block("header", "menu.sub");
                foreach ($m["sub"] as $ms) {
                    $iss = $m["div"] != $ms["div"] || $m["div"] == $ms["div"] && $gs == $ms["div"];
                    if (in_array($ms["div"], $ml) && $iss) {
                        $ms["active"] = true;
                    }
                    $core->tpl->block("header", "menu.sub.item", $ms);
                }
            }
        }
        $core->process("header");
        $core->tpl->output("header");
        $this->headered = true;
        $core->showstat = true;
    }
    public function footer()
    {
        $core = $this->core;
        $this->headered = false;
        $core->tpl->load("footer", "footer", defined("HACK_TPL_FOOTER") ? HACK : false);
        if (count($this->script)) {
            $script = implode(";\n", $this->script);
        } else {
            $script = false;
        }
        $core->tpl->vars("footer", array("title" => $this->title, "script" => $script, "copyright" => $core->config("site", "copy"), "altervision" => $core->lang["cms_powered_by"]));
        $core->process("footer");
        $this->headered = false;
        if ($core->user->level) {
            list($usec, $sec) = explode(" ", microtime());
            $endtimer = (double) $usec + (double) $sec;
            $worktime = sprintf("%1.3f", $endtimer - $core->timer);
            $core->tpl->block("footer", "debugga", array());
            $core->tpl->vars("footer", array("pr_time" => $worktime, "pr_sql" => $core->db->queries, "pr_mem" => mkb(function_exists("memory_get_peak_usage") ? memory_get_peak_usage() : 0), "pr_date" => date("d.m.Y H:i:s")));
        }
        $core->tpl->output("footer");
        if ($core->user->level) {
            foreach ($core->db->log as $q) {
                echo "\n<!-- " . $q . " -->";
            }
        }
    }
    public function form($formname, $action, $title, $field, $button = false)
    {
        $core = $this->core;
        $core->tpl->load($formname, "form", defined("HACK_TPL_FORM") ? HACK : false);
        $core->tpl->vars($formname, array("name" => $formname, "action" => $action, "title" => $title, "mce" => $core->url("js", "tiny_mce") . $core->url("js", "jquery.tinymce"), "codemirror" => $core->url("js", "codemirror") . $core->url("css", "codemirror"), "datejs" => $core->url("js", "jquery.datepicker") . $core->url("js", "jquery.datepicker.ru") . $core->url("css", "ui")));
        $hasfiles = false;
        $hasmce = false;
        $hasdate = false;
        $hascode = false;
        foreach ($field as &$f) {
            $core->tpl->block($formname, "field", array());
            switch ($f["type"]) {
                case "head":
                    $core->tpl->block($formname, "field.head", array("value" => $f["value"]));
                    break;
                case "line":
                    $core->tpl->block($formname, "field.line", array("value" => $f["value"]));
                    break;
                case "hidden":
                    $core->tpl->block($formname, "field.hidden", array("name" => $f["name"], "value" => $f["value"]));
                    break;
                case "text":
                    $core->tpl->block($formname, "field.text", array("head" => $f["head"], "descr" => $f["descr"], "name" => $f["name"], "value" => $f["value"], "maxwidth" => $f["length"], "req" => $f["req"], "ro" => $f["ro"]));
                    break;
                case "email":
                    $core->tpl->block($formname, "field.email", array("head" => $f["head"], "descr" => $f["descr"], "name" => $f["name"], "value" => $f["value"], "req" => $f["req"], "ro" => $f["ro"]));
                    break;
                case "number":
                    $core->tpl->block($formname, "field.number", array("head" => $f["head"], "descr" => $f["descr"], "name" => $f["name"], "value" => $f["value"], "min" => $f["min"], "max" => $f["max"], "step" => $f["step"], "req" => $f["req"], "ro" => $f["ro"]));
                    break;
                case "file":
                    $core->tpl->block($formname, "field.file", array("head" => $f["head"], "descr" => $f["descr"], "name" => $f["name"]));
                    $hasfiles = true;
                    break;
                case "pass":
                    $core->tpl->block($formname, "field.pass", array("head" => $f["head"], "descr" => $f["descr"], "name" => $f["name"], "value" => $f["value"], "maxwidth" => $f["length"]));
                    break;
                case "checkbox":
                case "vcheckbox":
                    $core->tpl->block($formname, "field.checkbox", array("head" => $f["head"], "descr" => $f["descr"], "name" => $f["name"], "value" => $f["value"] ? " value=\"" . $f["value"] . "\" " : "", "checked" => $f["checked"] ? " checked=\"checked\" " : ""));
                    break;
                case "textarea":
                    $core->tpl->block($formname, "field.textarea", array("head" => $f["head"], "descr" => $f["descr"], "name" => $f["name"], "value" => $f["value"], "rows" => $f["rows"], "ro" => $f["ro"]));
                    break;
                case "mces":
                    $core->tpl->block($formname, "field.mces", array("head" => $f["head"], "descr" => $f["descr"], "name" => $f["name"], "value" => $f["value"]));
                    $hasmce = true;
                    break;
                case "mcea":
                    $core->tpl->block($formname, "field.mcea", array("head" => $f["head"], "descr" => $f["descr"], "name" => $f["name"], "value" => $f["value"]));
                    $hasmce = true;
                    break;
                case "code":
                    $hascode = true;
                    $lang = $f["lang"] ? $f["lang"] : "generic";
                    $mime = $f["mime"] ? $f["mime"] : $lang;
                    $lang = explode(",", $lang);
                    foreach ($lang as $l) {
                        $codelang[$l] = true;
                    }
                    $core->tpl->block($formname, "field.code", array("head" => $f["head"], "descr" => $f["descr"], "name" => $f["name"], "value" => $f["value"], "lang" => $mime, "rows" => $f["rows"] ? $f["rows"] : 15));
                    break;
                case "select":
                    $core->tpl->block($formname, "field.select", array("head" => $f["head"], "descr" => $f["descr"], "name" => $f["name"], "s2" => $f["s2"]));
                    if ($f["options"]) {
                        $opts = array();
                        foreach ($f["options"] as $ok => $ov) {
                            $opts[] = array("name" => $ov, "value" => $ok, "select" => $ok == $f["value"] ? 1 : 0);
                        }
                    } else {
                        $opts = $f["value"];
                    }
                    foreach ($opts as $fld) {
                        $core->tpl->block($formname, "field.select.option", array("name" => $fld["name"], "value" => $fld["value"], "select" => $fld["select"] ? " selected=\"selected\" " : ""));
                    }
                    unset($fld);
                    break;
                case "mselect":
                    $this->set("select2");
                    $core->tpl->block($formname, "field.mselect", array("head" => $f["head"], "descr" => $f["descr"], "name" => $f["name"], "s2" => $f["s2"]));
                    if ($f["options"]) {
                        if (!is_array($f["value"])) {
                            $x = explode(",", $f["value"]);
                            $f["value"] = array();
                            foreach ($x as $xx) {
                                if ($xx = trim($xx)) {
                                    $f["value"][] = $xx;
                                }
                            }
                        }
                        $opts = array();
                        foreach ($f["options"] as $ok => $ov) {
                            $opts[] = array("name" => $ov, "value" => $ok, "select" => in_array($ok, $f["value"]));
                        }
                    } else {
                        $opts = $f["value"];
                    }
                    foreach ($opts as $fld) {
                        $core->tpl->block($formname, "field.mselect.option", array("name" => $fld["name"], "value" => $fld["value"], "select" => $fld["select"] ? " selected=\"selected\" " : ""));
                    }
                    unset($fld);
                    break;
                case "radio":
                    $core->tpl->block($formname, "field.radio", array("head" => $f["head"], "descr" => $f["descr"], "name" => $f["name"]));
                    foreach ($f["value"] as &$fld) {
                        $core->tpl->block($formname, "field.radio.option", array("name" => $fld["name"], "value" => $fld["value"], "select" => $fld["select"] ? " checked=\"checked\" " : ""));
                    }
                    unset($fld);
                    break;
                case "radioline":
                    $core->tpl->block($formname, "field.radioline", array("head" => $f["head"], "name" => $f["name"]));
                    foreach ($f["options"] as &$fld) {
                        $core->tpl->block($formname, "field.radioline.option", array("name" => $fld["name"], "value" => $fld["value"], "select" => $fld["value"] == $f["value"] ? " checked=\"checked\" " : ""));
                    }
                    unset($fld);
                    break;
                case "date":
                    $core->tpl->block($formname, "field.date", array("head" => $f["head"], "descr" => $f["descr"], "name" => $f["name"], "value" => $f["value"]));
                    $hasdate = true;
                    break;
            }
        }
        unset($f);
        if ($hasfiles) {
            $core->tpl->vars($formname, array("encoding" => " enctype=\"multipart/form-data\" "));
        }
        if ($hasmce) {
            $core->tpl->block($formname, "mce", array());
        }
        if ($hasdate) {
            $core->tpl->block($formname, "dates", array());
        }
        if ($hascode) {
            $core->tpl->block($formname, "codemirror", array());
            foreach ($codelang as $l => $t) {
                $core->tpl->block($formname, "codemirror.lang", array("path" => $core->url("js", "mode/" . $l . "/" . $l)));
            }
        }
        if (!$button) {
            $button = array(array("type" => "submit", "value" => $core->lang["save"]));
        } else {
            if (!is_array($button)) {
                $button = array(array("type" => "submit", "value" => $button));
            }
        }
        foreach ($button as $b) {
            $core->tpl->block($formname, "button", array("name" => $b["name"], "type" => $b["type"] ? $b["type"] : "button", "cls" => $b["cls"] ? $b["cls"] : "btn-" . BOXSKIN, "value" => $b["value"]));
        }
        $core->tpl->output($formname);
    }
    public function css($css)
    {
        $csl = is_array($css) ? sprintf("/%s/css/%s.css", $css[0], $css[1]) : sprintf("/core/css/%s.css", $css);
        if (!in_array($csl, $this->css)) {
            $this->css[] = $csl;
            $this->core->tpl->block("header", "meta", array("m" => "<link rel=\"stylesheet\" href=\"" . $csl . "\" type=\"text/css\" />"));
        }
    }
    public function js($js)
    {
        $jsl = is_array($js) ? sprintf("/%s/js/%s.js", $js[0], $js[1]) : sprintf("/core/js/%s.js", $js);
        if (!in_array($jsl, $this->js)) {
            $this->js[] = $jsl;
            $this->core->tpl->block("header", "meta", array("m" => "<script type=\"text/javascript\" src=\"" . $jsl . "\"></script>"));
        }
    }
    public function script($code)
    {
        $this->script[] = $code;
    }
    public function meta($name, $value)
    {
        $m = sprintf("<meta name=\"%s\" content=\"%s\" />", $name, htmlspecialchars($value));
        if (!in_array($m, $this->meta)) {
            $this->meta[] = $m;
            $this->core->tpl->block("header", "meta", array("m" => $m));
        }
    }
    public function metaline($m)
    {
        if (!in_array($m, $this->meta)) {
            $this->meta[] = $m;
        }
    }
    public function set($name)
    {
        if (!$this->sets[$name]) {
            return false;
        }
        if ($this->sets[$name]["js"]) {
            foreach ($this->sets[$name]["js"] as $js) {
                $this->js($js);
            }
        }
        if ($this->sets[$name]["css"]) {
            foreach ($this->sets[$name]["css"] as $css) {
                $this->css($css);
            }
        }
        if ($this->sets[$name]["meta"]) {
            foreach ($this->sets[$name]["meta"] as $m) {
                $this->metaline($m);
            }
        }
        if ($this->sets[$name]["script"]) {
            foreach ($this->sets[$name]["script"] as $s) {
                $this->script($s);
            }
        }
    }
}

?>