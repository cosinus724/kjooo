<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

class Template
{
    private $_tpldata = array();
    private $files = array();
    private $query = array();
    private $basic = "";
    private $modular = "";
    private $cache = "";
    private $code = array();
    public function __construct($configs = array())
    {
        if (isset($configs["basic"])) {
            $this->basic = $configs["basic"];
        }
        if (isset($configs["modular"])) {
            $this->modular = $configs["modular"];
        }
        if (isset($configs["cache"])) {
            $this->cache = $configs["cache"];
        }
        return true;
    }
    public function __destruct()
    {
    }
    public function load($part, $name, $module = NULL)
    {
        $path = $module ? @sprintf($this->modular, $module, $name) : @sprintf($this->basic, $name);
        if ($path && file_exists($path)) {
            $this->files[$part] = $path;
        } else {
            exit("Error loading template from " . $path);
        }
    }
    public function vars($part, $v)
    {
        if (!isset($this->_tpldata[$part])) {
            $this->_tpldata[$part] = array();
        }
        if (is_array($v)) {
            $this->_tpldata[$part] = array_merge($this->_tpldata[$part], $v);
        }
    }
    public function block($part, $block, $v = array())
    {
        $ptr =& $this->_tpldata[$part];
        $blocks = explode(".", $block);
        foreach ($blocks as $i => $b) {
            if ($i) {
                $ptr =& $ptr[count($ptr) - 1];
            }
            $b = $b . ".";
            if (!isset($prt[$b])) {
                $prt[$b] = array();
            }
            $ptr =& $ptr[$b];
        }
        $ptr[] = $v;
    }
    public function make($part)
    {
        ob_start();
        $this->parse($part);
        $data = ob_get_contents();
        ob_end_clean();
        return $data;
    }
    public function show()
    {
        foreach ($this->query as $part) {
            $this->parse($part);
        }
    }
    public function output($part, $charset = false)
    {
        if ($charset) {
            echo iconv("UTF-8", $charset, $this->make($part));
        } else {
            $this->query[] = $part;
        }
    }
    private function parse($part)
    {
        if (empty($this->files[$part])) {
            exit("Template error - no '" . $part . "' loaded");
        }
        $path = sprintf($this->cache, md5($this->files[$part]));
        $fmt1 = filemtime($this->files[$part]);
        $fmt2 = file_exists($path) ? filemtime($path) : 0;
        if ($fmt2 < $fmt1) {
            $code = file_get_contents($this->files[$part]);
            $code = preg_replace("#\\{([0-9a-z\\-_]+)\\}#i", "<?=\$_data['\$1'];?>", $code);
            $code = preg_replace("#\\{(([0-9a-z\\-_]+)\\.)*([0-9a-z\\-_]+)\\.([0-9a-z\\-_]+)\\}#i", "<?=\$\$3['\$4'];?>", $code);
            $code = preg_replace("#<!-- BEGIN ([0-9a-z\\-_]+) -->#i", "<? array_push ( \$_stack, \$_node ); unset ( \$_o ); \$_o = &\$\$_node; \$_node = '\$1'; if (is_array( \$_o['\$1.'] )) foreach ( \$_o['\$1.'] as &\$\$1 ) : ?>", $code);
            $code = preg_replace("#<!-- END ([0-9a-z\\-_]+) -->#i", "<? endforeach; unset ( \$\$1 ); \$_node = array_pop ( \$_stack ); ?>", $code);
            $code = preg_replace("#<!-- IFSET ([0-9a-z\\-_]+) -->#i", "<? if ( \$_data['\$1'] ) : ?>", $code);
            $code = preg_replace("#<!-- IFSET (([0-9a-z\\-_]+)\\.)*([0-9a-z\\-_]+)\\.([0-9a-z\\-_]+) -->#i", "<? if ( \$\$3['\$4'] ) : ?>", $code);
            $code = preg_replace("#<!-- IFNOT ([0-9a-z\\-_]+) -->#i", "<? if ( !\$_data['\$1'] ) : ?>", $code);
            $code = preg_replace("#<!-- IFNOT (([0-9a-z\\-_]+)\\.)*([0-9a-z\\-_]+)\\.([0-9a-z\\-_]+) -->#i", "<? if ( !\$\$3['\$4'] ) : ?>", $code);
            $code = preg_replace("#<!-- ELSEIF ([0-9a-z\\-_]+) -->#i", "<? elseif ( \$_data['\$1'] ) : ?>", $code);
            $code = preg_replace("#<!-- ELSEIF (([0-9a-z\\-_]+)\\.)*([0-9a-z\\-_]+)\\.([0-9a-z\\-_]+) -->#i", "<? elseif ( \$\$3['\$4'] ) : ?>", $code);
            $code = preg_replace("#<!-- ELSEIFNOT ([0-9a-z\\-_]+) -->#i", "<? elseif ( !\$_data['\$1'] ) : ?>", $code);
            $code = preg_replace("#<!-- ELSEIFNOT (([0-9a-z\\-_]+)\\.)*([0-9a-z\\-_]+)\\.([0-9a-z\\-_]+) -->#i", "<? elseif ( !\$\$3['\$4'] ) : ?>", $code);
            $code = preg_replace("#<!-- ELSE -->#i", "<? else : ?>", $code);
            $code = preg_replace("#<!-- ENDIF -->#i", "<? endif; ?>", $code);
            file_put_contents($path, $code);
            unset($code);
        }
        $_data =& $this->_tpldata[$part];
        $_node = "_data";
        $_stack = array();
        include $path;
    }
}

?>