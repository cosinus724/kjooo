<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

class eMailSender
{
    private $core = NULL;
    public function __construct($core)
    {
        $this->core = $core;
    }
    public function __destruct()
    {
    }
    public function send($to, $title, $text, $files = array())
    {
        $core = $this->core;
        $title = "=?UTF-8?B?" . base64_encode($title) . "?=";
        if (!is_array($to)) {
            $to = array($to);
        }
        if ($core->config("mail", "smtp")) {
            foreach ($to as $t) {
                $this->send_smtp($core->config("mail", "from"), $t, $title, $text, $files);
            }
        } else {
            foreach ($to as $t) {
                $this->send_mail($core->config("mail", "from"), $t, $title, $text, $files);
            }
        }
    }
    private function send_mail($from, $to, $title, $text, $files)
    {
        $type = strpos($text, "<") !== false ? "html" : "plain";
        if ($files) {
            $boundary = "---" . md5(microtime()) . "---";
            $headers = "From: " . $from . "\nContent-Type: multipart/mixed; boundary=\"" . $boundary . "\"";
            $body = "--" . $boundary . "\nContent-Type: text/plain; charset=utf-8\n" . $text . "\n--" . $boundary . "\n";
            foreach ($files as $path => $name) {
                $data = file_get_contents($path);
                $body .= "Content-Type: application/octet-stream; name==?utf-8?B?" . base64_encode($name) . "?=\n";
                $body .= "Content-Transfer-Encoding: base64\n";
                $body .= "Content-Disposition: attachment; filename==?utf-8?B?" . base64_encode($name) . "?=\n\n";
                $body .= chunk_split(base64_encode($data)) . "\n--" . $boundary . "--\n";
                unset($data);
            }
            $result = mail($to, $title, $body, $headers);
        } else {
            return mail($to, $title, $text, "From: " . $from . "\nContent-Type: text/" . $type . "; charset=UTF-8");
        }
    }
    private function send_smtp($from, $to, $title, $text, $files)
    {
        $core = $this->core;
        $domain = $core->config("mail", "domain");
        $type = strpos($text, "<") !== false ? "html" : "plain";
        $socket = fsockopen($core->config("mail", "server"), $core->config("mail", "port"), $errno, $errstr, 30);
        if ($domain) {
            fputs($socket, "EHLO " . $domain . "\r\n");
        } else {
            fputs($socket, "EHLO\r\n");
        }
        if ($this->_responce($socket) != "220") {
            return $this->_stop($socket, 72);
        }
        fputs($socket, "AUTH LOGIN\r\n");
        if ($this->_responce($socket) != "250") {
            return $this->_stop($socket, 74);
        }
        fputs($socket, base64_encode($core->config("mail", "user")) . "\r\n");
        if ($this->_responce($socket) != "334") {
            return $this->_stop($socket, 76);
        }
        fputs($socket, base64_encode($core->config("mail", "pass")) . "\r\n");
        if ($this->_responce($socket) != "334") {
            return $this->_stop($socket, 78);
        }
        if ($this->_responce($socket) != "235") {
            return $this->_stop($socket, 79);
        }
        fputs($socket, "MAIL FROM:<" . $from . ">\r\n");
        if ($this->_responce($socket) != "250") {
            return $this->_stop($socket, 81);
        }
        fputs($socket, "RCPT TO:<" . $to . ">\r\n");
        if ($this->_responce($socket) != "250") {
            return $this->_stop($socket, 83);
        }
        fputs($socket, "DATA\r\n");
        if ($this->_responce($socket) != "354") {
            return $this->_stop($socket, 85);
        }
        fputs($socket, "To: " . $to . "\r\n");
        fputs($socket, "From: " . $from . "\r\n");
        fputs($socket, "Subject: " . $title . "\r\n");
        if ($files) {
            $boundary = "---" . md5(microtime()) . "---";
            fputs($socket, "Content-Type: multipart/mixed; boundary=\"" . $boundary . "\"\r\n");
            fputs($socket, "Content-Transfer-Encoding: 8bit\r\n");
            fputs($socket, "\r\n\r\n");
            fputs($socket, "--" . $boundary . "\r\nContent-Type: text/" . $type . "; charset=utf-8\r\n\r\n" . $text . "\r\n--" . $boundary);
            foreach ($files as $path => $name) {
                $data = file_get_contents($path);
                fputs($socket, "\r\nContent-Type: application/octet-stream; name==?utf-8?B?" . base64_encode($name) . "?=\r\n");
                fputs($socket, "Content-Transfer-Encoding: base64\r\n");
                fputs($socket, "Content-Disposition: attachment; filename==?utf-8?B?" . base64_encode($name) . "?=\r\n\r\n");
                fputs($socket, chunk_split(base64_encode($data)) . "\r\n--" . $boundary);
                unset($data);
            }
            fputs($socket, "--\r\n.\r\n");
        } else {
            fputs($socket, "Content-Type: text/" . $type . "; charset=UTF-8\r\n");
            fputs($socket, "Content-Transfer-Encoding: 8bit\r\n");
            fputs($socket, "\r\n\r\n");
            fputs($socket, $text . " \r\n");
            fputs($socket, ".\r\n");
        }
        if ($this->_responce($socket) != "250") {
            return $this->_stop($socket, 111);
        }
        fputs($socket, "QUIT\r\n");
        fclose($socket);
        return true;
    }
    private function _responce($socket)
    {
        $server_response = "";
        $resp = "";
        while (substr($server_response, 3, 1) != " ") {
            if ($server_response = fgets($socket, 128)) {
                $resp .= $server_response;
            } else {
                return false;
            }
        }
        return substr($resp, 0, 3);
    }
    private function _stop($socket, $line)
    {
        fclose($socket);
        return false;
    }
}

?>