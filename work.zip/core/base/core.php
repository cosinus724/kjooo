<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

class Core
{
    public $get = array();
    public $post = array();
    public $cookie = array();
    public $files = array();
    public $server = array();
    public $flag = array();
    private $configs = array();
    private $alive = true;
    public $timer = 0;
    public $showstat = false;
    private $urls = array();
    private $handlers = array();
    public $cachetype = 0;
    private $cached = array();
    private $cachemod = array();
    private $cachepath = "";
    private $mchost = false;
    private $mcport = 11211;
    private $mcpref = false;
    private $mclife = 3600;
    private $conf = array();
    public $session = array();
    public $session_id = false;
    private $session_changed = false;
    private $session_meta = array();
    private $session_store = 0;
    private $session_path = "";
    private $ubase = "/";
    public function __construct($configs)
    {
        list($usec, $sec) = explode(" ", microtime());
        $this->timer = (double) $usec + (double) $sec;
        $this->get = isset($configs["get"]) ? $configs["get"] : $_GET;
        $this->post = isset($configs["post"]) ? $configs["post"] : $_POST;
        $this->cookie = isset($configs["cookie"]) ? $configs["cookie"] : $_COOKIE;
        $this->files = isset($configs["files"]) ? $configs["files"] : $_FILES;
        $this->server = isset($configs["server"]) ? $configs["server"] : $_SERVER;
        unset($configs["get"]);
        unset($configs["post"]);
        unset($configs["cookie"]);
        unset($configs["files"]);
        unset($configs["server"]);
        if (get_magic_quotes_gpc()) {
            $this->get = stripslashes_deep($this->get);
            $this->post = stripslashes_deep($this->post);
            $this->files = stripslashes_deep($this->files);
            $this->cookie = stripslashes_deep($this->cookie);
            $this->server = stripslashes_deep($this->server);
        }
        $this->get = add_magic_quotes($this->get);
        $this->post = add_magic_quotes($this->post);
        $this->files = add_magic_quotes($this->files);
        $this->cookie = add_magic_quotes($this->cookie);
        $this->server = add_magic_quotes($this->server);
        $this->cachepath = $configs["cachepath"] ? $configs["cachepath"] : PATH . "data/cache/%s.txt";
        if (defined("MC_HOST")) {
            $this->mchost = MC_HOST;
        }
        if (defined("MC_PORT")) {
            $this->mcport = MC_PORT;
        }
        if (defined("MC_PREF")) {
            $this->mcpref = MC_PREF;
        }
        if (defined("MC_LIFE")) {
            $this->mclife = MC_LIFE;
        }
        $this->session_path = isset($config["session"]) ? $config["session"] : PATH . "data/session/%s.txt";
        if ($this->cookie["ssid"]) {
            $this->startsess();
        }
        unset($config["session"]);
        $tz = defined("NOTINSTALLED") ? false : $this->config("site", "tz");
        if (!$tz) {
            $tz = @ini_get("date.timezone");
        }
        if (!$tz) {
            $tz = date_default_timezone_get();
        }
        date_default_timezone_set($tz ? $tz : "Europe/Moscow");
        $this->configs = $configs;
        $this->urls = array("index" => "<a href=\"/\">%s</a>", "index_u" => "/", "link" => "<a href=\"%1\$s\" title=\"%2\$s\">%2\$s</a>", "css" => "<link rel=\"stylesheet\" href=\"/core/css/%s.css\" type=\"text/css\" />", "js" => "<script type=\"text/javascript\" src=\"/core/js/%s.js\"></script>", "mcss" => "<link rel=\"stylesheet\" href=\"/%s/css/%s.css\" type=\"text/css\" />", "mjs" => "<script type=\"text/javascript\" src=\"/%s/style/%s.js\"></script>", "meta" => "<meta name=\"%s\" content=\"%s\" />", "a" => "/a-%s/%d", "m" => "/%s", "i" => "/%s/%s", "mp" => "/%s?%s", "mm" => "/%s?message=%s", "im" => "/%s/%d?message=%s", "ma" => "/%s?action=%s", "ia" => "/%s/%s?action=%s");
    }
    public function __destruct()
    {
        $this->stop();
    }
    public function stop()
    {
        if ($this->alive) {
            if (isset($this->site) && $this->site->headered) {
                $this->site->footer();
            }
            $this->alive = false;
            $this->savesess();
            $this->savecache();
            if (isset($this->tpl)) {
                $this->process("showsite-start");
                $this->tpl->show();
                $this->process("showsite-stop");
            }
            if (isset($this->site)) {
                unset($this->site);
            }
            if (isset($this->user)) {
                unset($this->user);
            }
            if (isset($this->tpl)) {
                unset($this->tpl);
            }
            if (isset($this->db)) {
                unset($this->db);
            }
            if (isset($this->text)) {
                unset($this->text);
            }
        }
        exit;
    }
    public function __get($name)
    {
        if ($name == "db") {
            $dbhost = isset($this->configs["dbhost"]) ? $this->configs["dbhost"] : SQL_HOST;
            $dbname = isset($this->configs["dbname"]) ? $this->configs["dbname"] : SQL_BASE;
            $dbuser = isset($this->configs["dbuser"]) ? $this->configs["dbuser"] : SQL_USER;
            $dbpass = isset($this->configs["dbpass"]) ? $this->configs["dbpass"] : SQL_PASS;
            $dbchar = isset($this->configs["dbchar"]) ? $this->configs["dbchar"] : (defined("SQL_CHRS") ? SQL_CHRS : false);
            $dbcoll = isset($this->configs["dbcoll"]) ? $this->configs["dbcoll"] : (defined("SQL_COLL") ? SQL_COLL : false);
            require_once PATH . "core/base/db.php";
            $this->db = new MySQL($dbhost, $dbuser, $dbpass, $dbname, $dbchar, $dbcoll);
            return $this->db;
        }
        if ($name == "tpl") {
            require_once PATH . "core/base/tpl.php";
            $this->tpl = new Template(array("basic" => isset($this->configs["tplpath"]) ? $this->configs["tplpath"] : PATH . "core/tpl/%s.tpl", "modular" => isset($this->configs["tplmod"]) ? $this->configs["tplmod"] : PATH . "%s/tpl/%s.tpl", "cache" => isset($this->configs["tplcache"]) ? $this->configs["tplcache"] : PATH . "data/tpl/%s.php"));
            return $this->tpl;
        }
        if ($name == "user") {
            require_once PATH . "core/base/user.php";
            $this->user = new User($this);
            return $this->user;
        }
        if ($name == "text") {
            require_once PATH . "core/base/text.php";
            $this->text = new texter($this);
            return $this->text;
        }
        if ($name == "email") {
            require_once PATH . "core/base/email.php";
            $this->email = new eMailSender($this);
            return $this->email;
        }
        if ($name == "site") {
            require_once PATH . "core/base/site.php";
            $this->site = new SiteElements($this);
            return $this->site;
        }
        if ($name == "lang") {
            $l = $this->user->meta["lang"] ? $this->user->meta["lang"] : $this->guesslang();
            $lang_file = sprintf($this->configs["lang_path"], $l);
            if (file_exists($lang_file)) {
                global $lang;
                require_once $lang_file;
                $this->lang = $lang;
                unset($lang);
            }
            if (defined("HACK_LANG")) {
                $lang_file = sprintf($this->configs["lang_mods"], HACK, $l);
                if (file_exists($lang_file)) {
                    global $lang;
                    require_once $lang_file;
                    $this->lang = array_merge($this->lang, $lang);
                    unset($lang);
                }
            }
            return $this->lang;
        }
        $ml = PATH_LIB . $name . ".php";
        $hl = defined("HACK") ? PATH . HACK . "/lib/" . $name . ".php" : false;
        if ($hl && file_exists($hl)) {
            require_once $hl;
        } else {
            if (file_exists($ml)) {
                require_once $ml;
            } else {
                return false;
            }
        }
        $this->{$name} = new $name($this);
        return $this->{$name};
    }
    public function guesslang()
    {
        if (defined("LANG")) {
            return LANG;
        }
        $lang = array("ru_ru" => "ru", "ru" => "ru");
        if ($this->cando("guesslang")) {
            $lang = $this->filter("guesslang", $lang);
        }
        $sl = strtolower($this->server["HTTP_ACCEPT_LANGUAGE"]);
        foreach ($lang as $ll => $lg) {
            if (strpos($sl, $ll) !== false) {
                return $lg;
            }
        }
        return "en";
    }
    public function handle($name, $function)
    {
        if (isset($this->handlers[$name])) {
            $this->handlers[$name][] = $function;
        } else {
            $this->handlers[$name] = array($function);
        }
        return true;
    }
    public function cando($name)
    {
        return isset($this->handlers[$name]);
    }
    public function process($name)
    {
        $result = false;
        if (isset($this->handlers[$name])) {
            foreach ($this->handlers[$name] as &$f) {
                $result = call_user_func($f, $this) || $result;
            }
            unset($f);
        }
        return $result;
    }
    public function filter($name, $data, $info = NULL)
    {
        if (isset($this->handlers[$name])) {
            if (isset($info)) {
                foreach ($this->handlers[$name] as &$f) {
                    $data = call_user_func($f, $this, $data, $info);
                }
                unset($f);
            } else {
                foreach ($this->handlers[$name] as &$f) {
                    $data = call_user_func($f, $this, $data);
                }
                unset($f);
            }
        }
        return $data;
    }
    private function startcache()
    {
        if ($this->cachetype) {
            return $this->cachetype;
        }
        if ($this->mchost) {
            if (class_exists("Memcached")) {
                $this->mcobj = new Memcached();
                $this->cachetype = $this->mcobj->addServer($this->mchost, $this->mcport) ? 2 : 1;
                $this->mclife += time();
            } else {
                if (class_exists("Memcache")) {
                    $this->mcobj = new Memcache();
                    $this->cachetype = $this->mcobj->addServer($this->mchost, $this->mcport) ? 3 : 1;
                } else {
                    $this->cachetype = 1;
                }
            }
        } else {
            $this->cachetype = 1;
        }
        return $this->cachetype;
    }
    public function cache($name, $value = NULL)
    {
        if (!$this->cachetype) {
            $this->startcache();
        }
        if (isset($this->cached[$name]) && $value === NULL) {
            return $this->cached[$name];
        }
        $cn = md5($name);
        if ($value === NULL) {
            switch ($this->cachetype) {
                case 2:
                case 3:
                    $mcn = $this->mcpref . $cn;
                    $jsondata = $this->mcobj->get($mcn);
                    break;
                default:
                    $mcn = sprintf($this->cachepath, $cn);
                    $jsondata = @file_get_contents($mcn);
            }
            if ($jsondata) {
                $data = json_decode($jsondata, true);
                $this->cached[$name] = $data;
                return $data;
            }
            return NULL;
        }
        $this->cachemod[] = $name;
        $this->cached[$name] = $value;
    }
    public function uncache($name)
    {
        if (!$this->cachetype) {
            $this->startcache();
        }
        unset($this->cached[$name]);
        switch ($this->cachetype) {
            case 2:
            case 3:
                $cn = $this->mcpref . md5($name);
                $this->mcobj->delete($cn, 0);
                break;
            default:
                $cn = sprintf($this->cachepath, md5($name));
                @unlink($cn);
        }
    }
    private function savecache()
    {
        $mods = array_unique($this->cachemod);
        if (!$mods) {
            return true;
        }
        if (!$this->cachetype) {
            $this->startcache();
        }
        switch ($this->cachetype) {
            case 2:
                foreach ($mods as $c) {
                    if (isset($this->cached[$c])) {
                        $cn = $this->mcpref . md5($c);
                        $dt = json_encode($this->cached[$c], JSON_UNESCAPED_UNICODE);
                        $this->mcobj->set($cn, $dt, $this->mclife);
                        unset($cn);
                        unset($dt);
                    }
                }
                unset($this->mcobj);
                break;
            case 3:
                foreach ($mods as $c) {
                    if (isset($this->cached[$c])) {
                        $cn = $this->mcpref . md5($c);
                        $dt = json_encode($this->cached[$c], JSON_UNESCAPED_UNICODE);
                        $this->mcobj->set($cn, $dt, 0, $this->mclife);
                        unset($cn);
                        unset($dt);
                    }
                }
                $this->mcobj->close();
                unset($this->mcobj);
                break;
            default:
                foreach ($mods as $c) {
                    if (isset($this->cached[$c])) {
                        $cn = sprintf($this->cachepath, md5($c));
                        $dt = json_encode($this->cached[$c], JSON_UNESCAPED_UNICODE);
                        file_put_contents($cn, $dt);
                        unset($cn);
                        unset($dt);
                    }
                }
        }
    }
    public function config($name, $field = false)
    {
        if (!isset($this->conf[$name])) {
            $data = $this->cache("config." . $name);
            if (!isset($data)) {
                $datajson = $this->db->field("SELECT `value` FROM " . DB_CONFIG . " WHERE `name` = '" . $name . "' LIMIT 1");
                $data = json_decode($datajson, true);
                $this->cache("config." . $name, $data);
            }
            $this->conf[$name] = $data;
            unset($data);
            unset($datajson);
        }
        return $field ? $this->conf[$name][$field] : $this->conf[$name];
    }
    public function reconf($name, $value)
    {
        $this->conf[$name] = $value;
        $data = addslashes(json_encode($value, JSON_UNESCAPED_UNICODE));
        $this->db->query("REPLACE INTO " . DB_CONFIG . " ( `name`, `value` ) VALUES ( '" . $name . "', '" . $data . "' )");
        $this->uncache("config." . $name);
    }
    public function sset($name, $value)
    {
        $this->startsess();
        $this->session[$name] = $value;
        $this->session_changed = true;
    }
    private function startsess()
    {
        if ($this->session_id) {
            return NULL;
        }
        if (!$this->cookie["ssid"]) {
            $ssid = md5(microtime() . mt_rand());
        } else {
            $ssid = preg_replace("#([^a-z0-9]+)#si", "", filter_var($this->cookie["ssid"], FILTER_SANITIZE_STRING));
        }
        $this->session_id = $ssid;
        setcookie("ssid", $ssid, time() + 1000000, "/");
        $ct = $this->startcache();
        $this->session_store = 1 < $ct ? 1 : 0;
        if ($this->session_store) {
            $sess = $this->cache("sess." . $this->session_id);
            if (!$sess) {
                $sd = $this->db->row("SELECT * FROM " . DB_SESS . " WHERE sess_uid = '" . $this->session_id . "' LIMIT 1");
                if ($sd) {
                    $sess = array("meta" => array("user" => (int) $sd["user_id"], "time" => $sd["sess_time"], "date" => (int) $sd["sess_date"], "ua" => $sd["sess_ua"], "ip" => int2ip($sd["sess_ip"])), "data" => $sd["sess_data"] ? json_decode($sd["sess_data"], true) : array());
                    $this->cache("sess." . $this->session_id, $sess);
                    $sst = true;
                } else {
                    $sst = false;
                }
            } else {
                $sst = true;
            }
        } else {
            $sn = sprintf($this->session_path, $this->session_id);
            if (file_exists($sn)) {
                $sst = true;
                $sess = json_decode(file_get_contents($sn), true);
            } else {
                $sst = false;
            }
        }
        $ip = remoteip($this->server);
        if ($sst) {
            $this->session = $sess["data"];
            $this->session_meta = $sess["meta"];
            if ($sess["meta"]["date"] != date("ymd")) {
                $this->session_changed = true;
            }
            if ($sess["meta"]["ua"] != $this->server["HTTP_USER_AGENT"]) {
                $this->session_meta["ua"] = $this->server["HTTP_USER_AGENT"];
                $this->session_changed = true;
            }
            if ($sess["meta"]["ip"] != $ip) {
                $this->session_meta["ip"] = $ip;
                $this->session_changed = true;
            }
        } else {
            $this->session_changed = true;
            $this->session_meta = array("user" => 0, "ua" => $this->server["HTTP_USER_AGENT"], "ip" => $ip);
        }
    }
    private function savesess()
    {
        if ($this->session_id && $this->session_changed) {
            $sess = array("meta" => $this->session_meta, "data" => $this->session ? $this->session : array());
            $sess["meta"]["time"] = time();
            $sess["meta"]["date"] = date("ymd");
            if (isset($this->user)) {
                $sess["meta"]["user"] = $this->user->id;
            } else {
                $sess["meta"]["user"] = 0;
            }
            if ($this->session_store) {
                $this->cache("sess." . $this->session_id, $sess);
                $this->db->replace(DB_SESS, array("sess_uid" => $this->session_id, "user_id" => (int) $sess["meta"]["user"], "sess_date" => (int) $sess["meta"]["date"], "sess_time" => $sess["meta"]["time"], "sess_ua" => $sess["meta"]["ua"], "sess_ip" => ip2int($sess["meta"]["ip"]), "sess_data" => addslashes(json_encode($sess["data"], JSON_UNESCAPED_UNICODE))));
            } else {
                $sn = sprintf($this->session_path, $this->session_id);
                file_put_contents($sn, json_encode($sess, JSON_UNESCAPED_UNICODE));
            }
        }
    }
    public function url()
    {
        $arguments = func_get_args();
        $url_id = $arguments[0];
        $arguments[0] = $this->urls[$url_id];
        return call_user_func_array("sprintf", $arguments);
    }
    public function u($path, $param = false, $replace = false)
    {
        if ($replace) {
            if (!$param) {
                $param = array();
            }
            if (!is_array($param)) {
                parse_str($param, $param);
            }
            if (!is_array($replace)) {
                parse_str($replace, $replace);
            }
            foreach ($replace as $k => $v) {
                $param[$k] = $v;
            }
        }
        if (is_array($path)) {
            $path = implode("/", $path);
        }
        if ($param && is_array($param)) {
            $param = http_build_query($param);
        }
        return $this->ubase . $path . ($param ? (strpos($path, "?") === false ? "?" : "&") . $param : "");
    }
    public function uri($path, $param = false, $replace = false)
    {
        if ($replace) {
            if (!$param) {
                $param = array();
            }
            if (!is_array($param)) {
                parse_str($param, $param);
            }
            if (!is_array($replace)) {
                parse_str($replace, $replace);
            }
            foreach ($replace as $k => $v) {
                $param[$k] = $v;
            }
        }
        if (is_array($path)) {
            $path = implode("/", $path);
        }
        if ($param && is_array($param)) {
            $param = http_build_query($param);
        }
        return $this->config("url", "base") . $path . ($param ? (strpos($path, "?") === false ? "?" : "&") . $param : "");
    }
    public function go($url, $hard = false)
    {
        if ($hard) {
            header("HTTP/1.1 301 Moved Permanently");
        }
        header("Location: " . $url);
        $this->stop();
    }
    public function msgo($msg, $url, $mt = "message", $ref = false)
    {
        if (!$ref) {
            $ref = $this->server["HTTP_REFERER"] ? $this->server["HTTP_REFERER"] : $url;
        }
        if (strpos($ref, $mt . "=") !== false) {
            $this->go(preg_replace("#" . $mt . "=([a-z0-9]+)#i", $mt . "=" . $msg, $ref));
        } else {
            $this->go($ref . (strpos($ref, "?") !== false ? "&" : "?") . $mt . "=" . $msg);
        }
    }
}

?>