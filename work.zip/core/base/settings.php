<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

define("DB_AUDIO", SQL_PREF . "audio");
define("DB_ADS", SQL_PREF . "ads");
define("DB_BAN_IP", SQL_PREF . "ban_ip");
define("DB_BAN_PH", SQL_PREF . "ban_phone");
define("DB_BL", SQL_PREF . "bl");
define("DB_CALL", SQL_PREF . "call");
define("DB_CASH", SQL_PREF . "cash");
define("DB_CHANGE", SQL_PREF . "change");
define("DB_CLICK", SQL_PREF . "click");
define("DB_COMP", SQL_PREF . "comp");
define("DB_CONFIG", SQL_PREF . "config");
define("DB_DOMAIN", SQL_PREF . "domain");
define("DB_EXT", SQL_PREF . "ext");
define("DB_FLOW", SQL_PREF . "flow");
define("DB_GANG", SQL_PREF . "gang");
define("DB_GEOIP", SQL_PREF . "geoip");
define("DB_GEOCITY", SQL_PREF . "geocity");
define("DB_LOAD", SQL_PREF . "load");
define("DB_LOG_INT", SQL_PREF . "log_int");
define("DB_LOG_PB", SQL_PREF . "log_pb");
define("DB_NEWS", SQL_PREF . "news");
define("DB_OFFER", SQL_PREF . "offer");
define("DB_ORDER", SQL_PREF . "order");
define("DB_PDB", SQL_PREF . "pdb");
define("DB_PRICE", SQL_PREF . "price");
define("DB_SESS", SQL_PREF . "sess");
define("DB_SITE", SQL_PREF . "site");
define("DB_SPLIT", SQL_PREF . "split");
define("DB_STAGE", SQL_PREF . "stage");
define("DB_STATS", SQL_PREF . "stats");
define("DB_STORE", SQL_PREF . "store");
define("DB_SUPP", SQL_PREF . "supp");
define("DB_TEAM", SQL_PREF . "team");
define("DB_TEST", SQL_PREF . "test");
define("DB_TRACK", SQL_PREF . "track");
define("DB_USER", SQL_PREF . "user");
define("DB_VARS", SQL_PREF . "vars");
define("OFFER_FILE", PATH . "data/offer/%d.jpg");
define("OFFER_LOGO", "/data/offer/%d.jpg");
if (defined("HACK")) {
    require_once PATH . HACK . "/start.php";
}
if (!defined("SITENAME")) {
    define("SITENAME", "AlterCPA");
}
if (!defined("SITENICE")) {
    define("SITENICE", "Alter<b>CPA</b>");
}
if (!defined("SITEMAIL")) {
    define("SITEMAIL", "info@work.cpa");
}
if (!defined("MINFINANCE")) {
    define("MINFINANCE", 2000);
}
if (!defined("CURBEFORE")) {
    define("CURBEFORE", "");
}
if (!defined("CURAFTER")) {
    define("CURAFTER", " <i class=\"fa fa-ruble\"></i>");
}
if (!defined("CURFORMAT")) {
    define("CURFORMAT", "%0d");
}
if (!defined("BOXSKIN")) {
    define("BOXSKIN", "success");
}
if (!defined("SALTKEY1")) {
    define("SALTKEY1", "O>MGOTK0+](Wuw7:g)0hNIQDQ,z&xZZEc)3#JyC;l-(eyV3==z9~]P(0ftUB?Is;");
}
if (!defined("SALTKEY2")) {
    define("SALTKEY2", "LGQSnA],rs9J[<13N=Dg/Z+6|-13jm@[0)|Dh?/VNA5+he>(XwCpg*<(3s#bDvF)");
}
if (!defined("SALTKEY3")) {
    define("SALTKEY3", "T2)X8Bn\$*^y<\$Yh9.yAfSvDZWPaP{k[Di7lLZP&m,<i=w--olJf+vegq/1*mH<Q!");
}
if (!defined("SALTKEY4")) {
    define("SALTKEY4", "~f.[n?j/RLYD21nL)lE=HcFS~lO &K]6w`+#1b@JiN_A&?6*c4u4t;/sy4kr=})-");
}
if (!defined("SALTKEY5")) {
    define("SALTKEY5", "T@G^b6x\$:5g%B3^> `Xp<Zn|>wdy,n,)|WhIf{e0+%b-\$zNcsJ^zwX-15PesTYiv");
}
if (!defined("SALTKEY6")) {
    define("SALTKEY6", ",1WV 3F-G(6vB@-XB[&8N%ZzU.MVZgpL!A-DJq& bv@Aehy3:ti7`\$hi1);<-@Lb");
}
if (!defined("SALTKEY7")) {
    define("SALTKEY7", "(olDR 0FJOw]\$>_?S72bseCc&Q+HzyXn{k`01!;+r!q;F^}2z8(sRL\$`,#Sp2Q! ");
}
if (!defined("SALTKEY8")) {
    define("SALTKEY8", "O2X[_uLFyu0lR#Q:u~hHih3,k6?B-=jogyN^4s^3j11^l7QSovC=Ivl8ya<|hC\$5");
}
if (!function_exists("istrash")) {
    function istrash($status, $reason)
    {
        if ($status == 12) {
            return true;
        }
        if ($status != 5) {
            return false;
        }
        if ($reason == 1) {
            return true;
        }
        if ($reason == 3) {
            return true;
        }
        if ($reason == 5) {
            return true;
        }
        if ($reason == 6) {
            return true;
        }
        if ($reason == 7) {
            return true;
        }
        if ($reason == 8) {
            return true;
        }
        if ($reason == 12) {
            return true;
        }
        return false;
    }
}
if (!function_exists("trashreason")) {
    function trashreason()
    {
        return array(1, 3, 5, 6, 7, 8, 12);
    }
}
if (!function_exists("isapprove")) {
    function isapprove($status)
    {
        if (defined("HOLDISAPPROVE")) {
            if (5 < $status && $status < 12) {
                return true;
            }
            return $status == 4 ? true : false;
        }
        return 5 < $status && $status < 12 ? true : false;
    }
}
if (!function_exists("approvestatus")) {
    function approvestatus()
    {
        if (defined("HOLDISAPPROVE")) {
            return array(4, 6, 7, 8, 9, 10, 11);
        }
        return array(6, 7, 8, 9, 10, 11);
    }
}
if (!function_exists("waitstatus")) {
    function waitstatus()
    {
        if (defined("HOLDISAPPROVE")) {
            return array(1, 2, 3);
        }
        return array(1, 2, 3, 4);
    }
}
if (!function_exists("whatstage")) {
    function whatstage($status, $reason)
    {
        if (!istrash($status, $reason)) {
            $status = (int) $status;
            switch ($status) {
                case 0:
                case 1:
                    return "new";
                case 2:
                case 3:
                    return "wait";
                case 4:
                    return "hold";
                case 5:
                    return "cancel";
                case 12:
                    return "trash";
                default:
                    return "approve";
            }
        } else {
            return "trash";
        }
    }
}

?>