<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function checkdatabase($db)
{
    $storage = array();
    $serverstore = $db->data("SHOW ENGINES");
    foreach ($serverstore as $s) {
        $storage[] = strtolower($s["Engine"]);
    }
    $engine = in_array("aria", $storage) ? "aria" : "myisam";
    require_once PATH . "core/setup/mdb.php";
    $model = dbmodel();
    checkmodel($db, $model, $engine);
    return true;
}
function updatedatabase($db, $version)
{
    require_once PATH . "core/setup/udb.php";
    $updates = getdatabaseupdates($version);
    foreach ($updates as $qu) {
        $db->query($qu);
    }
}
function dbstructure($db)
{
    $data = array();
    $table = $db->data("SHOW TABLE STATUS");
    foreach ($table as $t) {
        $tb = $t["Name"];
        $data[$tb] = array("engine" => $t["Engine"], "format" => $t["Row_format"], "options" => $t["Create_options"], "field" => array(), "index" => array());
        $fields = $db->data("SHOW FIELDS FROM " . $t["Name"]);
        foreach ($fields as $f) {
            $data[$tb]["field"][$f["Field"]] = array("type" => $f["Type"], "null" => $f["Null"] == "YES" ? true : false, "default" => $f["Default"], "extra" => $f["Extra"]);
        }
        $index = $db->data("SHOW KEYS FROM " . $t["Name"]);
        foreach ($index as $i) {
            if (!$data[$tb]["index"][$i["Key_name"]]) {
                $data[$tb]["index"][$i["Key_name"]] = array("type" => $i["Index_type"] == "FULLTEXT" ? 2 : ($i["Non_unique"] ? 0 : 1), "field" => array($i["Column_name"]));
            } else {
                $data[$tb]["index"][$i["Key_name"]]["field"][] = $i["Column_name"];
            }
        }
    }
    return $data;
}
function checkmodel($db, $model, $engine)
{
    $query = array();
    $exist = dbstructure($db);
    foreach ($model as $t => &$m) {
        $tt = SQL_PREF == "cpa_" ? $t : SQL_PREF . substr($t, 4);
        if ($exist[$tt]) {
            $mts = array();
            if ($m["main"][$engine]["options"] && $m["main"][$engine]["options"] != $exist[$tt]["options"]) {
                $mts[] = "ENGINE=" . $m["main"][$engine]["engine"] . " " . $m["main"][$engine]["options"];
            } else {
                if ($m["main"][$engine]["engine"] != $exist[$tt]["engine"]) {
                    $mts[] = "ENGINE=" . $m["main"][$engine]["engine"];
                }
            }
            if ($mts) {
                $query[] = "ALTER TABLE `" . $tt . "` " . implode(" ", $mts);
            }
            $flm = array();
            $prev = false;
            foreach ($m["field"] as $fk => $fd) {
                if ($exist[$tt]["field"][$fk]) {
                    if ($exist[$tt]["field"][$fk]["type"] != $fd["type"] || $exist[$tt]["field"][$fk]["null"] != $fd["null"] || $exist[$tt]["field"][$fk]["default"] !== $fd["default"] || $exist[$tt]["field"][$fk]["extra"] != $fd["extra"]) {
                        $ff = "`" . $fk . "` " . $fd["type"];
                        if (!$fd["null"]) {
                            $ff .= " NOT NULL";
                        }
                        if (isset($fd["default"])) {
                            $ff .= " DEFAULT '" . $fd["default"] . "'";
                        }
                        if ($fd["extra"]) {
                            $ff .= " " . $fd["extra"];
                        }
                        $flm[] = "CHANGE `" . $fk . "` " . $ff;
                    }
                    unset($exist[$tt]["field"][$fk]);
                } else {
                    $ff = "`" . $fk . "` " . $fd["type"];
                    if (!$fd["null"]) {
                        $ff .= " NOT NULL";
                    }
                    if (isset($fd["default"])) {
                        $ff .= " DEFAULT '" . $fd["default"] . "'";
                    }
                    if ($fd["extra"]) {
                        $ff .= " " . $fd["extra"];
                    }
                    $flm[] = "ADD " . $ff . ($prev ? " AFTER `" . $prev . "`" : "");
                }
                $prev = $fk;
            }
            foreach ($exist[$tt]["field"] as $fk => $fd) {
                $flm[] = "DROP `" . $fk . "`";
            }
            foreach ($m["index"] as $ik => $iv) {
                if ($exist[$tt]["index"][$ik]) {
                    if ($iv["type"] != $exist[$tt]["index"][$ik]["type"] || $iv["field"] != $exist[$tt]["index"][$ik]["field"]) {
                        if ($ik == "PRIMARY") {
                            $flm[] = "DROP PRIMARY KEY";
                        } else {
                            $flm[] = "DROP INDEX `" . $ik . "`";
                        }
                        if ($ik == "PRIMARY") {
                            $flm[] = "ADD PRIMARY KEY ( `" . implode("`, `", $iv["field"]) . "` )";
                        } else {
                            if ($iv["type"] == 2) {
                                $flm[] = "ADD FULLTEXT KEY `" . $ik . "` ( `" . implode("`, `", $iv["field"]) . "` )";
                            } else {
                                if ($iv["type"]) {
                                    $flm[] = "ADD UNIQUE `" . $ik . "` ( `" . implode("`, `", $iv["field"]) . "` ) USING BTREE";
                                } else {
                                    $flm[] = "ADD INDEX `" . $ik . "` ( `" . implode("`, `", $iv["field"]) . "` ) USING BTREE";
                                }
                            }
                        }
                    }
                    unset($exist[$tt]["index"][$ik]);
                } else {
                    if ($ik == "PRIMARY") {
                        $flm[] = "ADD PRIMARY KEY ( `" . implode("`, `", $iv["field"]) . "` )";
                    } else {
                        if ($iv["type"] == 2) {
                            $flm[] = "ADD FULLTEXT KEY `" . $ik . "` ( `" . implode("`, `", $iv["field"]) . "` )";
                        } else {
                            if ($iv["type"]) {
                                $flm[] = "ADD UNIQUE KEY `" . $ik . "` ( `" . implode("`, `", $iv["field"]) . "` )";
                            } else {
                                $flm[] = "ADD KEY `" . $ik . "` ( `" . implode("`, `", $iv["field"]) . "` )";
                            }
                        }
                    }
                }
            }
            foreach ($exist[$tt]["index"] as $ik => $iv) {
                if ($ik == "PRIMARY") {
                    $flm[] = "DROP PRIMARY KEY";
                } else {
                    $flm[] = "DROP INDEX `" . $ik . "`";
                }
            }
            if ($flm) {
                $query[] = "ALTER TABLE `" . $tt . "` " . implode(", ", $flm);
            }
        } else {
            $query[] = newdbtable($db, $tt, $m["main"][$engine], $m["field"], $m["index"]);
        }
    }
    foreach ($query as $qu) {
        $db->query($qu);
    }
}
function newdbtable($db, $name, $conf, $field, $index)
{
    $fl = array();
    foreach ($field as $fn => $fd) {
        $ff = "`" . $fn . "` " . $fd["type"];
        if (!$fd["null"]) {
            $ff .= " NOT NULL";
        }
        if (isset($fd["default"])) {
            $ff .= " DEFAULT '" . $fd["default"] . "'";
        }
        if ($fd["extra"]) {
            $ff .= " " . $fd["extra"];
        }
        $fl[] = $ff;
    }
    $kl = array();
    foreach ($index as $kn => $kd) {
        if ($kn == "PRIMARY") {
            $kk = "PRIMARY KEY ( `";
        } else {
            if ($kd["type"] == 2) {
                $kk = "FULLTEXT KEY `" . $kn . "` ( `";
            } else {
                if ($kd["type"]) {
                    $kk = "UNIQUE `" . $kn . "` ( `";
                } else {
                    $kk = "KEY `" . $kn . "` ( `";
                }
            }
        }
        $kk .= implode("`, `", $kd["field"]) . "` )";
        $kl[] = $kk;
    }
    $query = "CREATE TABLE `" . $name . "` ( " . implode(", ", $fl);
    if ($kl) {
        $query .= ", " . implode(", ", $kl);
    }
    $query .= " ) ENGINE=" . $conf["engine"] . " DEFAULT CHARSET=utf8";
    if ($conf["format"]) {
        $query .= " ROW_FORMAT=" . $conf["format"];
    }
    if ($conf["options"]) {
        $query .= " " . $conf["options"];
    }
    return $query;
}

?>