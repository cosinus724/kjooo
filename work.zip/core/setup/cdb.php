<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function checksystemconfigs($db, $core = false)
{
    $domain = $_SERVER["HTTP_HOST"] ? $_SERVER["HTTP_HOST"] : $_SERVER["SERVER_NAME"];
    $dmbase = substr($domain, 0, 4) === "www." ? substr($domain, 4) : $domain;
    $ctz = defined("TIMEZONE") ? TIMEZONE : @ini_get("date.timezone");
    if (!$ctz) {
        $ctz = date_default_timezone_get();
    }
    if (!$ctz) {
        $ctz = "Europe/Moscow";
    }
    if (defined("DEFCUR")) {
        $cur = DEFCUR;
        if (is_numeric($cur)) {
            if (!$core) {
                switch ($cur) {
                    case 10:
                        $cur = "eur";
                        break;
                    case 9:
                        $cur = "usd";
                        break;
                    default:
                        $cur = "rub";
                }
            } else {
                $cur = $core->currency->code($cur);
            }
        }
    } else {
        $cur = "rub";
    }
    $config = array("site" => array("name" => defined("SITENAME") ? SITENAME : "AlterCPA", "nice" => defined("SITENICE") ? SITENICE : "Alter<b>CPA</b>", "short" => defined("SITESHORT") ? SITESHORT : "A<b>C</b>", "email" => defined("SITEMAIL") ? SITEMAIL : "info@" . $dmbase, "copy" => defined("SITECOPY") ? SITECOPY : "&copy;", "tz" => $ctz), "url" => array("base" => defined("BASEURL") ? BASEURL : "http://" . $domain . "/", "lands" => defined("LANDSURL") ? LANDSURL : "http://land." . $dmbase . "/", "space" => defined("SPACEURL") ? SPACEURL : "http://blog." . $dmbase . "/", "api" => defined("APIURL") ? APIURL : ""), "mail" => array("from" => defined("MAIL_FROM") ? MAIL_FROM : "noreply@" . $dmbase, "smtp" => defined("MAIL_SERVER") ? true : false, "server" => defined("MAIL_SERVER") ? MAIL_SERVER : "ssl://smtp.yandex.net", "port" => defined("MAIL_PORT") ? MAIL_PORT : 465, "user" => defined("MAIL_USER") ? MAIL_USER : "noreply@" . $dmbase, "pass" => defined("MAIL_PASS") ? MAIL_PASS : "password", "domain" => defined("MAIL_DOMAIN") ? MAIL_DOMAIN : $dmbase), "register" => array("disable" => defined("NOREGISTER") ? true : false, "noref" => defined("HACK_NOREF") ? true : false, "hideref" => defined("HACK_HIDEREF") ? true : false, "contact" => defined("CHECKCONTACT") ? true : false), "redirect" => array("domain" => defined("REDURL") ? parse_url(REDURL, PHP_URL_HOST) : ($core ? parse_url($core->config("url", "redir"), PHP_URL_HOST) : $dmbase), "force" => 0, "flow" => defined("REDURLGO") ? REDURLGO : ($core ? $core->config("url", "rugo") : "go"), "test" => defined("REDURLST") ? REDURLST : ($core ? $core->config("url", "rust") : "to"), "park" => 1, "ip" => defined("PARKIP") ? PARKIP : ($core ? $core->config("url", "parkip") : $_SERVER["SERVER_ADDR"])), "sites" => array("domain" => defined("LANDSURL") ? parse_url(LANDSURL, PHP_URL_HOST) : ($core ? parse_url($core->config("url", "lands"), PHP_URL_HOST) : "land." . $dmbase), "control" => defined("LANDSCTRL") ? LANDSCTRL : "http://land." . $dmbase . "/control.php", "key" => defined("CONTROL") ? CONTROL : "", "park" => 0, "ip" => ""), "space" => array("domain" => defined("SPACEURL") ? parse_url(SPACEURL, PHP_URL_HOST) : ($core ? parse_url($core->config("url", "space"), PHP_URL_HOST) : "land." . $dmbase), "control" => defined("SPACECTRL") ? SPACECTRL : "http://blog." . $dmbase . "/control.php", "key" => defined("CONTROL") ? CONTROL : "", "park" => 0, "ip" => ""), "clicks" => array("life" => defined("CLICKLIFE") ? CLICKLIFE : 60, "good" => defined("GOODCLICK") ? GOODCLICK * 5 : 10, "server" => defined("CLICKSERVER") ? true : false, "host" => defined("CLICKSRV_HOST") ? CLICKSRV_HOST : "localhost", "port" => defined("CLICKSRV_PORT") ? CLICKSRV_PORT : 1862, "key" => defined("CLICKSRV_KEY") ? CLICKSRV_KEY : md5(microtime() . rand())), "lead" => array("life" => defined("LEADLIFE") ? LEADLIFE : 60, "stat" => defined("STATPERIOD") ? STATPERIOD : 15, "click" => 0), "offer" => array("page" => defined("OFFERS_PER_PAGE") ? OFFERS_PER_PAGE : 30, "allow" => "", "deny" => ""), "money" => array("minout" => defined("MINFINANCE") ? MINFINANCE : 100, "format" => defined("CURFORMAT") && CURFORMAT == "%d" ? true : false, "currency" => defined("DEFCUR") ? DEFCUR : "rub", "key" => defined("OXRKEY") ? OXRKEY : ""), "hide" => array("flows" => 0, "split" => 0, "domain" => 0, "postback" => 0, "offer" => 0, "offerext" => 0, "offercmp" => 0, "lead" => 0, "date" => 0, "hour" => 0, "offer" => 0, "flow" => 0, "utm" => 0, "geo" => 0, "ext" => 0, "site" => 0, "clickan" => 0, "click" => 0, "news" => 0, "int" => 0), "statcol" => array("cr" => 1, "epc" => 1, "app" => 1, "space" => 1, "suni" => 1, "sbad" => 1, "stime" => 1, "per" => 1, "clicks" => 1, "unique" => 1, "bad" => 1, "time" => 1, "ca" => 1, "cw" => 1, "cc" => 1, "ct" => 1, "cx" => 1, "ma" => 1, "mw" => 1, "mc" => 1, "mt" => 1, "ba" => 0, "bb" => 0, "flow" => 1, "site" => 1, "geo" => 1, "utm" => 1, "audio" => 1));
    foreach ($config as $n => $d) {
        $o = $db->start("SELECT `value` FROM " . DB_CONFIG . " WHERE `name` = '" . $n . "' LIMIT 1");
        if ($z = $db->one($o)) {
            $data = json_decode($z["value"], true);
            $exist = true;
        } else {
            $exist = $data = false;
        }
        $db->stop($o);
        if (!$exist) {
            $db->add(DB_CONFIG, array("name" => $n, "value" => addslashes(json_encode($d, JSON_UNESCAPED_UNICODE))));
        } else {
            if (is_array($d)) {
                $changed = false;
                foreach ($d as $di => $dv) {
                    if (!isset($data[$di])) {
                        $data[$di] = $dv;
                        $changed = true;
                    }
                }
                if ($changed) {
                    if ($core) {
                        $core->reconf($n, $data);
                    } else {
                        $db->edit(DB_CONFIG, array("value" => addslashes(json_encode($data, JSON_UNESCAPED_UNICODE))), array("name" => $n));
                    }
                }
            }
        }
    }
}

?>