<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function getdatabaseupdates($version)
{
    $updates = array();
    if ($version < 303000) {
        $updates[] = "UPDATE " . DB_CLICK . " SET click_hour = HOUR(FROM_UNIXTIME( click_time )) WHERE click_hour = 0";
        $updates[] = "UPDATE " . DB_ORDER . " SET cash_etc = ( SELECT SUM(cash_value) FROM cpa_cash WHERE cpa_cash.order_id = cpa_order.order_id AND cash_type IN ( 7, 8 ) ) WHERE cash_etc = 0 AND order_status BETWEEN 6 AND 11";
    }
    if ($version <= 303002) {
        $updates[] = "UPDATE " . DB_ORDER . " SET order_status = 3, order_webstat = 3 WHERE order_status = 4";
    }
    if ($version <= 304006) {
        $updates[] = "UPDATE " . DB_ORDER . " SET has_track = 1 WHERE order_id IN ( SELECT DISTINCT order_id FROM " . DB_TRACK . " )";
    }
    if ($version <= 306004) {
        $updates[] = "UPDATE " . DB_DOMAIN . " SET dom_addr = dom_url";
    }
    if ($version <= 306012) {
        $updates[] = "INSERT INTO `" . DB_LOG_INT . "` SELECT * FROM `" . SQL_PREF . "inlog`";
        $updates[] = "TRUNCATE TABLE `" . SQL_PREF . "inlog`";
        $updates[] = "DROP TABLE `" . SQL_PREF . "inlog`";
    }
    return $updates;
}

?>