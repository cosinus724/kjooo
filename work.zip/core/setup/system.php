<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function setupsystem($core)
{
    if ($core->db->field("SELECT COUNT(*) FROM " . DB_USER)) {
        $core->reconf("setup", true);
        return true;
    }
    $dbv = $core->config("dbversion");
    if ($dbv < DBVER) {
        require_once PATH . "core/setup/db.php";
        if (checkdatabase($core->db)) {
            $core->reconf("dbversion", DBVER);
        }
        require_once PATH . "core/setup/cdb.php";
        checksystemconfigs($core->db, $core);
    }
    if ($core->post["register"]) {
        $email = $core->text->email($core->post["email"]);
        $name = $core->text->line($core->post["name"]);
        $pass = $core->user->pass($core->post["pass"]);
        $ptxt = $core->text->line($core->post["pass"]);
        if (4 <= strlen($ptxt)) {
            if (4 <= strlen($name)) {
                $data = array("user_name" => $name, "user_mail" => $email, "user_pass" => $pass, "user_api" => md5(microtime()), "user_level" => 1, "user_work" => 2);
                if ($core->db->add(DB_USER, $data)) {
                    $core->post["in_user"] = $email;
                    $core->post["in_pass"] = $ptxt;
                    $core->user->login($core);
                    $core->reconf("setup", true);
                    $core->go("/");
                } else {
                    $re = 4;
                }
            } else {
                $re = 3;
            }
        } else {
            $re = 2;
        }
    } else {
        $re = 0;
    }
    $core->tpl->load("body", "setup-user");
    $core->tpl->vars("body", array("site" => $core->config("site", "name"), "title" => $core->config("site", "nice") ? $core->config("site", "nice") : $core->config("site", "name"), "reg" => $core->lang["reg_setup"], "register" => $core->lang["create"], "user" => $core->lang["login_user"], "mail" => $core->lang["login_mail"], "pass" => $core->lang["login_pass"], "er" . $re => "bad"));
    $core->tpl->output("body");
    $core->stop();
}

?>