<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function installconfig($core)
{
    if (class_exists("Memcached")) {
        $mc = new Memcached();
        if ($mc->addServer("127.0.0.1", 11211)) {
            $mcs = $mc->getStats();
            $mcs = array_pop($mcs);
            $mcc = $mcs["pid"] ? true : false;
        } else {
            $mcc = false;
        }
        unset($mc);
    } else {
        if (class_exists("Memcache")) {
            $mc = new Memcache();
            if ($mc->addServer("127.0.0.1", 11211)) {
                $mcs = $mc->getStats();
                $mcc = $mcs["pid"] ? true : false;
            } else {
                $mcc = false;
            }
            unset($mc);
        } else {
            $mcc = false;
        }
    }
    if ($core->post["setup"]) {
        $host = $core->text->link($core->post["host"]);
        $base = $core->text->link($core->post["base"]);
        $user = stripslashes($core->text->line($core->post["user"]));
        $pass = stripslashes($core->text->line($core->post["pass"]));
        if ($host && $base && $user) {
            $tdb = $core->db->connect(array("server" => $host, "db" => $base, "login" => $user, "pass" => $pass));
            if ($tdb) {
                $socket = $core->db->row("SHOW VARIABLES LIKE 'socket'");
                $sck = $socket["Value"] ? "" : "//";
                $socket = $socket["Value"] ? $socket["Value"] : "/var/run/mysqld/mysqld.sock";
                $mcx = $mcc ? "" : "//";
                $config = "<?php\nif (!defined( 'IN_ALTERCMS_CORE_ONE' )) die( 'Hacking attempt' );\t\t\t\t\n//define( 'HACK', 'hack-dist' ); // Hacks directory\ndefine( 'SQL_HOST', '" . $host . "' ); // Database server host\ndefine( 'SQL_BASE', '" . $base . "' ); // Database name\ndefine( 'SQL_USER', '" . $user . "' ); // Database user\ndefine( 'SQL_PASS', '" . $pass . "' ); // Database password\ndefine( 'SQL_PREF', 'cpa_' ); // Database prefix\n//define ( 'SQL_CHRS', 'utf8' ); // Main charset\n//define ( 'SQL_COLL', 'utf8_general_ci' ); // Collation charset\n" . $sck . "define ( 'SQL_SOCK', '" . $socket . "' ); // Database socket for ClickServer\n" . $mcx . "define( 'MC_HOST', '127.0.0.1' ); // MemCached server IP or socket\n" . $mcx . "define( 'MC_POST', 11211 ); // MemCached port or empty\n" . $mcx . "define( 'MC_PREF', 'cpa' ); // MemCached prefix\n//define( 'DEBUG', true ); // Generic debug\n//define( 'RAWDEBUG', true ); // Debug with non-html output\ndefine( 'SALTKEY1', '" . makesalt() . "' ); // Salt 1\ndefine( 'SALTKEY2', '" . makesalt() . "' ); // Salt 2\ndefine( 'SALTKEY3', '" . makesalt() . "' ); // Salt 3\ndefine( 'SALTKEY4', '" . makesalt() . "' ); // Salt 4\ndefine( 'SALTKEY5', '" . makesalt() . "' ); // Salt 5\ndefine( 'SALTKEY6', '" . makesalt() . "' ); // Salt 6\ndefine( 'SALTKEY7', '" . makesalt() . "' ); // Salt 7\ndefine( 'SALTKEY8', '" . makesalt() . "' ); // Salt 8\n?>";
                if (file_put_contents(PATH . "config.php", $config)) {
                    @unlink(PATH . "config-dist.php");
                    $core->go("/");
                } else {
                    $error = 3;
                }
            } else {
                $error = 2;
            }
        } else {
            $error = 1;
        }
    } else {
        $error = 0;
    }
    $core->tpl->load("body", "setup-config");
    $core->tpl->vars("body", array("db" => $core->lang["db_setup"], "start" => $core->lang["db_start"], "host" => $core->lang["db_host"], "base" => $core->lang["db_base"], "user" => $core->lang["db_user"], "pass" => $core->lang["pass"], "error" => $error ? $core->lang["db_error"][$error] : false));
    $core->tpl->output("body");
    $core->stop();
}
function makesalt()
{
    $c = "1234567890-=qwertyuiop[]asdfghjkl;zxcvbnm,.!@#\$%^&*()_+QWERTYUIOP{}ASDFGHJKL:|~ZXCVBNM<>?";
    $s = "";
    for ($i = 0; $i < 64; $i++) {
        $s .= $c[rand(0, 88)];
    }
    return $s;
}

?>