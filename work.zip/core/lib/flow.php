<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

class flow
{
    private $core = NULL;
    public function __construct($core)
    {
        $this->core = $core;
    }
    public function add($user, $id)
    {
        $user = (int) $user;
        $id = (int) $id;
        if (!($user && $id)) {
            return false;
        }
        $core = $this->core;
        $o = $core->cpa->get("offer", $id);
        if (!$o["offer_active"]) {
            return -1;
        }
        if (!$core->offer->auth($id, $user)) {
            return -1;
        }
        $lands = $core->cpa->get("lands", $id);
        $land = $lands[0]["site_id"];
        foreach ($lands as $l) {
            if ($l["site_default"]) {
                $land = $l["site_id"];
            }
        }
        $flow = array("user_id" => $user, "offer_id" => $id, "flow_site" => $land);
        if ($core->db->add(DB_FLOW, $flow)) {
            $fid = $core->db->lastid();
            $name = sprintf("%s - %s", $o["offer_name"], $fid);
            $core->db->edit(DB_FLOW, array("flow_name" => $name), array("flow_id" => $fid));
            $core->cache("flows.id" . $fid);
            $core->cpa->clear("flow", $fid);
            $core->cpa->clear("flows", $user);
            return $fid;
        }
        return false;
    }
    public function edit($user, $id, $info)
    {
        $user = (int) $user;
        $id = (int) $id;
        if (!($user && $id)) {
            return false;
        }
        if ($user != -1) {
            $f = $this->get($id);
            if ($f["user"] != $user) {
                return -1;
            }
        }
        $core = $this->core;
        $data = array();
        if (isset($info["site"])) {
            $data["flow_site"] = (int) $info["site"];
        }
        if (isset($info["space"])) {
            $data["flow_space"] = (int) $info["space"];
        }
        if (isset($info["cb"])) {
            $data["flow_cb"] = (int) $info["cb"];
        }
        if (isset($info["drd"])) {
            $data["domain_id"] = (int) $info["drd"];
        }
        if (isset($info["dst"])) {
            $data["domain_site"] = (int) $info["dst"];
        }
        if (isset($info["dsp"])) {
            $data["domain_space"] = (int) $info["dsp"];
        }
        if (isset($info["name"])) {
            $data["flow_name"] = addslashes($core->text->anum(stripslashes($info["name"])));
        }
        if (isset($info["url"])) {
            $data["flow_url"] = addslashes($core->text->line(stripslashes($info["url"])));
        }
        if (isset($info["pbu"])) {
            $data["flow_pbu"] = addslashes($core->text->line(stripslashes($info["pbu"])));
        }
        if (isset($info["mtrk"])) {
            $data["flow_mtrk"] = addslashes($core->text->anum(stripslashes($info["mtrk"])));
        }
        if (isset($info["ga"])) {
            $data["flow_ga"] = addslashes($core->text->anum(stripslashes($info["ga"])));
        }
        if (isset($info["fb"])) {
            $data["flow_fb"] = addslashes($core->text->anum(stripslashes($info["fb"])));
        }
        if (isset($info["vk"])) {
            $data["flow_vk"] = addslashes($core->text->anum(stripslashes($info["vk"])));
        }
        if (isset($info["utms"])) {
            $data["flow_utms"] = addslashes($core->text->anum(stripslashes($info["utms"])));
        }
        if (isset($info["utmc"])) {
            $data["flow_utmc"] = addslashes($core->text->anum(stripslashes($info["utmc"])));
        }
        if (isset($info["utmn"])) {
            $data["flow_utmn"] = addslashes($core->text->anum(stripslashes($info["utmn"])));
        }
        if (isset($info["utmt"])) {
            $data["flow_utmt"] = addslashes($core->text->anum(stripslashes($info["utmt"])));
        }
        if (isset($info["utmm"])) {
            $data["flow_utmm"] = addslashes($core->text->anum(stripslashes($info["utmm"])));
        }
        if (!$data) {
            return true;
        }
        if ($core->db->edit(DB_FLOW, $data, array("flow_id" => $id))) {
            $core->uncache("flows.id" . $id);
            $core->cpa->clear("flow", $id);
            $core->cpa->clear("flows", $user);
            return true;
        }
        return false;
    }
    public function del($user, $id)
    {
        $user = (int) $user;
        $id = (int) $id;
        if (!($user && $id)) {
            return false;
        }
        if ($user != -1) {
            $u = $this->get($id, "user");
            if ($u != $user) {
                return -1;
            }
        }
        $core = $this->core;
        if ($core->db->del(DB_FLOW, array("flow_id" => $id))) {
            $core->db->edit(DB_CLICK, array("flow_id" => 0), array("flow_id" => $id));
            $core->db->edit(DB_STATS, array("flow_id" => 0), array("flow_id" => $id));
            $core->db->edit(DB_ORDER, array("flow_id" => 0), array("flow_id" => $id));
            $core->uncache("flows.id" . $id);
            $core->cpa->clear("flow", $id);
            $core->cpa->clear("flows", $user);
            return true;
        }
        return false;
    }
    public function get($id, $field = false)
    {
        $id = (int) $id;
        if (!$id) {
            return false;
        }
        $core = $this->core;
        $f = $core->cache("flows.id" . $id);
        if (!$f) {
            $o = $core->db->row("SELECT * FROM " . DB_FLOW . " WHERE flow_id = '" . $id . "' LIMIT 1");
            if ($o) {
                $f = $this->make($o);
            } else {
                $f = -1;
            }
            $core->cache("flows.id" . $id, $f);
        }
        if ($f == -1) {
            return false;
        }
        return $field ? $f[$field] : $f;
    }
    public function make($o)
    {
        return array("id" => (int) $o["flow_id"], "user" => (int) $o["user_id"], "offer" => (int) $o["offer_id"], "site" => (int) $o["flow_site"], "space" => (int) $o["flow_space"], "drd" => (int) $o["domain_id"], "dst" => (int) $o["domain_site"], "dsp" => (int) $o["domain_space"], "cb" => (int) $o["flow_cb"], "name" => $o["flow_name"], "url" => $o["flow_url"], "pbu" => $o["flow_pbu"], "mtrk" => $o["flow_mtrk"], "fb" => $o["flow_fb"], "vk" => $o["flow_vk"], "ga" => $o["flow_ga"], "utms" => $o["flow_utms"], "utmc" => $o["flow_utmc"], "utmn" => $o["flow_utmn"], "utmt" => $o["flow_utmt"], "utmm" => $o["flow_utmm"]);
    }
    public function url($id, $real = false)
    {
        $id = (int) $id;
        if (!$id) {
            return false;
        }
        $f = $this->get($id);
        if (!$f) {
            return false;
        }
        return $this->makeurl($f, $real);
    }
    public function makeurl($f, $real = false)
    {
        $core = $this->core;
        $id = $flow = $f["id"];
        $d = $core->domain->get($f["user"]);
        if (!$real && ($f["url"] || $f["drd"] || $d["default"]["red"] || $core->config("redirect", "force"))) {
            if ($f["drd"] && $d["domain"]["red"][$f["drd"]]) {
                $domain = $d["domain"]["red"][$f["drd"]];
            } else {
                if ($d["default"]["red"]) {
                    $domain = $d["domain"]["red"][$d["default"]["red"]];
                } else {
                    if ($f["url"] || $core->config("redirect", "force")) {
                        $domain = $core->config("redirect", "domain");
                    } else {
                        $domain = false;
                    }
                }
            }
            if ($domain) {
                $url = "http://" . $domain . "/" . $core->config("redirect", "flow") . $id;
                return $url;
            }
        }
        if ($f["space"]) {
            $s = $core->cpa->get("site", $f["space"]);
            $u = explode("/", $s["site_url"], 2);
            list($domain, $path) = $u;
            if ($f["dsp"] && $d["addr"]["space"][$f["dsp"]]) {
                $domain = $d["addr"]["space"][$f["dsp"]];
            } else {
                if ($d["default"]["space"]) {
                    $domain = $d["addr"]["space"][$d["default"]["space"]];
                }
            }
            $param = array("flow" => $flow, "l" => $f["site"]);
            $st = $core->cpa->get("site", $f["site"], "site_type");
            if ($st == 2) {
                if ($f["drd"] && $d["addr"]["red"][$f["drd"]]) {
                    $param["dm"] = $d["addr"]["red"][$f["drd"]];
                } else {
                    if ($d["default"]["red"]) {
                        $param["dm"] = $d["addr"]["red"][$d["default"]["red"]];
                    }
                }
            } else {
                if ($f["dst"] && $d["addr"]["site"][$f["dst"]]) {
                    $param["dm"] = $d["addr"]["site"][$f["dst"]];
                } else {
                    if ($d["default"]["site"]) {
                        $param["dm"] = $d["addr"]["site"][$d["default"]["site"]];
                    }
                }
            }
        } else {
            $s = $core->cpa->get("site", $f["site"]);
            $u = explode("/", $s["site_url"], 2);
            list($domain, $path) = $u;
            if ($s["site_type"] == 2) {
                if ($f["drd"] && $d["addr"]["red"][$f["drd"]]) {
                    $domain = $d["addr"]["red"][$f["drd"]];
                } else {
                    if ($d["default"]["red"]) {
                        $domain = $d["addr"]["red"][$d["default"]["red"]];
                    }
                }
            } else {
                if ($f["dst"] && $d["addr"]["site"][$f["dst"]]) {
                    $domain = $d["addr"]["site"][$f["dst"]];
                } else {
                    if ($d["default"]["site"]) {
                        $domain = $d["addr"]["site"][$d["default"]["site"]];
                    }
                }
            }
            $param = array("flow" => $flow);
        }
        if ($f["cb"]) {
            $param["cb"] = 1;
        }
        if ($f["mtrk"]) {
            $param["mtrk"] = $f["mtrk"];
        }
        if ($f["fb"]) {
            $param["fb"] = $f["fb"];
        }
        if ($f["vk"]) {
            $param["vk"] = $f["vk"];
        }
        if ($f["ga"]) {
            $param["ga"] = $f["ga"];
        }
        if ($f["utms"]) {
            $param["utm_source"] = $f["utms"];
        }
        if ($f["utmc"]) {
            $param["utm_campaign"] = $f["utmc"];
        }
        if ($f["utmn"]) {
            $param["utm_content"] = $f["utmn"];
        }
        if ($f["utmt"]) {
            $param["utm_term"] = $f["utmt"];
        }
        if ($f["utmm"]) {
            $param["utm_medium"] = $f["utmm"];
        }
        $url = "http://" . $domain . ($path ? "/" . $path : "") . "/?" . http_build_query($param);
        return $url;
    }
}

?>