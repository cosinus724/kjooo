<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

class Finance
{
    private $core = NULL;
    private $user = NULL;
    private $db = NULL;
    public function __construct($core)
    {
        $this->core = $core;
        $this->user = $core->user;
        $this->db = $core->db;
    }
    public function __destruct()
    {
    }
    public function add($user, $order, $summ, $type, $comment, $uid = false)
    {
        $core = $this->core;
        $user = (int) $user;
        $order = (int) $order;
        $type = (int) $type;
        $comment = addslashes(stripslashes($comment));
        $uid = $uid ? preg_replace("#([^a-z0-9]+)#si", "", $uid) : false;
        if ($uid) {
            $fid = $core->db->field("SELECT cash_id FROM " . DB_CASH . " WHERE cash_uid = '" . $uid . "' LIMIT 1");
            if ($fid) {
                return false;
            }
        }
        $summ = $core->text->float($summ);
        $summ = round($summ, 2);
        if (!$summ) {
            return false;
        }
        $this->db->query("INSERT INTO " . DB_CASH . " SET user_id = '" . $user . "', order_id = '" . $order . "', cash_type = '" . $type . "', cash_value = '" . $summ . "', cash_descr = '" . $comment . "', cash_time = '" . time() . "', cash_uid = '" . $uid . "'");
        $id = $core->db->lastid();
        if ($id) {
            $core->db->query("UPDATE " . DB_USER . " SET user_cash = user_cash " . (0 < $summ ? "+ " . $summ : $summ) . " WHERE user_id = '" . $user . "'");
            $core->user->reset($user);
            return $id;
        }
        return false;
    }
    public function edit($id, $type, $summ = 0, $descr = false)
    {
        $core = $this->core;
        $id = (int) $id;
        $type = (int) $type;
        $summ = $core->text->float($summ);
        $summ = round($summ, 2);
        $data = array("cash_type" => $type);
        if ($descr !== false) {
            $data["cash_descr"] = addslashes(stripslashes($descr));
        }
        if ($summ) {
            $data["cash_value"] = $summ;
        }
        if ($core->db->edit(DB_CASH, $data, array("cash_id" => $id))) {
            if ($summ) {
                $user = $core->db->field("SELECT user_id FROM " . DB_CASH . " WHERE cash_id = '" . $id . "' LIMIT 1");
                $this->recount($user);
            }
            return true;
        }
        return false;
    }
    public function del($id)
    {
        $id = (int) $id;
        $t = $this->db->row("SELECT * FROM " . DB_CASH . " WHERE cash_id = '" . $id . "' LIMIT 1");
        if ($t["cash_id"]) {
            $this->db->query("DELETE FROM " . DB_CASH . " WHERE cash_id = '" . $id . "'");
            $this->recount($t["user_id"]);
            return true;
        }
        return false;
    }
    public function withdraw($id)
    {
        $core = $this->core;
        $id = (int) $id;
        $c = $core->db->row("SELECT user_id, cash_type, cash_value FROM " . DB_CASH . " WHERE cash_id = '" . $id . "' LIMIT 1");
        if ($c["cash_type"] != 3) {
            return false;
        }
        $wdid = $core->user->get($c["user_id"], "withdraw");
        $wdnm = $core->lang["profilecash"][$wdid];
        $wdto = $core->user->get($c["user_id"], "purse");
        $wdpr = sprintf("%0.2f", abs($c["cash_value"]) * (100 - (int) $core->lang["cashwdper"][$wdid]) / 100);
        $descr = sprintf("%s: %s, %s", $wdnm, $wdto, $wdpr);
        if ($core->db->edit(DB_CASH, array("cash_type" => 4, "cash_descr" => $descr), array("cash_id" => $id))) {
            return true;
        }
        return false;
    }
    public function recount($user)
    {
        $user = (int) $user;
        $this->db->query("UPDATE `" . DB_USER . "` SET `user_cash` = ( SELECT SUM(`cash_value`) FROM " . DB_CASH . " WHERE `user_id` = '" . $user . "' ) WHERE `user_id` = '" . $user . "'");
        $this->user->reset($user);
    }
    public function sync()
    {
        $this->core->db->query("UPDATE " . DB_USER . " u SET u.user_cash = ( SELECT SUM(c.cash_value) FROM " . DB_CASH . " c WHERE c.user_id = u.user_id AND c.cash_hidden = 0 )");
    }
}

?>