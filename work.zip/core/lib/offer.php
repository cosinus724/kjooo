<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

class offer
{
    private $core = NULL;
    public function __construct($core)
    {
        $this->core = $core;
    }
    public function names($user)
    {
        $core = $this->core;
        $offers = array();
        $ol = $core->cpa->get("offers");
        $u = $core->user->get($user);
        $c = $u["user_comp"] ? $core->cpa->get("comp", $u["user_comp"]) : array();
        if ($c["comp_offers"]) {
            $co = explode(",", $c["comp_offers"]);
            foreach ($co as $o) {
                if (($o = (int) $o) && $ol[$o]) {
                    $offers[$o] = $ol[$o];
                }
            }
        } else {
            foreach ($ol as $o => $n) {
                if ($this->auth($o, $user)) {
                    $offers[$o] = $n;
                }
            }
        }
        return $offers;
    }
    public function auth($offer, $user, $exti = false, $exts = false)
    {
        $auth = $this->core->cpa->get("offerauth", 0, $offer);
        if (!$auth) {
            return true;
        }
        if ($auth["block"]) {
            return false;
        }
        if (!$user) {
            return true;
        }
        if ($auth["private"]) {
            if ($exti && $exts && $auth["wle"][$exti] && in_array($exts, $auth["wle"][$exti])) {
                return true;
            }
            return $auth["wl"] ? in_array($user, $auth["wl"]) ? true : false : false;
        }
        if ($exti && $exts && $auth["ble"][$exti] && in_array($exts, $auth["ble"][$exti])) {
            return false;
        }
        if ($auth["bl"] && in_array($user, $auth["bl"])) {
            return false;
        }
        return true;
    }
    public function visible($offer, $user)
    {
        $auth = $this->core->cpa->get("offerauth", 0, $offer);
        if (!$auth) {
            return true;
        }
        if ($auth["block"]) {
            return false;
        }
        if (!$user) {
            return true;
        }
        if ($auth["private"] == 1) {
            return in_array($user, $auth["wl"]) ? true : false;
        }
        if ($auth["bl"] && in_array($user, $auth["bl"])) {
            return false;
        }
        return true;
    }
    public function price($id, $user = false)
    {
        $id = (int) $id;
        if (!$id) {
            return false;
        }
        $core = $this->core;
        $o = $core->cpa->get("offer", $id);
        $st = $core->cpa->get("offerstat", $id);
        $ps = $core->cpa->get("prices", $id);
        $data = array();
        $prt = unserialize($o["offer_prt"]);
        $cnt = $o["offer_country"] ? explode(",", $o["offer_country"]) : array("ru");
        foreach ($cnt as $c) {
            if ($c = trim($c)) {
                $cur = $core->currency->country($c);
                $data[$c] = array("code" => $c, "name" => $core->lang["country"][$c], "land" => 0 < $prt[$cur] ? $core->currency->show($prt[$cur], $cur) : false, "lp" => $prt[$cur], "lc" => $cur, "appr" => 0 < $st[$c][0] ? $st[$c][0] : 0, "cr" => 0 < $st[$c][1] ? $st[$c][1] : 0, "epc" => 0 < $st[$c][2] ? $core->currency->prntf("%0.2f", $st[$c][2]) : 0, "epcv" => $st[$c][2], "dsk" => 0, "dsku" => 0, "dskx" => 0, "dskp" => 0, "mob" => 0, "mobu" => 0, "mobx" => 0, "mobp" => 0);
            }
        }
        $uw = $user ? $user : $core->user->id;
        $ux = $core->user->get($user);
        $ur = $ux["user_ref"];
        $isvip = $ux["user_vip"];
        $isext = $ux["user_ext"];
        $isrvp = $ur ? $core->user->get($ur, "user_vip") : false;
        foreach ($ps as &$p) {
            if (!$p["wmset"]) {
                continue;
            }
            if ($p["price_out"]) {
                continue;
            }
            if ($p["wmid"] && !in_array($uw, $p["wmid"])) {
                continue;
            }
            if ($p["price_in"] == 1) {
                if (!$isvip) {
                    continue;
                }
                if ($p["price_inid"] && $uw != $p["price_inid"]) {
                    continue;
                }
            } else {
                if ($p["price_in"] == 2) {
                    if (!$isext) {
                        continue;
                    }
                    if ($p["price_inid"] && $uw != $p["price_inid"]) {
                        continue;
                    }
                } else {
                    if ($p["price_in"] == 3) {
                        if (!$isrvp) {
                            continue;
                        }
                        if ($p["price_inid"] && $ur != $p["price_inid"]) {
                            continue;
                        }
                    }
                }
            }
            $oid = (int) $p["offer_id"];
            $geo = $p["price_geo"] ? explode(",", $p["price_geo"]) : false;
            $wmp = $p["wm"];
            $wmu = $p["wmup"];
            $wmx = $p["wmxs"];
            $wmr = $p["wmper"];
            $cur = $p["price_cur"] ? $core->currency->id($p["price_cur"]) : false;
            foreach ($data as $cc => &$c) {
                if ($geo && !in_array($cc, $geo)) {
                    continue;
                }
                if ($p["price_mobile"]) {
                    if ($p["price_mobile"] == 1) {
                        $c["mob"] = 0 < $wmp ? $wmp : 0;
                        $c["mobu"] = 0 < $wmu ? $wmu : 0;
                        $c["mobx"] = 0 < $wmx ? $wmx : 0;
                        $c["mobp"] = 0 < $wmr ? $wmr : 0;
                        $c["mobc"] = $cur;
                    }
                    if ($p["price_mobile"] == 2) {
                        $c["dsk"] = 0 < $wmp ? $wmp : 0;
                        $c["dsku"] = 0 < $wmu ? $wmu : 0;
                        $c["dskx"] = 0 < $wmx ? $wmx : 0;
                        $c["dskp"] = 0 < $wmr ? $wmr : 0;
                        $c["dskc"] = $cur;
                    }
                } else {
                    $c["mob"] = 0 < $wmp ? $wmp : 0;
                    $c["dsk"] = $c["mob"];
                    $c["mobu"] = 0 < $wmu ? $wmu : 0;
                    $c["dsku"] = $c["mobu"];
                    $c["mobx"] = 0 < $wmx ? $wmx : 0;
                    $c["dskx"] = $c["mobx"];
                    $c["mobp"] = 0 < $wmr ? $wmr : 0;
                    $c["dskp"] = $c["mobp"];
                    $c["mobc"] = $cur;
                    $c["dskc"] = $c["mobc"];
                }
            }
        }
        unset($p);
        return $data;
    }
}

?>