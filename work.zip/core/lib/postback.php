<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

class postback
{
    private $core = NULL;
    public function __construct($core)
    {
        $this->core = $core;
    }
    public function make($o, $accept = false)
    {
        $user = (int) $o["wm_id"];
        if (!$user) {
            return false;
        }
        $flow = (int) $o["flow_id"];
        $order = (int) $o["order_id"];
        $status = (int) $o["order_webstat"];
        if ($o["order_status"] != $o["order_webstat"]) {
            $accept = false;
        }
        $url = $this->url($user, $flow, $status, $accept);
        if (!$url) {
            return false;
        }
        $url = html_entity_decode($url);
        if (substr($url, 0, 5) == "POST:") {
            $post = true;
            $url = substr($url, 5);
        } else {
            $post = false;
        }
        if (preg_match_all("#\\{stage\\:([^}]+)\\}#", $url, $ms)) {
            foreach ($ms[0] as $i => $m) {
                $stl = explode("|", $ms[1][$i]);
                $sti = $stl[$status - 1];
                $url = str_replace($m, $sti, $url);
            }
        }
        $pbd = array("id" => $o["order_id"], "oid" => $o["ext_oid"], "uid" => $o["ext_uid"], "src" => $o["ext_src"], "offer" => $o["offer_id"], "flow" => $o["flow_id"], "click" => $o["click_id"], "site" => $o["site_id"], "space" => $o["space_id"], "mobile" => $o["order_mobile"], "date" => $o["order_time"], "dateutc" => urlencode(date("r", $o["order_time"])), "ip" => int2ip($o["order_ip"]), "geo" => $o["order_country"], "count" => $o["order_count"], "price" => $o["price_total"], "cash" => $o["cash_wm"], "status" => $status, "stage" => whatstage($o["order_webstat"], $o["order_reason"]), "reason" => $o["order_reason"], "utms" => $o["utms"], "utmc" => $o["utmc"], "utmn" => $o["utmn"], "utmt" => $o["utmt"], "utmm" => $o["utmm"], "utm_source" => $o["utms"], "utm_campaign" => $o["utmc"], "utm_content" => $o["utmn"], "utm_term" => $o["utmt"], "utm_medium" => $o["utmm"]);
        $core = $this->core;
        if ($core->user->get($user, "user_ext")) {
            $offer = $core->cpa->get("offer", $o["offer_id"]);
            $odata = $offer["offer_pars"] ? unserialize($offer["offer_pars"]) : false;
            $ometa = $o["order_meta"] ? unserialize($o["order_meta"]) : false;
        } else {
            $offer = $odata = $ometa = false;
        }
        foreach ($pbd as $pbk => $pbv) {
            $url = str_replace("{" . $pbk . "}", $pbv, $url);
        }
        if ($offer) {
            foreach ($offer as $k => $v) {
                $url = str_replace("{offer:" . $k . "}", $v, $url);
            }
        }
        if ($odata) {
            foreach ($odata as $k => $v) {
                $url = str_replace("{data:" . $k . "}", $v, $url);
            }
        }
        if ($ometa) {
            foreach ($ometa as $k => $v) {
                $url = str_replace("{meta:" . $k . "}", $v, $url);
            }
        }
        if ($post) {
            $u = explode("?", $url, 2);
            $this->request($user, $flow, $order, $u[0], $u[1]);
        } else {
            $this->request($user, $flow, $order, $url);
        }
    }
    private function url($user, $flow, $status, $accept = false)
    {
        $core = $this->core;
        $ud = $core->user->get($user);
        if ($ud["user_ext"]) {
            $e = $core->cpa->get("ext", $ud["user_ext"]);
            $st = $accept ? 100 : $status;
            switch ($st) {
                case 1:
                    if ($e["url_new"]) {
                        return $e["url_new"];
                    }
                    break;
                case 3:
                    if ($e["url_nc"]) {
                        return $e["url_nc"];
                    }
                    break;
                case 4:
                    if ($e["url_rc"]) {
                        return $e["url_rc"];
                    }
                    break;
                case 5:
                    if ($e["url_dec"]) {
                        return $e["url_dec"];
                    }
                    break;
                case 10:
                    if ($e["url_pay"]) {
                        return $e["url_pay"];
                    }
                    break;
                case 11:
                    if ($e["url_ret"]) {
                        return $e["url_ret"];
                    }
                    break;
                case 12:
                    if ($e["url_del"]) {
                        return $e["url_del"];
                    }
                    break;
                case 100:
                    if ($e["url_acc"]) {
                        return $e["url_acc"];
                    }
                    break;
            }
        } else {
            if ($flow) {
                $f = $core->flow->get($flow);
                if ($f["pbu"]) {
                    return $f["pbu"];
                }
            }
        }
        return $ud["meta"]["pbu"] ? $ud["meta"]["pbu"] : false;
    }
    private function request($user, $flow, $order, $url, $post = false)
    {
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 3);
        curl_setopt($curl, CURLOPT_TIMEOUT, 5);
        if ($post) {
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $post);
        }
        $result = curl_exec($curl);
        $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);
        $usv = $post ? $url . "?" . $post : $url;
        $this->core->db->add(DB_LOG_PB, array("user_id" => (int) $user, "flow_id" => (int) $flow, "order_id" => (int) $order, "log_time" => time(), "log_status" => (int) $status, "log_url" => addslashes(stripslashes($usv)), "log_result" => addslashes(stripslashes($result))));
    }
}

?>