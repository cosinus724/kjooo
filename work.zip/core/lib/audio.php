<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

class audio
{
    private $core = NULL;
    public function __construct($core)
    {
        $this->core = $core;
    }
    public function sync()
    {
    }
    public function add()
    {
    }
}

?>