<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

class order
{
    private $core = NULL;
    private $mt = array(array(1, 5, 12), array(2, 5, 12), array(3, 5, 12, 100), array(2, 5, 12, 100), array(5, 12, 100), array(2, 12), array(2, 7, 8, 9, 10, 11, 12), array(6, 8, 9, 10, 11, 12), array(7, 9, 10, 11, 12), array(8, 10, 11, 12), array(11, 12), array(10, 12), array(2));
    public function __construct($core)
    {
        $this->core = $core;
    }
    public function canmove($status, $offer = false)
    {
        $status = (int) $status;
        $offer = $offer ? (int) $offer : false;
        $sl = array_flip($this->mt[$status]);
        foreach ($sl as &$s) {
            $s = true;
        }
        unset($s);
        $a = $this->core->cpa->team();
        if ($a["root"]) {
            return $sl;
        }
        if (5 < $status) {
            unset($sl[12]);
            if ($status < 12) {
                unset($sl[2]);
            }
        }
        if ($a["admin"]) {
            return $sl;
        }
        if ($offer !== false && $a["offer"] && !in_array($offer, $a["offer"])) {
            return array();
        }
        if ($a["mod"]) {
            return $sl;
        }
        switch ($status) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
                return $a["call"] ? $sl : array();
            case 6:
                return $a["pack"] ? $sl : array();
            case 7:
                return $a["send"] ? $sl : array();
            case 8:
            case 9:
            case 10:
            case 11:
                return $a["delivery"] ? $sl : array();
            case 5:
            case 12:
        }
        return array();
    }
    public function cando($status, $offer)
    {
        $status = (int) $status;
        $offer = (int) $offer;
        $a = $this->core->cpa->team();
        if ($a["root"] || $a["admin"]) {
            return true;
        }
        if ($a["offer"] && !in_array($offer, $a["offer"])) {
            return false;
        }
        if ($a["mod"]) {
            return true;
        }
        if ($a["delivery"] && 7 < $status && $status < 12) {
            return true;
        }
        if ($a["pack"] && $status == 6) {
            return true;
        }
        if ($a["send"] && $status == 7) {
            return true;
        }
        if ($a["call"]) {
            return $status < 5 ? true : false;
        }
        return false;
    }
    public function canedit($status, $offer)
    {
        $status = (int) $status;
        $offer = (int) $offer;
        $a = $this->core->cpa->team();
        $sl = array(2, 3, 4, 6, 7);
        if ($a["root"] || $a["admin"]) {
            return in_array($status, $sl) ? true : false;
        }
        if ($a["offer"] && !in_array($offer, $a["offer"])) {
            return false;
        }
        if ($a["mod"]) {
            return in_array($status, $sl) ? true : false;
        }
        if ($a["pack"] && $status == 6) {
            return true;
        }
        if ($a["send"] && $status == 7) {
            return true;
        }
        if ($a["call"]) {
            return 1 < $status && $status < 5 ? true : false;
        }
        return false;
    }
    public function canitem($status, $offer)
    {
        $status = (int) $status;
        $offer = (int) $offer;
        $a = $this->core->cpa->team();
        $sl = array(2, 3, 4, 6);
        if ($a["root"] || $a["admin"]) {
            return in_array($status, $sl) ? true : false;
        }
        if ($a["offer"] && !in_array($offer, $a["offer"])) {
            return false;
        }
        if ($a["mod"]) {
            return in_array($status, $sl) ? true : false;
        }
        if ($a["pack"] && $status == 6) {
            return true;
        }
        if ($a["call"]) {
            return 1 < $status && $status < 5 ? true : false;
        }
        return false;
    }
    public function notify($order)
    {
        $core = $this->core;
        $ce = $core->cpa->get("comp", $order["comp_id"], "comp_mailto");
        if (!$ce) {
            return true;
        }
        $ce = preg_split("#[,;\\s]+#", $ce, -1, PREG_SPLIT_NO_EMPTY);
        $ce = $ce ? array_unique($ce) : false;
        if (!$ce) {
            return true;
        }
        $data = array(sprintf("%s: %s", $core->lang["offer"], $core->cpa->get("offer", $order["offer_id"], "offer_name")));
        $df = array("order_name", "order_email", "order_phone", "order_comment", "order_country", "order_index", "order_area", "order_city", "order_street", "order_addr");
        foreach ($df as $d) {
            if ($order[$d]) {
                $data[] = sprintf("%s: %s", $core->lang["changelogs"][$d], $order[$d]);
            }
        }
        $data[] = "URL: " . $core->uri(array("order", $order["order_id"]));
        $data = implode("\n", $data);
        $core->email->send($ce, $core->lang["mail_neworder_h"], sprintf($core->lang["mail_neworder_t"], $data));
    }
}

?>