<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

class currency
{
    private $core = NULL;
    public $default = 0;
    public $format = "%0.2f";
    public $data = array(array("rub", "ru", "rur", "%s <i class=\"fa fa-rub\"></i>"), array("uah", "ua"), array("kzt", "kz", "kaz"), array("byn", "by", array("byr", "byb")), array("amd", "am"), array("kgs", "kg"), array("mdl", "md"), array("gel", "ge"), array("azn", "az"), array("usd", array("io", "gu", "mh", "fm", "mp", "pw", "pr", "tc", "us", "um", "vg", "vi"), NULL, "<i class=\"fa fa-usd\"></i> %s"), array("eur", array("as", "ad", "at", "be", "fi", "fr", "gf", "tf", "de", "gr", "gp", "ie", "it", "lu", "mq", "yt", "mc", "nl", "pt", "re", "ws", "sm", "si", "es", "va", "ax", "me", "bl", "pm"), NULL, "<i class=\"fa fa-eur\"></i> %s"), array("aed", "ae"), array("sar", "sa"), array("jod", array("jo", "ps")), array("kwd", "kw"), array("bhd", "bh"), array("qar", "qa"), array("omr", "om"), array("idr", "id"), array("bgn", "bg"), array("huf", "hu"), array("gbp", array("gs", "gb", "je", "im", "sh"), NULL, "<i class=\"fa fa-gbp\"></i> %s"), array("dkk", array("dk", "fo", "gl")), array("pln", "pl"), array("ron", "ro"), array("hrk", "hr"), array("czk", "cz"), array("sek", "se"), array("aud", array("au", "cx", "cc", "hm", "ki", "nr", "nf", "tv")), array("afn", "af"), array("all", "al"), array("ang", array("aw", "an", "mf", "cw", "sx")), array("aoa", "ao"), array("ars", "ar"), array("nzd", array("nz", "ck", "nu", "pn", "tk")), array("hkd", "hk"), array("cad", "ca"), array("jpy", "jp", NULL, "<i class=\"fa fa-jpy\"></i> %s"), array("dzd", "dz"), array("xcd", array("ai", "ag", "dm", "gd", "ms", "kn", "lc", "vc")), array("bsd", "bs"), array("bdt", "bd"), array("bbd", "bb"), array("bzd", "bz"), array("xof", array("bj", "bf", "gw", "ci", "ml", "ne", "sn", "tg")), array("bmd", "bm"), array("inr", array("bt", "in"), NULL, "<i class=\"fa fa-inr\"></i> %s"), array("bob", "bo"), array("bwp", "bw"), array("nok", array("bv", "no", "sj")), array("brl", "br"), array("bnd", "bn"), array("bif", "bi"), array("khr", "kh"), array("xaf", array("cm", "cf", "td", "cg", "gq", "ga")), array("cve", "cv"), array("kyd", "ky"), array("clp", "cl"), array("cny", "cn"), array("cop", "co"), array("kmf", "km"), array("cdf", "cd"), array("crc", "cr"), array("cup", "cu"), array("cyp", "cy"), array("djf", "dj"), array("dop", "do"), array("ecs", "ec"), array("egp", "eg"), array("svc", "sv"), array("etb", array("er", "et")), array("eek", "ee"), array("fkp", "fk"), array("fjd", "fj"), array("xpf", array("pf", "nc", "wf")), array("gmd", "gm"), array("gip", "gi"), array("gtq", "gt"), array("gnf", "gn"), array("gyd", "gy"), array("htg", "ht"), array("hnl", "hn"), array("isk", "is"), array("irr", "ir"), array("iqd", "iq"), array("ils", "il", NULL, "<i class=\"fa fa-ils\"></i> %s"), array("jmd", "jm"), array("kes", "ke"), array("kpw", "kp"), array("krw", "kr", NULL, "<i class=\"fa fa-krw\"></i> %s"), array("lak", "la"), array("lvl", "lv"), array("lbp", "lb"), array("lsl", "ls"), array("lrd", "lr"), array("lyd", "ly"), array("chf", array("li", "ch")), array("ltl", "lt"), array("mop", "mo"), array("mkd", "mk"), array("mga", "mg"), array("mwk", "mw"), array("myr", "my"), array("mvr", "mv"), array("mtl", "mt"), array("mro", "mr"), array("mur", "mu"), array("mxn", "mx"), array("mnt", "mn"), array("mad", array("ma", "eh")), array("mzn", "mz"), array("mmk", "mm"), array("nad", "na"), array("npr", "np"), array("nio", "ni"), array("ngn", "ng"), array("pkr", "pk"), array("pab", "pa"), array("pgk", "pg"), array("pyg", "py"), array("pen", "pe"), array("php", "ph"), array("rwf", "rw"), array("std", "st"), array("scr", "sc"), array("sll", "sl"), array("sgd", "sg"), array("skk", "sk"), array("sbd", "sb"), array("sos", "so"), array("zar", "za"), array("lkr", "lk"), array("sdg", "sd"), array("srd", "sr"), array("szl", "sz"), array("syp", "sy"), array("twd", "tw"), array("tjs", "tj"), array("tzs", "tz"), array("thb", "th"), array("top", "to"), array("ttd", "tt"), array("tnd", "tn"), array("try", "tr", NULL, "<i class=\"fa fa-try\"></i> %s"), array("tmt", "tm"), array("ugx", "ug"), array("uyu", "uy"), array("uzs", "uz"), array("vuv", "vu"), array("vef", "ve"), array("vnd", "vn"), array("yer", "ye"), array("zmk", "zm"), array("zwd", "zw", "zwl"), array("aqd", "aq"), array("bam", "ba"), array("ghs", "gh"), array("ggp", "gg"), array("rsd", "rs"));
    public $code = array();
    public $name = array();
    public $codes = array();
    public $names = array();
    public $cn2i = array();
    public $cr2i = array();
    private $cc = false;
    public function __construct($core)
    {
        $this->core = $core;
        $this->parse();
        $this->default = $this->id($core->config("money", "currency"));
        $this->format = $core->config("money", "format") ? "%d" : "%0.2f";
    }
    private function parse()
    {
        $core = $this->core;
        if ($core->cando("currencylist")) {
            $this->data = $core->filter("currencylist", $this->data);
        }
        foreach ($this->data as $id => $oo) {
            $this->cr2i[$oo[0]] = $id;
            if ($oo[2]) {
                if (is_array($oo[2])) {
                    foreach ($oo[2] as $a) {
                        $this->cr2i[$a] = $id;
                    }
                } else {
                    $this->cr2i[$oo[2]] = $id;
                }
            }
            if (is_array($oo[1])) {
                foreach ($oo[1] as $a) {
                    $this->cn2i[$a] = $id;
                }
            } else {
                $this->cn2i[$oo[1]] = $id;
            }
            $this->code[$id] = $oo[0];
            $this->name[$id] = $core->lang["currencies"][$oo[0]] ? $core->lang["currencies"][$oo[0]] : strtoupper($oo[0]);
            $this->codes[$oo[0]] = $core->lang["currencies"][$oo[0]] ? strtoupper($oo[0]) . ": " . $core->lang["currencies"][$oo[0]] : strtoupper($oo[0]);
            $this->names[$oo[0]] = $core->lang["currencies"][$oo[0]] ? $core->lang["currencies"][$oo[0]] : strtoupper($oo[0]);
        }
        asort($this->codes);
        asort($this->names);
    }
    public function country($c)
    {
        $c = strtolower($c);
        return isset($this->cn2i[$c]) ? $this->cn2i[$c] : $this->default;
    }
    public function code($c)
    {
        return $this->code[$c];
    }
    public function upcode($c)
    {
        return strtoupper($this->code[$c]);
    }
    public function name($c)
    {
        return $this->name[$c];
    }
    public function id($c)
    {
        $c = strtolower($c);
        return isset($this->cr2i[$c]) ? $this->cr2i[$c] : $this->default;
    }
    public function geoid($geo)
    {
        $ids = array();
        foreach ($geo as $g) {
            $ids[] = $this->country($g);
        }
        return array_unique($ids);
    }
    public function geoline($geo)
    {
        $geo = strtolower($geo);
        $geo = explode(",", $geo);
        $geo = array_unique($geo);
        return $this->geoid($geo);
    }
    public function show($p, $c)
    {
        return $this->data[$c][3] ? sprintf($this->data[$c][3], sprintf($this->format, $p)) : sprintf($this->format . " %s", $p, $this->code[$c]);
    }
    public function prnt($p)
    {
        return $this->data[$this->default][3] ? sprintf($this->data[$this->default][3], sprintf($this->format, $p)) : sprintf($this->format . " %s", $p, $this->code[$this->default]);
    }
    public function prntf($f, $p)
    {
        return $this->data[$this->default][3] ? sprintf($this->data[$this->default][3], sprintf($f, $p)) : sprintf($f . " %s", $p, $this->code[$this->default]);
    }
    public function sprint($p)
    {
        return $this->data[$this->default][3] ? sprintf($this->data[$this->default][3], $p) : sprintf("%s %s", $p, $this->code[$this->default]);
    }
    public function mval($m, $f = false)
    {
        $cl = $m < 0 ? "text-danger" : (0 < $m ? "text-success" : "text-muted");
        return "<span class=\"" . $cl . "\">" . sprintf($f ? $f : $this->format, $m) . "</span>";
    }
    public function money($m)
    {
        $cl = $m < 0 ? "text-danger" : (0 < $m ? "text-success" : "text-muted");
        return "<span class=\"" . $cl . "\">" . $this->prnt($m) . "</span>";
    }
    public function convert($p, $c)
    {
        if (!is_numeric($c)) {
            $c = strtolower($c);
            if (isset($this->cr2i[$c])) {
                $c = $this->cr2i[$c];
            } else {
                return false;
            }
        } else {
            $c = (int) $c;
        }
        if ($c == $this->default) {
            return $p;
        }
        if (!$this->cc) {
            $this->cc = $this->core->config("currencyconvert");
        }
        return sprintf("%0.2f", $p * $this->cc[$c]);
    }
    public function rawconv($p, $c)
    {
        if (!is_numeric($c)) {
            $c = strtolower($c);
            if (isset($this->cr2i[$c])) {
                $c = $this->cr2i[$c];
            } else {
                return false;
            }
        } else {
            $c = (int) $c;
        }
        if ($c == $this->default) {
            return $p;
        }
        if (!$this->cc) {
            $this->cc = $this->core->config("currencyconvert");
        }
        return $p * $this->cc[$c];
    }
    public function update()
    {
        $core = $this->core;
        $cc = $this->cc ? $this->cc : $core->config("currencyconvert");
        if (!$core->cando("currencyconvert")) {
            $ct = $this->cct_all();
            if ($ct) {
                $base = "usd";
            } else {
                $base = "rub";
                $ct = $this->cct_cbr();
                $ct[$base] = 1;
                $cx = $this->cct_uah();
                foreach ($cx as $c => $x) {
                    if (!$ct[$c]) {
                        $ct[$c] = $x * $ct["uah"];
                    }
                }
                if (!$ct) {
                    return false;
                }
            }
            $dc = $this->code($this->default);
            if ($dc != $base) {
                $coef = $ct[$dc];
                foreach ($ct as &$x) {
                    $x = 1 / ($coef / $x);
                }
                unset($x);
            }
        } else {
            $ct = $core->filter("currencyconvert", array());
        }
        foreach ($this->data as $id => &$x) {
            $cc[$id] = $ct[$this->code[$id]];
        }
        $this->cc = $cc;
        $core->reconf("currencyconvert", $cc);
        return $cc;
    }
    private function cct_cbr()
    {
        $ct = array();
        $ctp = json_decode(curl("https://www.cbr-xml-daily.ru/daily_json.js"));
        if (!$ctp) {
            $ctp = simplexml_load_string(curl("http://www.cbr.ru/scripts/XML_daily.asp?"));
        }
        if ($ctp) {
            foreach ($ctp->Valute as $v) {
                $code = strtolower($v->CharCode);
                $vv = $v->Value;
                if (strpos($vv, ",")) {
                    $vv = (double) strtr($vv, ",", ".");
                }
                $ct[$code] = $vv / $v->Nominal;
            }
        }
        if ($ct) {
            $this->core->reconf("cct_cbr", $ct);
            return $ct;
        }
        return $this->core->config("cct_cbr");
    }
    private function cct_uah()
    {
        $ct = array();
        $ctp = json_decode(curl("https://bank.gov.ua/NBUStatService/v1/statdirectory/exchange?json"), true);
        if ($ctp) {
            foreach ($ctp as $v) {
                $code = strtolower($v["cc"]);
                $ct[$code] = $v["rate"];
            }
        }
        if ($ct) {
            $this->core->reconf("cct_uah", $ct);
            return $ct;
        }
        return $this->core->config("cct_uah");
    }
    private function cct_all()
    {
        $ct = array();
        $key = $this->core->config("money", "key");
        if (!$key) {
            return false;
        }
        $ctp = json_decode(curl("https://openexchangerates.org/api/latest.json?app_id=" . $key), true);
        if ($ctp) {
            foreach ($ctp["rates"] as $code => $v) {
                $code = strtolower($code);
                $ct[$code] = 1 / $v;
            }
        }
        if ($ct) {
            $this->core->reconf("cct_all", $ct);
            return $ct;
        }
        return $this->core->config("cct_all");
    }
}

?>