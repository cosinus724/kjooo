<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

class support
{
    private $core = NULL;
    private $mode = 0;
    private $opt = array("offer" => array("i" => "number"));
    public function __construct($core)
    {
        $this->core = $core;
    }
    public function admin()
    {
        $this->mode = 1;
    }
    public function add($user)
    {
        $user = (int) $user;
        if (!$user) {
            return false;
        }
        $core = $this->core;
        $text = $core->text->line($core->post["text"]);
        $data = array("supp_user" => $user, "user_id" => $core->user->id, "user_name" => $core->user->name, "supp_type" => $this->mode, "supp_time" => time(), "supp_read" => 0, "supp_text" => $text, "supp_ip" => ip2int(remoteip($core->server)));
        $o = $core->text->link($core->post["o"]);
        if ($this->opt[$o]) {
            $opt = array();
            foreach ($this->opt[$o] as $on => $ot) {
                switch ($ot) {
                    case "int":
                        $opt[$on] = (int) $core->post[$on];
                        break;
                    case "link":
                        $opt[$on] = $core->text->link($core->post[$on]);
                        break;
                    case "number":
                        $opt[$on] = $core->text->number($core->post[$on]);
                        break;
                    default:
                        $opt[$on] = $core->text->line($core->post[$on]);
                }
            }
            $data["supp_opt"] = $o;
            $data["supp_data"] = addslashes(json_encode($opt));
        }
        if (!($data["supp_text"] || $data["supp_opt"])) {
            return false;
        }
        if ($core->db->add(DB_SUPP, $data)) {
            $id = $core->db->lastid();
            $cnt = $core->db->field("SELECT COUNT(*) FROM " . DB_SUPP . " WHERE supp_user = '" . $user . "' AND supp_type = '" . $this->mode . "' AND supp_read = 0");
            $u = array("supp_last" => time(), "supp_user" => $core->user->id, "supp_name" => $core->user->name, "supp_type" => $this->mode, "supp_notify" => 0);
            if ($this->mode) {
                $u["supp_new"] = $cnt;
            } else {
                $u["supp_admin"] = $cnt;
            }
            $core->user->set($user, $u);
            return $id;
        }
        return false;
    }
    public function del($msg)
    {
        if (!$this->mode) {
            return false;
        }
        $core = $this->core;
        $user = $core->db->field("SELECT supp_user FROM " . DB_SUPP . " WHERE supp_id = '" . $msg . "' LIMIT 1");
        if ($core->db->del(DB_SUPP, array("supp_id" => $msg))) {
            $cnts = $core->db->icol("SELECT supp_type, COUNT(*) FROM " . DB_SUPP . " WHERE supp_user = '" . $user . "' AND supp_read = 0 GROUP BY supp_type");
            $last = $core->db->row("SELECT user_id, user_name, supp_type, supp_time FROM " . DB_SUPP . " WHERE supp_user = '" . $user . "' ORDER BY supp_id DESC LIMIT 1");
            if ($last) {
                $data = array("supp_last" => $last["supp_time"], "supp_user" => $last["user_id"], "supp_name" => $last["user_name"], "supp_type" => $last["supp_type"], "supp_notify" => $cnts[1] ? 0 : 1, "supp_new" => $cnts[1], "supp_admin" => $cnts[0]);
            } else {
                $data = array("supp_last" => 0, "supp_user" => 0, "supp_name" => "", "supp_type" => 0, "supp_notify" => 0, "supp_new" => 0, "supp_admin" => 0);
            }
            $core->user->set($user, $data);
            return $msg;
        }
        return false;
    }
    public function show($user, $from = 0)
    {
        $user = (int) $user;
        if (!$user) {
            return false;
        }
        $from = (int) $from;
        $core = $this->core;
        $ms = array();
        $ur = array(0, 0);
        $type = $this->mode ? 0 : 1;
        $from = 0 < $from ? "< '" . $from . "'" : "> '" . abs($from) . "'";
        $mms = $core->db->data("SELECT * FROM " . DB_SUPP . " WHERE supp_user = '" . $user . "' AND supp_id " . $from . " ORDER BY supp_id DESC LIMIT 10");
        foreach ($mms as &$m) {
            $row = array("id" => $m["supp_id"], "uid" => $m["user_id"], "user" => $m["user_name"], "link" => $this->mode ? $core->u(array("users", $m["user_id"])) : "", "time" => $core->text->smartdate($m["supp_time"]), "text" => $m["supp_text"] ? $core->text->lines($m["supp_text"]) : false, "label" => $m["supp_type"] ? "success" : "primary", "uclass" => $m["supp_type"] ? "user-alt" : "user-blue", "rclass" => $m["supp_read"] ? "" : "unread", "new" => $m["supp_read"] ? 0 : $m["supp_type"] != $this->mode, "ip" => int2ip($m["supp_ip"]), "option" => $m["supp_opt"] ? $m["supp_opt"] : false, "param" => $m["supp_opt"] && $m["supp_data"] ? json_decode($m["supp_data"], true) : array());
            if ($m["supp_opt"]) {
                $mfn = $this->mode ? "msgopt_" . $m["supp_opt"] . "_admin" : "msgopt_" . $m["supp_opt"] . "_user";
                $mfh = $mfn . "_hack";
                if (function_exists($mfh)) {
                    $mfn = $mfh;
                }
                if (function_exists($mfn)) {
                    $opt = $mfn($core, $row);
                    foreach ($opt as $on => $ov) {
                        $row["opt" . $on] = $ov;
                    }
                }
            }
            if ($m["supp_read"] == 0) {
                $ur[$m["supp_type"] ? 0 : 1] = 1;
            }
            $ms[] = $row;
        }
        unset($m);
        unset($mms);
        if ($ur[$this->mode]) {
            $core->db->edit(DB_SUPP, array("supp_read" => 1), array("supp_user" => $user, "supp_type" => $type));
            if ($this->mode) {
                $core->user->set($user, array("supp_admin" => 0));
            } else {
                $core->user->set($user, array("supp_new" => 0));
            }
        }
        return $ms;
    }
    public function option($name, $params)
    {
        $this->opt[$name] = $params;
    }
    public function block($o)
    {
        $core = $this->core;
        $o = $core->text->link($o);
        if (!$o) {
            return false;
        }
        if (!$this->opt[$o]) {
            return false;
        }
        $mfn = "msgopt_" . $o . "_block";
        $mfh = $mfn . "_hack";
        if (function_exists($mfh)) {
            $mfn = $mfh;
        } else {
            if (!function_exists($mfn)) {
                return false;
            }
        }
        $param = array();
        foreach ($this->opt[$o] as $on => $ot) {
            switch ($ot) {
                case "int":
                    $param[$on] = (int) $core->get[$on];
                    break;
                case "link":
                    $param[$on] = $core->text->link($core->get[$on]);
                    break;
                case "number":
                    $param[$on] = $core->text->number($core->get[$on]);
                    break;
                default:
                    $param[$on] = $core->text->line($core->get[$on]);
            }
        }
        return $mfn($core, $param);
    }
}
function msgopt_offer_block($core, $param)
{
    return array("title" => $core->lang["supms_offer_un"], "text" => sprintf($core->lang["supms_offer_ut"], $core->cpa->get("offer", $param["i"], "offer_name")), "param" => $param);
}
function msgopt_offer_user($core, $msg)
{
    return array("title" => $core->lang["supms_offer_un"], "text" => sprintf($core->lang["supms_offer_ut"], $core->cpa->get("offer", $msg["param"]["i"], "offer_name")));
}
function msgopt_offer_admin($core, $msg)
{
    return array("title" => $core->lang["supms_offer_un"], "text" => sprintf($core->lang["supms_offer_ut"], $core->cpa->get("offer", $msg["param"]["i"], "offer_name")), "link" => $core->lang["supms_offer_ul"], "url" => $core->user->level ? $core->u(array("offer", $msg["param"]["i"]), array("action" => "wl", "user" => $msg["uid"])) : false);
}

?>