<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

if ($core->post["LMI_PAYEE_PURSE"] != WMR) {
    exit;
}
$id = (int) $core->post["LMI_PAYMENT_NO"];
if ($id) {
    $user = $core->db->row("SELECT * FROM " . DB_USER . " WHERE user_id = '" . $id . "' LIMIT 1");
    if (!$user["user_id"]) {
        exit;
    }
    if (!$core->post["LMI_PREREQUEST"]) {
        $hash = WMR . $core->post["LMI_PAYMENT_AMOUNT"] . $core->post["LMI_PAYMENT_NO"] . $core->post["LMI_MODE"] . $core->post["LMI_SYS_INVS_NO"] . $core->post["LMI_SYS_TRANS_NO"] . $core->post["LMI_SYS_TRANS_DATE"] . WMK . $core->post["LMI_PAYER_PURSE"] . $core->post["LMI_PAYER_WM"];
        $uid = md5($hash);
        $hash = strtoupper(hash("sha256", $hash));
        if ($hash != $core->post["LMI_HASH"]) {
            exit;
        }
        $core->finance->add($id, 0, $core->post["LMI_PAYMENT_AMOUNT"], 1, $core->post["LMI_PAYER_PURSE"], $uid);
    } else {
        echo "YES";
    }
    exit;
}
exit;

?>