<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

class domain
{
    private $core = NULL;
    private $tn = array("red", "site", "space");
    public function __construct($core)
    {
        $this->core = $core;
    }
    public function add($user, $domain, $type)
    {
        $core = $this->core;
        $user = (int) $user;
        $type = (int) $type;
        $domain = mb_strtolower($core->text->anum($domain), "UTF-8");
        if (substr($domain, 0, 4) == "www.") {
            $domain = substr($domain, 5);
        }
        $addr = $core->idna->encode($domain);
        if (!$addr) {
            return false;
        }
        $dok = filter_var($addr, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME);
        if (!$dok) {
            return false;
        }
        $domain = $core->idna->decode($addr);
        if (!defined("ALLOWSAMEPD")) {
            $uid = $core->db->field("SELECT user_id FROM " . DB_DOMAIN . " WHERE dom_addr = '" . $addr . "' AND user_id = '" . $user . "'");
            if ($uid !== NULL && $uid == $user) {
                return false;
            }
        }
        $d = array("user_id" => $user, "dom_type" => $type, "dom_url" => $domain, "dom_addr" => $addr, "dom_status" => 0, "dom_check" => 0, "dom_default" => 0);
        if ($core->db->add(DB_DOMAIN, $d)) {
            $uid = $core->db->lastid();
            $core->uncache("domain.u" . $user);
            return $uid;
        }
        return false;
    }
    public function del($user, $id)
    {
        $id = (int) $id;
        $user = (int) $user;
        if (!$id) {
            return false;
        }
        $core = $this->core;
        $d = $core->db->get(DB_DOMAIN, array("dom_id" => $id));
        if ($user != -1 && $d["user_id"] != $user) {
            return false;
        }
        $core->db->del(DB_DOMAIN, array("dom_id" => $id));
        $core->uncache("domain.u" . $d["user_id"]);
        return true;
    }
    public function def($user, $id)
    {
        $id = (int) $id;
        if (!$id) {
            return false;
        }
        $user = (int) $user;
        if (!$user) {
            return false;
        }
        $core = $this->core;
        $dr = $this->get($user);
        if ($dr["domain"]["red"][$id]) {
            $type = 0;
            $isdef = $dr["default"]["red"] == $id;
        } else {
            if ($dr["domain"]["site"][$id]) {
                $type = 1;
                $isdef = $dr["default"]["site"] == $id;
            } else {
                if ($dr["domain"]["space"][$id]) {
                    $type = 2;
                    $isdef = $dr["default"]["space"] == $id;
                } else {
                    return false;
                }
            }
        }
        $core->db->edit(DB_DOMAIN, array("dom_default" => 0), array("user_id" => $user, "dom_type" => $type));
        if (!$isdef) {
            $core->db->edit(DB_DOMAIN, array("dom_default" => 1), array("dom_id" => $id));
        }
        $core->uncache("domain.u" . $user);
        return true;
    }
    public function get($user)
    {
        $user = (int) $user;
        if (!$user) {
            return false;
        }
        $core = $this->core;
        $dr = $core->cache("domain.u" . $user);
        if (!$dr) {
            $dr = array("default" => array("red" => false, "site" => false, "space" => false), "domain" => array("red" => array(), "site" => array(), "space" => array()), "addr" => array("red" => array(), "site" => array(), "space" => array()));
            $dd = $core->db->data("SELECT dom_id, dom_type, dom_url, dom_addr, dom_default FROM " . DB_DOMAIN . " WHERE user_id IN ( 0, " . $user . " )");
            usort($dd, "domainstrcmp");
            foreach ($dd as $d) {
                $di = (int) $d["dom_id"];
                $dt = $this->tn[$d["dom_type"]];
                if ($d["dom_default"]) {
                    $dr["default"][$dt] = $di;
                }
                $dr["domain"][$dt][$di] = $d["dom_url"];
                $dr["addr"][$dt][$di] = $d["dom_url"];
            }
            $core->cache("domain.u" . $user, $dr);
        }
        return $dr;
    }
    public function show($user)
    {
        $user = (int) $user;
        $core = $this->core;
        $dd = $core->db->data("SELECT * FROM " . DB_DOMAIN . " WHERE user_id = " . $user);
        usort($dd, "domainstrcmp");
        $dr = array("red" => array(), "site" => array(), "space" => array());
        foreach ($dd as $d) {
            $dr[$this->tn[$d["dom_type"]]][] = array("id" => (int) $d["dom_id"], "status" => (int) $d["dom_status"], "check" => (int) $d["dom_check"], "default" => $d["dom_default"] ? true : false, "url" => $d["dom_url"]);
        }
        return $dr;
    }
    public function check($id)
    {
        $id = (int) $id;
        if (!$id) {
            return false;
        }
        $dm = $this->core->db->field("SELECT dom_addr FROM " . DB_DOMAIN . " WHERE dom_id = '" . $id . "' LIMIT 1");
        if ($dm) {
            return $this->checkdomain($id, $dm);
        }
        return false;
    }
    public function croncheck()
    {
        $tm = time() - 13500;
        $dd = $this->core->db->icol("SELECT dom_id, dom_addr FROM " . DB_DOMAIN . " WHERE user_id > 0 AND dom_check < " . $tm);
        foreach ($dd as $di => $dm) {
            $this->checkdomain($di, $dm);
        }
    }
    private function checkdomain($id, $url)
    {
        $curl = curl_init("http://" . $url . "/ok");
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 3);
        curl_setopt($curl, CURLOPT_TIMEOUT, 5);
        $result = curl_exec($curl);
        curl_close($curl);
        $status = $result == "ok" ? 1 : 2;
        $this->core->db->edit(DB_DOMAIN, array("dom_status" => $status, "dom_check" => time()), array("dom_id" => $id));
        return $status == 1 ? true : false;
    }
}
function domainstrcmp($a, $b)
{
    return strcmp($a["dom_url"], $b["dom_url"]);
}

?>