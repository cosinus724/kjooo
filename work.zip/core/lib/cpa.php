<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

class cpa
{
    private $core = NULL;
    private $data = NULL;
    private $prd = array();
    private $ta = array();
    public $statusgroup = array(1, 1, 1, 1, 1, 2, 3, 4, 5, 5, 6, 7, 2, "100" => 1, "101" => 5, "102" => 10, "103" => 6);
    private $sts = array();
    private $dlcs = array();
    private $dlc = array();
    private $dlt = array();
    public function __construct($core)
    {
        $this->core = $core;
    }
    public function __destruct()
    {
    }
    public function get($type, $id = 0, $field = false)
    {
        $id = (int) $id;
        if (isset($this->data[$type][$id])) {
            return $field ? $this->data[$type][$id][$field] : $this->data[$type][$id];
        }
        $cn = "cpa." . $type . $id;
        $zz = $this->core->cache($cn);
        if ($zz || is_array($zz)) {
            $this->data[$type][$id] = $zz;
            return $field ? $this->data[$type][$id][$field] : $this->data[$type][$id];
        }
        switch ($type) {
            case "comp":
                $info = $id ? $this->core->db->row("SELECT * FROM " . DB_COMP . " WHERE comp_id = '" . $id . "' LIMIT 1") : array();
                break;
            case "cc":
                $info = $id ? $this->core->db->field("SELECT comp_config FROM " . DB_COMP . " WHERE comp_id = '" . $id . "' LIMIT 1") : false;
                $info = $info ? unserialize($info) : array();
                break;
            case "compa":
                $info = $this->core->db->icol("SELECT comp_id, comp_name FROM " . DB_COMP);
                if ($info) {
                    asort($info);
                }
                break;
            case "comps":
                $info = $this->core->db->icol("SELECT comp_id, comp_name FROM " . DB_COMP . " WHERE comp_type = 0");
                if ($info) {
                    asort($info);
                }
                break;
            case "ccs":
                $info = $this->core->db->icol("SELECT comp_id, comp_name FROM " . DB_COMP . " WHERE comp_type = 1");
                if ($info) {
                    asort($info);
                }
                break;
            case "team":
                $info = $id ? $this->core->db->row("SELECT * FROM " . DB_TEAM . " WHERE team_id = '" . $id . "' LIMIT 1") : array();
                break;
            case "teams":
                $info = $id ? $this->core->db->icol("SELECT team_id, team_name FROM " . DB_TEAM . " WHERE comp_id = '" . $id . "'") : array();
                if ($info) {
                    asort($info);
                }
                break;
            case "mans":
                $info = $id ? $this->core->db->icol("SELECT user_id, user_name FROM " . DB_USER . " WHERE user_comp = '" . $id . "' ORDER BY user_name ASC") : array();
                break;
            case "allman":
                $info = $this->core->db->icol("SELECT user_id, user_name FROM " . DB_USER . " WHERE user_work > 0 ORDER BY user_name ASC");
                break;
            case "stage":
                $info = $id ? $this->core->db->data("SELECT * FROM " . DB_STAGE . " WHERE comp_id = '" . $id . "'") : array();
                break;
            case "ext":
                $info = $id ? $this->core->db->row("SELECT * FROM " . DB_EXT . " WHERE ext_id = '" . $id . "' LIMIT 1") : array();
                break;
            case "exts":
                $info = $this->core->db->icol("SELECT ext_id, ext_name FROM " . DB_EXT);
                if ($info) {
                    asort($info);
                }
                break;
            case "offer":
                $info = $this->core->db->row("SELECT * FROM " . DB_OFFER . " WHERE offer_id = '" . $id . "' LIMIT 1");
                unset($info["offer_pars"]);
                unset($info["stat_info"]);
                break;
            case "ofp":
                $info = $this->core->db->field("SELECT offer_pars FROM " . DB_OFFER . " WHERE offer_id = '" . $id . "' LIMIT 1");
                $info = $info ? unserialize($info) : array();
                break;
            case "offerstat":
                $info = $this->core->db->field("SELECT stat_info FROM " . DB_OFFER . " WHERE offer_id = '" . $id . "' LIMIT 1");
                $info = $info ? unserialize($info) : array();
                break;
            case "offers":
                $info = $this->core->db->icol("SELECT offer_id, offer_name FROM " . DB_OFFER . " WHERE offer_active = 1");
                asort($info);
                break;
            case "offersa":
                $info = $this->core->db->icol("SELECT offer_id, offer_name FROM " . DB_OFFER);
                asort($info);
                break;
            case "offercat":
                $info = $this->core->db->col("SELECT DISTINCT cat_id FROM " . DB_OFFER . " WHERE offer_active = 1");
                break;
            case "offersub":
                $info = $this->core->db->col("SELECT DISTINCT cat_sub FROM " . DB_OFFER . " WHERE offer_active = 1");
                break;
            case "offergeo":
                $og = $this->core->db->col("SELECT DISTINCT offer_country FROM " . DB_OFFER . " WHERE offer_active = 1");
                $info = array();
                foreach ($og as $ogi) {
                    if ($ogi) {
                        $ogl = explode(",", $ogi);
                        foreach ($ogl as $ogo) {
                            if ($ogo = trim($ogo)) {
                                $info[] = $ogo;
                            }
                        }
                    }
                }
                $info = array_unique($info);
                break;
            case "offerauth":
                $oad = $this->core->db->data("SELECT offer_id, offer_block, offer_private, offer_wl, offer_bl FROM " . DB_OFFER);
                $info = array();
                foreach ($oad as $o) {
                    if ($o["offer_block"]) {
                        $info[$o["offer_id"]] = array("block" => true);
                    } else {
                        if ($o["offer_private"]) {
                            $info[$o["offer_id"]] = array("private" => (int) $o["offer_private"], "wl" => array(), "wle" => array());
                            $ol = explode(" ", $o["offer_wl"]);
                            foreach ($ol as $oi) {
                                if ($oi = trim($oi)) {
                                    if (substr($oi, 0, 3) == "ext") {
                                        $oq = explode("-", substr($oi, 3), 2);
                                        $ei = (int) $oq[0];
                                        if (!$ei) {
                                            continue;
                                        }
                                        if (!$info[$o["offer_id"]]["wle"][$ei]) {
                                            $info[$o["offer_id"]]["wle"][$ei] = array();
                                        }
                                        $info[$o["offer_id"]]["wle"][$ei][] = $oq[1];
                                    } else {
                                        if (substr($oi, 0, 4) == "user") {
                                            $ui = (int) substr($oi, 4);
                                            if ($ui) {
                                                $info[$o["offer_id"]]["wl"][] = $ui;
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            if ($o["offer_bl"]) {
                                $info[$o["offer_id"]] = array("bl" => array(), "ble" => array());
                                $ol = explode(" ", $o["offer_bl"]);
                                foreach ($ol as $oi) {
                                    if ($oi = trim($oi)) {
                                        if (substr($oi, 0, 3) == "ext") {
                                            $oq = explode("-", substr($oi, 3), 2);
                                            $ei = (int) $oq[0];
                                            if (!$ei) {
                                                continue;
                                            }
                                            if (!$info[$o["offer_id"]]["ble"][$ei]) {
                                                $info[$o["offer_id"]]["ble"][$ei] = array();
                                            }
                                            $info[$o["offer_id"]]["ble"][$ei][] = $oq[1];
                                        } else {
                                            if (substr($oi, 0, 4) == "user") {
                                                $ui = (int) substr($oi, 4);
                                                if ($ui) {
                                                    $info[$o["offer_id"]]["bl"][] = $ui;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                break;
            case "price":
                $info = $this->core->db->field("SELECT offer_prt FROM " . DB_OFFER . " WHERE offer_id = '" . $id . "' LIMIT 1");
                $info = $info ? unserialize($info) : array();
                break;
            case "prices":
                $info = $this->core->db->data("SELECT * FROM " . DB_PRICE . " WHERE offer_id = '" . $id . "' ORDER BY price_sort ASC, price_id ASC");
                if ($info) {
                    foreach ($info as &$ii) {
                        if ($ii["price_wmid"]) {
                            $ii["wmid"] = array();
                            $wmls = explode(",", $ii["price_wmid"]);
                            foreach ($wmls as $w) {
                                if ($w = trim($w)) {
                                    $ii["wmid"][] = $w;
                                }
                            }
                        }
                    }
                }
                break;
            case "vars":
                $info = array();
                $ii = $this->core->db->data("SELECT * FROM " . DB_VARS . " WHERE offer_id = '" . $id . "' ORDER BY var_type, var_name ASC");
                foreach ($ii as $il) {
                    $info[$il["var_id"]] = $il;
                }
                unset($il);
                unset($ii);
                break;
            case "vprice":
                $info = array();
                $ii = $this->core->db->icol("SELECT var_id, var_price FROM " . DB_VARS . " WHERE offer_id = '" . $id . "'");
                foreach ($ii as $ix => $iz) {
                    $info[$ix] = $iz ? unserialize($iz) : array();
                }
                unset($il);
                unset($ix);
                unset($iz);
                break;
            case "vpars":
                $info = array();
                $ii = $this->core->db->icol("SELECT var_id, var_param FROM " . DB_VARS . " WHERE offer_id = '" . $id . "'");
                foreach ($ii as $ix => $iz) {
                    $info[$ix] = $iz ? unserialize($iz) : array();
                }
                unset($il);
                unset($ix);
                unset($iz);
                break;
            case "vpar":
                $info = array();
                $ii = $this->core->db->icol("SELECT var_id, var_param FROM " . DB_VARS . " WHERE offer_id = '" . $id . "'");
                foreach ($ii as $ix => $iz) {
                    if ($iz) {
                        $iz = unserialize($iz);
                        foreach ($iz as $iw => $iq) {
                            $info[$iw][$ix] = $iq;
                        }
                    }
                }
                unset($il);
                unset($ix);
                unset($iz);
                unset($iw);
                unset($iq);
                break;
            case "site":
                $info = $this->core->db->row("SELECT * FROM " . DB_SITE . " WHERE site_id = '" . $id . "' LIMIT 1");
                break;
            case "sites":
                $info = $this->core->db->data("SELECT * FROM " . DB_SITE . " WHERE offer_id = '" . $id . "' ORDER BY site_url ASC");
                break;
            case "siteurls":
                $info = $this->core->db->icol("SELECT site_id, site_url FROM " . DB_SITE);
                if ($info) {
                    asort($info);
                }
                break;
            case "lands":
                $info = $id ? $this->core->db->data("SELECT * FROM " . DB_SITE . " WHERE offer_id = '" . $id . "' AND site_type != 1 ORDER BY site_url ASC") : $this->core->db->icol("SELECT site_id, site_url FROM " . DB_SITE . " WHERE site_type != 1 ORDER BY site_url ASC");
                break;
            case "space":
                $info = $this->core->db->data("SELECT * FROM " . DB_SITE . " WHERE offer_id = '" . $id . "' AND site_type = 1 ORDER BY site_url ASC");
                break;
            case "flow":
                $info = $this->core->db->row("SELECT * FROM " . DB_FLOW . " WHERE flow_id = '" . $id . "' LIMIT 1");
                break;
            case "flows":
                $info = $this->core->db->icol("SELECT flow_id, flow_name FROM " . DB_FLOW . " WHERE user_id = '" . $id . "'");
                break;
            case "domain":
                $info = $this->core->db->icol("SELECT dom_id, dom_url FROM " . DB_DOMAIN . " WHERE user_id = '" . $id . "'");
                if ($info) {
                    asort($info);
                }
                break;
            case "split":
                $o = $this->core->db->data("SELECT * FROM " . DB_TEST . " WHERE split_id = '" . $id . "'");
                $info = array();
                foreach ($o as &$t) {
                    if ($t["test_geo"]) {
                        $geo = preg_split("/[\\,]+/", $t["test_geo"], -1, PREG_SPLIT_NO_EMPTY);
                        $geo = $geo ? $geo : false;
                    } else {
                        $geo = false;
                    }
                    if ($t["test_nogeo"]) {
                        $nogeo = preg_split("/[\\,]+/", $t["test_nogeo"], -1, PREG_SPLIT_NO_EMPTY);
                        $nogeo = $nogeo ? $nogeo : false;
                    } else {
                        $nogeo = false;
                    }
                    $info[(int) $t["test_id"]] = array("flow" => (int) $t["flow_id"], "url" => $t["test_url"] ? $t["test_url"] : false, "pos" => (int) $t["test_pos"], "geo" => $geo, "nogeo" => $nogeo, "mobile" => (int) $t["test_mobile"]);
                }
                unset($t);
                break;
            default:
                return false;
        }
        $this->core->cache($cn, $info);
        $this->data[$type][$id] = $info;
        return $field ? $info[$field] : $info;
    }
    public function clear($type, $id = 0)
    {
        $id = (int) $id;
        unset($this->data[$type][$id]);
        $this->core->uncache("cpa." . $type . $id);
    }
    public function team($a = false, $u = 0)
    {
        $u = (int) $u;
        if (!$this->ta[$u]) {
            $core = $this->core;
            if ($u) {
                $us = $core->user->get($u);
                $ca = $us["user_compad"];
                $ti = $us["user_team"];
                $tl = $us["user_teamlead"];
                $rt = $us["user_level"] || $us["user_work"] == 2;
            } else {
                $ca = (int) $core->user->compad;
                $ti = (int) $core->user->team;
                $tl = (int) $core->user->teamlead;
                $rt = $core->user->level || $core->user->work == 2;
            }
            $tm = $ti ? $this->get("team", $ti) : array();
            if ($tm["team_offer"]) {
                $off = array();
                $ol = explode(",", $tm["team_offer"]);
                foreach ($ol as $o) {
                    if ($o = (int) trim($o)) {
                        $off[] = $o;
                    }
                }
                if (!$off) {
                    $off = false;
                }
            } else {
                $off = false;
            }
            $this->ta[$u] = array("root" => $rt ? true : false, "admin" => $ca || $rt ? true : false, "team" => $ti && $tl ? true : false, "call" => $ti ? (int) $tm["team_call"] : 1, "pack" => $ti ? (int) $tm["team_pack"] : 1, "send" => $ti ? (int) $tm["team_send"] : 1, "delivery" => $ti ? (int) $tm["team_delivery"] : 1, "mod" => $ti ? $tm["team_mod"] ? true : false : true, "offer" => $ti ? $off : false);
        }
        return $a ? $this->ta[$u][$a] : $this->ta[$u];
    }
    public function price($offer, $user = 0, $type = false)
    {
        if (!$user) {
            $user = $this->core->user->id;
        }
        if (is_array($user)) {
            list($user, $comp) = $user;
        } else {
            $comp = false;
        }
        $cachename = $comp ? (string) $user . ":" . $comp : $user;
        if (!$this->prd[$offer][$cachename]) {
            $o = $this->get("offer", $offer);
            $p = unserialize($o["offer_prt"]);
            $u = $this->core->user->get($user);
            $c = $this->core->user->get($comp);
            $wmp = $u["user_vip"] && $o["offer_wm_vip"] ? $o["offer_wm_vip"] : $o["offer_wm"];
            $wmu = $u["user_vip"] && $o["offer_wmu_vip"] ? $o["offer_wmu_vip"] : $o["offer_wmu"];
            if ($comp) {
                $pay = $c["user_vip"] && $o["offer_pay_vip"] ? $o["offer_pay_vip"] : $o["offer_pay"];
                $pyu = $c["user_vip"] && $o["offer_pyu_vip"] ? $o["offer_pyu_vip"] : $o["offer_pyu"];
            } else {
                $pay = $u["user_vip"] && $o["offer_pay_vip"] ? $o["offer_pay_vip"] : $o["offer_pay"];
                $pyu = $u["user_vip"] && $o["offer_pyu_vip"] ? $o["offer_pyu_vip"] : $o["offer_pyu"];
            }
            if ($u["user_ext"]) {
                if ($o["offer_wm_ext"]) {
                    $wmp = $o["offer_wm_ext"];
                    $wmu = $o["offer_wmu_ext"];
                }
                if ($o["offer_pay_ext"]) {
                    $pay = $o["offer_pay_ext"];
                    $pyu = $o["offer_pyu_ext"];
                }
            }
            if ($ref = $u["user_ref"]) {
                $rv = $this->core->user->get($ref, "user_vip");
                $rep = $rv && $o["offer_ref_vip"] ? $o["offer_ref_vip"] : $o["offer_ref"];
            } else {
                $rep = $sup = $ref = $sub = 0;
            }
            if (isset($p[$user])) {
                if ($p[$user][0]) {
                    $wmp = $p[$user][0];
                    $wmu = $p[$user][3];
                }
                if ($p[$user][1]) {
                    $pay = $p[$user][1];
                    $pyu = $p[$user][4];
                }
                if ($p[$user][2] && $ref) {
                    $rep = $p[$user][2];
                }
            }
            if (isset($p[$comp])) {
                if ($p[$comp][0]) {
                    $wmp = $p[$comp][0];
                    $wmu = $p[$comp][3];
                }
                if ($p[$comp][1]) {
                    $pay = $p[$comp][1];
                    $pyu = $p[$comp][4];
                }
                if ($p[$comp][2] && $ref) {
                    $rep = $p[$comp][2];
                }
            }
            if ($ref && isset($p[$ref])) {
                if ($p[$ref][0]) {
                    $wmp = $p[$ref][0];
                    $wmu = $p[$ref][3];
                }
                if ($p[$ref][1]) {
                    $pay = $p[$ref][1];
                    $pyu = $p[$ref][4];
                }
                if ($p[$ref][2]) {
                    $rep = $p[$ref][2];
                }
            }
            $this->prd[$offer][$cachename] = array("wmp" => $wmp, "wmu" => $wmu, "pay" => $pay, "pyu" => $pyu, "ref" => $ref, "rep" => $rep, "vip" => $u["user_vip"], "ext" => $u["user_ext"]);
        }
        return $type ? $this->prd[$offer][$cachename][$type] : $this->prd[$offer][$cachename];
    }
    public function stages($comp, $status = false, $all = false)
    {
        $sg = $status !== false ? $this->statusgroup[(int) $status] : false;
        $stage = array();
        $sl = $this->get("stage", $comp);
        foreach ($sl as $s) {
            if (!$all && $s["stage_auto"]) {
                continue;
            }
            if ($sg && $sg != $s["stage_group"]) {
                continue;
            }
            $stage[$s["stage_id"]] = $s["stage_name"];
        }
        return $stage;
    }
    public function stagebyslug($comp, $slug)
    {
        if (!$slug) {
            return false;
        }
        $sl = $this->get("stage", $comp);
        foreach ($sl as $s) {
            if ($s["stage_slug"] == $slug) {
                return $s["stage_id"];
            }
        }
        return false;
    }
    public function stagescript($comp)
    {
        if (!isset($this->sts[$comp])) {
            $script = array();
            $stage = $this->get("stage", $comp);
            foreach ($stage as $s) {
                if (!($s["stage_from"] || $s["stage_to"] || $s["stage_why"])) {
                    continue;
                }
                $choise = array("stage" => $s["stage_id"], "group" => $s["stage_group"], "why" => array());
                if ($s["stage_from"]) {
                    $choise["why"][] = array("f", "order_status", "=", $s["stage_from"]);
                }
                if ($s["stage_to"]) {
                    $choise["why"][] = array("t", "order_status", "=", $s["stage_to"]);
                }
                if ($s["stage_why"]) {
                    $ww = explode("\n", $s["stage_why"]);
                    foreach ($ww as $w) {
                        if ($w = trim($w)) {
                            $newchoise = $choise;
                            if (preg_match_all("/(f|t|o|p)\\:([a-z0-9\\_]+)\\:([0-9]+)/i", $w, $ms)) {
                                foreach ($ms[1] as $i => $t) {
                                    $newchoise["why"][] = array($t, $ms[2][$i], "=", $ms[3][$i]);
                                }
                            }
                            if (preg_match_all("/(f|t|o|p)\\:([a-z0-9\\_]+)\\:\\(([^)]+)\\)/i", $w, $ms)) {
                                foreach ($ms[1] as $i => $t) {
                                    $res = $ms[3][$i];
                                    $rid = $res[0];
                                    if (strpos("=!-<?>+", $rid) !== false) {
                                        $rt = $rid;
                                        $res = substr($res, 1);
                                    } else {
                                        $rt = "=";
                                    }
                                    $newchoise["why"][] = array($t, $ms[2][$i], $rt, $res);
                                }
                            }
                            $script[] = $newchoise;
                        }
                    }
                } else {
                    $script[] = $choise;
                }
            }
            $this->sts[$comp] = $script;
        }
        return $this->sts[$comp];
    }
    private function dlcs()
    {
        if (!$this->dlcs) {
            $this->dlcs = array(1 => "generic", 2 => "rupost", 3 => "webex", 4 => "novaposhta");
            if (function_exists("hacks_delivery")) {
                hacks_delivery($this->core);
            }
            $this->dlcs = $this->core->filter("delivery_types", $this->dlcs);
        }
        return $this->dlcs;
    }
    public function dlc($id)
    {
        if (!$this->dlc[$id]) {
            $dlcs = $this->dlcs();
            $dlc = $dlcs[$id];
            if (!$dlc) {
                return false;
            }
            $dlcn = "delivery_" . $dlc;
            if (defined("HACK") && file_exists(PATH . HACK . "delivery/" . $dlc . ".php")) {
                require_once PATH . HACK . "delivery/" . $dlc . ".php";
            } else {
                require_once PATH . "core/delivery/" . $dlc . ".php";
            }
            if (class_exists($dlcn)) {
                $this->dlc[$id] = new $dlcn($this->core);
            } else {
                return false;
            }
        }
        return $this->dlc[$id];
    }
    public function dltypes($comp, $id = 0)
    {
        if (!isset($this->dlt[$comp])) {
            $this->dlt[$comp] = array();
            $cc = $this->get("cc", $comp);
            $dlc = $this->dlcs();
            foreach ($dlc as $i => $d) {
                if ($cc[$d]) {
                    $this->dlt[$comp][$i] = array("id" => $i, "code" => $d, "price" => $cc[$d . "_price"]);
                }
            }
            if (!$this->dlt[$comp]) {
                $this->dlt[$comp][1] = array("id" => 1, "code" => "generic", "price" => $this->code->lang["deliverbase"][0], "fail" => true);
            }
        }
        return $id ? $this->dlt[$comp][$id] : $this->dlt[$comp];
    }
    public function dlcron()
    {
        $comps = $this->get("compa");
        foreach ($comps as $i => $n) {
            $dlt = $this->dltypes($i);
            $cc = $this->get("cc", $i);
            foreach ($dlt as $d => $t) {
                $dlc = $this->dlc($d);
                $dlc->cron($cc);
            }
        }
    }
    public function dltrack($id)
    {
        $core = $this->core;
        $o = $core->db->row("SELECT comp_id, order_delivery, track_code, order_country, offer_id, order_id, order_status, has_track FROM " . DB_ORDER . " WHERE order_id = '" . $id . "' LIMIT 1");
        if (!$o) {
            return false;
        }
        if (!$o["track_code"]) {
            return false;
        }
        if ($o["order_delivery"] <= 1) {
            return false;
        }
        $c = $this->get("cc", $o["comp_id"]);
        if (!$c) {
            return false;
        }
        $dlc = $this->dlc($o["order_delivery"]);
        if (!$dlc) {
            return false;
        }
        $tr = $dlc->track($c, $o["track_code"]);
        if (!$tr) {
            return false;
        }
        $tc = $core->db->col("SELECT track_md5 FROM " . DB_TRACK . " WHERE order_id = '" . $id . "'");
        $changes = array("trcheck" => $tr["next"]);
        foreach ($tr["stage"] as $s) {
            if (!in_array($s["md5"], $tc)) {
                $core->db->add(DB_TRACK, array("offer_id" => $o["offer_id"], "order_id" => $o["order_id"], "track_status" => $s["status"], "track_md5" => $s["md5"], "track_time" => $s["time"], "track_country" => $s["country"] ? $s["country"] : $o["order_country"], "track_zip" => $s["zip"], "track_city" => $s["city"], "track_comment" => $s["comment"]));
                $changes["trdate"] = $s["time"];
                $changes["trst"] = $s["status"];
                $st = (int) $s["status"];
                switch ($st) {
                    case 2:
                        if ($o["order_status"] < 8) {
                            $changes["status"] = 8;
                        }
                        break;
                    case 4:
                        if ($o["order_status"] < 9) {
                            $changes["status"] = 9;
                        }
                        break;
                    case 5:
                        if ($o["order_status"] < 10) {
                            $changes["status"] = 10;
                        }
                        break;
                    case 6:
                        if ($o["order_status"] < 11) {
                            $changes["status"] = 11;
                        }
                        break;
                }
            }
        }
        if (!$o["has_track"]) {
            $core->db->edit(DB_ORDER, array("has_track" => 1), array("order_id" => $id));
        }
        require_once PATH_MODS . "order-edit.php";
        return order_edit($core, $id, $changes);
    }
    public function dloptions($o)
    {
        if (!$o["order_id"]) {
            return false;
        }
        if ($o["order_delivery"] <= 1) {
            return false;
        }
        $c = $this->get("cc", $o["comp_id"]);
        if (!$c) {
            return false;
        }
        $dlc = $this->dlc($o["order_delivery"]);
        if (!$dlc) {
            return false;
        }
        return $dlc->options($c, $o);
    }
    public function dlaction($o, $action)
    {
        $core = $this->core;
        if (!$o) {
            return false;
        }
        if (!$o["track_code"]) {
            return false;
        }
        if ($o["order_delivery"] <= 1) {
            return false;
        }
        $c = $this->get("cc", $o["comp_id"]);
        if (!$c) {
            return false;
        }
        $dlc = $this->dlc($o["order_delivery"]);
        if (!$dlc) {
            return false;
        }
        $result = $dlc->action($action, $c, $o);
        if (is_array($result)) {
            require_once PATH_MODS . "order-edit.php";
            return order_edit($core, $id, $result);
        }
        return $result ? true : false;
    }
    public function dlform($comp)
    {
        $c = $this->get("cc", $comp);
        $dlc = $this->dlcs();
        $core = $this->core;
        $fields = array();
        foreach ($dlc as $i => $d) {
            $fields[] = array("type" => "head", "value" => $core->lang["delivery"][$i]);
            if ($core->lang["delivera"][$i]) {
                $fields[] = array("type" => "line", "value" => $core->lang["delivera"][$i]);
            }
            $fields[] = array("type" => "checkbox", "name" => $d, "head" => $core->lang["delivery_active"], "checked" => $c[$d]);
            $fields[] = array("type" => "number", "min" => 0, "step" => 0.01, "name" => $d . "_price", "head" => $core->lang["price"], "descr" => $core->lang["delivery_price"], "value" => $c[$d . "_price"]);
            if ($mf = $this->dlc($i)->form($c)) {
                $fields = array_merge($fields, $mf);
            }
        }
        return $fields;
    }
    public function dlsave($comp)
    {
        $core = $this->core;
        $dlc = $this->dlcs();
        $config = array();
        foreach ($dlc as $i => $d) {
            $config[$d] = $core->post[$d] ? 1 : 0;
            $config[$d . "_price"] = $core->text->float($core->post[$d . "_price"]);
            if ($mf = $this->dlc($i)->save()) {
                $config += $mf;
            }
        }
        return $config;
    }
}

?>