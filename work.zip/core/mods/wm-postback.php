<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function wm_postback($core)
{
    $message = isset($core->get["message"]) ? $core->text->link($core->get["message"]) : false;
    $action = isset($core->get["action"]) ? $core->text->link($core->get["action"]) : false;
    $id = isset($core->get["id"]) ? (int) $core->get["id"] : false;
    if ($core->config("hide", "flows")) {
        $core->go($core->u("", array("message" => "access")));
    }
    $canuser = $core->user->level || $core->user->work == -2;
    $wm = isset($core->post["wm"]) ? (int) $core->post["wm"] : (int) $core->get["wm"];
    if ($canuser && $wm) {
        $user = $wm;
        $udt = $core->user->get($wm);
        $uinfo = sprintf($core->lang["stat_user"], $udt["user_name"], $udt["user_mail"]);
        $core->site->info("text", $uinfo);
    } else {
        $user = $core->user->id;
        $wm = NULL;
    }
    switch ($message) {
        case "ok":
            $core->site->info("info", "done_basic");
            break;
        case "error":
            $core->site->info("error", "error_basic");
            break;
        case "access":
            $core->site->info("error", "access_denied");
            break;
    }
    switch ($action) {
        case "save":
            $pbu = $core->text->line($core->post["url"]);
            $core->user->meta($user, array("pbu" => $pbu));
            $core->go($core->u("postback", array("message" => "ok", "wm" => $wm)));
    }
    $where = array("user_id = '" . $user . "'");
    $param = array();
    if ($canuser && $wm) {
        $param["wm"] = $wm;
    }
    if ($o = (int) $core->get["o"]) {
        $param["o"] = $o;
        $where[] = "order_id = '" . $o . "'";
    } else {
        $o = false;
    }
    if ($f = (int) $core->get["f"]) {
        $param["f"] = $f;
        $where[] = "flow_id = '" . $f . "'";
    } else {
        $f = false;
    }
    $where = implode(" AND ", $where);
    $page = 0 < $core->get["page"] ? (int) $core->get["page"] : 1;
    $sh = 30;
    $st = $sh * ($page - 1);
    $lc = $core->db->field("SELECT COUNT(*) FROM " . DB_LOG_PB . " WHERE " . $where);
    $log = $lc ? $core->db->data("SELECT * FROM " . DB_LOG_PB . " WHERE " . $where . " ORDER BY log_id DESC LIMIT " . $st . ", " . $sh) : array();
    $ud = $core->user->get($user);
    $core->site->bc($core->lang["menu_sub_postback"], $core->u("postback", array("wm" => $wm)));
    $core->site->pt($core->lang["flow_pbu_l"]);
    $core->site->header();
    $core->tpl->load("body", "postback", defined("HACK_TPL_POSTBACK") ? HACK : false);
    $core->tpl->vars("body", array("pages" => pages($core->u("postback", $param), $lc, $sh, $page, sprintf($core->lang["shown"], $st + 1, min($st + $sh, $lc), $lc)), "o" => $o, "wm" => $wm, "find" => $core->lang["find"], "u_save" => $core->u("postback", array("action" => "save", "wm" => $wm)), "lpbu" => $core->lang["flow_pbu_g"], "lpbud" => $core->lang["flow_pbu_d"], "pbu" => $ud["meta"]["pbu"], "pbs" => 1 < $page || $o || $f ? false : true, "save" => $core->lang["save"], "flow" => $core->lang["flow"], "time" => $core->lang["time"], "action" => $core->lang["action"], "order" => $core->lang["order"], "status" => $core->lang["status"], "result" => $core->lang["result"], "noitem" => $core->lang["noitems"]));
    $flows = $core->cpa->get("flows", $user);
    foreach ($flows as $of => $n) {
        $core->tpl->block("body", "flow", array("name" => $n, "value" => $of, "select" => $of == $f ? "selected=\"selected\"" : ""));
    }
    if ($log) {
        foreach ($log as $l) {
            $core->tpl->block("body", "log", array("id" => $l["log_id"], "time" => $core->text->smartdate($l["log_time"]), "flow" => $flows[$l["flow_id"]], "u_flow" => $core->u("postback", parset($param, "f", $l["flow_id"])), "order" => $l["order_id"], "u_order" => $core->u("postback", parset($param, "o", $l["order_id"])), "url" => wordwrap($l["log_url"], 70, "<wbr />", true), "status" => $l["log_status"], "stcl" => 199 < $l["log_status"] && $l["log_status"] < 300 ? "success" : "danger", "stic" => 199 < $l["log_status"] && $l["log_status"] < 300 ? "check-circle" : "exclamation-circle", "short" => $core->text->excerpt($l["log_result"], 50), "result" => htmlspecialchars($l["log_result"])));
        }
    } else {
        $core->tpl->block("body", "noitem");
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}

?>