<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function cronupdate_pdb($core)
{
    if (defined("PDB_RU")) {
        updb_ru($core);
    }
    if ($core->cando("cronupdate_pdb")) {
        $core->process("cronupdate_pdb");
    }
    $core->db->query("ALTER TABLE " . DB_PDB . " ORDER BY `phone` ASC");
    $core->db->query("OPTIMIZE TABLE " . DB_PDB);
    return time() + 864000 + rand(0, 86400);
}
function updb_ru($core)
{
    $pagelists = file_get_contents("http://www.rossvyaz.ru/opendata/");
    if (preg_match_all("#href=\"(([\\w\\-\\/]+)Kody([\\w\\-\\_]+).csv)\"#i", $pagelists, $pgl)) {
        $pages = array_unique($pgl[1]);
        foreach ($pages as $p) {
            if (substr($p, 0, 2) == "//") {
                $p = "http:" . $p;
            }
            if ($p[0] == "/") {
                $p = "http://www.rossvyaz.ru" . $p;
            }
            $page = file($p);
            $oldcode = $st = $en = $scode = $ecode = 0;
            unset($page[0]);
            foreach ($page as $pg) {
                $pg = explode(";", $pg);
                $pg = array_map("trim", $pg);
                $st = $pg[0] . $pg[1];
                $scode = substr($st, 0, 6);
                if ($oldcode < $scode) {
                    $en = $pg[0] . $pg[2];
                    $ecode = substr($en, 0, 6);
                    $oper = iconv("windows-1251", "utf-8", $pg[4]);
                    $place = explode("|", iconv("windows-1251", "utf-8", $pg[5]));
                    $pc = count($place);
                    if (1 < $pc) {
                        if ($pc == 2) {
                            $region = trim($place[1]);
                            $city = trim($place[0]);
                        } else {
                            $region = trim($place[2]);
                            $city = sprintf("%s, %s", trim($place[1]), trim($place[0]));
                        }
                    } else {
                        $city = "";
                        $region = trim($place[0]);
                    }
                    for ($i = $scode; $i <= $ecode; $i++) {
                        $oldcode = $i;
                        $core->db->replace(DB_PDB, array("phone" => "7" . $i, "country" => "ru", "operator" => $oper, "region" => $region, "city" => $city));
                    }
                }
            }
        }
    } else {
        return false;
    }
}

?>