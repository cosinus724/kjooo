<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function cron1day($core)
{
    set_time_limit(300);
    $today = date("Ymd", strtotime("-1 day"));
    $tt = strtotime(date2form($today) . " 23:59:59");
    $spaces = $core->db->icol("SELECT flow_id, COUNT(*) FROM " . DB_CLICK . " WHERE click_date = '" . $today . "' AND click_space = 1 GROUP BY flow_id");
    $suni = $core->db->icol("SELECT flow_id, COUNT(*) FROM " . DB_CLICK . " WHERE click_date = '" . $today . "' AND click_space = 1 AND click_unique = 1 GROUP BY flow_id");
    $sgood = $core->db->icol("SELECT flow_id, COUNT(*) FROM " . DB_CLICK . " WHERE click_date = '" . $today . "' AND click_space = 1 AND click_good = 1 GROUP BY flow_id");
    $stim = $core->db->icol("SELECT flow_id, SUM(click_good) FROM " . DB_CLICK . " WHERE click_date = '" . $today . "' AND click_space = 1 GROUP BY flow_id");
    $clicks = $core->db->icol("SELECT flow_id, COUNT(*) FROM " . DB_CLICK . " WHERE click_date = '" . $today . "' AND click_space = 0 GROUP BY flow_id");
    $unique = $core->db->icol("SELECT flow_id, COUNT(*) FROM " . DB_CLICK . " WHERE click_date = '" . $today . "' AND click_space = 0 AND click_unique = 1 GROUP BY flow_id");
    $good = $core->db->icol("SELECT flow_id, COUNT(*) FROM " . DB_CLICK . " WHERE click_date = '" . $today . "' AND click_space = 0 AND click_good = 1 GROUP BY flow_id");
    $tim = $core->db->icol("SELECT flow_id, SUM(click_good) FROM " . DB_CLICK . " WHERE click_date = '" . $today . "' AND click_space = 0 GROUP BY flow_id");
    $fids = array_unique(array_merge(array_keys($spaces), array_keys($clicks)));
    foreach ($fids as $f) {
        $ff = $core->cpa->get("flow", $f);
        $core->db->add(DB_STATS, array("flow_id" => $f, "user_id" => $ff["user_id"], "offer_id" => $ff["offer_id"], "stat_date" => $today, "stat_space" => $spaces[$f], "stat_suni" => $suni[$f], "stat_sgood" => $sgood[$f], "stat_stime" => $stim[$f], "stat_click" => $clicks[$f], "stat_unique" => $unique[$f], "stat_good" => $good[$f], "stat_time" => $tim[$f]));
    }
    unset($clicks);
    unset($unique);
    unset($good);
    unset($tim);
    unset($spaces);
    unset($suni);
    unset($sgood);
    unset($stim);
    unset($fids);
    $ufc = $core->db->icol("SELECT user_id, COUNT(*) FROM " . DB_FLOW . " GROUP BY user_id");
    $ftp = $core->db->data("SELECT user_id, COUNT(*) AS `c`, SUM(flow_convert) AS `cr`, SUM(flow_epc) AS `epc` FROM " . DB_FLOW . " WHERE flow_convert > 0 GROUP BY user_id");
    foreach ($ftp as $f) {
        $uid = $f["user_id"];
        $dte = array("user_flw" => $ufc[$uid], "user_flwa" => $f["c"], "user_cr" => $f["cr"] / $f["c"] * 100, "user_epc" => $f["epc"] / $f["c"]);
        $core->db->edit(DB_USER, $dte, "user_id = '" . $uid . "'");
    }
    $tm = time();
    $clicklife = date("Ymd", $tm - 86400 * $core->config("clicks", "life"));
    $core->db->del(DB_CLICK, "click_date < '" . $clicklife . "'");
    $sesslife = date("ymd", $tm - 2170000);
    $core->db->del(DB_SESS, "sess_date < '" . $sesslife . "'");
    $zsesslife = date("ymd", $tm - 120000);
    $core->db->del(DB_SESS, "sess_date < '" . $zsesslife . "' AND sess_ua = 'Zabbix'");
    $leadlife = $tm - 86400 * $core->config("lead", "life");
    $orders = $core->db->col("SELECT order_id FROM " . DB_ORDER . " WHERE order_time < '" . $leadlife . "' AND order_status < 5");
    if ($orders) {
        require_once PATH_MODS . "order-edit.php";
        foreach ($orders as $o) {
            order_edit($core, $o, array("status" => 5, "reason" => 11));
        }
    }
    $loglife = $tm - 666777;
    $core->db->del(DB_LOG_INT, "log_time < '" . $loglife . "'");
    $core->db->del(DB_LOG_PB, "log_time < '" . $loglife . "'");
    cleancache(DIR_WORK, 186400);
    cleancache(DIR_SESSION, 1592000);
    cleancache(DIR_TPLS, 86400);
    $core->db->query("OPTIMIZE TABLE " . DB_CLICK);
    $core->db->query("OPTIMIZE TABLE " . DB_SESS);
    $core->db->query("OPTIMIZE TABLE " . DB_LOG_INT);
    $core->db->query("OPTIMIZE TABLE " . DB_LOG_PB);
}

?>