<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function base_menu($core, $menu)
{
    if (!$core->config("hide", "news")) {
        array_push($menu, "news");
    }
    return $menu;
}
function base_module($core)
{
    $module = $core->get["m"] ? $core->get["m"] : NULL;
    $action = $core->get["action"] ? $core->get["action"] : NULL;
    $id = $core->post["id"] ? (int) $core->post["id"] : ($core->get["id"] ? (int) $core->get["id"] : 0);
    $page = 0 < $core->get["page"] ? (int) $core->get["page"] : 1;
    $message = $core->get["message"] ? $core->get["message"] : NULL;
    switch ($module) {
        case "talk":
            $n = $id ? $core->db->row("SELECT * FROM " . DB_NEWS . " WHERE news_id = '" . $id . "' LIMIT 1") : false;
            if ($n) {
                $ok = true;
                if ($n["news_vip"] && !($core->user->vip || $core->user->level)) {
                    $ok = false;
                }
                if ($n["news_group"] == 1 && !($core->user->work == 0 || $core->user->work == 2 || $core->user->level)) {
                    $ok = false;
                }
                if ($n["news_group"] == 2 && !($core->user->work == 1 || $core->user->work == 2 || $core->user->level)) {
                    $ok = false;
                }
            } else {
                $ok = false;
            }
            if ($ok) {
                $gid = array("", "users", "building");
                $offer = $core->cpa->get("offersa");
                $core->site->bc($core->lang["news"], $core->url("m", "news"));
                $core->site->header();
                $core->tpl->load("body", "talk", defined("HACK_TPL_TALK") ? HACK : false);
                $core->tpl->vars("body", array("id" => $n["news_id"], "url" => $core->url("i", "talk", $n["news_id"]), "vip" => $n["news_vip"], "title" => $n["news_title"], "text" => $core->text->out($n["news_text"]), "group" => $core->lang["news_groups"][$n["news_group"]], "gid" => $gid[$n["news_group"]], "group" => $core->lang["news_groups"][$n["news_group"]], "cid" => $n["news_cat"], "cat" => $core->lang["newscats"][$n["news_cat"]], "u_cat" => $core->url("m", "news") . "?c=" . $n["news_cat"], "oid" => $n["offer_id"], "offer" => $offer[$n["offer_id"]], "u_offer" => $core->url("m", "news") . "?o=" . $n["offer_id"], "type" => $n["news_group"], "date" => smartdate($n["news_time"]), "disqus" => defined("DISQUS") ? DISQUS : false, "base" => rtrim($core->config("url", "base"), "/")));
                $core->tpl->output("body");
                $core->site->footer();
                $core->stop();
            } else {
                $core->go($core->url("m", "news"));
            }
        case "news":
            if ($core->config("hide", "news")) {
                $core->go($core->url("mm", "", "access"));
            }
            switch ($message) {
                case "ok":
                    $core->site->info("info", "done");
                    break;
                case "e":
                    $core->site->info("error", "error");
                    break;
            }
            $where = $params = array();
            if (isset($core->get["s"]) && $core->get["s"]) {
                require_once PATH_CORE . "search.php";
                $search = new SearchWords($core->get["s"]);
                if ($s = $search->get()) {
                    $where[] = "(" . $search->field(array("news_title", "news_text")) . ")";
                } else {
                    $search = $s = false;
                }
            } else {
                $search = $s = false;
            }
            switch ($core->user->work) {
                case 1:
                    $where[] = "news_group IN ( 0,2 )";
                    break;
                case 2:
                    $where[] = "news_group IN ( 0,1,2 )";
                    break;
                default:
                    $where[] = "news_group IN ( 0,1 )";
            }
            if (!($core->user->vip || $core->user->level)) {
                $where[] = "news_vip = 0";
            }
            if ($cat = (int) $core->get["c"]) {
                $where[] = "news_cat = '" . $cat . "'";
                $params["c"] = $cat;
            } else {
                $cat = false;
            }
            if ($of = (int) $core->get["o"]) {
                $where[] = "offer_id = '" . $of . "'";
                $params["o"] = $of;
            } else {
                $of = false;
            }
            $sh = 10;
            $st = $sh * ($page - 1);
            $where = implode(" AND ", $where);
            $nc = $core->db->field("SELECT COUNT(*) FROM " . DB_NEWS . " WHERE " . $where);
            $news = $core->db->data("SELECT * FROM " . DB_NEWS . " WHERE " . $where . " ORDER BY news_id DESC LIMIT " . $st . ", " . $sh);
            $core->site->bc($core->lang["news"], $core->url("m", "news"));
            $core->site->set("select2");
            $core->site->header();
            $core->tpl->load("body", "news", defined("HACK_TPL_NEWS") ? HACK : false);
            $core->tpl->vars("body", array("u_add" => $core->url("m", "news-add"), "add" => $core->lang["news_add_h"], "pages" => $nc ? pages($core->url("m", "news?") . http_build_query($params), $nc, $sh, $page, sprintf($core->lang["shown"], $st + 1, min($st + $sh, $nc), $nc)) : false, "shown" => sprintf($core->lang["shown"], $st + 1, min($st + $sh, $nc), $nc), "u_search" => $core->url("m", "news"), "s" => $s, "search" => $core->lang["search"], "find" => $core->lang["find"], "offer" => $core->lang["offer"], "cat" => $core->lang["news_cat"], "edit" => $core->lang["edit"], "del" => $core->lang["del"], "confirm" => $core->lang["confirm"], "comments" => $core->lang["comments"], "noitems" => $core->lang["nofound"], "base" => rtrim($core->config("url", "base"), "/"), "disqus" => defined("DISQUS") ? DISQUS : false));
            if ($core->user->level) {
                $core->tpl->block("body", "add");
            }
            $gid = array("", "users", "building");
            $offer = $core->cpa->get("offersa");
            $offers = $core->cpa->get("offers");
            foreach ($core->lang["newscats"] as $ci => $cn) {
                $core->tpl->block("body", "cat", array("id" => $ci, "name" => $cn, "select" => $ci == $cat));
            }
            foreach ($offers as $ci => $cn) {
                $core->tpl->block("body", "offer", array("id" => $ci, "name" => $cn, "select" => $ci == $of));
            }
            if ($news) {
                foreach ($news as $n) {
                    $core->tpl->block("body", "news", array("id" => $n["news_id"], "url" => $core->url("i", "talk", $n["news_id"]), "title" => $n["news_title"], "vip" => $n["news_vip"] ? true : false, "text" => $core->text->out($n["news_text"]), "gid" => $gid[$n["news_group"]], "group" => $core->lang["news_groups"][$n["news_group"]], "cid" => $n["news_cat"], "cat" => $core->lang["newscats"][$n["news_cat"]], "u_cat" => $core->url("m", "news?") . parset($params, "c", $n["news_cat"]), "oid" => $n["offer_id"], "offer" => $offer[$n["offer_id"]], "u_offer" => $core->url("m", "news?") . parset($params, "o", $n["offer_id"]), "date" => smartdate($n["news_time"]), "edit" => $core->url("i", "news", $n["news_id"]), "del" => $core->url("ia", "news", $n["news_id"], "del")));
                    if ($core->user->level) {
                        $core->tpl->block("body", "news.edit");
                    }
                }
            } else {
                $core->tpl->block("body", "noitems");
            }
            $core->tpl->output("body");
            $core->site->footer();
            $core->stop();
        case "profile":
            switch ($message) {
                case "ok":
                    $core->site->info("info", "done_profile");
                    break;
                case "error":
                    $core->site->info("error", "error_profile");
                    break;
                case "info":
                    $core->site->info("error", "info_profile");
                    break;
            }
            switch ($action) {
                case "save":
                    $data = array("name" => $core->text->line($core->post["name"]), "wmr" => $core->text->line($core->post["wmr"]), "news" => $core->post["news"] ? 1 : 0);
                    $meta = array("skype" => $core->text->line($core->post["skype"]), "telegram" => $core->text->line($core->post["telegram"]), "vk" => $core->text->line($core->post["vk"]), "whatsapp" => $core->text->line($core->post["whatsapp"]), "lang" => $core->text->link($core->post["lang"]));
                    if ($data["name"]) {
                        $email = $core->text->email($core->post["email"]);
                        if ($email && $email != $core->user->mail) {
                            $uid = $core->db->field("SELECT user_id FROM " . DB_USER . " WHERE user_mail = '" . $email . "' LIMIT 1");
                            if (!$uid || $uid == $core->user->id) {
                                $data["mail"] = $email;
                            }
                        }
                        if ($core->post["pass"] && $core->post["pass"] == $core->post["conf"]) {
                            $data["pass"] = $core->user->pass($core->post["pass"]);
                        }
                        $message = $core->user->edit($data) ? "ok" : "error";
                        if ($message == "ok") {
                            $core->user->meta($core->user->id, $meta);
                            if ($data["pass"]) {
                                $user = $core->user->get($core->user->id);
                                $core->user->load($user);
                            }
                        }
                        $core->go($core->url("mm", "profile", $message));
                    } else {
                        $core->go($core->url("mm", "profile", "info"));
                    }
                case "reset":
                    $core->user->edit(array("api" => md5(microtime())));
                    $core->go($core->url("mm", "profile", "ok"));
            }
            if ($core->user->work == 0 && $core->config("register", "contact")) {
                $cnok = false;
                if ($core->user->meta["vk"]) {
                    $cnok = true;
                }
                if ($core->user->meta["skype"]) {
                    $cnok = true;
                }
                if ($core->user->meta["telegram"]) {
                    $cnok = true;
                }
                if ($core->user->meta["whatsapp"]) {
                    $cnok = true;
                }
                if (!$cnok) {
                    $core->site->info("warning", "error_user_contact");
                }
            }
            $lang = array();
            foreach ($core->lang["languages"] as $l1 => $l2) {
                $lang[] = array("name" => $l2, "value" => $l1, "select" => $l1 == $core->user->meta["lang"]);
            }
            $core->site->bc($core->lang["profile"], $core->url("m", "profile"));
            $core->site->pt($core->lang["profile_h"]);
            $core->site->header();
            $field = array(array("type" => "line", "value" => $core->text->lines($core->lang["profile_t"])), array("type" => "head", "value" => $core->lang["user_info"]), array("type" => "text", "length" => 100, "name" => "name", "head" => $core->lang["user_name"], "descr" => $core->lang["user_name_d"], "value" => $core->user->name), array("type" => "text", "length" => 100, "name" => "email", "head" => $core->lang["user_email"], "descr" => $core->lang["user_email_d"], "value" => $core->user->email), array("type" => "checkbox", "name" => "news", "head" => $core->lang["user_news"], "descr" => $core->lang["user_news_d"], "checked" => $core->user->news), array("type" => "text", "length" => 25, "name" => "wmr", "head" => $core->lang["user_wmr"], "descr" => $core->lang["user_wmr_d"], "value" => $core->user->wmr), array("type" => "text", "length" => 50, "name" => "skype", "head" => $core->lang["user_skype"], "value" => $core->user->meta["skype"]), array("type" => "text", "length" => 50, "name" => "telegram", "head" => $core->lang["user_telegram"], "value" => $core->user->meta["telegram"]), array("type" => "text", "length" => 50, "name" => "whatsapp", "head" => $core->lang["user_whatsapp"], "value" => $core->user->meta["whatsapp"]), array("type" => "text", "length" => 50, "name" => "vk", "head" => $core->lang["user_vk"], "value" => $core->user->meta["vk"]), array("type" => "select", "name" => "lang", "head" => $core->lang["user_lang"], "descr" => $core->lang["user_lang_d"], "value" => $lang), array("type" => "head", "value" => $core->lang["user_access"]), array("type" => "pass", "length" => 32, "name" => "pass", "head" => $core->lang["user_pass"], "descr" => $core->lang["user_pass_d"]), array("type" => "pass", "length" => 32, "name" => "conf", "head" => $core->lang["user_conf"], "descr" => $core->lang["user_conf_d"]));
            $field[] = array("type" => "head", "value" => $core->lang["user_apis"]);
            $field[] = array("type" => "line", "value" => $core->text->lines($core->lang["user_apis_t"]));
            $field[] = array("type" => "text", "name" => "api_id\" readonly=\"readonly", "head" => $core->lang["user_api"], "descr" => $core->lang["user_api_d"], "value" => $core->user->id);
            $field[] = array("type" => "text", "name" => "api_key\" readonly=\"readonly", "head" => $core->lang["user_key"], "descr" => sprintf($core->lang["user_key_d"], $core->url("ma", "profile", "reset")), "value" => $core->user->api);
            $core->site->form("profile", $core->url("ma", "profile", "save"), false, $field);
            $core->site->footer();
            $core->stop();
        case "money":
            switch ($message) {
                case "ok":
                    $core->site->info("info", "done_basic");
                    break;
                case "out":
                    $core->site->info("info", "done_fin_out");
                    break;
                case "pay-ok":
                    $core->site->info("info", "done_fin_pay");
                    break;
                case "error":
                    $core->site->info("error", "error_basic");
                    break;
                case "minimal":
                    $core->site->info("error", "error_fin_min");
                    break;
                case "nomoney":
                    $core->site->info("error", "error_fin_max");
                    break;
                case "nopurse":
                    $core->site->info("error", "error_fin_wmr");
                    break;
                case "pay-e":
                    $core->site->info("error", "error_fin_pay");
                    break;
            }
            switch ($action) {
                case "out":
                    if ($core->user->wmr) {
                        $cash = (int) $core->post["cash"];
                        $minf = $core->config("money", "minout");
                        if ($cash < $minf) {
                            $core->go($core->url("mm", "money", "minimal"));
                        }
                        if ($core->user->cash < $cash) {
                            $core->go($core->url("mm", "money", "nomoney"));
                        }
                        if ($core->finance->add($core->user->id, 0, 0 - $cash, 4, $core->user->wmr)) {
                            $core->go($core->url("mm", "money", "out"));
                        } else {
                            $core->go($core->url("mm", "money", "error"));
                        }
                    } else {
                        $core->go($core->url("mm", "money", "nopurse"));
                    }
                case "cancel":
                    $c = $core->db->row("SELECT * FROM " . DB_CASH . " WHERE cash_id = '" . $id . "' LIMIT 1");
                    if ($c["user_id"] == $core->user->id && $c["cash_type"] == 4) {
                        if ($core->finance->del($id)) {
                            $core->go($core->url("mm", "money", "ok"));
                        } else {
                            $core->go($core->url("mm", "money", "error"));
                        }
                    } else {
                        $core->go($core->url("mm", "", "access"));
                    }
            }
            $page = $core->get["page"] ? (int) $core->get["page"] : 1;
            $en = 25;
            $st = $en * ($page - 1);
            $trc = $core->db->field("SELECT COUNT(*) FROM " . DB_CASH . " WHERE user_id = '" . $core->user->id . "'");
            $trs = $trc ? $core->db->data("SELECT * FROM " . DB_CASH . " WHERE user_id = '" . $core->user->id . "' ORDER BY cash_time DESC LIMIT " . $st . ", " . $en) : array();
            $add = 0 - $core->user->cash;
            if ($add <= 0) {
                $add = "";
            }
            $minf = $core->config("money", "minout");
            $core->site->bc($core->lang["finance_h"], $core->url("m", "money"));
            $core->site->header();
            $core->tpl->load("body", "finance", defined("HACK_TPL_FINANCE") ? HACK : false);
            $core->tpl->vars("body", array("title" => $core->lang["finance_h"], "text" => $core->text->lines(sprintf($core->lang["finance_t"], $core->currency->prnt($minf))), "u_add" => "", "pay" => $core->lang["finance_pay"], "toadd" => $add, "pay_id" => $core->user->id, "pay_comment" => base64_encode(sprintf($core->lang["pay_comment"], $core->user->id)), "pay_purse" => WMR, "u_out" => $core->url("ma", "money", "out"), "toout" => $core->user->cash < $minf ? "" : $core->user->cash, "min" => $minf, "out" => $core->lang["finance_out"], "nofins" => $core->lang["nofins"], "type" => $core->lang["type"], "cash" => $core->lang["cash"], "status" => $core->lang["status"], "date" => $core->lang["date"], "action" => $core->lang["action"], "cancel" => $core->lang["cancel"], "confirm" => $core->lang["confirm"], "pages" => pages($core->url("m", "money"), $trc, $en, $page), "ncash" => $core->lang["money_cash"], "nhold" => $core->lang["money_hold"], "ucash" => $core->currency->prnt($core->user->cash), "uhold" => 0 < $core->user->meta["hold"] ? $core->currency->prnt($core->user->meta["hold"]) : false));
            if (count($trs)) {
                foreach ($trs as &$c) {
                    $core->tpl->block("body", "fin", array("type" => $core->lang["cash_type"][$c["cash_type"]], "tid" => $c["cash_type"], "descr" => $c["cash_descr"] ? "(" . $c["cash_descr"] . ")" : "", "value" => $core->currency->money($c["cash_value"]), "cancel" => $core->url("ia", "money", $c["cash_id"], "cancel"), "time" => smartdate($c["cash_time"])));
                    if ($c["cash_type"] == 4) {
                        $core->tpl->block("body", "fin.action");
                    }
                }
                unset($t);
                unset($trs);
            } else {
                $core->tpl->block("body", "nofin", array());
            }
            if ($core->user->work == 1) {
                $core->tpl->block("body", "canin");
            }
            $core->tpl->output("body");
            $core->site->footer();
            $core->stop();
        case "offers":
            require_once PATH_MODS . "offers.php";
            offers($core);
        case "support":
            switch ($action) {
                case "add":
                    $core->support->add($core->user->id);
                    if ($core->get["z"] == "ajax") {
                        echo "ok";
                        $core->stop();
                    } else {
                        $core->go($core->url("m", "support"));
                    }
                case "update":
                    $messages = $core->support->show($core->user->id, $core->get["from"]);
                    if ($mc = count($messages)) {
                        $core->tpl->load("body", "message", defined("HACK_TPL_MESSAGE") ? HACK : false);
                        $mn = $mx = $mm = 0;
                        foreach ($messages as &$m) {
                            $core->tpl->block("body", "msg", $m);
                            $mx = max($mx, $m["id"]);
                            $mn = $mn ? min($mn, $m["id"]) : $m["id"];
                            if ($m["new"]) {
                                $mm += 1;
                            }
                        }
                        $core->tpl->vars("body", array("showmore" => $core->lang["support_more"], "mn" => $mn, "mx" => $mx, "mc" => $mm));
                        if (0 <= $core->get["from"]) {
                            $core->tpl->block("body", "more");
                        }
                        $core->tpl->output("body");
                    }
                    $core->stop();
            }
            $core->site->bc($core->lang["support"], $core->url("m", "support"));
            $core->site->header();
            $core->tpl->load("body", "message", defined("HACK_TPL_MESSAGE") ? HACK : false);
            switch (BOXSKIN) {
                case "primary":
                    $bg = "light-blue";
                    break;
                case "success":
                    $bg = "green";
                    break;
                case "danger":
                    $bg = "red";
                    break;
                case "warning":
                    $bg = "yellow";
                    break;
                case "info":
                    $bg = "aqua";
                    break;
                default:
                    $bg = "green";
            }
            $core->tpl->vars("body", array("title" => $core->lang["support"], "text" => $core->lang["support_info"], "nomessage1" => $core->lang["support_nm1"], "nomessage2" => $core->lang["support_nm2"], "add" => $core->lang["send"], "cancel" => $core->lang["cancel"], "showmore" => $core->lang["support_more"], "placeholder" => $core->lang["support_placeholder"], "u_support" => $core->url("m", "support"), "u_load" => $core->url("ma", "support", "update"), "u_add" => $core->url("ma", "support", "add"), "mc" => 0, "hasman" => $core->user->man ? 1 : 0, "manager" => $core->lang["support_manager"], "moreinfo" => $core->lang["support_moreblock"] ? $core->lang["support_moreinfo"] : false, "email" => $core->lang["user_email"], "skype" => $core->lang["user_skype"], "telegram" => $core->lang["user_telegram"], "vk" => $core->lang["user_vk"], "whatsapp" => $core->lang["user_whatsapp"], "bg" => $bg, "btn" => BOXSKIN));
            $core->tpl->block("body", "face");
            if ($core->lang["support_moreblock"]) {
                foreach ($core->lang["support_moreblock"] as $su => $sn) {
                    $core->tpl->block("body", "face.ib", array("url" => $su, "text" => $sn));
                }
            }
            if ($core->user->man) {
                $man = $core->user->get($core->user->man);
                $core->tpl->block("body", "face.man", array("name" => $man["user_name"], "email" => $man["user_mail"], "skype" => $man["meta"]["skype"], "telegram" => $man["meta"]["telegram"], "vk" => $man["meta"]["vk"], "whatsapp" => $man["meta"]["whatsapp"], "wacl" => preg_replace("#([^0-9]+)#i", "", $man["meta"]["whatsapp"])));
            }
            $o = $core->text->link($core->get["o"]);
            if ($b = $core->support->block($o)) {
                $b["o"] = $o;
                $core->tpl->block("body", "face.block", $b);
                foreach ($b["param"] as $bn => $bv) {
                    $core->tpl->block("body", "face.block.param", array("n" => $bn, "v" => $bv));
                }
            } else {
                $core->tpl->block("body", "face.form");
            }
            $mn = $mx = 0;
            $messages = $core->support->show($core->user->id);
            if ($mc = count($messages)) {
                foreach ($messages as &$m) {
                    $core->tpl->block("body", "msg", $m);
                    $mx = max($mx, $m["id"]);
                    $mn = $mn ? min($mn, $m["id"]) : $m["id"];
                }
                unset($m);
                $core->tpl->block("body", "more");
            } else {
                $core->tpl->block("body", "face.nomsg");
            }
            $core->tpl->vars("body", array("mn" => $mn, "mx" => $mx));
            $core->tpl->output("body");
            $core->site->footer();
            $core->stop();
        case "referal":
            if ($core->config("register", "noref")) {
                $core->go("/");
            }
            $sh = 30;
            $st = $sh * ($page - 1);
            $users = $core->db->field("SELECT COUNT(*) FROM " . DB_USER . " WHERE user_ref = '" . $core->user->id . "'");
            $user = $users ? $core->db->data("SELECT * FROM " . DB_USER . " WHERE user_ref = '" . $core->user->id . "' ORDER BY user_name ASC LIMIT " . $st . ", " . $sh) : array();
            if (function_exists("referalurl")) {
                $url = referalurl($core);
            } else {
                $url = $core->uri("", array("from" => $core->user->id));
            }
            $core->site->bc($core->lang["referal_h"], $core->url("m", "referal"));
            $core->site->header();
            $core->tpl->load("body", "referal", defined("HACK_TPL_REFERAL") ? HACK : false);
            $core->tpl->vars("body", array("title" => $core->lang["referal_h"], "text" => $core->text->lines($core->lang["referal_t"]), "url" => $url, "nousers" => $core->lang["referal_no"], "name" => $core->lang["user"], "flows" => $core->lang["ref_flows"], "cash" => $core->lang["ref_cash"], "pages" => pages($core->url("m", "referal"), $users, $sh, $page), "shown" => $users ? sprintf($core->lang["shown"], $st + 1, min($st + $sh, $users), $users) : ""));
            if (count($user)) {
                foreach ($user as &$i) {
                    $core->tpl->block("body", "user", array("name" => $i["user_name"], "cash" => $core->currency->money($i["user_got"])));
                }
            } else {
                $core->tpl->block("body", "nouser");
            }
            $core->tpl->output("body");
            $core->site->footer();
            $core->stop();
    }
    return false;
}
function base_404($core)
{
    $core->site->bc("404");
    $core->site->header();
    $core->tpl->load("body", "404", defined("HACK_TPL_404") ? HACK : false);
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}

?>