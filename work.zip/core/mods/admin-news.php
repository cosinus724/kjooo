<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function admin_news($core)
{
    $action = isset($core->get["action"]) ? $core->text->link($core->get["action"]) : NULL;
    $id = isset($core->get["id"]) ? (int) $core->get["id"] : 0;
    switch ($action) {
        case "add":
            $data = array("offer_id" => (int) $core->post["offer"], "news_cat" => (int) $core->post["cat"], "news_title" => $core->text->line($core->post["title"]), "news_text" => $core->text->code($core->post["text"]), "news_time" => time(), "news_group" => (int) $core->post["group"], "news_vip" => $core->post["vip"] ? 1 : 0);
            if ($core->db->add(DB_NEWS, $data)) {
                $id = $core->db->lastid();
                $send = $core->post["send"] ? 1 : 0;
                if ($send) {
                    $mvip = $data["news_vip"] ? " AND user_vip = 1 " : "";
                    switch ($data["news_group"]) {
                        case 1:
                            $mails = $core->db->col("SELECT user_mail FROM " . DB_USER . " WHERE user_news = 1 AND user_work = 0 " . $mvip);
                            break;
                        case 2:
                            $mails = $core->db->col("SELECT user_mail FROM " . DB_USER . " WHERE user_news = 1 AND user_work = 1 " . $mvip);
                            break;
                        default:
                            $mails = $core->db->col("SELECT user_mail FROM " . DB_USER . " WHERE user_news = 1 " . $mvip);
                    }
                    $title = sprintf("%s: %s", $core->config("site", "name"), stripslashes($data["news_title"]));
                    $text = sprintf($core->lang["mail_news_t"], stripslashes($data["news_text"]), $core->uri("talk/" . $id), $core->uri("profile"));
                    $core->email->send($mails, $title, $text);
                }
                $core->go($core->url("mm", "news", "ok"));
            } else {
                $core->go($core->url("mm", "news", "e"));
            }
        case "edit":
            $data = array("offer_id" => (int) $core->post["offer"], "news_cat" => (int) $core->post["cat"], "news_title" => $core->text->line($core->post["title"]), "news_text" => $core->text->code($core->post["text"]), "news_group" => (int) $core->post["group"], "news_vip" => $core->post["vip"] ? 1 : 0);
            if ($core->db->edit(DB_NEWS, $data, "news_id = '" . $id . "'")) {
                $send = $core->post["send"] ? 1 : 0;
                if ($send) {
                    $mvip = $data["news_vip"] ? " AND user_vip = 1 " : "";
                    switch ($data["news_group"]) {
                        case 1:
                            $mails = $core->db->col("SELECT user_mail FROM " . DB_USER . " WHERE user_news = 1 AND user_work = 0 " . $mvip);
                            break;
                        case 2:
                            $mails = $core->db->col("SELECT user_mail FROM " . DB_USER . " WHERE user_news = 1 AND user_work = 1 " . $mvip);
                            break;
                        default:
                            $mails = $core->db->col("SELECT user_mail FROM " . DB_USER . " WHERE user_news = 1 " . $mvip);
                    }
                    $core->email->send($mails, sprintf($core->lang["mail_news_h"], stripslashes($data["news_title"])), sprintf($core->lang["mail_news_t"], stripslashes($data["news_text"]), $id));
                }
                $core->go($core->url("mm", "news", "ok"));
            } else {
                $core->go($core->url("mm", "news", "e"));
            }
        case "del":
            if ($core->db->del(DB_NEWS, "news_id = '" . $id . "'")) {
                $core->go($core->url("mm", "news", "ok"));
            } else {
                $core->go($core->url("mm", "news", "e"));
            }
    }
    $message = isset($core->get["message"]) ? $core->text->link($core->get["message"]) : NULL;
    switch ($message) {
        case "add-ok":
            $core->site->info("info", "done_add");
            break;
        case "edit-ok":
            $core->site->info("info", "done_edit");
            break;
        case "del-ok":
            $core->site->info("info", "done_del");
            break;
        case "add-e":
            $core->site->info("error", "error_add");
            break;
        case "edit-e":
            $core->site->info("error", "error_edit");
            break;
        case "del-e":
            $core->site->info("error", "error_del");
            break;
    }
    if ($id) {
        $n = $core->db->row("SELECT * FROM " . DB_NEWS . " WHERE news_id = '" . $id . "' LIMIT 1");
        $core->site->bc($core->lang["news"], $core->url("m", "news"));
        $core->site->bc($core->lang["news_edit_h"]);
        $core->site->header();
        $offers = array("&mdash;");
        $olist = $core->cpa->get("offersa");
        if (is_array($olist)) {
            $offers += $olist;
        }
        $field = array(array("type" => "line", "value" => $core->text->lines($core->lang["news_t"])), array("type" => "select", "name" => "cat", "head" => $core->lang["news_cat"], "value" => $n["news_cat"], "options" => $core->lang["newscats"]), array("type" => "select", "name" => "offer", "head" => $core->lang["offer"], "value" => $n["offer_id"], "options" => $offers), array("type" => "text", "length" => 100, "name" => "title", "head" => $core->lang["title"], "value" => $n["news_title"]), array("type" => "mcea", "name" => "text", "head" => $core->lang["text"], "value" => $n["news_text"]), array("type" => "select", "name" => "group", "head" => $core->lang["news_group"], "value" => $n["news_group"], "options" => $core->lang["news_groups"]), array("type" => "checkbox", "name" => "vip", "head" => $core->lang["news_vip"], "descr" => $core->lang["news_vip_d"], "checked" => $n["news_vip"]), array("type" => "checkbox", "name" => "send", "head" => $core->lang["news_send"], "descr" => $core->lang["news_send_d"]));
        $core->site->form("news", $core->url("ia", "news", $id, "edit"), $core->lang["news_edit_h"], $field);
        $core->site->footer();
        $core->stop();
    } else {
        return false;
    }
}
function admin_news_add($core)
{
    $core->site->bc($core->lang["news"], $core->url("m", "news"));
    $core->site->bc($core->lang["news_add_h"]);
    $core->site->header();
    $offers = array("&mdash;");
    $olist = $core->cpa->get("offersa");
    if (is_array($olist)) {
        $offers += $olist;
    }
    $field = array(array("type" => "line", "value" => $core->text->lines($core->lang["news_t"])), array("type" => "select", "name" => "cat", "head" => $core->lang["news_cat"], "options" => $core->lang["newscats"]), array("type" => "select", "name" => "offer", "head" => $core->lang["offer"], "options" => $offers), array("type" => "text", "length" => 100, "name" => "title", "head" => $core->lang["title"]), array("type" => "mcea", "name" => "text", "head" => $core->lang["text"]), array("type" => "select", "name" => "group", "head" => $core->lang["news_group"], "options" => $core->lang["news_groups"]), array("type" => "checkbox", "name" => "vip", "head" => $core->lang["news_vip"], "descr" => $core->lang["news_vip_d"]), array("type" => "checkbox", "name" => "send", "head" => $core->lang["news_send"], "descr" => $core->lang["news_send_d"]));
    $core->site->form("news", $core->url("ma", "news", "add"), $core->lang["news_add_h"], $field, $core->lang["create"]);
    $core->site->footer();
    $core->stop();
}

?>