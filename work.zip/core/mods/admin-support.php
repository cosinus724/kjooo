<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function admin_support($core, $config = array())
{
    $id = (int) $core->get["id"];
    if (isset($core->get["action"])) {
        switch ($core->get["action"]) {
            case "add":
                if ($config["manager"]) {
                    $u = $core->user->get($id);
                    if ($u["user_work"] == 0 || $u["user_man"] == $config["manager"]) {
                        if ($u["user_man"] != $config["manager"] && !$config["vip"]) {
                            $core->go($core->url("mm", "supporthq", "access"));
                        }
                    } else {
                        $core->go($core->url("mm", "supporthq", "access"));
                    }
                }
                $core->support->admin();
                $core->support->add($id);
                if ($core->get["z"] == "ajax") {
                    echo "ok";
                    $core->stop();
                } else {
                    $core->go($core->u(array("supporthq", $id)));
                }
            case "del":
                if ($config["manager"]) {
                    $u = $core->user->get($id);
                    if ($u["user_work"] == 0 || $u["user_man"] == $config["manager"]) {
                        if ($u["user_man"] != $config["manager"] && !$config["vip"]) {
                            $core->go($core->url("mm", "supporthq", "access"));
                        }
                    } else {
                        $core->go($core->url("mm", "supporthq", "access"));
                    }
                }
                $core->support->admin();
                $core->support->del($core->get["msg"]);
                if ($core->get["z"] == "ajax") {
                    echo $core->get["msg"];
                    $core->stop();
                } else {
                    $core->go($core->u(array("supporthq", $id)));
                }
            case "show":
                if ($config["manager"]) {
                    $u = $core->user->get($id);
                    if ($u["user_work"] == 0 || $u["user_man"] == $config["manager"]) {
                        if ($u["user_man"] != $config["manager"] && !$config["vip"]) {
                            $core->stop();
                        }
                    } else {
                        $core->stop();
                    }
                }
                $from = (int) $core->get["from"];
                $core->support->admin();
                $messages = $core->support->show($id, $from);
                if ($mc = count($messages)) {
                    $core->tpl->load("body", "message", defined("HACK_TPL_MESSAGE") ? HACK : false);
                    $mn = $mx = $mm = 0;
                    foreach ($messages as &$m) {
                        $core->tpl->block("body", "msg", $m);
                        if ($m["uid"] == $id) {
                            $core->tpl->block("body", "msg.admin", array("u" => $core->user->get($m["uid"], "user_mail"), "d" => $core->url("ia", "supporthq", $id, "del") . "&msg=" . $m["id"]));
                        }
                        $mx = max($mx, $m["id"]);
                        $mn = $mn ? min($mn, $m["id"]) : $m["id"];
                        if ($m["new"]) {
                            $mm += 1;
                        }
                    }
                    $core->tpl->vars("body", array("showmore" => $core->lang["support_more"], "delete" => $core->lang["del"], "mn" => $mn, "mx" => $mx, "mc" => $mm));
                    if (0 <= $core->get["from"]) {
                        $core->tpl->block("body", "more");
                    } else {
                        $core->tpl->block("body", "havemsg");
                    }
                    $core->tpl->output("body");
                }
                $core->stop();
        }
    }
    if (isset($core->get["message"])) {
        switch ($core->get["message"]) {
            case "access":
                $core->site->info("error", "access_denied");
                break;
        }
    }
    $isadm = $config["manager"] ? false : true;
    if ($id) {
        $user = $core->user->get($id);
        if ($config["manager"]) {
            if ($user["user_work"] == 0 || $user["user_man"] == $config["manager"]) {
                if ($user["user_man"] != $config["manager"] && !$config["vip"]) {
                    $core->go($core->url("mm", "supporthq", "access"));
                }
            } else {
                $core->go($core->url("mm", "supporthq", "access"));
            }
        }
        $core->site->bc($core->lang["support_h"], $core->u("supporthq"));
        $core->site->bc($user["user_name"]);
        $core->site->header();
        $core->tpl->load("body", "message", defined("HACK_TPL_MESSAGE") ? HACK : false);
        $core->tpl->vars("body", array("title" => $core->lang["support"], "add" => $core->lang["send"], "confirm" => $core->lang["confirm"], "nomessage1" => $core->lang["support_nm1"], "nomessage2" => $core->lang["support_nm2"], "showmore" => $core->lang["support_more"], "delete" => $core->lang["del"], "placeholder" => $core->lang["support_ph_admin"], "u_support" => $core->u(array("supporthq", $id)), "u_load" => $core->u(array("supporthq", $id), "action=show"), "u_add" => $core->u(array("supporthq", $id), "action=add"), "mc" => 0));
        $core->tpl->block("body", "face");
        $o = $core->text->link($core->get["o"]);
        if ($b = $core->support->block($o)) {
            $b["o"] = $o;
            $core->tpl->block("body", "face.block", $b);
            foreach ($b["param"] as $bn => $bv) {
                $core->tpl->block("body", "face.block.param", array("n" => $bn, "v" => $bv));
            }
        } else {
            $core->tpl->block("body", "face.form");
        }
        $core->support->admin();
        $messages = $core->support->show($id);
        $mn = $mx = 0;
        if ($mc = count($messages)) {
            foreach ($messages as &$m) {
                $core->tpl->block("body", "msg", $m);
                $core->tpl->block("body", "msg.admin", array("u" => $m["uid"] == $id ? $user["user_mail"] : false, "d" => $core->u(array("supporthq", $id), array("action" => "del", "msg" => $m["id"]))));
                $mx = max($mx, $m["id"]);
                $mn = $mn ? min($mn, $m["id"]) : $m["id"];
            }
            unset($m);
            $core->tpl->block("body", "more");
        } else {
            $core->tpl->block("body", "face.nomsg");
        }
        $core->tpl->vars("body", array("mn" => $mn, "mx" => $mx));
        $core->tpl->output("body");
        $core->site->footer();
    } else {
        $reload = isset($core->get["reload"]);
        $relast = (int) $core->get["reload"];
        $core->site->bc($core->lang["support_h"], $core->u("supporthq"));
        if (!$reload) {
            $core->site->header();
        }
        $param = array();
        $where = array("supp_last != 0");
        if ($config["manager"]) {
            if ($config["vip"]) {
                $where[] = "( user_work = 0 OR user_man = '" . $config["manager"] . "' )";
            } else {
                $where[] = "user_man = '" . $config["manager"] . "'";
            }
        }
        if ($config["vip"] || !$config["manager"]) {
            if ($man = (int) $core->get["man"]) {
                $where[] = "user_man = '" . $man . "'";
                $param["man"] = $man;
            }
        } else {
            $man = false;
        }
        $page = max(1, (int) $core->get["page"]);
        $sh = 30;
        $st = ($page - 1) * $sh;
        $where = implode(" AND ", $where);
        $sc = $core->db->field("SELECT COUNT(*) FROM " . DB_USER . " WHERE " . $where);
        $supp = $sc ? $core->db->data("SELECT * FROM " . DB_USER . " WHERE " . $where . " ORDER BY supp_last DESC LIMIT " . $st . ", " . $sh) : array();
        $core->tpl->load("body", "support", defined("HACK_TPL_SUPP") ? HACK : false);
        $news = $sound = 0;
        foreach ($supp as &$s) {
            if ($s["supp_admin"]) {
                $news += $s["supp_admin"];
                if ($relast && $relast < $s["supp_last"]) {
                    $sound += 1;
                }
            }
            $core->tpl->block("body", "supp", array("link" => $core->u(array("supporthq", $s["user_id"])), "id" => $s["user_id"], "time" => smartdate($s["supp_last"]), "name" => $s["user_name"], "email" => $s["user_mail"], "user" => $s["supp_name"], "status" => $s["supp_admin"] ? sprintf($core->lang["support_new"], $s["supp_admin"]) : ($s["supp_type"] ? $s["supp_new"] ? $core->lang["support_ur"] : $core->lang["support_ok"] : $core->lang["support_ua"]), "uclass" => $s["supp_type"] ? "text-success fat" : "text-info", "iclass" => $s["supp_admin"] ? "envelope" : ($s["supp_type"] ? $s["supp_new"] ? "clock-o" : "check-circle" : "exclamation-triangle"), "sclass" => $s["supp_admin"] ? "text-danger" : ($s["supp_type"] ? $s["supp_new"] ? "text-muted" : "text-success" : "text-warning"), "vclass" => $s["supp_admin"] ? "new" : "no", "u_manager" => $core->u("supporthq", parset($param, "man", $s["user_man"])), "manager" => $s["user_man"] ? $core->user->get($s["user_man"], "user_name") : false));
        }
        unset($supp);
        unset($s);
        $core->tpl->vars("body", array("title" => $core->lang["support_h"], "name" => $core->lang["name"], "email" => $core->lang["email"], "manager" => $core->lang["manager"], "last" => $core->lang["support_last"], "status" => $core->lang["status"], "time" => $core->lang["time"], "user" => $core->lang["user"], "pages" => pages($core->u("supporthq", $param), $sc, $sh, $page, sprintf($core->lang["shown"], $st + 1, min($st + $sh, $sc), $sc)), "shown" => sprintf($core->lang["shown"], $st + 1, min($st + $sh, $sc), $sc), "isadm" => $config["vip"] || !$config["manager"], "face" => $reload ? false : true, "notify" => numinf($core->lang["support_unread"], $news), "nc" => $sound ? 1 : 0, "lm" => time(), "u_load" => $core->u("supporthq", $param)));
        $core->tpl->output("body");
        if (!$reload) {
            $core->site->footer();
        }
    }
    $core->stop();
}

?>