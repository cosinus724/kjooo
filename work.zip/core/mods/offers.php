<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function offers($core)
{
    if ($core->user->work == 0) {
        if ($core->config("hide", "offers")) {
            $core->go($core->u("", array("message" => "access")));
        }
    } else {
        if ($core->user->work == -1) {
            if ($core->config("hide", "offerext")) {
                $core->go($core->u("", array("message" => "access")));
            }
        } else {
            if ($core->user->work == 1 && $core->config("hide", "offercmp")) {
                $core->go($core->u("", array("message" => "access")));
            }
        }
    }
    $canuser = $core->user->level || $core->user->work == -2;
    $wm = isset($core->post["wm"]) ? (int) $core->post["wm"] : (int) $core->get["wm"];
    if ($canuser && $wm) {
        $user = $wm;
        $udt = $core->user->get($wm);
        $uinfo = sprintf($core->lang["stat_user"], $udt["user_name"], $udt["user_mail"]);
        $core->site->info("text", $uinfo);
    } else {
        $user = $core->user->id;
        $wm = NULL;
    }
    $id = $core->post["id"] ? (int) $core->post["id"] : ($core->get["id"] ? (int) $core->get["id"] : 0);
    if ($id) {
        offerone($core, $id, $wm);
    } else {
        offerlist($core, $wm);
    }
    $core->stop();
}
function offerlist($core, $wm)
{
    $user = $wm ? $wm : $core->user->id;
    $ud = $core->user->get($user);
    $ogeo = $core->cpa->get("offergeo");
    $ocat = $core->cpa->get("offercat");
    $osub = $core->lang["offer_subs"] ? $core->cpa->get("offersub") : false;
    $where = $params = array();
    $donotload = false;
    $where[] = "offer_active = 1";
    if ($wm) {
        $params["wm"] = $wm;
    }
    if (isset($core->get["s"]) && $core->get["s"]) {
        require_once PATH_CORE . "search.php";
        $search = new SearchWords($core->get["s"]);
        if ($s = $search->get()) {
            $params["s"] = $s;
            $where[] = "(" . $search->field(array("offer_name", "offer_text")) . ")";
        } else {
            $search = $s = false;
        }
    } else {
        $search = $s = false;
    }
    if ($cat = (int) $_GET["c"]) {
        $where[] = "cat_id = '" . $cat . "'";
        $params["c"] = $cat;
        if (!in_array($cat, $ocat)) {
            $donotload = true;
        }
    } else {
        $cat = false;
    }
    if ($sub = (int) $_GET["cc"]) {
        $where[] = "cat_sub = '" . $sub . "'";
        $params["cc"] = $sub;
        if (!in_array($sub, $osub)) {
            $donotload = true;
        }
    } else {
        $sub = false;
    }
    if ($ex = $_GET["ex"] ? 1 : 0) {
        $where[] = "offer_excl = '" . $ex . "'";
        $params["ex"] = 1;
    } else {
        $ex = false;
    }
    if ($rc = $_GET["rc"] ? 1 : 0) {
        $where[] = "offer_recom = '" . $rc . "'";
        $params["rc"] = 1;
    } else {
        $rc = false;
    }
    if ($geo = $core->text->link($core->get["geo"])) {
        $where[] = "offer_country LIKE '%" . $geo . "%'";
        $params["geo"] = $geo;
        if (!in_array($geo, $ogeo)) {
            $donotload = true;
        }
    } else {
        $geo = false;
    }
    $page = max(1, (int) $core->get["page"]);
    $sh = $core->config("offer", "page");
    if (!$sh) {
        $sh = 30;
    }
    $st = $sh * ($page - 1);
    if (!$donotload) {
        $owl = $core->db->col("SELECT offer_id FROM " . DB_OFFER . " WHERE MATCH ( offer_wl ) AGAINST ( '+user" . $user . "' IN BOOLEAN MODE )");
        if ($owl) {
            $where[] = "( offer_private = 0 OR offer_private = 2 OR ( offer_private = 1 AND offer_id IN ( " . implode(",", $owl) . " ) ) )";
        }
        $obl = $core->db->col("SELECT offer_id FROM " . DB_OFFER . " WHERE MATCH ( offer_bl ) AGAINST ( '+user" . $user . "' IN BOOLEAN MODE )");
        if ($obl) {
            $where[] = "offer_id NOT IN( " . implode(",", $obl) . " )";
        }
        $where = implode(" AND ", $where);
        $oc = $core->db->field("SELECT COUNT(*) FROM " . DB_OFFER . " WHERE " . $where);
        $offer = $oc ? $core->db->data("SELECT offer_id, cat_id, cat_sub, offer_excl, offer_recom, offer_name, offer_text, offer_country, offer_convert, offer_epc FROM " . DB_OFFER . " WHERE " . $where . " ORDER BY offer_sort DESC, offer_name ASC LIMIT " . $st . ", " . $sh) : false;
        $flows = $offer ? $core->db->icol("SELECT offer_id, COUNT(*) FROM " . DB_FLOW . " WHERE user_id = '" . $user . "' GROUP BY offer_id") : false;
    } else {
        $offer = $flows = $oc = false;
    }
    $core->site->bc($core->lang["offers_h"], $core->u("offers", array("wm" => $wm)));
    if ($cat) {
        $core->site->bc($core->lang["offer_cats"][$cat]);
    }
    if ($core->get["format"] != "txt") {
        $core->site->header();
    }
    $core->tpl->load("body", "offers", defined("HACK_TPL_OFFERS") ? HACK : false);
    if ($core->get["format"] == "txt") {
        $core->tpl->load("body", "offers-txt");
        header("Content-type: text/plain; charset=utf-8");
    }
    if ($offer) {
        foreach ($offer as $o) {
            if (!$core->offer->visible($o["offer_id"], $user)) {
                continue;
            }
            $core->tpl->block("body", "offer", array("u" => $core->u(array("offers", $o["offer_id"]), array("wm" => $wm)), "u_cat" => $core->u("offers", parset($params, "c", $o["cat_id"])), "u_sub" => $core->u("offers", parset($params, "cc", $o["cat_sub"])), "u_excl" => $core->u("offers", parset($params, "ex", $o["offer_excl"])), "u_recom" => $core->u("offers", parset($params, "rc", $o["offer_recom"])), "excl" => $o["offer_excl"], "recom" => $o["offer_recom"], "cat" => $o["cat_id"], "catname" => $core->lang["offer_cats"][$o["cat_id"]], "sub" => $o["cat_sub"], "subname" => $core->lang["offer_subs"] ? $core->lang["offer_subs"][$o["cat_sub"]] : false, "id" => $o["offer_id"], "logo" => sprintf(OFFER_LOGO, $o["offer_id"]), "auth" => $core->offer->auth($o["offer_id"], $user), "add" => $ud["user_work"] == 0 || $ud["user_work"] == 2 || $ud["user_work"] == -2 ? $core->u(array("flow", $o["offer_id"]), array("action" => "add", "wm" => $wm)) : false, "request" => $core->u("support", array("o" => "offer", "i" => $o["offer_id"])), "name" => $o["offer_text"] ? $o["offer_text"] : $o["offer_name"], "cr" => $o["offer_convert"], "epc" => sprintf("%0.2f", $o["offer_epc"]), "my" => $flows[$o["offer_id"]] ? true : false, "status" => $flows[$o["offer_id"]] ? sprintf($core->lang["offer_flows"], $flows[$o["offer_id"]]) : $core->lang["offer_noflow"]));
            $price = $core->offer->price($o["offer_id"], $user);
            foreach ($price as $p) {
                $p["dsk"] = offerpayments($core, $p["dsk"], $p["dsku"], $p["dskx"], $p["dskp"], $p["dskc"]);
                $p["mob"] = offerpayments($core, $p["mob"], $p["mobu"], $p["mobx"], $p["mobp"], $p["mobc"]);
                if ($p["dsk"] == $p["mob"]) {
                    $p["eq"] = true;
                }
                $core->tpl->block("body", "offer.price", $p);
            }
        }
    } else {
        $core->tpl->block("body", "nooffer");
    }
    if ($wm) {
        $needreset = 1 < count($params);
    } else {
        $needreset = $params ? true : false;
    }
    $core->tpl->vars("body", array("text" => $core->text->lines($core->lang["offers_text"]), "nooffers" => $core->lang["offers_no"], "name" => $core->lang["name"], "gender" => $core->lang["gender"], "wm" => $core->lang["offer_towm"], "approve" => $core->lang["offer_approve"], "action" => $core->lang["action"], "status" => $core->lang["status"], "cats" => $core->lang["cat"], "subs" => defined("OFFERSUBS") ? $core->lang["subdiv"] : false, "country" => $core->lang["order_country"], "more" => $core->lang["offer_more"], "showonly" => $core->lang["offer_showonly"], "add" => $core->lang["offer_newflow"], "request" => $core->lang["offer_request"], "confirm" => $core->lang["offer_confirm"], "geo" => $core->lang["offer_geo"], "price" => $core->lang["price"], "prices" => $core->lang["offer_prices"], "desktop" => $core->lang["offer_desktop"], "mobile" => $core->lang["offer_mobile"], "upsale" => $core->lang["offer_upsale"], "excl" => $core->lang["offer_excl_s"], "isexcl" => $ex, "recom" => $core->lang["offer_recom_s"], "isrecom" => $rc, "reset" => $core->lang["reset"], "u_reset" => $needreset ? $core->u("offers", array("wm" => $wm)) : false, "u_search" => $core->u("offers"), "s" => $s, "wm" => $wm, "pages" => $oc ? pages($core->u("offers", $params), $oc, $sh, $page, sprintf($core->lang["shown"], $st + 1, min($st + $sh, $oc), $oc)) : false, "search" => $core->lang["search"], "find" => $core->lang["find"]));
    foreach ($core->lang["offer_cats"] as $ci => $cn) {
        if (in_array($ci, $ocat)) {
            $core->tpl->block("body", "cat", array("id" => $ci, "name" => $cn, "select" => $ci == $cat));
        }
    }
    foreach ($core->lang["country"] as $ci => $cn) {
        if (in_array($ci, $ogeo)) {
            $core->tpl->block("body", "geo", array("id" => $ci, "name" => $cn, "select" => $ci == $geo));
        }
    }
    if ($core->lang["offer_subs"]) {
        foreach ($core->lang["offer_subs"] as $ci => $cn) {
            if (in_array($ci, $osub)) {
                $core->tpl->block("body", "sub", array("id" => $ci, "name" => $cn, "select" => $ci == $sub));
            }
        }
    }
    $core->tpl->output("body");
    if ($core->get["format"] != "txt") {
        $core->site->footer();
    }
}
function offerone($core, $id, $wm)
{
    $user = $wm ? $wm : $core->user->id;
    $ud = $core->user->get($user);
    $offer = $core->cpa->get("offer", $id);
    if (!$offer["offer_active"]) {
        $core->go($core->u("offers", array("wm" => $wm)));
    }
    if (!$core->offer->visible($id, $user)) {
        $core->go($core->u("offers", array("wm" => $wm)));
    }
    $sites = $core->cpa->get("sites", $id);
    if ($ud["user_work"] == 0 || $ud["user_work"] == 2 || $ud["user_work"] == -2) {
        $flows = $core->db->data("SELECT * FROM " . DB_FLOW . " WHERE user_id = '" . $user . "' AND offer_id = '" . $id . "'");
        $fc = count($flows);
    } else {
        $flows = $fc = false;
    }
    $core->site->bc($core->lang["offers_h"], $core->u("offers", array("wm" => $wm)));
    $core->site->bc($offer["offer_name"]);
    $core->site->page = $offer["offer_text"] ? $offer["offer_text"] : $offer["offer_name"];
    $core->site->header();
    $core->tpl->load("body", "offer", defined("HACK_TPL_OFFER") ? HACK : false);
    $core->tpl->vars("body", $offer);
    $core->tpl->vars("body", array("url" => $core->lang["site"], "wm" => $core->lang["offer_towm"], "action" => $core->lang["action"], "add" => $core->lang["offer_newflow"], "request" => $core->lang["offer_request"], "confirm" => $core->lang["offer_confirm"], "excl" => $core->lang["offer_excl"], "recom" => $core->lang["offer_recom"], "logo" => sprintf(OFFER_LOGO, $offer["offer_id"]), "u_add" => $ud["user_work"] == 0 || $ud["user_work"] == 2 || $ud["user_work"] == -2 ? $core->u(array("flow", $offer["offer_id"]), array("action" => "add", "wm" => $wm)) : false, "u_request" => $core->u("support", array("o" => "offer", "i" => $offer["offer_id"])), "text" => $offer["offer_text"] ? $core->text->out($offer["offer_text"]) : $core->lang["offer_notext"], "auth" => $core->offer->auth($id, $user), "cat" => $core->lang["cat"], "sub" => $core->lang["subdiv"], "geoprice" => $core->lang["offer_geoprice"], "approve" => $core->lang["offer_approve"], "geo" => $core->lang["offer_geo"], "price" => $core->lang["price"], "prices" => $core->lang["offer_prices"], "desktop" => $core->lang["offer_desktop"], "mobile" => $core->lang["offer_mobile"], "upsale" => $core->lang["offer_upsale"], "land" => $core->lang["offer_land"], "space" => $core->lang["offer_space"], "noland" => $core->lang["offer_noland"], "nospace" => $core->lang["offer_nospace"], "flowlist" => $core->lang["offer_flowlist"], "noflow" => $core->lang["offer_noflow"], "flow_name" => $core->lang["offer_flow"], "flow_cash" => $core->lang["offer_cash"], "total" => $core->lang["total"], "appr" => 0 < $offer["offer_approve"] ? sprintf("%0.1f", $offer["offer_approve"]) : false, "cr" => 0 < $offer["offer_convert"] ? sprintf("%0.2f", $offer["offer_convert"]) : false, "epc" => 0 < $offer["offer_epc"] ? $core->currency->prntf("%0.2f", $offer["offer_epc"]) : false, "gender" => 0 < $offer["stat_m"] || 0 < $offer["stat_f"] ? true : false, "stat_m" => sprintf("%0.1f", $offer["stat_m"]), "stat_f" => sprintf("%0.1f", $offer["stat_f"]), "status" => $fc ? sprintf($core->lang["offer_flows"], $fc) : $core->lang["offer_noflow"], "cat_name" => $core->lang["offer_cats"][$offer["cat_id"]], "sub_name" => $core->lang["offer_subs"] ? $core->lang["offer_subs"][$offer["cat_sub"]] : false));
    $price = $core->offer->price($id);
    foreach ($price as $p) {
        $p["dsk"] = offerpayments($core, $p["dsk"], $p["dsku"], $p["dskx"], $p["dskp"], $p["dskc"]);
        $p["mob"] = offerpayments($core, $p["mob"], $p["mobu"], $p["mobx"], $p["mobp"], $p["mobc"]);
        if ($p["dsk"] == $p["mob"]) {
            $p["eq"] = true;
        }
        $core->tpl->block("body", "price", $p);
    }
    $counts = array("site" => 0, "space" => 0);
    foreach ($sites as $s) {
        $type = $s["site_type"] == 1 ? "space" : "site";
        $counts[$type] += 1;
        $core->tpl->vars("body", array("has" . $type => 1));
        $core->tpl->block("body", $type, array("id" => $s["site_id"], "u" => $s["site_url"], "n" => $s["site_name"] ? $s["site_name"] : $s["site_url"], "appr" => 0 < $s["site_approve"] ? sprintf("%0.1f", $s["site_approve"]) : false, "cr" => 0 < $s["site_convert"] ? sprintf("%0.2f", $s["site_convert"]) : false, "epc" => 0 < $s["site_epc"] ? $core->currency->prntf("%0.2f", $s["site_epc"]) : false, "mb" => $s["site_mobile"], "mbt" => $core->lang["site_mobiles"][$s["site_mobile"]]));
    }
    unset($s);
    unset($sites);
    foreach ($counts as $c => $i) {
        if (!$i) {
            $core->tpl->block("body", "no" . $c);
        }
    }
    if ($ud["user_work"] == 0 || $ud["user_work"] == 2) {
        if ($core->offer->auth($id, $user)) {
            $core->tpl->block("body", "wm");
            if ($fc) {
                foreach ($flows as $f) {
                    $core->tpl->block("body", "wm.flow", array("stats" => $core->u(array("flow", $f["flow_id"]), array("wm" => $wm)), "name" => $f["flow_name"], "epc" => $core->currency->prntf("%0.2f", $f["flow_epc"]), "cr" => $f["flow_convert"], "total" => $core->currency->prnt($f["flow_total"])));
                }
                unset($f);
                unset($flows);
            } else {
                $core->tpl->block("body", "wm.noflow");
            }
        } else {
            $core->tpl->block("body", "request");
        }
    }
    switch ($ud["user_work"]) {
        case 1:
            $nf = "news_group IN ( 0,2 )";
            break;
        case 2:
            $nf = "news_group IN ( 0,1,2 )";
            break;
        default:
            $nf = "news_group IN ( 0,1 )";
    }
    if (!$ud["user_vip"]) {
        $nf .= " AND news_vip = 0";
    }
    $news = $core->db->data("SELECT news_id, news_time, news_cat, news_title FROM " . DB_NEWS . " WHERE offer_id = '" . $id . "' AND " . $nf . " ORDER BY news_id DESC LIMIT 4");
    if ($news) {
        $core->tpl->block("body", "news", array("title" => $core->lang["news_offer"], "all" => $core->lang["news_offer_all"], "u_all" => 3 < count($news) ? $core->u("news", array("o" => $id)) : false));
        $ni = 0;
        foreach ($news as $n) {
            $ni += 1;
            if (3 < $ni) {
                break;
            }
            $core->tpl->block("body", "news.one", array("id" => $n["news_id"], "url" => $core->u(array("talk", $n["news_id"])), "title" => $n["news_title"], "cid" => $n["news_cat"], "cat" => $core->lang["newscats"][$n["news_cat"]], "date" => date("d.m.y", $n["news_time"])));
        }
    }
    $allow = $offer["offer_allow"] ? $offer["offer_allow"] : $core->config("offer", "allow");
    $allow = $allow ? explode(",", $allow) : false;
    $deny = $offer["offer_deny"] ? $offer["offer_deny"] : $core->config("offer", "deny");
    $deny = $deny ? explode(",", $deny) : false;
    if ($allow || $deny) {
        $core->tpl->block("body", "source");
        foreach ($allow as $x) {
            $core->tpl->block("body", "source.allow", array("x" => $core->lang["offer_src"][$x]));
        }
        foreach ($deny as $x) {
            $core->tpl->block("body", "source.deny", array("x" => $core->lang["offer_src"][$x]));
        }
    }
    $core->tpl->output("body");
    $core->site->footer();
}
function offerpayments($core, $m, $u, $x, $p, $cur = false)
{
    $line = array();
    if (0 < $p) {
        $line[] = (string) $p . "%";
    }
    if (0 < $m) {
        $line[] = $cur === false ? $core->currency->prnt($m) : $core->currency->show($m, $cur);
    }
    if (0 < $u) {
        $line[] = "<abbr title=\"" . $core->lang["price_up"] . "\">" . ($cur === false ? $core->currency->prnt($u) : $core->currency->show($u, $cur)) . "</abbr>";
    }
    if (0 < $x) {
        $line[] = "<abbr title=\"" . $core->lang["price_xs"] . "\">" . ($cur === false ? $core->currency->prnt($x) : $core->currency->show($x, $cur)) . "</abbr>";
    }
    return implode(" + ", $line);
}

?>