<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function team_menu($core, $menu)
{
    $menu["team"] = array("team", "teambuild");
    return $menu;
}
function team_action($core)
{
    $action = $core->get["a"] ? $core->get["a"] : NULL;
    $id = $core->post["id"] ? (int) $core->post["id"] : ($core->get["id"] ? (int) $core->get["id"] : 0);
    $ci = $core->user->comp;
    $ti = $core->user->team;
    switch ($action) {
        case "team-user-add":
            $name = $core->text->line($core->post["name"]);
            $email = $core->text->email($core->post["email"]);
            $pass = $core->user->pass(trim($core->post["pass"]));
            $uid = $core->db->field("SELECT user_id FROM " . DB_USER . " WHERE user_mail = '" . $email . "' LIMIT 1");
            if (!$uid) {
                $sql = "INSERT INTO " . DB_USER . " SET user_name = '" . $name . "', user_mail = '" . $email . "', user_pass = '" . $pass . "', user_work = 1, user_comp = '" . $ci . "', user_team = '" . $ti . "'";
                if ($name && $email && trim($core->post["pass"]) && $core->db->query($sql)) {
                    $uid = $core->db->lastid();
                    $core->cpa->clear("mans", $core->user->comp);
                    $core->cpa->clear("allman");
                    $core->go($core->url("im", "teambuild", $uid, "ok"));
                } else {
                    $core->go($core->url("mm", "teambuild", "error"));
                }
            } else {
                $core->go($core->url("mm", "teambuild", "exists"));
            }
        case "team-user-edit":
            $user = $core->db->row("SELECT * FROM " . DB_USER . " WHERE user_id = '" . $id . "' LIMIT 1");
            if ($user["user_comp"] && $user["user_comp"] == $ci && $user["user_team"] == $ti) {
                $email = $core->text->email($core->post["email"]);
                if ($email != $user["user_mail"]) {
                    $uid = $core->db->field("SELECT user_id FROM " . DB_USER . " WHERE user_mail = '" . $email . "' LIMIT 1");
                    if ($uid) {
                        $core->go($core->url("mm", "teambuild", "exists"));
                    }
                }
                $data = array("user_name" => $core->text->line($core->post["name"]), "user_mail" => $email, "user_ban" => $core->post["ban"] ? 1 : 0, "user_teamlead" => $core->post["teamlead"] ? 1 : 0);
                if ($pass = trim($core->post["pass"])) {
                    $data["user_pass"] = $core->user->pass($pass);
                }
                if ($data["user_ban"] && ($id == $core->user->id || $user["user_compad"])) {
                    $core->go($core->url("mm", "teambuild", "access"));
                }
                if ($core->user->set($id, $data)) {
                    $core->cpa->clear("mans", $core->user->comp);
                    $core->cpa->clear("allman");
                    $core->go($core->url("mm", "teambuild", "ok"));
                } else {
                    $core->go($core->url("mm", "teambuild", "error"));
                }
            } else {
                $core->go($core->url("mm", "teambuild", "access"));
            }
        case "team-user-del":
            $user = $core->db->row("SELECT * FROM " . DB_USER . " WHERE user_id = '" . $id . "' LIMIT 1");
            if ($id != 1 && $id != $core->user->id && $user["user_comp"] == $ci && $user["user_team"] == $ti) {
                $core->db->query("DELETE FROM " . DB_CASH . " WHERE user_id = '" . $id . "'");
                if ($core->db->query("DELETE FROM " . DB_USER . " WHERE user_id = '" . $id . "'")) {
                    $core->cpa->clear("mans", $core->user->comp);
                    $core->cpa->clear("allman");
                    $core->go($core->url("mm", "teambuild", "ok"));
                } else {
                    $core->go($core->url("mm", "teambuild", "error"));
                }
            } else {
                $core->go($core->url("mm", "teambuild", "access"));
            }
    }
    return false;
}
function team_module($core)
{
    $module = $core->get["m"] ? $core->get["m"] : NULL;
    $id = $core->post["id"] ? (int) $core->post["id"] : ($core->get["id"] ? (int) $core->get["id"] : 0);
    $page = 0 < $core->get["page"] ? (int) $core->get["page"] : 1;
    $message = $core->get["message"] ? $core->get["message"] : NULL;
    $ci = $core->user->comp;
    $ti = $core->user->team;
    $comp = $core->cpa->get("comp", $core->user->comp);
    switch ($module) {
        case "team":
            require_once PATH_MODS . "comp-calls.php";
            callstat($core, "team", $ti);
        case "teambuild":
            switch ($message) {
                case "ok":
                    $core->site->info("info", "done_basic");
                    break;
                case "error":
                    $core->site->info("info", "error_basic");
                    break;
                case "exists":
                    $core->site->info("error", "error_user_exist");
                    break;
                case "access":
                    $core->site->info("error", "access_denied");
                    break;
            }
            if ($id) {
                $user = $core->db->row("SELECT * FROM " . DB_USER . " WHERE user_id = '" . $id . "' LIMIT 1");
                if ($user["user_comp"] != $ci && $user["user_team"] != $ti) {
                    $core->go($core->url("mm", "teambuild", "access"));
                }
                $core->site->bc($core->lang["team"], $core->url("m", "team"));
                $core->site->bc($core->lang["personel"], $core->url("m", "teambuild"));
                $core->site->bc($user["user_name"]);
                $core->site->header();
                $field = array(array("type" => "text", "length" => 100, "name" => "name", "head" => $core->lang["user_name"], "descr" => $core->lang["user_name_d"], "value" => $user["user_name"]), array("type" => "text", "length" => 100, "name" => "email", "head" => $core->lang["user_email"], "descr" => $core->lang["user_email_d"], "value" => $user["user_mail"]), array("type" => "pass", "length" => 32, "name" => "pass", "head" => $core->lang["user_pass"], "descr" => $core->lang["user_pass_d"]), array("type" => "checkbox", "name" => "teamlead", "head" => $core->lang["user_teamlead"], "descr" => $core->lang["user_teamlead_d"], "checked" => $user["user_teamlead"]), array("type" => "checkbox", "name" => "ban", "head" => $core->lang["user_ban"], "descr" => $core->lang["user_ban_d"], "checked" => $user["user_ban"]));
                $core->site->form("useredit", $core->url("a", "team-user-edit", $id), $core->lang["user_edit"], $field);
                $core->site->footer();
            } else {
                $mans = $core->db->data("SELECT * FROM " . DB_USER . " WHERE user_team = '" . $ti . "' ORDER BY user_name ASC");
                $core->site->bc($core->lang["team"], $core->url("m", "team"));
                $core->site->bc($core->lang["personel"]);
                $core->site->header();
                $core->tpl->load("body", "list", defined("HACK_TPL_LIST") ? HACK : false);
                $core->tpl->vars("body", array("title" => $core->lang["team_personel_h"], "text" => $core->text->lines($core->lang["team_personel_t"]), "name" => $core->lang["name"], "info" => $core->lang["access"], "action" => $core->lang["action"], "level" => $core->lang["level"], "edit" => $core->lang["edit"], "del" => $core->lang["del"], "confirm" => $core->lang["confirm"]));
                foreach ($mans as &$i) {
                    if ($i["user_ban"]) {
                        $level = "<b class=\"warn red\">" . $core->lang["ban"] . "</b>";
                    } else {
                        if ($i["user_teamlead"]) {
                            $level = "<span class=\"boss\">" . $core->lang["admin"] . "</span>";
                        } else {
                            $level = $core->lang["user_works"][1];
                        }
                    }
                    $core->tpl->block("body", "item", array("id" => $i["user_id"], "name" => $i["user_name"], "more" => "<a href=\"mailto:" . $i["user_mail"] . "\" class=\"small grey\">" . $i["user_mail"] . "</a>", "info" => $level, "url" => $core->url("i", "teambuild", $i["user_id"]), "edit" => $core->url("i", "teambuild", $i["user_id"]), "del" => $core->url("a", "team-user-del", $i["user_id"])));
                }
                unset($i);
                unset($mans);
                $core->tpl->output("body");
                $field = array(array("type" => "text", "length" => 100, "name" => "name", "head" => $core->lang["user_name"], "descr" => $core->lang["user_name_d"]), array("type" => "text", "length" => 100, "name" => "email", "head" => $core->lang["user_email"], "descr" => $core->lang["user_email_d"]), array("type" => "pass", "length" => 32, "name" => "pass", "head" => $core->lang["user_pass"], "descr" => $core->lang["user_pass_d"]));
                $core->site->form("useradd", $core->url("a", "team-user-add", ""), $core->lang["comp_user_add"], $field, $core->lang["create"]);
                $core->site->footer();
            }
            $core->stop();
    }
    return false;
}

?>