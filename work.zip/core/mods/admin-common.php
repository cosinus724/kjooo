<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function admin_files($core)
{
    $action = isset($core->get["action"]) ? $core->text->link($core->get["action"]) : NULL;
    switch ($action) {
        case "add":
            $ext = strtolower(substr($core->files["file"]["name"], strrpos($core->files["file"]["name"], ".") + 1));
            $name = $core->text->link($core->files["file"]["name"]);
            $ge = array("jpg", "jpeg", "png", "gif", "pdf", "zip", "rar", "7z", "doc", "docx", "xls", "xlsx", "flv");
            if (in_array($ext, $ge)) {
                move_uploaded_file($core->files["file"]["tmp_name"], DIR_NEWS . $name);
            }
            $core->go($core->url("m", "files"));
        case "del":
            $name = $core->text->link($core->get["name"]);
            @unlink(DIR_NEWS . $name);
            $core->go($core->url("m", "files"));
    }
    $d = opendir(DIR_NEWS);
    $files = array();
    while ($f = readdir($d)) {
        if (is_file(DIR_NEWS . $f)) {
            $files[] = $f;
        }
    }
    closedir($d);
    sort($files);
    $core->tpl->load("body", "files");
    $core->tpl->vars("body", array("u_load" => $core->url("ma", "file", "add"), "upload" => $core->lang["upload"], "delete" => $core->lang["del"], "confirm" => $core->lang["confirm"]));
    foreach ($files as $f) {
        $core->tpl->block("body", "file", array("url" => sprintf(PATH_NEWS, $f), "size" => mkb(filesize(DIR_NEWS . $f)), "time" => date("d.m.Y H:i:s", filemtime(DIR_NEWS . $f)), "name" => $f, "del" => $core->u("files", array("action" => "del", "name" => $f))));
    }
    $core->tpl->output("body");
    $core->stop();
}

?>