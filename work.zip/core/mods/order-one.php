<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function order_module_one($core, $id)
{
    $action = $core->post["action"] ? $core->text->link($core->post["action"]) : $core->text->link($core->get["action"]);
    if ($action) {
        switch ($action) {
            case "addr":
                require_once PATH_LIB . "addr.php";
                $addr = $core->post["addr"] ? $core->text->line($core->post["addr"]) : $core->text->line($core->get["addr"]);
                echo checkaddr($addr);
                $core->stop();
            case "vkarea":
                $c = $core->text->link($core->get["c"]);
                $q = $core->text->line($core->get["q"]);
                $result = "";
                if (1 < mb_strlen($q) && ($ci = $core->lang["vkcid"][$c])) {
                    $data = json_decode(curl("https://api.vk.com/method/database.getRegions?count=10&country_id=" . $ci . "&q=" . $q), true);
                    if ($data["response"]) {
                        foreach ($data["response"] as $r) {
                            $result .= "<a href=\"#\" onclick=\"return sr(this);\">" . $r["title"] . "</a>";
                        }
                    }
                }
                echo $result;
                $core->stop();
            case "vkcity":
                $c = $core->text->link($core->get["c"]);
                $q = $core->text->line($core->get["q"]);
                $result = "";
                if (1 < mb_strlen($q) && ($ci = $core->lang["vkcid"][$c])) {
                    $data = json_decode(curl("https://api.vk.com/method/database.getCities?count=10&country_id=" . $ci . "&q=" . $q), true);
                    if ($data["response"]) {
                        foreach ($data["response"] as $r) {
                            $region = trim($r["region"]);
                            $city = $pcity = trim($r["title"]);
                            if ($r["area"]) {
                                $pcity = trim($r["area"]) . ", " . $city;
                                $city .= ", " . trim($r["area"]);
                            }
                            if ($region) {
                                $city .= ", " . $region;
                            }
                            $region = addslashes($region);
                            $pcity = addslashes($pcity);
                            $result .= "<a href=\"#\" onclick=\"return sc('" . $pcity . "','" . $region . "');\">" . $city . "</a>" . "\n";
                        }
                    }
                }
                echo $result;
                $core->stop();
            case "edit":
                $changes = array();
                $order = $core->db->row("SELECT * FROM " . DB_ORDER . " WHERE order_id = '" . $id . "' LIMIT 1");
                $status = $order["order_status"];
                $ct = $core->cpa->get("comp", $order["comp_id"], "comp_type");
                if (isset($core->post["name"])) {
                    $changes["name"] = $core->text->line($core->post["name"]);
                }
                if (isset($core->post["email"])) {
                    $changes["email"] = $core->text->email($core->post["email"]);
                }
                if (isset($core->post["phone"])) {
                    $changes["phone"] = preg_replace("#([^0-9]+)#", "", $core->post["phone"]);
                }
                if (isset($core->post["comment"])) {
                    $changes["comment"] = $core->text->line($core->post["comment"]);
                }
                if (isset($core->post["country"])) {
                    $changes["country"] = $core->text->link($core->post["country"]);
                }
                if (isset($core->post["addr"])) {
                    $changes["addr"] = $core->text->line($core->post["addr"]);
                }
                if (isset($core->post["area"])) {
                    $changes["area"] = $core->text->line($core->post["area"]);
                }
                if (isset($core->post["city"])) {
                    $changes["city"] = $core->text->line($core->post["city"]);
                }
                if (isset($core->post["street"])) {
                    $changes["street"] = $core->text->line($core->post["street"]);
                }
                if (isset($core->post["index"])) {
                    $changes["index"] = (int) $core->post["index"];
                }
                if (isset($core->post["track"])) {
                    $changes["track"] = $core->text->line($core->post["track"]);
                }
                if (isset($core->post["curr"])) {
                    $changes["curr"] = (int) $core->post["curr"];
                }
                if (isset($core->post["discount"])) {
                    $changes["discount"] = (int) $core->post["discount"];
                }
                if (isset($core->post["delivery"])) {
                    $changes["delivery"] = (int) $core->post["delivery"];
                }
                if (isset($core->post["delpr"])) {
                    $changes["delpr"] = $core->text->float($core->post["delpr"]);
                }
                if (isset($core->post["more"])) {
                    $changes["more"] = $core->text->float($core->post["more"]);
                }
                if (isset($core->post["base"])) {
                    if (is_array($core->post["base"])) {
                        $changes["base"] = array();
                        foreach ($core->post["base"] as $i => $c) {
                            if ($c = $core->text->float($c)) {
                                $changes["base"][(int) $i] = $c;
                            }
                        }
                    } else {
                        $changes["base"] = $core->text->float($core->post["base"]);
                    }
                }
                if (isset($core->post["counts"])) {
                    if (is_array($core->post["counts"])) {
                        $changes["counts"] = array();
                        foreach ($core->post["counts"] as $i => $c) {
                            if ($c = (int) $c) {
                                $changes["counts"][(int) $i] = $c;
                            }
                        }
                    } else {
                        $changes["counts"] = (int) $core->post["counts"];
                    }
                }
                if (isset($core->post["meta"]) && is_array($core->post["meta"])) {
                    $changes["meta"] = array();
                    foreach ($core->post["meta"] as $k => $v) {
                        $changes["meta"][$k] = stripslashes($v);
                    }
                }
                if (isset($core->post["start"]) && ($st = (int) $core->post["start"])) {
                    $ln = time() - $st;
                    if ($ln < 3600) {
                        $changes["length"] = $ln;
                    }
                }
                $act = $core->text->link($core->post["act"]);
                switch ($status) {
                    case 2:
                    case 3:
                    case 4:
                        if ($act) {
                            $changes["calls"] = 1;
                        }
                        if ($act == "accept") {
                            if ($hh = (int) $core->post["hold"]) {
                                $changes["hold"] = $hh;
                            } else {
                                $changes["accept"] = 1;
                                if ($ct) {
                                    $changes["comp"] = (int) $core->post["comp"];
                                }
                            }
                        }
                        if ($act == "cancel") {
                            $changes["status"] = 5;
                            $changes["reason"] = (int) $core->post["reason"];
                        }
                        if ($act == "recall" || $act == "nocall") {
                            $changes["status"] = $act == "recall" ? 3 : 4;
                            $rcd = date2form(form2date($core->post["rcdate"]));
                            $changes["rec"] = $rcd ? strtotime(sprintf("%s %02d:%02d", $rcd, (int) $core->post["rchour"], (int) $core->post["rcmins"])) : strtotime("+15 minutes");
                        }
                        break;
                    case 5:
                        if ($act == "accept") {
                            $changes["accept"] = 1;
                        }
                        if ($act == "process") {
                            $changes["status"] = 2;
                        }
                        break;
                    case 6:
                        if ($act == "done") {
                            $changes["status"] = 7;
                        }
                        if ($act == "cancel") {
                            $changes["status"] = 5;
                            $changes["reason"] = (int) $core->post["reason"];
                        }
                        break;
                    case 7:
                        if ($act == "done") {
                            $changes["status"] = 8;
                        }
                        if ($act == "back") {
                            $changes["status"] = 6;
                        }
                        if ($act == "cancel") {
                            $changes["status"] = 5;
                            $changes["reason"] = (int) $core->post["reason"];
                        }
                        break;
                    case 8:
                    case 9:
                        if ($act == "done") {
                            $changes["status"] = $status + 1;
                        }
                        if ($act == "return") {
                            $changes["status"] = 11;
                        }
                        if ($act == "back") {
                            $changes["status"] = $status - 1;
                        }
                        break;
                }
                switch ($act) {
                    case "accept":
                    case "cancel":
                    case "return":
                    case "back":
                    case "done":
                        $changes["stage"] = (int) $core->post["stage"][$act];
                        break;
                    case "recall":
                    case "nocall":
                    case "tocall":
                    case "uncall":
                        $changes["stage"] = (int) $core->post["stage"]["recall"];
                        break;
                    default:
                        if (isset($core->post["stage"]["main"]) && $core->post["stage"]["main"] != "") {
                            $changes["stage"] = (int) $core->post["stage"]["main"];
                        }
                }
                if ($core->post["check"]) {
                    $changes["check"] = 1;
                }
                if ($core->post["uncheck"]) {
                    $changes["check"] = 0;
                }
                require_once PATH_MODS . "order-edit.php";
                if (order_edit($core, $id, $changes, $order)) {
                    if ($core->post["delip"] || $core->post["delphone"]) {
                        $sql = "SELECT order_id FROM " . DB_ORDER . " WHERE order_id != '" . $order["order_id"] . "' AND order_status < 4 AND comp_id = '" . $order["comp_id"] . "'";
                        if ($core->post["delip"]) {
                            $sql .= " AND order_ip = '" . $order["order_ip"] . "'";
                        }
                        if ($core->post["delphone"]) {
                            $sql .= " AND order_phone = '" . $order["order_phone"] . "'";
                        }
                        $ids = $core->db->col($sql);
                        foreach ($ids as $i) {
                            order_edit($core, $i, array("status" => 5, "reason" => 7));
                        }
                    }
                    if ($core->post["next"]) {
                        $core->go($core->url("ma", "order", "pickup"));
                    } else {
                        $core->go($core->post["r"] ? $core->post["r"] : $core->url("mm", "order", "save"));
                    }
                } else {
                    $core->go($core->url("im", "order", $id, "oerror"));
                }
            case "retrack":
                $core->cpa->dltrack($id);
                msgo($core, "ok");
            case "move":
                $comp = (int) $core->post["comp"];
                if ($core->user->level && $comp) {
                    require_once PATH_MODS . "order-edit.php";
                    $result = order_edit($core, $id, array("comp" => $comp));
                } else {
                    $result = false;
                }
                if ($core->get["ajax"]) {
                    echo $result ? "ok" : "error";
                    $core->stop();
                } else {
                    msgo($core, $result ? "move" : "nomove");
                }
        }
    }
    $order = $core->db->row("SELECT * FROM " . DB_ORDER . " WHERE order_id = '" . $id . "' LIMIT 1");
    if ($core->user->level < 1 && $order["comp_id"] != $core->user->comp && $order["cc_id"] != $core->user->comp) {
        $core->go($core->url("mm", "", "access"));
    }
    $offer = $core->cpa->get("offer", $order["offer_id"]);
    $comp = $core->cpa->get("comp", $order["comp_id"]);
    $allstages = $core->cpa->stages($order["comp_id"], -1, 1);
    $vars = $offer["offer_vars"] ? $core->cpa->get("vars", $offer["offer_id"]) : false;
    $canmove = $core->order->canmove($order["order_status"], $order["offer_id"]);
    $canitem = $core->order->canitem($order["order_status"], $order["offer_id"]);
    $canedit = $core->order->canedit($order["order_status"], $order["offer_id"]);
    if ($core->cpa->get("comp", $core->user->comp, "comp_type") && $order["comp_id"] != $core->user->comp) {
        $canitem = $canedit = false;
    }
    if ($canedit) {
        switch ($action) {
            case "prices":
                $c = (int) $core->get["curr"];
                $p = $offer["offer_prt"] ? unserialize($offer["offer_prt"]) : array();
                $price = array("base" => (int) $p[$c], "delpr" => (int) $core->lang["deliverbase"][$c], "vars" => array());
                if ($offer["offer_vars"]) {
                    foreach ($vars as $vv) {
                        $vp = $vv["var_price"] ? unserialize($vv["var_price"]) : array();
                        $price["vars"][] = array((int) $vv["var_id"], (int) $vp[$c]);
                    }
                }
                echo json_encode($price);
                $core->stop();
            case "mark":
                switch ($order["order_status"]) {
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                        $st = "1,2,3,4";
                        break;
                    case 6:
                    case 7:
                        $st = "6,7";
                        break;
                    default:
                        $st = $order["order_status"];
                }
                $core->db->query("UPDATE " . DB_ORDER . " SET mark_id = '" . $core->user->id . "', mark_time = '" . time() . "' WHERE order_status IN ( " . $st . " ) AND order_phone = '" . $o["order_phone"] . "'");
                $core->stop();
            case "dlaction":
                $action = $core->text->link($core->get["oa"]);
                $core->cpa->dlaction($order, $action);
                msgo($core, "ok");
            case "script":
                $o = $offer["offer_call"];
                $o = preg_replace("#\\[block\\=\\\"(.*?)\\\"\\]#si", "<div class=\"callscript-block\"><a href=\"#\" class=\"plusi\" onclick=\"\$(this).next().toggle(); return false;\">\$1</a><div class=\"csbin\" style=\"display:none;\">", $o);
                $o = str_replace("[/block]", "</div></div>", $o);
                echo "<div class=\"callscript\">" . $o . "</div>";
                $core->stop();
            case "send":
                $code = $core->text->line($core->post["code"]);
                require_once PATH_MODS . "order-edit.php";
                if (order_edit($core, $id, array("status" => 8, "track" => $code))) {
                    msgo($core, "send");
                } else {
                    msgo($core, "nocode");
                }
            case "promo-acc":
                if ($core->db->query("UPDATE " . DB_ORDER . " SET promo_status = 1 WHERE order_id = '" . $id . "'")) {
                    msgo($core, "done");
                } else {
                    msgo($core, "error");
                }
            case "promo-dec":
                if ($core->db->query("UPDATE " . DB_ORDER . " SET promo_status = 2 WHERE order_id = '" . $id . "'")) {
                    msgo($core, "done");
                } else {
                    msgo($core, "error");
                }
        }
    }
    $site = $order["site_id"] ? $core->cpa->get("site", $order["site_id"], "site_url") : false;
    $space = $order["space_id"] ? $core->cpa->get("site", $order["space_id"], "site_url") : false;
    $oips = $core->db->field("SELECT COUNT(*) FROM " . DB_ORDER . " WHERE order_ip = '" . $order["order_ip"] . "'" . ($core->user->level ? "" : " AND comp_id = '" . $order["comp_id"] . "'"));
    $ophs = $core->db->field("SELECT COUNT(*) FROM " . DB_ORDER . " WHERE order_phone = '" . $order["order_phone"] . "'" . ($core->user->level ? "" : " AND comp_id = '" . $order["comp_id"] . "'"));
    $order["items"] = $order["order_items"] ? unserialize($order["order_items"]) : array();
    $user = $order["wm_id"] ? $core->user->get($order["wm_id"]) : array();
    $uc = $core->user->comp ? $core->cpa->get("comp", $core->user->comp) : array();
    $callscheme = $uc["callscheme"] ? $uc["callscheme"] : "tel:+%s";
    $oph = $core->db->row("SELECT * FROM " . DB_PDB . " WHERE `phone` = '" . substr($order["order_phone"], 1, 6) . "' LIMIT 1");
    if ($oph) {
        $ophone = $oph["operator"];
        if ($oph["region"]) {
            $ophone .= " (" . $oph["region"] . ($oph["city"] ? ", " . $oph["city"] : "") . ")";
        }
    } else {
        $ophone = $core->lang["order_phone_na"];
        $p1 = (int) substr($order["order_phone"], 0, 1);
        if ($pq = $core->lang["ph2cn"][$p1]) {
            $ophone = $core->lang["country"][$pq];
        }
        $p2 = (int) substr($order["order_phone"], 0, 2);
        if ($pq = $core->lang["ph2cn"][$p2]) {
            $ophone = $core->lang["country"][$pq];
        }
        $p3 = (int) substr($order["order_phone"], 0, 3);
        if ($pq = $core->lang["ph2cn"][$p3]) {
            $ophone = $core->lang["country"][$pq];
        }
        $p4 = (int) substr($order["order_phone"], 0, 4);
        if ($pq = $core->lang["ph2cn"][$p4]) {
            $ophone = $core->lang["country"][$pq];
        }
    }
    $addr = $order["order_addr"];
    if ($order["order_street"]) {
        $addr = $order["order_street"] . ", " . $addr;
    }
    if ($order["order_city"]) {
        $addr = $order["order_city"] . ", " . $addr;
    }
    if ($order["order_area"]) {
        $addr = $order["order_area"] . ", " . $addr;
    }
    if ($offer["offer_paramurl"]) {
        $cache = sprintf(PATH_CACHE, md5($order["order_meta"]));
        if (!file_exists($cache)) {
            $post = unserialize($order["order_meta"]);
            $form = curl($offer["offer_paramurl"], $post);
            file_put_contents($cache, $form);
        } else {
            $form = file_get_contents($cache);
        }
    } else {
        $form = NULL;
    }
    if ($order["geoip_country"]) {
        $geoip = $order["geoip_city"] ? $order["geoip_city"] : "";
        if ($order["geoip_region"]) {
            $geoip .= ", " . $order["geoip_region"];
        }
        if ($order["geoip_district"]) {
            $geoip .= ", " . $order["geoip_district"];
        }
        $geoip = trim($geoip, ", ");
        if ($geoip && $order["geoip_lat"] && $order["geoip_lng"]) {
            $geoip = "<a target=\"_blank\" href=\"http://maps.yandex.ru/?ll=" . $order["geoip_lng"] . "%2C" . $order["geoip_lat"] . "\">" . $geoip . "</a>";
        }
    }
    $mxmt = time() - 60;
    if ($mxmt < $order["mark_time"] && $order["mark_id"] != $core->user->id) {
        $core->site->info("error", sprintf($core->lang["order_marked"], $core->user->get($order["mark_id"], "user_name"), date("H:i:s", $order["mark_time"])));
    } else {
        if ($core->user->work == 1 && $canedit) {
            $core->tpl->block("body", "marker");
        }
    }
    $core->site->bc($core->lang["orders_h"], $core->url("m", "order"));
    $core->site->bc($offer["offer_name"]);
    $core->site->bc($order["order_name"]);
    $core->site->header();
    $core->tpl->load("body", "order", defined("HACK_TPL_ORDER") ? HACK : false);
    $core->tpl->vars("body", $offer);
    $core->tpl->vars("body", $order);
    if ($core->user->work == 2) {
        $uname = $user["user_name"];
        if (!($order["ext_id"] || $user["user_vip"])) {
            $uname = $core->text->cut($user["user_mail"], 20);
        }
    } else {
        $uname = $order["wm_id"];
    }
    $core->tpl->vars("body", array("u_edit" => $core->url("ia", "order", $id, "edit"), "u_addr" => $core->url("ia", "order", $id, "addr"), "u_vkcity" => $core->url("ia", "order", $id, "vkcity"), "u_vkarea" => $core->url("ia", "order", $id, "vkarea"), "u_price" => $core->url("ia", "order", $id, "prices") . "&curr=", "u_script" => $core->url("ia", "order", $id, "script"), "u_mark" => $core->url("ia", "order", $id, "mark"), "start" => time(), "order" => $core->lang["order"], "save" => $core->lang["order_save"], "justsave" => $core->lang["order_justsave"], "next" => $core->lang["order_save_next"], "action" => $core->lang["order_work_action"], "mark" => $core->lang["order_marks"], "source" => $core->lang["source"], "comp" => $core->lang["company"], "site" => $core->lang["site"], "space" => $core->lang["stat_spaces"], "store" => $core->lang["store"], "count" => $core->lang["count"], "price" => $core->lang["price"], "more_price" => $core->lang["order_more"], "total" => $core->lang["total"], "name" => $core->lang["name"], "oname" => $core->lang["order_name"], "email" => $core->lang["email"], "fio" => $core->lang["username"], "address" => $core->lang["order_addr"], "address_d" => $core->lang["order_addr_d"], "street" => $core->lang["street"], "city" => $core->lang["city"], "area" => $core->lang["area"], "phone" => $core->lang["phone"], "index" => $core->lang["index"], "ocountry" => $core->lang["order_country"], "comment" => $core->lang["order_comment"], "call" => $core->lang["call"], "track" => $core->lang["track"], "checkaddr" => $core->lang["order_checkaddr"], "checkaddrerror" => $core->lang["order_checkaddr_error"], "delivery" => $core->lang["deliver"], "nodelivery" => $core->lang["delivery"][0], "discount" => $core->lang["discount"], "stage" => $core->lang["comp_stage"], "nostage" => $core->lang["comp_stage_no"], "keepstage" => $core->lang["comp_stage_keep"], "callscript" => $core->lang["oi_ccs"], "ophwarn" => $core->lang["order_phwarn"], "ophban" => $core->lang["order_phban"], "oipwarn" => $core->lang["order_ipwarn"], "oipban" => $core->lang["order_ipban"], "order_extu" => $core->lang["order_extu"], "order_exts" => $core->lang["order_exts"], "order_exto" => $core->lang["order_exto"], "order_ismob" => $core->lang["order_ismob"], "order_isbad" => $core->lang["order_isbad"], "order_reprice" => $core->lang["order_reprice"], "country" => $order["order_country"] ? $order["order_country"] : ($order["geoip_country"] ? $order["geoip_country"] : "zz"), "currency" => $core->currency->upcode($order["price_cur"]), "curname" => $core->currency->name($order["price_cur"]), "vkcid" => json_encode($core->lang["vkcid"]), "geoip" => $geoip, "geoip_cname" => $core->lang["country"][$order["geoip_country"]], "form" => $form, "status" => $core->lang["statuso"][$order["order_status"]], "date" => smartdate($order["order_time"]), "fulladdr" => $addr, "r" => $core->server["HTTP_REFERER"], "site_url" => $site, "space_url" => $space, "comp_name" => $comp["comp_name"], "order_stage" => $allstages[$order["order_stage"]], "settrack" => $offer["offer_delivery"] && 6 < $order["order_status"] && $order["order_status"] < 12 ? true : false, "callscheme" => $callscheme, "phone_call" => sprintf($callscheme, $order["order_phone"]), "phone_info" => $ophone, "ispaid" => $core->lang["order_ispaid"], "paid_type" => $core->lang["order_paid"][$order["paid_ok"]], "paid_date" => smartdate($order["paid_time"]), "paid_info" => $core->text->lines($order["paid_from"]), "order_ip" => int2ip($order["order_ip"]), "order_mobile" => $order["order_mobile"] ? $core->lang["order_mobile"] : false, "order_bad" => $order["order_bad"] ? $core->lang["order_bad"] : false, "ipwarn" => 1 < $oips ? numinf($core->lang["order_others"], $oips) : false, "ipwarnu" => $core->url("m", "order?s=") . int2ip($order["order_ip"]), "phwarn" => 1 < $ophs ? numinf($core->lang["order_others"], $ophs) : false, "phwarnu" => $core->url("m", "order?s=") . $order["order_phone"], "wm_name" => $order["wm_id"] ? $user["user_level"] ? "<b>" . $uname . "</b>" : $uname : $core->lang["order_src_sh"], "wm_class" => $order["wm_id"] ? $order["ext_id"] ? "ext" : ($user["user_ban"] ? "warn" : ($user["user_warn"] ? "ua" : ($user["user_vip"] ? "vip" : "user"))) : "search", "promo_code" => $core->lang["promo_code"], "promo_code_d" => $core->lang["promo_code_d"], "promo_status" => $core->lang["promo_code_s"], "promo_accept" => $core->lang["promo_accept"], "promo_decline" => $core->lang["promo_decline"], "promo_confirma" => $core->lang["promo_confirma"], "promo_confirmd" => $core->lang["promo_confirmd"], "hide_items" => $uc["hide_items"] ? 1 : 0, "hide_audio" => $uc["hide_audio"] ? 1 : 0, "hide_status" => $uc["hide_status"] ? 1 : 0, "hide_change" => $uc["hide_change"] ? 1 : 0));
    if ($site) {
        $core->tpl->block("body", "site");
    }
    if ($space) {
        $core->tpl->block("body", "space");
    }
    if ($form) {
        $core->tpl->block("body", "form");
    }
    if ($order["paid_ok"]) {
        $core->tpl->block("body", "paid");
    }
    if ($order["order_file"]) {
        $core->tpl->block("body", "file");
    }
    foreach ($core->lang["country"] as $cc => $cn) {
        $core->tpl->block("body", "cosel", array("code" => $cc, "vk" => $core->lang["vkcid"][$cc], "name" => $cn, "sel" => $cc == $order["order_country"] ? "selected=\"selected\"" : ""));
    }
    if (defined("PROMO")) {
        $core->tpl->block("body", "promocode", array("text" => enpromo($order["order_phone"])));
        if ($order["promo_code"]) {
            $core->tpl->block("body", "promostatus", array("code" => $order["promo_code"], "phone" => depromo($order["promo_code"]), "stid" => $order["promo_status"], "status" => $core->lang["promo_status"][$order["promo_status"]], "accept" => $core->url("ia", "order", $order["order_id"], "promo-acc"), "decline" => $core->url("ia", "order", $order["order_id"], "promo-dec")));
            if ($order["order_status"] == 10 && $order["promo_status"] == 0) {
                $core->tpl->block("body", "promostatus.action");
            }
        }
    }
    if ($canitem) {
        $core->tpl->block("body", "edit");
        if ($offer["offer_delivery"]) {
            $core->tpl->block("body", "edit.delivery");
        }
        if ($offer["offer_line"]) {
            $core->tpl->vars("body", array("line" => $offer["offer_line"]));
        }
    } else {
        $core->tpl->block("body", "view");
    }
    $core->tpl->block("body", $canedit ? "editinfo" : "viewinfo");
    if ($vars) {
        $ndprice = 0;
        $vtype = 3;
        $items = $order["order_items"] ? unserialize($order["order_items"]) : array();
        foreach ($vars as $v) {
            if ($vtype != $v["var_type"]) {
                $core->tpl->block("body", "items", array("name" => $core->lang["varstype"][$v["var_type"]]));
                $vtype = $v["var_type"];
            }
            $vpr = $v["var_price"] ? unserialize($v["var_price"]) : array();
            $ipr = isset($items[$v["var_id"]][1]) ? $items[$v["var_id"]][1] : $vpr[$order["price_cur"]];
            $core->tpl->block("body", "items.item", array("id" => $v["var_id"], "name" => $v["var_name"], "single" => $v["var_single"], "base" => $ipr ? $ipr : 0, "count" => (int) $items[$v["var_id"]][0], "total" => $ipr * (int) $items[$v["var_id"]][0]));
            if ($canitem) {
                $core->tpl->block("body", "items.item.edit");
            } else {
                $core->tpl->block("body", "items.item.view");
            }
            $ndprice += $ipr * (int) $items[$v["var_id"]][0];
        }
    } else {
        $core->tpl->block("body", "single", array("name" => $offer["offer_name"], "total" => $order["price_base"] * (int) $order["order_count"]));
        if ($canitem) {
            $core->tpl->block("body", "single.edit");
        } else {
            $core->tpl->block("body", "single.view");
        }
        $ndprice = $order["price_base"] * (int) $order["order_count"];
    }
    if ($canitem) {
        $core->tpl->block("body", "dcedit", array("total" => $ndprice * (100 - $order["order_discount"]) / 100));
        foreach ($core->lang["discounts"] as $i => $n) {
            $core->tpl->block("body", "dcedit.line", array("id" => $i, "name" => $n, "check" => $i == $order["order_discount"] ? "selected=\"selected\"" : ""));
        }
    } else {
        $core->tpl->block("body", "dcview", array("name" => $core->lang["discounts"][$order["order_discount"]], "total" => $ndprice * (100 - $order["order_discount"]) / 100));
    }
    if ($offer["offer_delivery"]) {
        $core->tpl->block("body", "delivery", array("name" => $core->lang["delivery"][$order["order_delivery"]]));
        if ($canitem) {
            $core->tpl->block("body", "delivery.edit");
            $dlvs = $core->cpa->dltypes($order["comp_id"]);
            foreach ($dlvs as $i => $n) {
                $core->tpl->block("body", "delivery.edit.line", array("id" => $i, "name" => $core->lang["delivery"][$i], "price" => $n["price"], "check" => $i == $order["order_delivery"] ? "selected=\"selected\"" : ""));
            }
        } else {
            $core->tpl->block("body", "delivery.view");
        }
        $dlo = $core->cpa->dloptions($order);
        if ($dlo) {
            foreach ($dlo as $opt) {
                $core->tpl->block("body", "delopt", $opt);
            }
        }
        if ($canedit && 6 < $order["order_status"] && $order["order_status"] < 10) {
            $core->tpl->block("body", "track");
        }
        if ($order["track_code"]) {
            $core->tpl->block("body", "delopt", array("icon" => "fa-refresh", "url" => $core->url("ia", "order", $order["order_id"], "retrack"), "name" => $core->lang["delivery_check"]));
        }
    }
    if ($canitem) {
        $cids = $core->currency->geoline($offer["offer_country"]);
        foreach ($cids as $i) {
            $core->tpl->block("body", "edit.curr", array("id" => $i, "name" => $core->currency->name($i), "code" => $core->currency->upcode($i), "check" => $i == $order["price_cur"] ? "selected=\"selected\"" : ""));
        }
    }
    $actns = false;
    if ($canedit) {
        if (1 < $order["order_status"] && $order["order_status"] < 5) {
            $core->tpl->block("body", "accept", array("text" => $core->lang["order_accept"], "to" => $core->lang["order_accept_to"], "after" => $core->lang["order_accept_after"], "days" => $core->lang["order_accept_days"]));
            $hold = false;
            $ofps = $core->cpa->get("ofp", $offer["offer_id"]);
            if ($offer["offer_hold"] || isset($ofps["hold-wm" . $order["wm_id"]])) {
                $hold = isset($ofps["hold-wm" . $order["wm_id"]]) ? $ofps["hold-wm" . $order["wm_id"]] : $offer["offer_hold"];
                if ($order["order_auto"]) {
                    $hold = round(($order["order_auto"] - time()) / 86400);
                }
                $core->tpl->block("body", "accept.hold", array("dc" => $hold));
            } else {
                if ($comp["comp_type"]) {
                    $ocmp = preg_split("/[\\s\\,]+/", $offer["out_comps"], -1, PREG_SPLIT_NO_EMPTY);
                    if ($ocmp) {
                        $cmps = $core->cpa->get("comps");
                        $core->tpl->block("body", "accept.move");
                        foreach ($cmps as $c => $n) {
                            if (in_array($c, $ocmp)) {
                                $core->tpl->block("body", "accept.move.comp", array("v" => $c, "n" => $n));
                            }
                        }
                    }
                }
            }
            $sss1 = $core->cpa->stages($order["comp_id"], $comp["autoaccept"] ? 10 : 6);
            $sss2 = $hold !== false ? $core->cpa->stages($order["comp_id"], 4) : array();
            $sss = array_merge($sss1, $sss2);
            if ($sss) {
                $core->tpl->block("body", "accept.stage");
                foreach ($sss as $sv => $sn) {
                    $core->tpl->block("body", "accept.stage.one", array("n" => $sn, "v" => $sv));
                }
            }
            $rctime = strtotime("+15 minutes");
            $rcdate = date("Y-m-d", $rctime);
            $rchour = (int) date("H", $rctime);
            $rcmins = round((int) date("i", $rctime) / 5) * 5;
            $core->tpl->block("body", "recall", array("next" => $core->lang["order_nextcall"], "at" => $core->lang["order_nextcall_at"], "date" => $rcdate));
            $core->tpl->block("body", "recall.type", array("v" => "recall", "n" => $core->lang["order_recall"]));
            for ($a = 0; $a < 24; $a++) {
                $core->tpl->block("body", "recall.hour", array("t" => sprintf("%02d", $a), "s" => $a == $rchour));
            }
            $a = 0;
            while ($a < 60) {
                $core->tpl->block("body", "recall.min", array("t" => sprintf("%02d", $a), "s" => $a == $rcmins));
                $a += 5;
            }
            if ($sss = $core->cpa->stages($order["comp_id"], 2)) {
                $core->tpl->block("body", "recall.stage");
                foreach ($sss as $sv => $sn) {
                    $core->tpl->block("body", "recall.stage.one", array("n" => $sn, "v" => $sv));
                }
            }
        } else {
            if ($order["order_status"] == 5) {
                $actns = $core->lang["cancelo"];
            } else {
                if ($order["order_status"] == 6) {
                    $actns = $core->lang["packingo"];
                } else {
                    if ($order["order_status"] == 7) {
                        $actns = $core->lang["sendingo"];
                    } else {
                        if ($order["order_status"] == 8) {
                            $actns = $core->lang["delivero"];
                        } else {
                            if ($order["order_status"] == 9) {
                                $actns = $core->lang["payo"];
                            }
                        }
                    }
                }
            }
        }
        if (1 < $order["order_status"] && $order["order_status"] < 8 && $order["order_status"] != 5) {
            $core->tpl->block("body", "cancel", array("text" => $core->lang["order_cancel_l"], "reason" => $core->lang["order_reason"]));
            foreach ($core->lang["reasono"] as $v => $n) {
                $core->tpl->block("body", "cancel.reason", array("v" => $v, "n" => $n));
            }
            if ($sss = $core->cpa->stages($order["comp_id"], 5)) {
                $core->tpl->block("body", "cancel.stage");
                foreach ($sss as $sv => $sn) {
                    $core->tpl->block("body", "cancel.stage.one", array("n" => $sn, "v" => $sv));
                }
            }
        }
        if (1 < $order["order_status"] && $order["order_status"] < 4) {
            $marks = array();
            if (1 < $oips) {
                $ooips = $core->db->field("SELECT COUNT(*) FROM " . DB_ORDER . " WHERE order_id != '" . $id . "' AND order_ip = '" . $order["order_ip"] . "' AND order_status < 4 AND comp_id = '" . $order["comp_id"] . "'");
                if ($ooips) {
                    $marks["delip"] = sprintf($core->lang["order_del_ip"], $ooips);
                }
            }
            if (1 < $ophs) {
                $oophs = $core->db->field("SELECT COUNT(*) FROM " . DB_ORDER . " WHERE order_id != '" . $id . "' AND order_phone = '" . $order["order_phone"] . "' AND order_status < 4 AND comp_id = '" . $order["comp_id"] . "'");
                if ($oophs) {
                    $marks["delphone"] = sprintf($core->lang["order_del_phone"], $oophs);
                }
            }
        } else {
            $marks = array();
        }
        if (1 < $order["order_status"] && $order["order_status"] < 10 && $order["order_status"] != 5) {
            if ($order["order_check"]) {
                $marks["uncheck"] = $core->lang["order_uncheck"];
            } else {
                $marks["check"] = $core->lang["order_tocheck"];
            }
        }
        $core->tpl->block("body", "buttons");
        if ($sss = $core->cpa->stages($order["comp_id"], $order["order_status"])) {
            $core->tpl->block("body", "buttons.stage");
            foreach ($sss as $sv => $sn) {
                $core->tpl->block("body", "buttons.stage.one", array("n" => $sn, "v" => $sv));
            }
        }
        if ($marks) {
            foreach ($marks as $v => $n) {
                $core->tpl->block("body", "mark", array("n" => $n, "v" => $v));
            }
        }
        if ($actns) {
            foreach ($actns as $v => $n) {
                $core->tpl->block("body", "action", array("n" => $n, "v" => $v));
                switch ($v) {
                    case "accept":
                        $sss = $core->cpa->stages($order["comp_id"], $comp["autoaccept"] ? 10 : 6);
                        break;
                    case "process":
                        $sss = $core->cpa->stages($order["comp_id"], 2);
                        break;
                    case "done":
                        $sss = $core->cpa->stages($order["comp_id"], $order["order_status"] + 1);
                        break;
                    case "back":
                        $sss = $core->cpa->stages($order["comp_id"], $order["order_status"] - 1);
                        break;
                    case "return":
                        $sss = $core->cpa->stages($order["comp_id"], 11);
                        break;
                    default:
                        $sss = false;
                }
                if ($sss) {
                    $core->tpl->block("body", "action.stage");
                    foreach ($sss as $sv => $sn) {
                        $core->tpl->block("body", "action.stage.one", array("n" => $sn, "v" => $sv));
                    }
                }
            }
        }
    }
    if ($order["order_status"] == 1 && $canmove[2]) {
        $core->tpl->block("body", "pickup", array("u" => $core->url("ia", "order", $id, "pickup"), "t" => $core->lang["order_pick_up"], "c" => $core->lang["order_pick_confirm"]));
    }
    $track = $order["has_track"] ? $core->db->data("SELECT * FROM " . DB_TRACK . " WHERE order_id = '" . $order["order_id"] . "' ORDER BY track_id ASC") : array();
    if ($track) {
        $core->tpl->block("body", "tracking", array("title" => $core->lang["delivery_track"], "time" => $core->lang["date"], "status" => $core->lang["status"], "zip" => $core->lang["index"], "city" => $core->lang["city"], "comment" => $core->lang["comment"], "country" => $core->lang["order_country"]));
        foreach ($track as $t) {
            $core->tpl->block("body", "tracking.row", array("stid" => $t["track_status"], "status" => $core->lang["dlstatus"][$t["track_status"]], "time" => smartdate($t["track_time"]), "country" => $core->lang["country"][$t["track_country"]], "zip" => $t["track_zip"], "city" => $t["track_city"], "comment" => $t["track_comment"]));
        }
    }
    $audio = $order["has_audio"] ? $core->db->data("SELECT * FROM " . DB_AUDIO . " WHERE order_id = '" . $order["order_id"] . "' ORDER BY audio_time DESC") : array();
    if ($audio) {
        $core->tpl->block("body", "audio", array("title" => $core->lang["order_audio"], "listen" => $core->lang["log_listen"], "download" => $core->lang["download"], "time" => $core->lang["date"], "user" => $core->lang["user"], "phone" => $core->lang["phone"]));
        foreach ($audio as $a) {
            $asing = $a["audio_src"] ? array($a["audio_src"]) : array();
            if ($a["audio_mp3"]) {
                $asing[] = $a["audio_mp3"];
            }
            if ($a["audio_ogg"]) {
                $asing[] = $a["audio_ogg"];
            }
            if ($a["audio_wav"]) {
                $asing[] = $a["audio_wav"];
            }
            $hsing = count($asing) == 1 ? $asing[0] : false;
            $core->tpl->block("body", "audio.row", array("time" => smartdate($a["audio_time"]), "from" => $a["audio_from"] ? $a["audio_from"] : false, "to" => $a["audio_to"] ? $a["audio_to"] : false, "length" => $a["audio_length"], "uid" => $a["user_id"], "user" => $a["user_id"] ? $core->user->get($a["user_id"], "user_name") : false, "single" => $hsing, "first" => $asing[0], "src" => $a["audio_src"], "mp3" => $a["audio_mp3"], "ogg" => $a["audio_ogg"], "wav" => $a["audio_wav"]));
        }
    }
    $log = $core->db->data("SELECT * FROM " . DB_CALL . " WHERE order_id = '" . $id . "' ORDER BY call_id ASC");
    if ($log) {
        rsort($log);
        $core->tpl->block("body", "log", array("title" => $core->lang["order_log"], "user" => $core->lang["user"], "status" => $core->lang["status"], "time" => $core->lang["date"], "next" => $core->lang["log_next"], "length" => $core->lang["log_length"]));
        foreach ($log as $l) {
            $u = $l["user_id"] ? $core->user->get($l["user_id"], "user_name") : false;
            if ($l["call_length"]) {
                if (60 < $l["call_length"]) {
                    $mm = floor($l["call_length"] / 60);
                    $ss = $l["call_length"] % 60;
                    $cl = sprintf($core->lang["log_ms"], $mm, $ss);
                } else {
                    $cl = sprintf($core->lang["log_sec"], $l["call_length"]);
                }
            } else {
                $cl = false;
            }
            $core->tpl->block("body", "log.row", array("user" => $u ? $u : $core->lang["log_robot"], "type" => $u ? true : false, "time" => smartdate($l["call_time"]), "next" => $l["call_next"] ? smartdate($l["call_next"]) : false, "status" => $core->lang["statuso"][$l["call_status"]], "sclass" => $l["call_status"], "length" => $cl));
        }
        unset($log);
        unset($l);
    }
    $chl = $core->db->data("SELECT * FROM " . DB_CHANGE . " WHERE order_id = '" . $id . "' ORDER BY change_id ASC");
    if ($chl) {
        rsort($chl);
        $core->tpl->block("body", "chl", array("title" => $core->lang["order_chl"], "user" => $core->lang["user"], "time" => $core->lang["time"], "changes" => $core->lang["order_changes"]));
        foreach ($chl as $l) {
            $u = $l["user_id"] ? $core->user->get($l["user_id"], "user_name") : false;
            $dd = unserialize($l["change_data"]);
            $core->tpl->block("body", "chl.row", array("user" => $u ? $u : $core->lang["log_robot"], "type" => $u ? true : false, "warn" => $l["change_warn"] ? "red" : "", "time" => smartdate($l["change_time"])));
            foreach ($dd as $n => $d) {
                if ($d != "") {
                    if ($n == "comp_id") {
                        $d = $core->cpa->get("comp", $d, "comp_name");
                    }
                    if ($n == "order_country") {
                        $d = $core->lang["country"][$d];
                    }
                    if ($n == "price_cur") {
                        $d = $core->lang["price_cur"][$d];
                    }
                    if ($n == "order_delivery") {
                        $d = $core->lang["delivery"][$d];
                    }
                    if ($n == "order_reason") {
                        $d = $core->lang["reasono"][$d];
                    }
                    if ($n == "order_comment") {
                        $d = nl2br($d);
                    }
                    if ($n == "order_stage") {
                        $d = $d ? $allstages[$d] : $core->lang["no"];
                    }
                    if ($n == "calling") {
                        $dd = preg_split("#\\s+#", $d, -1, PREG_SPLIT_NO_EMPTY);
                        $d = "";
                        foreach ($dd as $di) {
                            $dt = substr($di, strrpos($di, ".") + 1);
                            switch ($dt) {
                                case "mp3":
                                    $d .= "<audio controls><source src=\"" . $di . "\" type=\"audio/mpeg\"><a href=\"" . $di . "\">" . $di . "</a></audio> ";
                                    break;
                                case "ogg":
                                    $d .= "<audio controls><source src=\"" . $di . "\" type=\"audio/ogg\"><a href=\"" . $di . "\">" . $di . "</a></audio> ";
                                    break;
                                default:
                                    $d .= "<a href=\"" . $di . "\">" . $di . "</a> ";
                            }
                        }
                    }
                } else {
                    $d = $core->lang["no"];
                }
                $core->tpl->block("body", "chl.row.line", array("n" => $core->lang["changelogs"][$n], "d" => $d));
            }
        }
        unset($log);
        unset($l);
    }
    $core->tpl->output("body");
    $core->site->footer();
}

?>