<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function admin_offer_vars($core, $id)
{
    $action = isset($core->get["action"]) ? $core->text->link($core->get["action"]) : NULL;
    switch ($action) {
        case "add":
            $name = $core->text->line($core->post["name"]);
            $vars = $core->db->field("SELECT offer_vars FROM " . DB_OFFER . " WHERE offer_id = '" . $id . "' LIMIT 1");
            if ($vars && $core->db->add(DB_VARS, array("offer_id" => $id, "var_name" => $name))) {
                $id = $core->db->lastid();
                $core->cpa->clear("vars", $id);
                $core->cpa->clear("vprice", $id);
                $core->cpa->clear("vpar", $id);
                $core->cpa->clear("vpars", $id);
                $core->go($core->url("im", "offer-var", $id, "add-ok"));
            } else {
                $core->go($core->url("mm", "offer-vars", "add-e"));
            }
    }
    $message = isset($core->get["message"]) ? $core->text->link($core->get["message"]) : NULL;
    switch ($message) {
        case "edit-ok":
            $core->site->info("info", "done_offer_var_edit");
            break;
        case "del-ok":
            $core->site->info("info", "done_offer_var_del");
            break;
        case "add-e":
            $core->site->info("error", "error_offer_var_add");
            break;
        case "edit-e":
            $core->site->info("error", "error_offer_var_edit");
            break;
        case "del-e":
            $core->site->info("error", "error_offer_var_del");
            break;
    }
    $offer = $core->db->row("SELECT * FROM " . DB_OFFER . " WHERE offer_id = '" . $id . "' LIMIT 1");
    if (!$offer["offer_vars"]) {
        $core->go($core->url("m", "offer"));
    }
    $vars = $core->db->data("SELECT * FROM " . DB_VARS . " WHERE offer_id = '" . $id . "' ORDER BY var_type ASC, var_name ASC");
    $core->site->bc($core->lang["offers_h"], $core->url("m", "offer"));
    $core->site->bc(sprintf($core->lang["offer_vars_h"], $offer["offer_name"]));
    $core->site->pt($core->lang["goods"]);
    $core->site->header();
    $core->tpl->load("body", "offer-vars", defined("HACK_TPL_OFVARS") ? HACK : false);
    $core->tpl->vars("body", array("title" => sprintf($core->lang["offer_vars_h"], $offer["offer_name"]), "text" => $core->text->lines($core->lang["offer_vars_t"]), "u_add" => $core->url("ia", "offer-vars", $id, "add"), "name" => $core->lang["name"], "short" => $core->lang["short"], "single" => $core->lang["var_single"], "nc" => $core->lang["var_nc"], "info" => $core->lang["info"], "type" => $core->lang["type"], "action" => $core->lang["action"], "param" => $core->lang["params"], "add" => $core->lang["add"], "edit" => $core->lang["edit"], "del" => $core->lang["del"], "confirm" => $core->lang["confirm"], "noitems" => $core->lang["noitems"]));
    if ($vars) {
        foreach ($vars as $i) {
            $core->tpl->block("body", "item", array("id" => $i["var_id"], "name" => $i["var_name"], "short" => $i["var_short"], "type" => $core->lang["varstype"][$i["var_type"]], "single" => $i["var_single"], "nc" => $i["var_nc"], "url" => $core->url("i", "offer-var", $i["var_id"]), "param" => $core->url("i", "offer-vpar", $i["var_id"]), "edit" => $core->url("i", "offer-var", $i["var_id"]), "del" => $core->url("ia", "offer-var", $i["var_id"], "del")));
        }
    } else {
        $core->tpl->block("body", "noitem");
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}
function admin_offer_var($core, $id)
{
    $vari = $core->db->row("SELECT * FROM " . DB_VARS . " WHERE var_id = '" . $id . "' LIMIT 1");
    $action = isset($core->get["action"]) ? $core->text->link($core->get["action"]) : NULL;
    switch ($action) {
        case "edit":
            $price = $vari["var_price"] ? unserialize($vari["var_price"]) : array();
            foreach ($core->post["prt"] as $u => $v) {
                $u = (int) $u;
                if ($v = round($core->text->float($v), 2)) {
                    $price[$u] = $v;
                } else {
                    unset($price[$u]);
                }
            }
            $data = array("var_name" => $core->text->line($core->post["name"]), "var_short" => $core->text->line($core->post["short"]), "var_type" => $core->post["type"] ? 1 : 0, "var_single" => $core->post["single"] ? 1 : 0, "var_nc" => $core->post["nc"] ? 1 : 0, "var_price" => addslashes(serialize($price)));
            if ($core->db->edit(DB_VARS, $data, "var_id = '" . $id . "'")) {
                $core->cpa->clear("vars", $vari["offer_id"]);
                $core->cpa->clear("vprice", $vari["offer_id"]);
                $core->go($core->url("im", "offer-vars", $vari["offer_id"], "edit-ok"));
            } else {
                $core->go($core->url("im", "offer-vars", $vari["offer_id"], "edit-e"));
            }
        case "del":
            if ($core->db->query("DELETE FROM " . DB_VARS . " WHERE var_id = '" . $id . "'")) {
                $core->cpa->clear("vars", $vari["offer_id"]);
                $core->cpa->clear("vprice", $vari["offer_id"]);
                $core->cpa->clear("vpar", $vari["offer_id"]);
                $core->cpa->clear("vpars", $vari["offer_id"]);
                $core->go($core->url("im", "offer-vars", $vari["offer_id"], "del-ok"));
            } else {
                $core->go($core->url("im", "offer-vars", $vari["offer_id"], "del-e"));
            }
        case "params":
            $param = array();
            foreach ($core->post["param"] as $u => $v1) {
                $u = (int) $u;
                $v1 = $core->text->link($v1);
                $v2 = trim(stripslashes($core->post["value"][$u]));
                if ($v1 && $v2) {
                    $param[$v1] = $v2;
                }
            }
            $param = addslashes(serialize($param));
            if ($core->db->edit(DB_VARS, array("var_param" => $param), "var_id = '" . $id . "'")) {
                $core->cpa->clear("vars", $vari["offer_id"]);
                $core->cpa->clear("vpar", $vari["offer_id"]);
                $core->cpa->clear("vpars", $vari["offer_id"]);
                $core->go($core->url("im", "offer-vars", $vari["offer_id"], "edit-ok"));
            } else {
                $core->go($core->url("im", "offer-vars", $vari["offer_id"], "edit-e"));
            }
    }
    $message = isset($core->get["message"]) ? $core->text->link($core->get["message"]) : NULL;
    switch ($message) {
        case "add-ok":
            $core->site->info("info", "done_offer_var_add");
            break;
        case "add-e":
            $core->site->info("error", "error_offer_var_add");
            break;
    }
    $prt = unserialize($vari["var_price"]);
    $offer = $core->db->row("SELECT * FROM " . DB_OFFER . " WHERE offer_id = '" . $vari["offer_id"] . "' LIMIT 1");
    $core->site->bc($core->lang["offers_h"], $core->url("m", "offer"));
    $core->site->bc(sprintf($core->lang["offer_vars_h"], $offer["offer_name"]), $core->url("i", "offer-vars", $offer["offer_id"]));
    $core->site->bc($vari["var_name"]);
    $core->site->header();
    $field = array(array("type" => "text", "length" => 100, "name" => "name", "head" => $core->lang["name"], "value" => $vari["var_name"]), array("type" => "text", "length" => 100, "name" => "short", "head" => $core->lang["var_short"], "descr" => $core->lang["var_short_d"], "value" => $vari["var_short"]), array("type" => "checkbox", "name" => "type", "head" => $core->lang["var_type"], "descr" => $core->lang["var_type_d"], "checked" => $vari["var_type"]), array("type" => "checkbox", "name" => "single", "head" => $core->lang["var_single"], "descr" => $core->lang["var_single_d"], "checked" => $vari["var_single"]), array("type" => "checkbox", "name" => "nc", "head" => $core->lang["var_nc"], "descr" => $core->lang["var_nc_d"], "checked" => $vari["var_nc"]), array("type" => "head", "value" => $core->lang["prices"]));
    $cids = $core->currency->geoline($offer["offer_country"]);
    foreach ($core->currency->data as $i => $n) {
        if (in_array($i, $cids)) {
            $descr = array();
            if (is_array($n[1])) {
                foreach ($n[1] as $c) {
                    $descr[] = "<span class=\"flagname\"><img src=\"/core/images/flag/" . $c . ".png\" alt=\"" . $c . "\" align=\"top\" /> " . $core->lang["country"][$c] . "</span>";
                }
            } else {
                $descr[] = "<span class=\"flagname\"><img src=\"/core/images/flag/" . $n[1] . ".png\" alt=\"" . $n[1] . "\" align=\"top\" /> " . $core->lang["country"][$n[1]] . "</span>";
            }
            $descr = "ID: " . $i . " - " . strtoupper($core->currency->code($i)) . ". " . implode(" ", $descr);
            $field[] = array("type" => "number", "name" => "prt[" . $i . "]", "head" => $core->currency->name($i), "descr" => $descr, "value" => $prt[$i], "step" => 0.01);
        }
    }
    $core->site->form("edit", $core->url("ia", "offer-var", $id, "edit"), $core->lang["offer_var_edit_h"], $field);
    $core->site->footer();
    $core->stop();
}
function admin_offer_vpar($core, $id)
{
    $vari = $core->db->row("SELECT * FROM " . DB_VARS . " WHERE var_id = '" . $id . "' LIMIT 1");
    $pars = $vari["var_param"] ? unserialize($vari["var_param"]) : array();
    $offer = $core->db->row("SELECT * FROM " . DB_OFFER . " WHERE offer_id = '" . $vari["offer_id"] . "' LIMIT 1");
    $core->site->bc($core->lang["offers_h"], $core->url("m", "offer"));
    $core->site->bc(sprintf($core->lang["offer_vars_h"], $offer["offer_name"]), $core->url("i", "offer-vars", $offer["offer_id"]));
    $core->site->bc($vari["var_name"]);
    $core->site->pt(sprintf($core->lang["offer_vpars_h"], $vari["var_name"]));
    $core->site->header();
    $core->tpl->load("body", "param", defined("HACK_TPL_PARAM") ? HACK : false);
    $core->tpl->vars("body", array("u_save" => $core->url("ia", "offer-var", $id, "params"), "save" => $core->lang["save"], "name" => $core->lang["name"], "value" => $core->lang["value"]));
    $i = 1;
    foreach ($pars as $k => $v) {
        $core->tpl->block("body", "param", array("id" => $i, "name" => $k, "val" => $v ? $v : ""));
        $i++;
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}

?>