<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function cron10min($core)
{
    $tm = time();
    set_time_limit(1350);
    require_once PATH_MODS . "cron-int.php";
    require_once PATH_MODS . "order-edit.php";
    $comps = $core->db->data("SELECT comp_id, int_chk_url, int_chk_field, int_chk_count, int_chk_format, int_chk_code, int_chk_pre FROM " . DB_COMP . " WHERE int_chk = 1 ORDER BY RAND()");
    foreach ($comps as $c) {
        integration_check($core, $c);
    }
    unset($comps);
    $comps = $core->db->data("SELECT comp_id, int_lng_url, int_lng_field, int_lng_count, int_lng_format, int_lng_code, int_lng_pre FROM " . DB_COMP . " WHERE int_lng = 1");
    foreach ($comps as $c) {
        integration_long($core, $c);
    }
    unset($comps);
    $comps = $core->db->data("SELECT comp_id, int_dlc_url, int_dlc_field, int_dlc_count, int_dlc_format, int_dlc_code, int_dlc_pre FROM " . DB_COMP . " WHERE int_dlc = 1");
    foreach ($comps as $c) {
        integration_dlc($core, $c);
    }
    unset($comps);
    $oids = $core->db->col("SELECT order_id FROM " . DB_ORDER . " WHERE order_status = 4 AND order_auto != 0 AND order_auto < '" . $tm . "'");
    if ($oids) {
        foreach ($oids as $o) {
            order_edit($core, $o, array("accept" => 1));
        }
    }
    $mt = $tm - 600;
    $tids = $core->db->col("SELECT DISTINCT test_id FROM " . DB_CLICK . " WHERE click_time > " . $mt . " AND test_id != 0");
    if ($tids) {
        $tids = implode(",", $tids);
        $sids = $core->db->col("SELECT DISTINCT split_id FROM " . DB_TEST . " WHERE test_id IN ( " . $tids . " )");
        $sids = implode(",", $sids);
        $core->db->query("UPDATE " . DB_SPLIT . " SET split_last = '" . $tm . "' WHERE split_id IN ( " . $sids . " )");
    }
    $core->cpa->dlcron();
    $oids = $core->db->col("SELECT order_id FROM " . DB_ORDER . " WHERE track_on = 1 AND track_check < '" . time() . "'");
    foreach ($oids as $o) {
        $core->cpa->dltrack($o);
    }
    $tm5s = $tm - 300;
    $users = $core->db->icol("SELECT user_id, user_mail FROM " . DB_USER . " WHERE supp_new > 0 AND supp_notify = 0 AND supp_last < '" . $tm5s . "'");
    if ($users) {
        $core->db->query("UPDATE " . DB_USER . " SET supp_notify = 1 WHERE user_id IN ( " . implode(", ", array_keys($users)) . " )");
        $title = sprintf($core->lang["mail_support_h"], $core->config("site", "name"));
        $text = sprintf($core->lang["mail_support_t"], $core->config("site", "name"), $core->uri("support"));
        $core->email->send($users, $title, $text);
    }
    if (defined("SUPPORT_NOTIFY")) {
        $admins = $core->db->field("SELECT COUNT(*) FROM " . DB_USER . " WHERE supp_admin > 0 AND supp_notify = 0 AND supp_last < '" . $tm5s . "'");
        if ($admins) {
            $core->db->query("UPDATE " . DB_USER . " SET supp_notify = 1 WHERE supp_admin > 0 AND supp_notify = 0 AND supp_last < '" . $tm5s . "'");
            $title = sprintf($core->lang["mail_support_ah"], $core->config("site", "name"));
            $text = sprintf($core->lang["mail_support_at"], $core->config("site", "name"), $admins, $core->uri("supporthq"));
            $core->email->send($users, $title, $text);
        }
    }
    $stt = $tm - $core->config("lead", "stat") * 86400;
    $std = date("Ymd", $stt);
    $trr = implode(",", trashreason());
    $aps = implode(",", approvestatus());
    $wts = implode(",", waitstatus());
    $unq = $core->config("lead", "click") ? "" : " AND click_unique = 1";
    $ltm = $core->config("statland");
    if ($ltm < $tm) {
        $oap = $core->db->icol("SELECT site_id, COUNT(*) FROM " . DB_ORDER . " WHERE site_id != 0 AND order_status IN ( " . $aps . " ) GROUP BY site_id");
        $owt = $oap ? $core->db->icol("SELECT site_id, COUNT(*) FROM " . DB_ORDER . " WHERE site_id != 0 AND ( order_status IN ( " . $wts . " ) OR ( order_status = 5 AND order_reason NOT IN ( " . $trr . " ) ) ) GROUP BY site_id") : array();
        $sids = array_unique(array_merge(array_keys($oap), array_keys($owt)));
        foreach ($sids as $si) {
            $app = $oap[$si] ? sprintf("%0.1f", $oap[$si] / ($oap[$si] + $owt[$si]) * 100) : 0;
            $core->db->edit(DB_SITE, array("site_approve" => $app), array("site_id" => $si));
        }
        $sc = $core->db->icol("SELECT site_id, COUNT(*) FROM " . DB_CLICK . " WHERE click_space = 0 " . $unq . " AND click_date >= '" . $std . "' GROUP BY site_id");
        $sa = $core->db->icol("SELECT site_id, SUM(cash_wm) FROM " . DB_ORDER . " WHERE site_id != 0 AND order_status IN ( " . $aps . " ) AND order_time >= '" . $stt . "' GROUP BY site_id");
        $so = $core->db->icol("SELECT site_id, COUNT(*) FROM " . DB_ORDER . " WHERE site_id != 0 AND order_status != 12 AND order_reason NOT IN ( " . $trr . " ) AND order_time >= '" . $stt . "' GROUP BY site_id");
        foreach ($so as $si => $sm) {
            $conv = $sc[$si] ? sprintf("%0.2f", $sm / $sc[$si] * 100) : 0;
            $epc = $sc[$si] ? sprintf("%0.2f", $sa[$si] / $sc[$si]) : 0;
            $core->db->edit(DB_SITE, array("site_convert" => $conv, "site_epc" => $epc), array("site_id" => $si));
        }
        unset($sa);
        unset($ci);
        unset($sm);
        unset($sc);
        unset($so);
        $core->reconf("statland", $tm + 21700 + rand(0, 4200));
    }
    $ltm = $core->config("statspace");
    if ($ltm < $tm) {
        $oap = $core->db->icol("SELECT space_id, COUNT(*) FROM " . DB_ORDER . " WHERE space_id != 0 AND order_status IN ( " . $aps . " ) GROUP BY space_id");
        $owt = $oap ? $core->db->icol("SELECT space_id, COUNT(*) FROM " . DB_ORDER . " WHERE space_id != 0 AND ( order_status IN ( " . $wts . " ) OR ( order_status = 5 AND order_reason NOT IN ( " . $trr . " ) ) ) GROUP BY space_id") : array();
        $sids = array_unique(array_merge(array_keys($oap), array_keys($owt)));
        foreach ($sids as $si) {
            $app = $oap[$si] ? sprintf("%0.1f", $oap[$si] / ($oap[$si] + $owt[$si]) * 100) : 0;
            $core->db->edit(DB_SITE, array("site_approve" => $app), array("site_id" => $si));
        }
        $sc = $core->db->icol("SELECT site_id, COUNT(*) FROM " . DB_CLICK . " WHERE click_space = 1 " . $unq . " AND click_date >= '" . $std . "' GROUP BY site_id");
        $sa = $core->db->icol("SELECT space_id, SUM(cash_wm) FROM " . DB_ORDER . " WHERE space_id != 0 AND order_status IN ( " . $aps . " ) AND order_time >= '" . $stt . "' GROUP BY space_id");
        $so = $core->db->icol("SELECT space_id, COUNT(*) FROM " . DB_ORDER . " WHERE space_id != 0 AND order_status != 12 AND order_reason NOT IN ( " . $trr . " ) AND order_time >= '" . $stt . "' GROUP BY space_id");
        foreach ($so as $si => $sm) {
            $conv = $sc[$si] ? sprintf("%0.2f", $sm / $sc[$si] * 100) : 0;
            $epc = $sc[$si] ? sprintf("%0.2f", $sa[$si] / $sc[$si]) : 0;
            $core->db->edit(DB_SITE, array("site_convert" => $conv, "site_epc" => $epc), array("site_id" => $si));
        }
        unset($sa);
        unset($ci);
        unset($sm);
        unset($sc);
        unset($so);
        $core->reconf("statspace", $tm + 21700 + rand(0, 4200));
    }
    $ltm = $core->config("statflow");
    if ($ltm < $tm) {
        $sc = $core->db->icol("SELECT flow_id, COUNT(*) FROM " . DB_CLICK . " WHERE click_space = 0 " . $unq . " AND click_date >= '" . $std . "' GROUP BY flow_id");
        $sa = $core->db->icol("SELECT flow_id, SUM(cash_wm) FROM " . DB_ORDER . " WHERE flow_id != 0 AND order_status IN ( " . $aps . " ) AND order_time >= '" . $stt . "' GROUP BY flow_id");
        $so = $core->db->icol("SELECT flow_id, COUNT(*) FROM " . DB_ORDER . " WHERE flow_id != 0 AND order_status != 12 AND order_reason NOT IN ( " . $trr . " ) AND order_time >= '" . $stt . "' GROUP BY flow_id");
        foreach ($so as $si => $sm) {
            $conv = $sc[$si] ? sprintf("%0.2f", $sm / $sc[$si] * 100) : 0;
            $epc = $sc[$si] ? sprintf("%0.2f", $sa[$si] / $sc[$si]) : 0;
            $core->db->edit(DB_FLOW, array("flow_convert" => $conv, "flow_epc" => $epc), array("flow_id" => $si));
        }
        unset($sa);
        unset($ci);
        unset($sm);
        unset($sc);
        unset($so);
        $core->reconf("statflow", $tm + 21700 + rand(0, 4200));
    }
    $oid = $core->db->col("SELECT offer_id FROM " . DB_OFFER . " WHERE offer_active = 1 AND stat_next < '" . $tm . "'");
    foreach ($oid as $o) {
        $geo = $stats = $changes = array();
        $gl = $core->cpa->get("offer", $o, "offer_country");
        $gl = $gl ? explode(",", $gl) : "ru";
        foreach ($gl as $g) {
            if ($g = trim($g)) {
                $geo[] = $g;
            }
        }
        foreach ($geo as $g) {
            $stats[$g] = array(0, 0, 0);
        }
        $oap = $core->db->icol("SELECT order_country, COUNT(*) FROM " . DB_ORDER . " WHERE offer_id = '" . $o . "' AND order_status IN ( " . $aps . " ) GROUP BY order_country");
        if ($oap) {
            $owt = $core->db->icol("SELECT order_country, COUNT(*) FROM " . DB_ORDER . " WHERE offer_id = '" . $o . "' AND ( order_status IN ( " . $wts . " ) OR ( order_status = 5 AND order_reason NOT IN ( " . $trr . " ) ) ) GROUP BY order_country");
            $ta = array_sum($oap);
            $tw = array_sum($owt);
            $changes["offer_approve"] = sprintf("%0.1f", $ta / ($ta + $tw) * 100);
            $gtp = array_unique(array_merge(array_keys($oap), array_keys($owt)));
            foreach ($gtp as $g) {
                $stats[$g][0] = $oap[$g] ? sprintf("%0.1f", $oap[$g] / ($oap[$g] + $owt[$g]) * 100) : 0;
            }
        } else {
            $changes["offer_approve"] = 0;
        }
        $sc = $core->db->icol("SELECT click_geo, COUNT(*) FROM " . DB_CLICK . " WHERE offer_id = '" . $o . "' AND click_space = 0 " . $unq . " AND click_date >= '" . $std . "' GROUP BY click_geo");
        $sa = $core->db->icol("SELECT order_country, SUM(cash_wm) FROM " . DB_ORDER . " WHERE offer_id = '" . $o . "' AND site_id != 0 AND order_status IN ( " . $aps . " ) AND order_time >= '" . $stt . "' GROUP BY order_country");
        $so = $core->db->icol("SELECT order_country, COUNT(*) FROM " . DB_ORDER . " WHERE offer_id = '" . $o . "' AND site_id != 0 AND order_status != 12 AND order_reason NOT IN ( " . $trr . " ) AND order_time >= '" . $stt . "' GROUP BY order_country");
        $tc = array_sum($sc);
        $ta = array_sum($sa);
        $to = array_sum($so);
        $changes["offer_convert"] = $tc ? sprintf("%0.2f", $to / $tc * 100) : 0;
        $changes["offer_epc"] = $tc ? sprintf("%0.2f", $ta / $tc) : 0;
        foreach ($so as $si => $sm) {
            $stats[$si][1] = $sc[$si] ? sprintf("%0.2f", $sm / $sc[$si] * 100) : 0;
            $stats[$si][2] = $sa[$si] && $sc[$si] ? sprintf("%0.2f", $sa[$si] / $sc[$si]) : 0;
        }
        unset($sa);
        unset($ci);
        unset($sm);
        unset($sc);
        unset($so);
        $gs = $core->db->icol("SELECT order_gender, COUNT(*) FROM " . DB_ORDER . " WHERE offer_id = '" . $o . "' AND order_status IN ( " . $aps . " ) GROUP BY order_gender");
        $gt = array_sum($gs);
        $changes["stat_m"] = $gs[1] ? sprintf("%0.1f", $gs[1] / $gt * 100) : 0;
        $changes["stat_f"] = $gs[2] ? sprintf("%0.1f", $gs[2] / $gt * 100) : 0;
        $changes["stat_next"] = $tm + 21700 + rand(0, 4200);
        $changes["stat_info"] = addslashes(serialize($stats));
        $core->db->edit(DB_OFFER, $changes, array("offer_id" => $o));
        $core->cpa->clear("offer", $o);
        $core->cpa->clear("offerstat", $o);
    }
    $upstat = $core->config("cronupdates");
    $updates = array("geoip" => PATH_MODS . "cron-geoip.php", "pdb" => PATH_MODS . "cron-pdb.php");
    if ($core->cando("cron_updates")) {
        $updates = $core->filter("cron_updates", $updates);
    }
    $updated = false;
    foreach ($updates as $name => $path) {
        if ($upstat[$name] < $tm) {
            if (!file_exists($path)) {
                continue;
            }
            require_once $path;
            $fname = "cronupdate_" . $name;
            if (!function_exists($fname)) {
                continue;
            }
            $updated = true;
            $upstat[$name] = $fname($core);
        }
    }
    if ($upstat["currency"] < $tm) {
        $core->currency->update();
        $upstat["currency"] = $tm + 4200 + rand(0, 1350);
        $updated = true;
    }
    $core->domain->croncheck();
    if ($updated) {
        $core->reconf("cronupdates", $upstat);
    }
    cleancache(DIR_CACHE, 10000);
}

?>