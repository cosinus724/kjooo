<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function wm_split($core)
{
    if (!($core->user->work == -1 || $core->user->work == 0 || $core->user->work == 2 || $core->user->work == -2)) {
        $core->go($core->u("", array("message" => "access")));
    }
    if ($core->config("hide", "split")) {
        $core->go($core->u("", array("message" => "access")));
    }
    $canuser = $core->user->level || $core->user->work == -2;
    $wm = isset($core->post["wm"]) ? (int) $core->post["wm"] : (int) $core->get["wm"];
    if ($canuser && $wm) {
        $user = $wm;
        $udt = $core->user->get($wm);
        $uinfo = sprintf($core->lang["stat_user"], $udt["user_name"], $udt["user_mail"]);
        $core->site->info("text", $uinfo);
    } else {
        $user = $core->user->id;
        $wm = NULL;
    }
    $action = $core->get["action"] ? $core->get["action"] : false;
    $id = $core->get["id"] ? (int) $core->get["id"] : 0;
    if ($action) {
        wm_split_action($core, $action, $id, $wm);
    }
    $message = $core->get["message"] ? $core->get["message"] : NULL;
    switch ($message) {
        case "ok":
            $core->site->info("info", "done_split");
            break;
        case "error":
            $core->site->info("error", "error_split");
            break;
        case "access":
            $core->site->info("error", "access_denied");
            break;
    }
    $module = $core->get["m"] ? $core->get["m"] : false;
    switch ($module) {
        case "split-edit":
            wm_split_edit($core, $id, $wm);
        case "split-test":
            wm_split_test($core, $id, $wm);
        default:
            if ($id) {
                wm_split_stat($core, $id, $wm);
            } else {
                wm_split_list($core, $wm);
            }
    }
}
function wm_split_action($core, $action, $id, $wm)
{
    switch ($action) {
        case "split-add":
            $data = array("user_id" => $wm ? $wm : $core->user->id, "offer_id" => (int) $core->post["offer"], "split_name" => $core->text->line($core->post["name"]), "split_active" => 1, "split_time" => time(), "split_last" => 0);
            if ($core->db->add(DB_SPLIT, $data)) {
                $id = $core->db->lastid();
                $core->go($core->u("split", array("message" => "ok", "wm" => $wm)));
            } else {
                $core->go($core->u("split", array("message" => "error", "wm" => $wm)));
            }
        case "split-edit":
            $user = $core->db->field("SELECT user_id FROM " . DB_SPLIT . " WHERE split_id = '" . $id . "' LIMIT 1");
            if ($wm) {
                if ($user != $wm) {
                    $core->go($core->u("split", array("message" => "access", "wm" => $wm)));
                }
            } else {
                if ($user != $core->user->id) {
                    $core->go($core->u("split", array("message" => "access")));
                }
            }
            $data = array("domain_id" => (int) $core->post["domain"], "split_name" => $core->text->line($core->post["name"]), "split_active" => $core->post["active"] ? 1 : 0);
            if ($core->db->edit(DB_SPLIT, $data, array("split_id" => $id))) {
                $core->go($core->u("split", array("message" => "ok", "wm" => $wm)));
            } else {
                $core->go($core->u("split", array("message" => "error", "wm" => $wm)));
            }
        case "split-del":
            $user = $core->db->field("SELECT user_id FROM " . DB_SPLIT . " WHERE split_id = '" . $id . "' LIMIT 1");
            if ($wm) {
                if ($user != $wm) {
                    $core->go($core->u("split", array("message" => "access", "wm" => $wm)));
                }
            } else {
                if ($user != $core->user->id) {
                    $core->go($core->u("split", array("message" => "access")));
                }
            }
            if ($core->db->del(DB_SPLIT, array("split_id" => $id))) {
                $core->db->del(DB_TEST, array("split_id" => $id));
                $core->go($core->u("split", array("message" => "ok", "wm" => $wm)));
            } else {
                $core->go($core->u("split", array("message" => "error", "wm" => $wm)));
            }
        case "test-add":
            $user = $core->db->field("SELECT user_id FROM " . DB_SPLIT . " WHERE split_id = '" . $id . "' LIMIT 1");
            if ($wm) {
                if ($user != $wm) {
                    $core->go($core->u("split", array("message" => "access", "wm" => $wm)));
                }
            } else {
                if ($user != $core->user->id) {
                    $core->go($core->u("split", array("message" => "access")));
                }
            }
            $data = array("split_id" => $id, "flow_id" => (int) $core->post["flow"], "test_name" => $core->text->line($core->post["name"]));
            if ($core->db->add(DB_TEST, $data)) {
                $core->cpa->clear("split", $id);
                $core->go($core->u(array("split", $id), array("message" => "ok", "wm" => $wm)));
            } else {
                $core->go($core->u(array("split", $id), array("message" => "error", "wm" => $wm)));
            }
        case "test-edit":
            $split = $core->db->field("SELECT split_id FROM " . DB_TEST . " WHERE test_id = '" . $id . "' LIMIT 1");
            $user = $core->db->field("SELECT user_id FROM " . DB_SPLIT . " WHERE split_id = '" . $split . "' LIMIT 1");
            if ($wm) {
                if ($user != $wm) {
                    $core->go($core->u("split", array("message" => "access", "wm" => $wm)));
                }
            } else {
                if ($user != $core->user->id) {
                    $core->go($core->u("split", array("message" => "access")));
                }
            }
            $data = array("flow_id" => (int) $core->post["flow"], "test_name" => $core->text->line($core->post["name"]), "test_url" => $core->text->line($core->post["url"]), "test_pos" => (int) $core->post["pos"], "test_geo" => $core->text->codeline($core->post["geo"]), "test_nogeo" => $core->text->codeline($core->post["nogeo"]), "test_mobile" => (int) $core->post["mobile"]);
            if ($core->db->edit(DB_TEST, $data, array("test_id" => $id))) {
                $core->cpa->clear("split", $split);
                $core->go($core->u(array("split", $split), array("message" => "ok", "wm" => $wm)));
            } else {
                $core->go($core->u(array("split", $split), array("message" => "error", "wm" => $wm)));
            }
        case "test-del":
            if (!$core->post["accept"]) {
                $core->go($core->u(array("split-test", $id), array("message" => "error", "wm" => $wm)));
            }
            $split = $core->db->field("SELECT split_id FROM " . DB_TEST . " WHERE test_id = '" . $id . "' LIMIT 1");
            $user = $core->db->field("SELECT user_id FROM " . DB_SPLIT . " WHERE split_id = '" . $split . "' LIMIT 1");
            if ($wm) {
                if ($user != $wm) {
                    $core->go($core->u("split", array("message" => "access", "wm" => $wm)));
                }
            } else {
                if ($user != $core->user->id) {
                    $core->go($core->u("split", array("message" => "access")));
                }
            }
            if ($core->db->del(DB_TEST, array("test_id" => $id))) {
                $core->cpa->clear("split", $split);
                $core->go($core->u(array("split", $split), array("message" => "ok", "wm" => $wm)));
            } else {
                $core->go($core->u(array("split", $split), array("message" => "error", "wm" => $wm)));
            }
    }
}
function wm_split_list($core, $wm)
{
    $user = $wm ? $wm : $core->user->id;
    $page = 0 < $core->get["page"] ? (int) $core->get["page"] : 1;
    $sh = 30;
    $st = ($page - 1) * $sh;
    $sc = $core->db->field("SELECT COUNT(*) FROM " . DB_SPLIT . " WHERE user_id = '" . $user . "'");
    $split = $sc ? $core->db->data("SELECT * FROM " . DB_SPLIT . " WHERE user_id = '" . $user . "' ORDER BY split_active DESC, split_last DESC LIMIT " . $st . ", " . $sh) : array();
    $oname = $core->cpa->get("offersa");
    $offer = $core->offer->names($user);
    $dd = $core->domain->get($user);
    $domain = $dd["domain"]["red"];
    $core->site->bc($core->lang["split_h"], $core->url("split", array("wm" => $wm)));
    $core->site->set("select2");
    $core->site->header();
    $core->tpl->load("body", "split", defined("HACK_TPL_SPLIT") ? HACK : false);
    $core->tpl->vars("body", array("title" => $core->lang["split_h"], "text" => $core->text->lines($core->lang["split_t"]), "name" => $core->lang["name"], "url" => $core->lang["url"], "offer" => $core->lang["offer"], "last" => $core->lang["split_last"], "time" => $core->lang["split_time"], "action" => $core->lang["action"], "edit" => $core->lang["settings"], "del" => $core->lang["del"], "confirm" => $core->lang["confirm"], "noitems" => $core->lang["split_n"], "pages" => pages($core->u("split", array("wm" => $wm)), $nc, $sh, $page), "shown" => sprintf($core->lang["shown"], $st + 1, min($st + $sh, $nc), $nc), "add" => $core->lang["split_add"], "u_add" => $core->u("split", array("action" => "split-add", "wm" => $wm))));
    foreach ($offer as $v => $n) {
        $core->tpl->block("body", "offer", array("v" => $v, "n" => $n));
    }
    if ($split) {
        $rurl = $core->config("redirect", "domain") ? "http://" . $core->config("redirect", "domain") . "/" : $core->config("url", "base");
        if ($dd["default"]["red"]) {
            $rurl = "http://" . $dd["domain"]["red"][$dd["default"]["red"]] . "/";
        }
        foreach ($split as $s) {
            $did = (int) $s["domain_id"];
            $dom = $s["domain_id"] && $domain[$did] ? "http://" . $domain[$did] . "/" : $rurl;
            $core->tpl->block("body", "item", array("id" => $s["split_id"], "name" => $s["split_name"], "uu" => $dom . $core->config("redirect", "test") . $s["split_id"], "offer" => $oname[$s["offer_id"]], "cls" => $s["split_active"] ? "ok green" : "wait grey", "last" => $s["split_last"] ? smartdate($s["split_last"]) : $core->lang["no"], "active" => $core->lang["splitactive"][$s["split_active"]], "time" => smartdate($s["split_time"]), "url" => $core->u(array("split", $s["split_id"]), array("wm" => $wm)), "edit" => $core->u(array("split-edit", $s["split_id"]), array("wm" => $wm)), "del" => $core->u(array("split", $s["split_id"]), array("action" => "split-del", "wm" => $wm))));
        }
    } else {
        $core->tpl->block("body", "noitem");
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}
function wm_split_stat($core, $id, $wm)
{
    $user = $wm ? $wm : $core->user->id;
    $ud = $core->user->get($user);
    $s = $core->db->row("SELECT * FROM " . DB_SPLIT . " WHERE split_id = '" . $id . "' LIMIT 1");
    if ($s["user_id"] != $user) {
        $core->go($core->u("split", array("message" => "access", "wm" => $wm)));
    }
    $test = $core->db->icol("SELECT test_id, test_name FROM " . DB_TEST . " WHERE split_id = '" . $id . "'");
    $today = date("Ymd");
    $yest = strtotime("-1 day");
    $week1 = date("Ymd", strtotime("-6 days"));
    extract(params($core, array("to" => "date", "from" => "date")));
    if (!$to || $today < $to) {
        $to = $today;
    }
    if ($to < $from) {
        $from = $to;
    }
    if (!$from) {
        $from = $week1;
    }
    $param = array("from" => $from, "to" => $to, "wm" => $wm);
    $tests = implode(", ", array_keys($test));
    if ($tests) {
        require_once PATH_MODS . "wm-api.php";
        $stats = wm_stats_load($core, "test_id", $from, $to, "test_id IN ( " . $tests . " )", array("names" => $test));
        foreach ($stats as $i => &$st) {
            $st["url"] = $core->u(array("split-test", $i), array("wm" => $wm));
            $st["leadu"] = $core->u("leads", array("from" => date2form($from), "to" => date2form($to), "t" => $i, "wm" => $wm));
        }
    } else {
        $stats = array();
    }
    $flows = $ud["user_ext"] ? false : $core->db->icol("SELECT flow_id, flow_name FROM " . DB_FLOW . " WHERE user_id = '" . $user . "' AND offer_id = '" . $s["offer_id"] . "' ORDER BY flow_name ASC");
    $core->site->bc($core->lang["split_h"], $core->u("split", array("wm" => $wm)));
    $core->site->bc($s["split_name"]);
    $core->site->header();
    $core->tpl->load("body", "stats-split", defined("HACK_TPL_STATS_SPLIT") ? HACK : false);
    $core->tpl->vars("body", array("name" => $core->lang["name"], "edit" => $core->lang["settings"], "add" => $core->lang["split_addt"], "u_add" => $core->u(array("split", $id), array("action" => "test-add", "wm" => $wm)), "dates" => $core->lang["split_dates"], "test" => $core->lang["split_test"], "flow" => $flows ? $core->lang["flow"] : false, "from" => date2form($from), "to" => date2form($to), "wm" => $wm, "u_today" => $core->u(array("split", $id), array("wm" => $wm, "from" => date("Y-m-d"), "to" => date("Y-m-d"))), "u_yesterday" => $core->u(array("split", $id), array("wm" => $wm, "from" => date("Y-m-d", $yest), "to" => date("Y-m-d", $yest))), "u_leads" => $core->u("leads", $param) . "&t=", "u_stats" => $core->u("stats", $param) . "&t=", "u_offer" => $core->u("offerstat", $param) . "&t=", "u_flow" => $core->u("flowstat", $param) . "&t=", "u_hour" => $core->u("hourstat", $param) . "&t=", "u_geo" => $core->u("geostat", $param) . "&t=", "u_utm" => $core->u("utm", $param) . "&t=", "u_site" => $core->u("site", $param) . "&t=", "u_click" => $core->u("click", $param) . "&t=", "u_ext" => $ud["user_ext"] ? $core->u("exti", $param) . "&t=" : false, "s_leads" => $core->lang["menu_sub_leads"], "s_stats" => $core->lang["menu_sub_stats"], "s_offer" => $core->lang["menu_sub_offerstat"], "s_flow" => $core->lang["menu_sub_flowstat"], "s_hour" => $core->lang["menu_sub_hourstat"], "s_geo" => $core->lang["menu_sub_geostat"], "s_utm" => $core->lang["menu_sub_utm"], "s_site" => $core->lang["menu_sub_site"], "s_click" => $core->lang["menu_sub_click"], "s_ext" => $core->lang["menu_sub_exti"]));
    if ($flows) {
        foreach ($flows as $v => $n) {
            $core->tpl->block("body", "flow", array("v" => $v, "n" => $n));
        }
    }
    require_once PATH_MODS . "wm-stats.php";
    wm_stats_block($core, $stats, 2);
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}
function wm_split_edit($core, $id, $wm)
{
    $user = $wm ? $wm : $core->user->id;
    $s = $core->db->row("SELECT * FROM " . DB_SPLIT . " WHERE split_id = '" . $id . "' LIMIT 1");
    if ($s["user_id"] != $user) {
        $core->go($core->u("split", array("message" => "access", "wm" => $wm)));
    }
    $dd = $core->domain->get($user);
    $dmn = $dd["domain"]["red"];
    if ($dmn) {
        $doms = array(array("name" => $core->lang["flow_redirect_o"], "value" => 0));
        foreach ($dmn as $d => $m) {
            $doms[] = array("name" => $m, "value" => $d, "select" => $s["domain_id"] == $d);
        }
    } else {
        $doms = false;
    }
    $core->site->bc($core->lang["split_h"], $core->url("split", array("wm" => $wm)));
    $core->site->bc($s["split_name"]);
    $core->site->pt($core->lang["split_edit_h"]);
    $core->site->header();
    $field = array(array("type" => "line", "value" => $core->text->lines($core->lang["split_edit_t"])), array("type" => "text", "length" => 100, "name" => "name", "head" => $core->lang["name"], "value" => $s["split_name"], "req" => 1), $doms ? array("type" => "select", "name" => "domain", "head" => $core->lang["domain"], "value" => $doms) : array("type" => "hidden", "name" => "domain", "value" => 0), array("type" => "checkbox", "name" => "active", "head" => $core->lang["split_active"], "descr" => $core->lang["split_active_d"], "checked" => $s["split_active"]));
    $core->site->form("splitedit", $core->u(array("split", $id), array("action" => "split-edit", "wm" => $wm)), false, $field);
    $core->site->footer();
    $core->stop();
}
function wm_split_test($core, $id, $wm)
{
    $user = $wm ? $wm : $core->user->id;
    $ud = $core->user->get($user);
    $t = $core->db->row("SELECT * FROM " . DB_TEST . " WHERE test_id = '" . $id . "' LIMIT 1");
    $s = $core->db->row("SELECT * FROM " . DB_SPLIT . " WHERE split_id = '" . $t["split_id"] . "' LIMIT 1");
    if ($s["user_id"] != $user) {
        $core->go($core->u("split", array("message" => "access", "wm" => $wm)));
    }
    if (!$ud["user_ext"]) {
        $flows = array(array("name" => $core->lang["split_flow_no"], "value" => 0));
        $fl = $core->db->icol("SELECT flow_id, flow_name FROM " . DB_FLOW . " WHERE user_id = '" . $user . "' AND offer_id = '" . $s["offer_id"] . "' ORDER BY flow_name ASC");
        foreach ($fl as $v => $n) {
            $flows[] = array("name" => $n, "value" => $v, "select" => $v == $t["flow_id"]);
        }
    } else {
        $flows = false;
    }
    $mobile = array();
    foreach ($core->lang["splitmobile"] as $v => $n) {
        $mobile[] = array("name" => $n, "value" => $v, "select" => $v == $t["test_mobile"]);
    }
    $core->site->bc($core->lang["split_h"], $core->u("split", array("wm" => $wm)));
    $core->site->bc($s["split_name"], $core->u(array("split", $t["split_id"]), array("wm" => $wm)));
    $core->site->bc($t["test_name"]);
    $core->site->set("select2");
    $core->site->header();
    $field = array(array("type" => "line", "value" => $core->text->lines($core->lang["split_test_t"])), array("type" => "text", "length" => 100, "name" => "name", "head" => $core->lang["name"], "value" => $t["test_name"], "req" => 1), $flows ? array("type" => "select", "name" => "flow", "head" => $core->lang["split_flow"], "descr" => $core->lang["split_flow_d"], "value" => $flows) : NULL, array("type" => "text", "length" => 250, "name" => "url", "head" => $core->lang["split_url"], "descr" => $core->lang["split_url_d"], "value" => $t["test_url"]), array("type" => "number", "min" => 0, "step" => 0.1, "name" => "pos", "head" => $core->lang["split_pos"], "descr" => $core->lang["split_pos_d"], "value" => $t["test_pos"] ? $t["test_pos"] : ""), array("type" => "mselect", "name" => "geo", "head" => $core->lang["split_geo"], "descr" => $core->lang["split_geo_d"], "value" => $t["test_geo"], "options" => $core->lang["country"]), array("type" => "mselect", "name" => "nogeo", "head" => $core->lang["split_nogeo"], "descr" => $core->lang["split_nogeo_d"], "value" => $t["test_nogeo"], "options" => $core->lang["country"]), array("type" => "select", "name" => "mobile", "head" => $core->lang["split_mobile"], "descr" => $core->lang["split_mobile_d"], "value" => $mobile));
    $core->site->form("splitedit", $core->u(array("split-test", $id), array("action" => "test-edit", "wm" => $wm)), $core->lang["split_test_h"], $field);
    $field = array(array("type" => "line", "value" => $core->text->lines($core->lang["split_del_t"])), array("type" => "checkbox", "name" => "accept", "head" => $core->lang["split_delete"], "descr" => $core->lang["split_delete_d"], "req" => 1));
    $core->site->form("splitdel", $core->u(array("split-test", $id), array("action" => "test-del", "wm" => $wm)), $core->lang["split_del_h"], $field, $core->lang["del"]);
    $core->site->footer();
    $core->stop();
}

?>