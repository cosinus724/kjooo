<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function order_cash($core, $order)
{
    $uw = $order["wm_id"];
    $ur = $uw ? $core->user->get($uw, "user_ref") : false;
    $isvip = $uw ? $core->user->get($uw, "user_vip") : false;
    $isext = $uw ? $core->user->get($uw, "user_ext") : false;
    $isrvp = $ur ? $core->user->get($ur, "user_vip") : false;
    $wmid = $isext ? $order["ext_id"] . "-" . $order["ext_src"] : $uw;
    $up = $core->cpa->get("comp", $order["comp_id"], "user_id");
    if ($order["cc_id"]) {
        $uc = $core->cpa->get("comp", $order["cc_id"], "user_id");
        $isclc = true;
    } else {
        $uc = $isclc = false;
    }
    $price = $core->cpa->get("prices", $order["offer_id"]);
    $wmp = $wmu = $wml = $wxs = $wmxl = $pay = $pyu = $pyl = $pxs = $pxl = $ccp = $ccu = $ccl = $cxs = $cxl = $rep = 0;
    $ocntr = strtolower($order["order_country"]);
    $summ = $core->currency->convert($order["price_total"], $order["price_cur"]);
    foreach ($price as $p) {
        if ($p["price_in"] == 1) {
            if (!$isvip) {
                continue;
            }
            if ($p["price_inid"] && $uw != $p["price_inid"]) {
                continue;
            }
        } else {
            if ($p["price_in"] == 2) {
                if (!$isext) {
                    continue;
                }
                if ($p["price_inid"] && $uw != $p["price_inid"]) {
                    continue;
                }
            } else {
                if ($p["price_in"] == 3) {
                    if (!$isrvp) {
                        continue;
                    }
                    if ($p["price_inid"] && $ur != $p["price_inid"]) {
                        continue;
                    }
                }
            }
        }
        if ($p["price_out"] == 1) {
            if (!$isclc) {
                continue;
            }
            if ($p["price_outid"] && $uc != $p["price_outid"]) {
                continue;
            }
        } else {
            if ($p["price_outid"] && $up != $p["price_outid"]) {
                continue;
            }
        }
        if ($p["price_geo"]) {
            $geo = explode(",", $p["price_geo"]);
            if (!in_array($ocntr, $geo)) {
                continue;
            }
        }
        if ($p["price_promo"]) {
            if ($p["price_promo"] == 1 && $order["promo_code"] == 0) {
                continue;
            }
            if ($p["price_promo"] == 2 && $order["promo_code"] != 0) {
                continue;
            }
        }
        if ($p["price_deliv"]) {
            if ($p["price_deliv"] == 1 && $order["order_delivery"] == 0) {
                continue;
            }
            if ($p["price_deliv"] == 2 && $order["order_delivery"] != 0) {
                continue;
            }
        }
        if ($p["price_mobile"]) {
            if ($p["price_mobile"] == 1 && $order["order_mobile"] != 1) {
                continue;
            }
            if ($p["price_mobile"] == 2 && $order["order_mobile"] == 1) {
                continue;
            }
        }
        if ($p["price_bad"]) {
            if ($p["price_bad"] == 1 && $order["order_bad"] != 1) {
                continue;
            }
            if ($p["price_bad"] == 2 && $order["order_bad"] == 1) {
                continue;
            }
        }
        if ($p["wmid"] && !in_array($wmid, $p["wmid"])) {
            continue;
        }
        $cur = $p["price_cur"] ? $core->currency->id($p["price_cur"]) : NULL;
        if ($p["wmset"]) {
            $pwm = isset($cur) ? $core->currency->convert($p["wm"], $cur) : $p["wm"];
            if ($p["price_out"]) {
                $ccp = $p["wmper"] ? sprintf("%0.2f", $p["wmper"] * $summ / 100 + $pwm) : $pwm;
                $ccu = isset($cur) ? $core->currency->convert($p["wmup"], $cur) : $p["wmup"];
                $ccl = $p["wmlim"];
                $cxs = isset($cur) ? $core->currency->convert($p["wmxs"], $cur) : $p["wmxs"];
                $cxl = $p["wmxl"];
            } else {
                $wmp = $p["wmper"] ? sprintf("%0.2f", $p["wmper"] * $summ / 100 + $pwm) : $pwm;
                $wmu = isset($cur) ? $core->currency->convert($p["wmup"], $cur) : $p["wmup"];
                $wml = $p["wmlim"];
                $wxs = isset($cur) ? $core->currency->convert($p["wmxs"], $cur) : $p["wmxs"];
                $wxl = $p["wmxl"];
            }
        }
        if ($p["payset"]) {
            $ppy = isset($cur) ? $core->currency->convert($p["pay"], $cur) : $p["pay"];
            $pay = $p["payper"] ? sprintf("%0.2f", $p["payper"] * $summ / 100 + $ppy) : $ppy;
            $pyu = isset($cur) ? $core->currency->convert($p["payup"], $cur) : $p["payup"];
            $pyl = $p["paylim"];
            $pxs = isset($cur) ? $core->currency->convert($p["payxs"], $cur) : $p["payxs"];
            $pxl = $p["payxl"];
        }
        if ($p["parset"]) {
            $ppr = isset($cur) ? $core->currency->convert($p["partner"], $cur) : $p["partner"];
            $rep = $p["partper"] ? sprintf("%0.2f", $p["partper"] * $summ / 100 + $ppr) : $ppr;
        }
        if ($p["price_last"]) {
            break;
        }
    }
    $ocnts = $order["order_count"];
    $xcnts = $order["order_xcnt"];
    if (1 < $ocnts) {
        if ($wmu) {
            $wmp += $wmu * max(0, ($wml ? min($ocnts, $wml) : $ocnts) - 1);
        }
        if ($pyu) {
            $pay += $pyu * max(0, ($pyl ? min($ocnts, $pyl) : $ocnts) - 1);
        }
        if ($ccu) {
            $ccp += $ccu * max(0, ($ccl ? min($ocnts, $ccl) : $ocnts) - 1);
        }
        if ($wxs) {
            $wmp += $wxs * max(0, $wxl ? min($xcnts, $wxl) : $xcnts);
        }
        if ($pxs) {
            $pay += $pxs * max(0, $pxl ? min($xcnts, $pxl) : $xcnts);
        }
        if ($cxs) {
            $ccp += $cxs * max(0, $cxl ? min($xcnts, $cxl) : $xcnts);
        }
    }
    return array("up" => $up, "uc" => $uc, "uw" => $uw, "ur" => $ur, "pay" => $pay, "ccp" => $ccp, "wmp" => $wmp, "rep" => $rep);
}

?>