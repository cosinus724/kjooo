<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function company_integration($core, $id, $mode = false)
{
    if ($core->user->work == 1 && $core->config("hide", "int")) {
        $core->go($core->url("mm", "", "access"));
    }
    if ($core->get["action"] == "save") {
        $field = array();
        $flds = explode("\n", $core->post["add_field"]);
        if ($flds) {
            foreach ($flds as $k) {
                $kk = explode(" ", trim($k), 2);
                $field[$kk[0]] = stripslashes(trim($kk[1]));
            }
        }
        $field = addslashes(serialize($field));
        $fielda = array();
        $fldsa = explode("\n", $core->post["acc_field"]);
        if ($fldsa) {
            foreach ($fldsa as $k) {
                $kk = explode(" ", trim($k), 2);
                $fielda[$kk[0]] = stripslashes(trim($kk[1]));
            }
        }
        $fielda = addslashes(serialize($fielda));
        $field2 = array();
        $flds2 = explode("\n", $core->post["chk_field"]);
        if ($flds2) {
            foreach ($flds2 as $k) {
                $kk = explode(" ", trim($k), 2);
                $field2[$kk[0]] = stripslashes(trim($kk[1]));
            }
        }
        $field2 = addslashes(serialize($field2));
        $field3 = array();
        $flds3 = explode("\n", $core->post["lng_field"]);
        if ($flds3) {
            foreach ($flds3 as $k) {
                $kk = explode(" ", trim($k), 2);
                $field3[$kk[0]] = stripslashes(trim($kk[1]));
            }
        }
        $field3 = addslashes(serialize($field3));
        $field4 = array();
        $flds4 = explode("\n", $core->post["dlv_field"]);
        if ($flds4) {
            foreach ($flds4 as $k) {
                $kk = explode(" ", trim($k), 2);
                $field4[$kk[0]] = stripslashes(trim($kk[1]));
            }
        }
        $field4 = addslashes(serialize($field4));
        $field5 = array();
        $flds5 = explode("\n", $core->post["dlc_field"]);
        if ($flds5) {
            foreach ($flds5 as $k) {
                $kk = explode(" ", trim($k), 2);
                $field5[$kk[0]] = stripslashes(trim($kk[1]));
            }
        }
        $field5 = addslashes(serialize($field5));
        $edit = array("int_add" => $core->post["add"] ? 1 : 0, "int_add_url" => str_replace("&amp;", "&", str_replace("&quot;", "\"", $core->text->line($core->post["add_url"]))), "int_add_pre" => $core->text->code($core->post["add_pre"]), "int_add_field" => $field, "int_add_code" => $core->text->code($core->post["add_code"]), "int_acc" => $core->post["acc"] ? 1 : 0, "int_acc_url" => str_replace("&amp;", "&", str_replace("&quot;", "\"", $core->text->line($core->post["acc_url"]))), "int_acc_pre" => $core->text->code($core->post["acc_pre"]), "int_acc_field" => $fielda, "int_acc_code" => $core->text->code($core->post["acc_code"]), "int_chk" => $core->post["chk"] ? 1 : 0, "int_chk_url" => str_replace("&amp;", "&", str_replace("&quot;", "\"", $core->text->line($core->post["chk_url"]))), "int_chk_pre" => $core->text->code($core->post["chk_pre"]), "int_chk_field" => $field2, "int_chk_format" => (int) $core->post["chk_format"], "int_chk_count" => (int) $core->post["chk_count"], "int_chk_code" => $core->text->code($core->post["chk_code"]), "int_lng" => $core->post["lng"] ? 1 : 0, "int_lng_url" => str_replace("&amp;", "&", str_replace("&quot;", "\"", $core->text->line($core->post["lng_url"]))), "int_lng_pre" => $core->text->code($core->post["lng_pre"]), "int_lng_field" => $field3, "int_lng_format" => (int) $core->post["lng_format"], "int_lng_count" => (int) $core->post["lng_count"], "int_lng_code" => $core->text->code($core->post["lng_code"]), "int_dlv" => (int) $core->post["dlv"], "int_dlv_url" => str_replace("&amp;", "&", str_replace("&quot;", "\"", $core->text->line($core->post["dlv_url"]))), "int_dlv_pre" => $core->text->code($core->post["dlv_pre"]), "int_dlv_field" => $field4, "int_dlv_code" => $core->text->code($core->post["dlv_code"]), "int_dlc" => $core->post["dlc"] ? 1 : 0, "int_dlc_url" => str_replace("&amp;", "&", str_replace("&quot;", "\"", $core->text->line($core->post["dlc_url"]))), "int_dlc_pre" => $core->text->code($core->post["dlc_pre"]), "int_dlc_field" => $field5, "int_dlc_format" => (int) $core->post["dlc_format"], "int_dlc_count" => (int) $core->post["dlc_count"], "int_dlc_code" => $core->text->code($core->post["dlc_code"]));
        if ($core->db->edit(DB_COMP, $edit, "comp_id = '" . $id . "'")) {
            $core->cpa->clear("comp", $id);
            $core->go($core->url("mm", $mode ? "comps" : "integration", "edit-ok"));
        } else {
            $core->go($core->url("mm", $mode ? "comps" : "integration", "edit-e"));
        }
    }
    $comp = $core->cpa->get("comp", $id);
    $user = $comp["user_id"] ? $core->user->get($comp["user_id"]) : array("user_id" => 123, "user_api" => "abcd");
    $pb = trim($core->config("url", "api"), "/");
    if (!$pb) {
        $pb = trim($core->config("url", "base"), "/") . "/api";
    }
    $pb .= "/sale/status.json?id=" . $user["user_id"] . "-" . $user["user_api"] . "&oid={subid}&status={status}";
    $flds = unserialize($comp["int_add_field"]);
    $fld = "";
    if ($flds) {
        foreach ($flds as $k => $v) {
            $fld .= (string) $k . " " . $v . "\n";
        }
    }
    $fld = trim($fld);
    $fldsa = unserialize($comp["int_acc_field"]);
    $flda = "";
    if ($fldsa) {
        foreach ($fldsa as $k => $v) {
            $flda .= (string) $k . " " . $v . "\n";
        }
    }
    $flda = trim($flda);
    $fldsd = unserialize($comp["int_dlv_field"]);
    $fldd = "";
    if ($fldsd) {
        foreach ($fldsd as $k => $v) {
            $fldd .= (string) $k . " " . $v . "\n";
        }
    }
    $fldd = trim($fldd);
    $flds2 = unserialize($comp["int_chk_field"]);
    $fld2 = "";
    if ($flds2) {
        foreach ($flds2 as $k => $v) {
            $fld2 .= (string) $k . " " . $v . "\n";
        }
    }
    $fld2 = trim($fld2);
    $flds3 = unserialize($comp["int_lng_field"]);
    $fld3 = "";
    if ($flds3) {
        foreach ($flds3 as $k => $v) {
            $fld3 .= (string) $k . " " . $v . "\n";
        }
    }
    $fld3 = trim($fld3);
    $flds4 = unserialize($comp["int_dlc_field"]);
    $fld4 = "";
    if ($flds4) {
        foreach ($flds4 as $k => $v) {
            $fld4 .= (string) $k . " " . $v . "\n";
        }
    }
    $fld4 = trim($fld4);
    $dlc = array();
    foreach ($core->lang["comp_int_dlv_o"] as $v => $n) {
        $dlc[] = array("name" => $n, "value" => $v, "select" => $v == $comp["int_dlv"]);
    }
    $format = array();
    foreach ($core->lang["comp_int_formats"] as $v => $n) {
        $format[] = array("name" => $n, "value" => $v, "select" => $v == $comp["int_chk_format"]);
    }
    $format2 = array();
    foreach ($core->lang["comp_int_formats"] as $v => $n) {
        $format2[] = array("name" => $n, "value" => $v, "select" => $v == $comp["int_lng_format"]);
    }
    $format3 = array();
    foreach ($core->lang["comp_int_formats"] as $v => $n) {
        $format3[] = array("name" => $n, "value" => $v, "select" => $v == $comp["int_dlc_format"]);
    }
    $core->site->bc($core->lang["comp_int_h"]);
    $core->site->header();
    $action = $mode ? $core->url("ia", "integration", $id, "save") : $core->url("ma", "integration", "save");
    $field = array(array("type" => "line", "value" => $core->text->lines($core->lang["comp_int_t"])), array("type" => "text", "head" => $core->lang["comp_int_pb"], "ro" => 1, "value" => $pb), array("type" => "head", "value" => $core->lang["comp_int_add_h"]), array("type" => "line", "value" => $core->text->lines($core->lang["comp_int_add_t"])), array("type" => "checkbox", "name" => "add", "head" => $core->lang["comp_int_add"], "descr" => $core->lang["comp_int_add_d"], "checked" => $comp["int_add"]), array("type" => "text", "length" => 200, "name" => "add_url", "head" => $core->lang["comp_int_add_url"], "descr" => $core->lang["comp_int_add_url_d"], "value" => htmlspecialchars($comp["int_add_url"])), array("type" => "code", "lang" => "clike,php", "mime" => "text/x-php", "name" => "add_pre", "head" => $core->lang["comp_int_pre"], "value" => $comp["int_add_pre"]), array("type" => "textarea", "rows" => 5, "name" => "add_field", "head" => $core->lang["comp_int_add_field"], "descr" => $core->lang["comp_int_add_field_d"], "value" => $fld), array("type" => "code", "lang" => "clike,php", "mime" => "text/x-php", "name" => "add_code", "head" => $core->lang["comp_int_add_code"], "descr" => $core->lang["comp_int_add_code_d"], "value" => $comp["int_add_code"]), array("type" => "head", "value" => $core->lang["comp_int_acc_h"]), array("type" => "line", "value" => $core->text->lines($core->lang["comp_int_acc_t"])), array("type" => "checkbox", "name" => "acc", "head" => $core->lang["comp_int_add"], "descr" => $core->lang["comp_int_add_d"], "checked" => $comp["int_acc"]), array("type" => "text", "length" => 200, "name" => "acc_url", "head" => $core->lang["comp_int_add_url"], "descr" => $core->lang["comp_int_add_url_d"], "value" => htmlspecialchars($comp["int_acc_url"])), array("type" => "code", "lang" => "clike,php", "mime" => "text/x-php", "name" => "acc_pre", "head" => $core->lang["comp_int_pre"], "value" => $comp["int_acc_pre"]), array("type" => "textarea", "rows" => 5, "name" => "acc_field", "head" => $core->lang["comp_int_add_field"], "descr" => $core->lang["comp_int_add_field_d"], "value" => $flda), array("type" => "code", "lang" => "clike,php", "mime" => "text/x-php", "name" => "acc_code", "head" => $core->lang["comp_int_add_code"], "descr" => $core->lang["comp_int_add_code_d"], "value" => $comp["int_acc_code"]), array("type" => "head", "value" => $core->lang["comp_int_chk_h"]), array("type" => "line", "value" => $core->text->lines($core->lang["comp_int_chk_t"])), array("type" => "checkbox", "name" => "chk", "head" => $core->lang["comp_int_chk"], "descr" => $core->lang["comp_int_chk_d"], "checked" => $comp["int_chk"]), array("type" => "text", "length" => 200, "name" => "chk_url", "head" => $core->lang["comp_int_chk_url"], "descr" => $core->lang["comp_int_chk_url_d"], "value" => htmlspecialchars($comp["int_chk_url"])), array("type" => "code", "lang" => "clike,php", "mime" => "text/x-php", "name" => "chk_pre", "head" => $core->lang["comp_int_pre"], "value" => $comp["int_chk_pre"]), array("type" => "textarea", "rows" => 5, "name" => "chk_field", "head" => $core->lang["comp_int_chk_field"], "descr" => $core->lang["comp_int_chk_field_d"], "value" => $fld2), array("type" => "text", "length" => 5, "name" => "chk_count", "head" => $core->lang["comp_int_chk_count"], "descr" => $core->lang["comp_int_chk_count_d"], "value" => $comp["int_chk_count"]), array("type" => "select", "name" => "chk_format", "head" => $core->lang["comp_int_chk_format"], "value" => $format), array("type" => "code", "lang" => "clike,php", "mime" => "text/x-php", "name" => "chk_code", "head" => $core->lang["comp_int_chk_code"], "descr" => $core->lang["comp_int_chk_code_d"], "value" => $comp["int_chk_code"]), array("type" => "head", "value" => $core->lang["comp_int_lng_h"]), array("type" => "line", "value" => $core->text->lines($core->lang["comp_int_lng_t"])), array("type" => "checkbox", "name" => "lng", "head" => $core->lang["comp_int_lng"], "descr" => $core->lang["comp_int_lng_d"], "checked" => $comp["int_lng"]), array("type" => "text", "length" => 200, "name" => "lng_url", "head" => $core->lang["comp_int_chk_url"], "descr" => $core->lang["comp_int_chk_url_d"], "value" => htmlspecialchars($comp["int_lng_url"])), array("type" => "code", "lang" => "clike,php", "mime" => "text/x-php", "name" => "lng_pre", "head" => $core->lang["comp_int_pre"], "value" => $comp["int_lng_pre"]), array("type" => "textarea", "rows" => 5, "name" => "lng_field", "head" => $core->lang["comp_int_chk_field"], "descr" => $core->lang["comp_int_chk_field_d"], "value" => $fld3), array("type" => "text", "length" => 5, "name" => "lng_count", "head" => $core->lang["comp_int_chk_count"], "descr" => $core->lang["comp_int_chk_count_d"], "value" => $comp["int_lng_count"]), array("type" => "select", "name" => "lng_format", "head" => $core->lang["comp_int_chk_format"], "value" => $format2), array("type" => "code", "lang" => "clike,php", "mime" => "text/x-php", "name" => "lng_code", "head" => $core->lang["comp_int_chk_code"], "descr" => $core->lang["comp_int_chk_code_d"], "value" => $comp["int_lng_code"]), array("type" => "head", "value" => $core->lang["comp_int_dlv_h"]), array("type" => "line", "value" => $core->text->lines($core->lang["comp_int_dlv_t"])), array("type" => "select", "name" => "dlv", "head" => $core->lang["comp_int_dlc"], "value" => $dlc), array("type" => "text", "length" => 200, "name" => "dlv_url", "head" => $core->lang["comp_int_add_url"], "descr" => $core->lang["comp_int_add_url_d"], "value" => htmlspecialchars($comp["int_dlv_url"])), array("type" => "code", "lang" => "clike,php", "mime" => "text/x-php", "name" => "dlv_pre", "head" => $core->lang["comp_int_pre"], "value" => $comp["int_dlv_pre"]), array("type" => "textarea", "rows" => 5, "name" => "dlv_field", "head" => $core->lang["comp_int_add_field"], "descr" => $core->lang["comp_int_add_field_d"], "value" => $fldd), array("type" => "code", "lang" => "clike,php", "mime" => "text/x-php", "name" => "dlv_code", "head" => $core->lang["comp_int_add_code"], "descr" => $core->lang["comp_int_add_code_d"], "value" => $comp["int_dlv_code"]), array("type" => "head", "value" => $core->lang["comp_int_dlc_h"]), array("type" => "line", "value" => $core->text->lines($core->lang["comp_int_dlc_t"])), array("type" => "checkbox", "name" => "dlc", "head" => $core->lang["comp_int_dlc"], "descr" => $core->lang["comp_int_dlc_d"], "checked" => $comp["int_dlc"]), array("type" => "text", "length" => 200, "name" => "dlc_url", "head" => $core->lang["comp_int_chk_url"], "descr" => $core->lang["comp_int_chk_url_d"], "value" => htmlspecialchars($comp["int_dlc_url"])), array("type" => "code", "lang" => "clike,php", "mime" => "text/x-php", "name" => "dlc_pre", "head" => $core->lang["comp_int_pre"], "value" => $comp["int_dlc_pre"]), array("type" => "textarea", "rows" => 5, "name" => "dlc_field", "head" => $core->lang["comp_int_chk_field"], "descr" => $core->lang["comp_int_chk_field_d"], "value" => $fld4), array("type" => "text", "length" => 5, "name" => "dlc_count", "head" => $core->lang["comp_int_chk_count"], "descr" => $core->lang["comp_int_chk_count_d"], "value" => $comp["int_dlc_count"]), array("type" => "select", "name" => "dlc_format", "head" => $core->lang["comp_int_chk_format"], "value" => $format3), array("type" => "code", "lang" => "clike,php", "mime" => "text/x-php", "name" => "dlc_code", "head" => $core->lang["comp_int_chk_code"], "descr" => $core->lang["comp_int_chk_code_d"], "value" => $comp["int_dlc_code"]));
    $core->site->form("integrate", $action, $core->lang["comp_int_h"], $field);
    $core->site->footer();
    $core->stop();
}
function integration_log($core, $comp)
{
    if ($core->user->work == 1 && $core->config("hide", "int")) {
        $core->go($core->url("mm", "", "access"));
    }
    $where = $param = array();
    if (!$comp) {
        if ($c = (int) $core->get["c"]) {
            $where[] = "comp_id = '" . $c . "'";
            $param["c"] = $c;
        } else {
            $c = 0;
        }
    } else {
        $where[] = "comp_id = '" . $comp . "'";
    }
    if ($o = (int) $core->get["o"]) {
        $where[] = "order_id = '" . $o . "'";
        $param["o"] = $o;
    } else {
        $o = 0;
    }
    if ($t = (int) $core->get["t"]) {
        $where[] = "log_type = '" . $t . "'";
        $param["t"] = $t;
    } else {
        $t = 0;
    }
    $where = $where ? " WHERE " . implode(" AND ", $where) : "";
    $page = max(1, (int) $core->get["page"]);
    $sh = 30;
    $st = $sh * ($page - 1);
    $lc = $core->db->field("SELECT COUNT(*) FROM " . DB_LOG_INT . $where);
    $log = $lc ? $core->db->data("SELECT * FROM " . DB_LOG_INT . " " . $where . " ORDER BY log_id DESC LIMIT " . $st . ", " . $sh) : array();
    $comps = $core->cpa->get("compa");
    $core->site->bc($core->lang["comp_inlog"]);
    $core->site->header();
    $core->tpl->load("body", "comp-inlog", defined("HACK_TPL_COMPINLOG") ? HACK : false);
    $core->tpl->vars("body", array("type" => $core->lang["type"], "comp" => $core->lang["company"], "show" => $core->lang["show"], "action" => $core->lang["action"], "status" => $core->lang["status"], "time" => $core->lang["time"], "order" => $core->lang["order"], "find" => $core->lang["find"], "reply" => $core->lang["inlog_reply"], "export" => $core->lang["inlog_export"], "result" => $core->lang["inlog_result"], "done" => $core->lang["done"], "error" => $core->lang["error"], "isadm" => $comp ? false : true, "u_search" => $core->url("m", "integration-log"), "o" => $o ? $o : "", "pages" => pages($core->url("m", "integration-log?") . http_build_query($param), $lc, $sh, $page), "shown" => sprintf($core->lang["shown"], $st + 1, min($st + $sh, $lc), $lc)));
    foreach ($comps as $i => $st) {
        $core->tpl->block("body", "comp", array("name" => $st, "value" => $i, "select" => $c == $i ? "selected=\"selected\"" : ""));
    }
    foreach ($core->lang["inlogtypes"] as $i => $st) {
        $core->tpl->block("body", "type", array("name" => $st, "value" => $i, "select" => $t == $i ? "selected=\"selected\"" : ""));
    }
    if ($log) {
        foreach ($log as $l) {
            $post = trim($l["log_post"]);
            if ($post[0] == "{" || $post[0] == "[") {
                $tp = json_encode(json_decode($post), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
                if ($tp) {
                    $post = $tp;
                }
            }
            $reply = trim($l["log_reply"]);
            if ($l["log_type"] < 3 || $l["log_type"] == 5) {
                if ($reply[0] == "{" || $reply[0] == "[") {
                    $tp = json_encode(json_decode($reply), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
                    $exprt = var_export(json_decode($reply, true), true);
                    if ($tp) {
                        $reply = $tp;
                    }
                } else {
                    $exprt = false;
                }
                $result = $l["log_result"];
                $ok = $result ? true : false;
            } else {
                $result = false;
                $ok = $reply ? true : false;
                switch ($l["log_result"]) {
                    case 1:
                        $exprt = var_export(json_decode($reply, true), true);
                        $reply = json_encode(json_decode($reply), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
                        break;
                    case 2:
                        $exprt = var_export(unserialize($reply), true);
                        break;
                    case 3:
                        $exprt = var_export(simplexml_load_string($reply), true);
                        break;
                    default:
                        $exprt = false;
                }
            }
            $core->tpl->block("body", "item", array("id" => $l["log_id"], "comp" => $comps[$l["comp_id"]], "u_comp" => $core->url("m", "integration-log?") . parset($param, "c", $l["comp_id"]), "type" => $core->lang["inlogtypes"][$l["log_type"]], "u_type" => $core->url("m", "integration-log?") . parset($param, "t", $l["log_type"]), "order" => $l["order_id"], "u_order" => $core->url("i", "order", $l["order_id"]), "time" => smartdate($l["log_time"]), "url" => $l["log_url"], "post" => htmlspecialchars($post), "reply" => htmlspecialchars($reply), "export" => htmlspecialchars($exprt), "result" => $result, "ok" => $ok));
        }
    } else {
        $core->tpl->block("body", "noitem");
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}

?>