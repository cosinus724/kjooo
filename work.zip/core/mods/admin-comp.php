<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function admin_comp($core)
{
    $action = isset($core->get["action"]) ? $core->text->link($core->get["action"]) : NULL;
    $id = isset($core->get["id"]) ? (int) $core->get["id"] : 0;
    switch ($action) {
        case "add":
            $name = $core->text->line($core->post["name"]);
            if (!$name) {
                $core->go($core->url("mm", "comps", "add-e"));
            }
            $mail = $core->text->link($name) . "@" . $core->server["HTTP_HOST"];
            if ($core->db->add(DB_COMP, array("comp_name" => $name))) {
                $id = $core->db->lastid();
                $ud = array("user_name" => $name, "user_mail" => $mail, "user_pass" => $core->user->pass(md5(microtime())), "user_work" => 1, "user_comp" => $id, "user_compad" => 1, "user_api" => md5(microtime() . rand()));
                if ($core->db->add(DB_USER, $ud)) {
                    $uid = $core->db->lastid();
                    $core->db->edit(DB_COMP, array("user_id" => $uid), array("comp_id" => $id));
                }
                $core->cpa->clear("comps");
                $core->cpa->clear("compa");
                $core->go($core->url("im", "comps", $id, "add-ok"));
            } else {
                $core->go($core->url("mm", "comps", "add-e"));
            }
        case "edit":
            $edit = array("user_id" => (int) $core->post["user"], "comp_name" => $core->text->line($core->post["name"]), "comp_type" => $core->post["type"] ? 1 : 0, "comp_mailto" => $core->text->email($core->post["mailto"]), "comp_block" => (int) $core->post["block"], "comp_offers" => $core->text->intline($core->post["offers"]), "autoaccept" => $core->post["autoaccept"] ? 1 : 0, "callscheme" => $core->text->line($core->post["callscheme"]), "ccp_day" => (int) $core->post["ccp_day"], "ccp_night" => (int) $core->post["ccp_night"], "ccp_sale" => (int) $core->post["ccp_sale"], "ccp_upsale" => $core->text->line($core->post["ccp_upsale"]), "hide_items" => $core->post["hide_items"] ? 1 : 0, "hide_audio" => $core->post["hide_audio"] ? 1 : 0, "hide_status" => $core->post["hide_status"] ? 1 : 0, "hide_change" => $core->post["hide_change"] ? 1 : 0);
            if ($core->db->edit(DB_COMP, $edit, "comp_id = '" . $id . "'")) {
                $core->cpa->clear("comp", $id);
                $core->cpa->clear("comps");
                $core->cpa->clear("compa");
                $core->cpa->clear("ccs");
                $core->go($core->url("mm", "comps", "edit-ok"));
            } else {
                $core->go($core->url("mm", "comps", "edit-e"));
            }
        case "del":
            if ($core->db->query("DELETE FROM " . DB_COMP . " WHERE comp_id = '" . $id . "'")) {
                $core->db->query("DELETE FROM " . DB_USER . " WHERE user_comp = '" . $id . "'");
                $core->db->query("DELETE FROM " . DB_ORDER . " WHERE comp_id = '" . $id . "'");
                $core->db->query("DELETE FROM " . DB_STORE . " WHERE comp_id = '" . $id . "'");
                $core->cpa->clear("comp", $id);
                $core->cpa->clear("comps");
                $core->cpa->clear("compa");
                $core->cpa->clear("ccs");
                $core->go($core->url("mm", "comps", "del-ok"));
            } else {
                $core->go($core->url("mm", "comps", "del-e"));
            }
    }
    $message = isset($core->get["message"]) ? $core->text->link($core->get["message"]) : NULL;
    switch ($message) {
        case "add-ok":
            $core->site->info("info", "done_comps_add");
            break;
        case "edit-ok":
            $core->site->info("info", "done_comps_edit");
            break;
        case "del-ok":
            $core->site->info("info", "done_comps_del");
            break;
        case "add-e":
            $core->site->info("error", "error_comps_add");
            break;
        case "edit-e":
            $core->site->info("error", "error_comps_edit");
            break;
        case "del-e":
            $core->site->info("error", "error_comps_del");
            break;
        case "del-a":
            $core->site->info("error", "error_comps_root");
            break;
    }
    if ($id) {
        $comp = $core->db->row("SELECT * FROM " . DB_COMP . " WHERE comp_id = '" . $id . "' LIMIT 1");
        $user = array(array("name" => "&mdash; " . $core->lang["comp_free"] . " &mdash;", "value" => 0));
        $users = $core->db->icol("SELECT user_id, user_name FROM " . DB_USER . " WHERE user_comp = '" . $id . "' AND user_compad = 1 ORDER BY user_name ASC");
        foreach ($users as $u => $n) {
            $user[] = array("name" => $n, "value" => $u, "select" => $u == $comp["user_id"]);
        }
        $core->site->bc($core->lang["admin_comp_h"], $core->url("m", "comps"));
        $core->site->bc($comp["comp_name"]);
        $core->site->set("select2");
        $core->site->header();
        $field = array(array("type" => "text", "length" => 100, "name" => "name", "head" => $core->lang["name"], "value" => $comp["comp_name"]), array("type" => "checkbox", "name" => "type", "head" => $core->lang["comp_type"], "descr" => $core->lang["comp_type_d"], "checked" => $comp["comp_type"]), array("type" => "select", "name" => "user", "head" => $core->lang["comp_user"], "descr" => $core->lang["comp_user_d"], "value" => $user), array("type" => "number", "name" => "block", "head" => $core->lang["comp_block"], "descr" => $core->lang["comp_block_d"], "value" => $comp["comp_block"]), array("type" => "email", "length" => 100, "name" => "mailto", "head" => $core->lang["comp_mailto"], "descr" => $core->lang["comp_mailto_d"], "value" => $comp["comp_mailto"]), array("type" => "text", "name" => "callscheme", "head" => $core->lang["comp_callscheme"], "descr" => $core->lang["comp_callscheme_d"], "value" => $comp["callscheme"]), array("type" => "mselect", "name" => "offers", "head" => $core->lang["comp_offers"], "descr" => $core->lang["comp_offers_d"], "options" => $core->cpa->get("offers"), "value" => $comp["comp_offers"]), array("type" => "checkbox", "name" => "autoaccept", "head" => $core->lang["comp_autoaccept"], "descr" => $core->lang["comp_autoaccept_d"], "checked" => $comp["autoaccept"]), array("type" => "checkbox", "name" => "hide_items", "head" => $core->lang["comp_hide_items"], "checked" => $comp["hide_items"]), array("type" => "checkbox", "name" => "hide_audio", "head" => $core->lang["comp_hide_audio"], "checked" => $comp["hide_audio"]), array("type" => "checkbox", "name" => "hide_status", "head" => $core->lang["comp_hide_status"], "checked" => $comp["hide_status"]), array("type" => "checkbox", "name" => "hide_change", "head" => $core->lang["comp_hide_change"], "checked" => $comp["hide_change"]), array("type" => "head", "value" => $core->lang["comp_ccp"]), array("type" => "line", "value" => $core->text->lines($core->lang["comp_ccp_d"])), array("type" => "text", "name" => "ccp_day", "head" => $core->lang["comp_ccp_day"], "descr" => $core->lang["comp_ccp_day_d"], "value" => $comp["ccp_day"]), array("type" => "text", "name" => "ccp_night", "head" => $core->lang["comp_ccp_night"], "descr" => $core->lang["comp_ccp_night_d"], "value" => $comp["ccp_night"]), array("type" => "text", "name" => "ccp_sale", "head" => $core->lang["comp_ccp_sale"], "descr" => $core->lang["comp_ccp_sale_d"], "value" => $comp["ccp_sale"]), array("type" => "text", "name" => "ccp_upsale", "head" => $core->lang["comp_ccp_upsale"], "descr" => $core->lang["comp_ccp_upsale_d"], "value" => $comp["ccp_upsale"]));
        $core->site->form("comp", $core->url("ia", "comps", $id, "edit"), $core->lang["comp_edit"], $field);
        $core->site->footer();
    } else {
        $comps = $core->db->data("SELECT comp_id, comp_name, comp_type, user_id FROM " . DB_COMP . " ORDER BY comp_name ASC");
        $core->site->bc($core->lang["admin_comp_h"], $core->url("m", "comps"));
        $core->site->header();
        $core->tpl->load("body", "comps", defined("HACK_TPL_COMPS") ? HACK : false);
        $core->tpl->vars("body", array("title" => $core->lang["admin_comp_h"], "name" => $core->lang["name"], "type" => $core->lang["type"], "cash" => $core->lang["cash"], "action" => $core->lang["action"], "delivery" => $core->lang["deliver"], "stage" => $core->lang["comp_stages"], "int" => $core->lang["comp_int"], "edit" => $core->lang["edit"], "del" => $core->lang["del"], "confirm" => $core->lang["confirms"], "noitems" => $core->lang["noitems"], "u_add" => $core->url("ma", "comps", "add"), "add" => $core->lang["add"], "u_log" => $core->url("m", "integration-log"), "log" => $core->lang["comp_inlog"]));
        if ($comps) {
            foreach ($comps as $i) {
                $core->tpl->block("body", "item", array("id" => $i["comp_id"], "name" => $i["comp_name"], "cash" => $i["user_id"] ? $core->currency->money($core->user->get($i["user_id"], "user_cash")) : $core->lang["comp_free"], "tid" => $i["comp_type"], "type" => $core->lang["comp_types"][$i["comp_type"]], "int" => $core->url("i", "integration", $i["comp_id"]), "stage" => $core->url("i", "comp-stage", $i["comp_id"]), "delivery" => $core->url("i", "comp-delivery", $i["comp_id"]), "edit" => $core->url("i", "comps", $i["comp_id"]), "del" => $core->url("ia", "comps", $i["comp_id"], "del")));
            }
        } else {
            $core->tpl->block("body", "noitem");
        }
        $core->tpl->output("body");
        $core->site->footer();
    }
    $core->stop();
}

?>