<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function crontab($type)
{
    define("IN_ALTERCMS_CORE_ONE", true);
    require_once PATH . "config.php";
    if (!defined("PIDFILE")) {
        define("PIDFILE", PATH . "data/work/%s.pid");
    }
    if (!defined("STATFILE")) {
        define("STATFILE", PATH . "data/work/cron-%s.txt");
    }
    $pidfile = sprintf(PIDFILE, $type);
    $pid = @file_get_contents($pidfile);
    $file = $_SERVER["PHP_SELF"];
    if (is_dir("/proc/")) {
        if ($pid && is_dir("/proc/" . $pid)) {
            $cmdline = @file_get_contents("/proc/" . $pid . "/cmdline");
            if (strpos($cmdline, $file) !== false) {
                exit;
            }
        }
    } else {
        if ($pid) {
            exec("ps -a " . $pid, $oo);
            $sub = strrpos($oo[0], "CMD");
            $oo = end($oo);
            $cmdline = trim(substr($oo, $sub));
            if (strpos($cmdline, $file) !== false) {
                exit;
            }
        }
    }
    file_put_contents($pidfile, getmypid());
    $stmr = microtime();
    define("INTHEWORK", true);
    require_once PATH . "core/start.php";
    if (defined("HACK")) {
        $hf = PATH . HACK . "/hack/cron-" . $type . ".php";
        if (file_exists($hf)) {
            require_once $hf;
        }
    }
    $task1 = "cron" . $type;
    $task2 = "cron" . $type . "_hack";
    if (function_exists($task2)) {
        $task2($core);
    }
    if (!function_exists($task1)) {
        require_once PATH_MODS . "cron-" . $type . ".php";
        $task1($core);
    } else {
        $task1($core);
    }
    $stmr = explode(" ", $stmr);
    $stmr = (double) $stmr[0] + (double) $stmr[1];
    $ftmr = explode(" ", microtime());
    $ftmr = (double) $ftmr[0] + (double) $ftmr[1];
    $timer = sprintf("%1.3f", $ftmr - $stmr);
    $ram = function_exists("memory_get_peak_usage") ? memory_get_peak_usage() : 0;
    $sf = sprintf(STATFILE, $type);
    $stats = array("timer" => $timer, "memory" => $ram);
    file_put_contents($sf, json_encode($stats));
}

?>