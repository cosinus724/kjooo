<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function configpage_diag($core)
{
    $action = isset($core->get["action"]) ? $core->text->link($core->get["action"]) : false;
    if ($action) {
        switch ($action) {
            case "cleanup":
                $cache = $core->text->link($core->get["cache"]);
                switch ($cache) {
                    case "mc":
                        if (isset($core->mcobj)) {
                            $core->mcobj->flush();
                        }
                        break;
                    case "main":
                        cleandir(PATH . "data/cache/");
                        break;
                    case "session":
                        cleandir(PATH . "data/session/");
                        break;
                    case "tpls":
                        cleandir(PATH . "data/tpls/");
                        break;
                    case "load":
                        cleandir(PATH . "data/load/");
                        break;
                    default:
                        $core->filter("cache_cleanup", $cache);
                }
                $core->go($core->u("config-diag", "message=cache"));
            case "fixdb":
                require_once PATH . "core/setup/db.php";
                require_once PATH . "core/setup/cdb.php";
                $dbv = $core->config("dbversion");
                checkdatabase($core->db);
                checksystemconfigs($core->db, $core);
                updatedatabase($core->db, $dbv);
                $core->go($core->u("config-diag", "message=ok"));
        }
    }
    $message = isset($core->get["message"]) ? $core->text->link($core->get["message"]) : false;
    if ($message) {
        switch ($message) {
            case "ok":
                $core->site->info("info", "done_basic");
                break;
            case "cache":
                $core->site->info("info", "done_control_cache_clean");
                break;
        }
    }
    $core->site->bc($core->lang["configs_h"], $core->u("config"));
    $core->site->bc($core->lang["config_diag"]);
    $core->site->header();
    $core->tpl->load("body", "config-diag", defined("HACК_TPL_CONFIGDIAG") ? HACK : false);
    $core->tpl->vars("body", array("cache" => $core->lang["config_diag_cache"], "crons" => $core->lang["config_diag_crons"], "name" => $core->lang["name"], "size" => $core->lang["size"], "files" => $core->lang["cache_files"], "action" => $core->lang["action"], "confirm" => $core->lang["confirm"], "clean" => $core->lang["cache_cleanup"], "start" => $core->lang["cron_start"], "timer" => $core->lang["cron_timer"], "ram" => $core->lang["cron_ram"]));
    $caches = array("main" => PATH . "data/cache/", "tpls" => PATH . "data/tpls/", "session" => PATH . "data/session/", "load" => PATH . "data/load/");
    $caches = $core->filter("cache_filter", $caches);
    if ($core->cachetype == 1 && isset($core->mcobj)) {
        $data = $core->mcobj->getStats();
        $core->tpl->block("body", "cache", array("name" => $core->lang["cache_mc"], "files" => $data["curr_items"], "size" => mkb($data["bytes"]), "clean" => $core->u("config-diag", "action=cleanup&cache=mc")));
    }
    if ($core->cachetype == 2 && isset($core->mcobj)) {
        $data = $core->mcobj->getStats();
        $data = array_pop($data);
        $core->tpl->block("body", "cache", array("name" => $core->lang["cache_mc"], "files" => $data["curr_items"], "size" => mkb($data["bytes"]), "clean" => $core->u("config-diag", "action=cleanup&cache=mc")));
    }
    foreach ($caches as $name => $dir) {
        $data = cachedirscan($dir);
        $core->tpl->block("body", "cache", array("name" => $core->lang["cache_" . $name], "files" => (int) $data["files"], "size" => mkb($data["size"]), "clean" => $core->u("config-diag", "action=cleanup&cache=" . $name)));
    }
    $crons = array("1min", "3min", "10min", "1day");
    $crons = $core->filter("cron_list", $crons);
    foreach ($crons as $c) {
        $pid = @file_get_contents(DIR_WORK . $c . ".pid");
        $ptm = @filemtime(DIR_WORK . $c . ".pid");
        $pst = @file_get_contents(DIR_WORK . "cron-" . $c . ".txt");
        $pst = $pst ? json_decode($pst, true) : array();
        if (is_dir("/proc/")) {
            if ($pid && is_dir("/proc/" . $pid)) {
                $cmdline = @file_get_contents("/proc/" . $pid . "/cmdline");
                $pwk = strpos($cmdline, $file) !== false ? true : false;
            } else {
                $pwk = false;
            }
        } else {
            if ($pid) {
                exec("ps -a " . $pid, $oo);
                $sub = strrpos($oo[0], "CMD");
                $oo = end($oo);
                $cmdline = trim(substr($oo, $sub));
                $pwk = strpos($cmdline, $file) !== false ? true : false;
            } else {
                $pwk = false;
            }
        }
        $core->tpl->block("body", "cron", array("name" => $core->lang["crontask_" . $c], "uid" => $c, "pid" => $pid, "work" => $pwk, "start" => $ptm ? $core->text->smartdate($ptm) : false, "timer" => $pst["timer"], "ram" => $pst["memory"] ? mkb($pst["memory"]) : false));
    }
    $core->tpl->block("body", "task", array("title" => $core->lang["dbfix_title"], "descr" => $core->lang["dbfix_descr"], "button" => $core->lang["dbfix_button"], "url" => $core->u("config-diag", "action=fixdb")));
    $core->process("diag_config_page");
    $core->tpl->output("body");
    $core->process("diag_config_blocks");
    $core->site->footer();
    $core->stop();
}
function cachedirscan($dir)
{
    $size = $files = 0;
    $d = @opendir($dir);
    if (!$d) {
        return array("size" => 0, "files" => 0);
    }
    while (($f = readdir($d)) !== false) {
        if ($f == "." || $f == ".." || $f == "index.html") {
            continue;
        }
        if (is_dir($dir . $f)) {
            $data = cachedirscan($dir . $f . "/");
            $size += $data["size"];
            $files += $data["files"];
        } else {
            $files += 1;
            $size += filesize($dir . $f);
        }
    }
    closedir($d);
    return array("size" => $size, "files" => $files);
}

?>