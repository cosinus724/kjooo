<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function admin_business($core)
{
    $id = (int) $core->get["id"];
    if (!$id) {
        $id = date("Ym");
    }
    if ($id < 10000) {
        $id *= 100;
    }
    $year = round($id / 100);
    $month = $id % 100;
    if ($month) {
        $f = strtotime((string) $year . "-" . $month . "-01");
        $e = strtotime("+ 1 month", $f);
    } else {
        $f = strtotime((string) $year . "-01-01");
        $e = strtotime("+ 1 year", $f);
    }
    $balance = array();
    $money = $core->db->icol("SELECT cash_type, SUM(cash_value) FROM " . DB_CASH . " WHERE cash_time BETWEEN '" . $f . "' AND '" . $e . "' GROUP BY cash_type");
    foreach ($core->lang["cash_type"] as $i => &$v) {
        $balance[$i] = $money[$i] * $core->lang["cash_balance"][$i];
    }
    $debt = $core->db->icol("SELECT user_name, user_cash FROM " . DB_USER . " WHERE user_work = 1 AND user_cash < 0 ORDER BY user_cash DESC");
    $cred = $core->db->icol("SELECT user_name, user_cash FROM " . DB_USER . " WHERE user_work IN ( 0, 2 )AND user_cash > 0 ORDER BY user_cash ASC");
    $exts = $core->db->icol("SELECT user_name, user_cash FROM " . DB_USER . " WHERE user_work = -1 AND user_cash > 0 ORDER BY user_cash ASC");
    $core->site->bc($core->lang["menu_business"]);
    $core->site->header();
    $core->tpl->load("body", "business", defined("HACK_TPL_BUSINESS") ? HACK : false);
    $core->tpl->vars("body", array("u_trans" => $core->url("m", "trans"), "trans" => $core->lang["menu_trans"], "years" => $core->lang["year"], "months" => $core->lang["month"], "cat" => $core->lang["business_cat"], "total" => $core->lang["business_total"], "summ" => $core->lang["cash"], "balance" => $core->lang["business_balance"], "user" => $core->lang["user"], "debt" => $core->lang["debt_list"], "cred" => $core->lang["cred_list"], "nodebts" => $core->lang["debt_no"], "nocreds" => $core->lang["cred_no"], "cred_balance" => $core->lang["cred_balance"], "cred_wait" => $core->lang["cred_wait"], "ext_balance" => $core->lang["ext_balance"], "noext" => $core->lang["ext_no"], "m_balance" => $core->currency->money(array_sum($balance)), "d_balance" => $core->currency->money(abs($dt = array_sum($debt))), "c_balance" => $core->currency->money($ct = array_sum($cred)), "c_ext" => $core->currency->money($et = array_sum($exts)), "c_wait" => $core->currency->money(abs($money[4])), "c_total" => $core->currency->money($ct + $et + abs($money[4]))));
    if ($dt) {
        $core->tpl->block("body", "dt");
    }
    if ($ct) {
        $core->tpl->block("body", "ct");
    }
    if ($et) {
        $core->tpl->block("body", "et");
    }
    if ($money[4]) {
        $core->tpl->block("body", "morecred");
    }
    for ($y = 2014; $y <= date("Y"); $y++) {
        $core->tpl->block("body", "year", array("class" => $y == $year ? "current" : "", "mclass" => $y == $year ? "primary" : "info", "url" => $core->url("i", "business", $y), "text" => $y));
    }
    for ($m = 1; $m < 13; $m++) {
        $core->tpl->block("body", "month", array("class" => $m == $month ? "current" : "", "mclass" => $m == $month ? "primary" : "info", "url" => $core->url("i", "business", sprintf("%04d%02d", $year, $m)), "text" => $core->lang["months"][$m]));
    }
    foreach ($core->lang["cash_type"] as $i => &$v) {
        $core->tpl->block("body", "cash", array("id" => $i, "name" => $v, "summ" => $core->currency->money($money[$i]), "balance" => $core->currency->money($balance[$i])));
    }
    unset($v);
    if (count($debt)) {
        foreach ($debt as $n => $s) {
            $core->tpl->block("body", "debt", array("name" => $n, "summ" => $core->currency->money(abs($s))));
        }
    } else {
        $core->tpl->block("body", "nodebt");
    }
    if (count($cred)) {
        foreach ($cred as $n => $s) {
            $core->tpl->block("body", "cred", array("name" => $n, "summ" => $core->currency->money(abs($s))));
        }
    } else {
        if (!$money[4]) {
            $core->tpl->block("body", "nocred");
        }
    }
    if (count($exts)) {
        foreach ($exts as $n => $s) {
            $core->tpl->block("body", "ext", array("name" => $n, "summ" => $core->currency->money(abs($s))));
        }
    } else {
        if (!$money[4]) {
            $core->tpl->block("body", "noext");
        }
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}
function admin_trans($core)
{
    $action = isset($core->get["action"]) ? $core->text->link($core->get["action"]) : NULL;
    $id = isset($core->get["id"]) ? (int) $core->get["id"] : 0;
    switch ($action) {
        case "del":
            $core->finance->del($id);
            msgo($core, "del");
    }
    $message = isset($core->get["message"]) ? $core->text->link($core->get["message"]) : NULL;
    switch ($message) {
        case "del":
            $core->site->info("info", "trans_del");
            break;
    }
    $where = $param = array();
    if (isset($core->get["s"]) && $core->get["s"]) {
        require_once PATH_CORE . "search.php";
        $search = new SearchWords($core->get["s"]);
        if ($s = $search->get()) {
            $where[] = $search->field(array("cash_descr"), 1);
        } else {
            $s = false;
        }
        if ($s) {
            $param["s"] = $s;
        }
    } else {
        $s = false;
    }
    if ($d = $core->get["d"]) {
        $dd = explode("-", $d);
        $ds = mktime(0, 0, 0, $dd[1], $dd[2], $dd[0]);
        $de = mktime(23, 59, 59, $dd[1], $dd[2], $dd[0]);
        $where[] = "( cash_time BETWEEN '" . $ds . "' AND '" . $de . "' )";
        $param["d"] = $d;
    } else {
        $d = false;
    }
    if (isset($core->get["f"]) && $core->get["f"] != "") {
        $f = (int) $core->get["f"];
        $param["f"] = $f;
        $where[] = "user_id = '" . $f . "'";
    } else {
        $f = false;
    }
    if (isset($core->get["t"]) && $core->get["t"] != "") {
        $t = (int) $core->get["t"];
        $param["t"] = $t;
        $where[] = "cash_type = '" . $t . "'";
    } else {
        $t = false;
    }
    $page = max(1, (int) $core->get["page"]);
    $sh = defined("TRANS_PER_PAGE") ? TRANS_PER_PAGE : 50;
    $st = $sh * ($page - 1);
    $where = count($where) ? implode(" AND ", $where) : "1";
    $trc = $core->db->field("SELECT COUNT(*) FROM " . DB_CASH . " WHERE " . $where);
    $trs = $trc ? $core->db->data("SELECT * FROM " . DB_CASH . " WHERE " . $where . " ORDER BY cash_time DESC LIMIT " . $st . ", " . $sh) : array();
    if ($trc) {
        $ui = array();
        foreach ($trs as &$tq) {
            $ui[] = $tq["user_id"];
        }
        unset($tq);
        $ui = implode(",", array_unique($ui));
        $u = $core->db->icol("SELECT user_id, user_name FROM " . DB_USER . " WHERE user_id IN ( " . $ui . " )");
    } else {
        $u = array();
    }
    $core->site->bc($core->lang["menu_sub_trans"], $core->url("m", "trans"));
    $core->site->header();
    $core->tpl->load("body", "trans", defined("HACK_TPL_TRANS") ? HACK : false);
    $core->tpl->vars("body", array("user" => $core->lang["user"], "type" => $core->lang["type"], "cash" => $core->lang["cash"], "status" => $core->lang["status"], "time" => $core->lang["time"], "del" => $core->lang["del"], "confirm" => $core->lang["confirm"], "action" => $core->lang["action"], "d" => $d, "f" => $f, "s" => $search ? $search->get() : $s, "pages" => pages($core->u("trans", $param), $trc, $sh, $page, sprintf($core->lang["shown"], $st + 1, min($st + $sh, $trc), $trc)), "shown" => sprintf($core->lang["shown"], $st + 1, min($st + $sh, $trc), $trc), "filter" => $core->lang["filter"], "date" => $core->lang["date"], "search" => $core->lang["search"], "find" => $core->lang["find"]));
    if ($f) {
        $core->tpl->block("body", "user");
        $core->tpl->vars("body", array("user" => $core->lang["user"], "u" => $u[$f], "reset" => $core->url("m", "trans?") . ($d ? "d=" . $d . "&" : "") . ($s ? "s=" . $s . "&" : "")));
    }
    foreach ($core->lang["cash_type"] as $i => $st) {
        $core->tpl->block("body", "type", array("name" => $st, "value" => $i, "select" => $t == $i ? "selected=\"selected\"" : ""));
    }
    if (count($trs)) {
        foreach ($trs as &$c) {
            $core->tpl->block("body", "fin", array("user" => $u[$c["user_id"]], "uu" => $core->url("m", "trans") . "?f=" . $c["user_id"], "type" => $core->lang["cash_type"][$c["cash_type"]], "tid" => $c["cash_type"], "descr" => $c["cash_descr"] ? "(" . ($search ? $search->highlight($c["cash_descr"]) : $c["cash_descr"]) . ")" : "", "value" => $core->currency->money($c["cash_value"]), "del" => $core->url("ia", "trans", $c["cash_id"], "del"), "time" => smartdate($c["cash_time"])));
        }
        unset($t);
        unset($trs);
    } else {
        $core->tpl->block("body", "nofin", array());
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}
function admin_dynamics($core)
{
    $today = date("Ymd");
    $day7 = date("Ymd", strtotime("-6 days"));
    $day30 = date("Ymd", strtotime("-30 days"));
    $day90 = date("Ymd", strtotime("-90 days"));
    if (isset($core->get["to"]) && $core->get["to"]) {
        $to = form2date($core->get["to"]);
        if ($today < $to) {
            $to = $today;
        }
    } else {
        $to = $today;
    }
    if (isset($core->get["from"]) && $core->get["from"]) {
        $from = form2date($core->get["from"]);
        if ($to < $from) {
            $from = $to;
        }
    } else {
        $from = $day30;
    }
    $ff = strtotime(date2form($from) . " 00:00:00");
    $tt = strtotime(date2form($to) . " 23:59:59");
    $stats = array();
    $oq = $core->db->start("SELECT cash_time, cash_value FROM " . DB_CASH . " WHERE cash_type IN ( 2, 3, 6 ) AND cash_time BETWEEN '" . $ff . "' AND '" . $tt . "'");
    while ($q = $core->db->one($oq)) {
        if (!$q["cash_value"]) {
            continue;
        }
        $d = date("Ymd", $q["cash_time"]);
        $v = 0 - $q["cash_value"];
        if (!$stats[$d]) {
            $stats[$d] = array("i" => 0, "o" => 0);
        }
        $stats[$d][0 < $v ? "i" : "o"] += $v;
    }
    $core->db->stop($oq);
    krsort($stats);
    foreach ($stats as &$s) {
        $s["t"] = $s["i"] + $s["o"];
    }
    unset($s);
    reset($stats);
    list($d, $s) = each($stats);
    while (1) {
        $d1 = $d;
        $s1 = $s;
        list($d, $s) = each($stats);
        if (!$d) {
            break;
        }
        $stats[$d1]["d"] = $s1["t"] - $s["t"];
    }
    reset($stats);
    $core->site->bc($core->lang["dynamics"], $core->url("m", "dynamics"));
    $core->site->header();
    $core->tpl->load("body", "dynamics", defined("HACK_TPL_DYNAMICS") ? HACK : false);
    $core->tpl->vars("body", array("date" => $core->lang["date"], "income" => $core->lang["anal_income"], "outcome" => $core->lang["anal_outcome"], "total" => $core->lang["anal_total"], "from" => date2form($from), "to" => date2form($to), "show" => $core->lang["show"], "hasstats" => $stats ? true : false, "noitems" => $core->lang["nostats"], "u_analytics" => $core->url("m", "analytics"), "analytics" => $core->lang["menu_analytics"], "day7" => $core->lang["anal_day7"], "day30" => $core->lang["anal_day30"], "day90" => $core->lang["anal_day90"], "u_day7" => $core->url("m", "dynamics?from=") . date2form($day7) . "&to=" . date2form($today), "u_day30" => $core->url("m", "dynamics?from=") . date2form($day30) . "&to=" . date2form($today), "u_day90" => $core->url("m", "dynamics?from=") . date2form($day90) . "&to=" . date2form($today)));
    if ($stats) {
        foreach ($stats as $d => $s) {
            $core->tpl->block("body", "date", array("day" => date2form($d), "wd" => $core->lang["weekday"][date("w", strtotime(date2form($d)))], "in" => $core->currency->money($s["i"]), "out" => $core->currency->money($s["o"]), "total" => $core->currency->money($s["t"]), "delta" => $core->currency->money($s["d"]), "ttl" => sprintf("%0.2f", $s["t"])));
        }
        ksort($stats);
        foreach ($stats as $d => $s) {
            $core->tpl->block("body", "gr", array("date" => date2form($d), "total" => sprintf("%0.2f", $s["t"])));
        }
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}
function admin_outs($core)
{
    $action = isset($core->get["action"]) ? $core->text->link($core->get["action"]) : NULL;
    $id = isset($core->get["id"]) ? (int) $core->get["id"] : 0;
    switch ($action) {
        case "accept":
            $c = $core->db->row("SELECT * FROM " . DB_CASH . " WHERE cash_id = '" . $id . "' LIMIT 1");
            if ($c["cash_type"] == 4) {
                if ($core->finance->edit($id, 5)) {
                    $core->go($core->url("mm", "outs", "acc-ok"));
                } else {
                    $core->go($core->url("mm", "outs", "acc-e"));
                }
            } else {
                $core->go($core->url("mm", "outs", "acc-e"));
            }
        case "decline":
            $c = $core->db->row("SELECT * FROM " . DB_CASH . " WHERE cash_id = '" . $id . "' LIMIT 1");
            if ($c["cash_type"] == 4) {
                if ($core->finance->del($id)) {
                    $core->go($core->url("mm", "outs", "dec-ok"));
                } else {
                    $core->go($core->url("mm", "outs", "dec-e"));
                }
            } else {
                $core->go($core->url("mm", "outs", "dec-e"));
            }
        case "bulk":
            $outs = array();
            if ($core->post["ids"]) {
                foreach ($core->post["ids"] as $i) {
                    if ($i = (int) $i) {
                        $outs[] = $i;
                    }
                }
            }
            $otp = $outs ? $core->db->col("SELECT cash_id FROM " . DB_CASH . " WHERE cash_id IN ( " . implode(",", $outs) . " ) AND cash_type = 4") : array();
            if ($core->post["decline"]) {
                foreach ($otp as $id) {
                    $core->finance->del($id);
                }
                $core->go($core->url("mm", "outs", "dec-ok"));
            } else {
                foreach ($otp as $id) {
                    $core->finance->edit($id, 5);
                }
                $core->go($core->url("mm", "outs", "acc-ok"));
            }
    }
    $message = isset($core->get["message"]) ? $core->text->link($core->get["message"]) : NULL;
    switch ($message) {
        case "acc-ok":
            $core->site->info("info", "done_out_acc");
            break;
        case "dec-ok":
            $core->site->info("info", "done_out_dec");
            break;
        case "acc-e":
            $core->site->info("error", "error_out_acc");
            break;
        case "dec-e":
            $core->site->info("error", "error_out_dec");
            break;
    }
    $trs = $core->db->data("SELECT * FROM " . DB_CASH . "  WHERE cash_type = 4 ORDER BY user_id ASC, cash_time DESC");
    if (count($trs)) {
        $ui = $s = array();
        foreach ($trs as &$t) {
            $ui[] = $t["user_id"];
            $s[$t["user_id"]] += $t["cash_value"];
        }
        unset($t);
        $ui = implode(",", array_unique($ui));
        $u = $core->db->icol("SELECT user_id, user_name FROM " . DB_USER . " WHERE user_id IN ( " . $ui . " )");
        $bo = $core->db->icol("SELECT wm_id, COUNT(*) FROM " . DB_ORDER . " WHERE wm_id IN ( " . $ui . " ) AND order_check = 1 GROUP BY wm_id");
    } else {
        $u = $bo = $s = array();
    }
    $core->site->bc($core->lang["menu_outs"], $core->url("m", "outs"));
    $core->site->header();
    $core->tpl->load("body", "outs", defined("HACK_TPL_LIST") ? HACK : false);
    $core->tpl->vars("body", array("user" => $core->lang["user"], "accept" => $core->lang["accept"], "decline" => $core->lang["decline"], "cash" => $core->lang["cash"], "pay" => $core->lang["pay"], "time" => $core->lang["date"], "action" => $core->lang["action"], "cancel" => $core->lang["cancel"], "confirma" => $core->lang["oconfirma"], "confirmd" => $core->lang["oconfirmd"], "nofins" => $core->lang["noout"], "check" => $core->lang["outcheck"], "select" => $core->lang["outselect"], "u_bulk" => $core->url("ma", "outs", "bulk")));
    if (count($trs)) {
        $ou = 0;
        foreach ($trs as &$c) {
            if ($ou != $c["user_id"]) {
                $ou = $c["user_id"];
                $core->tpl->block("body", "user", array("id" => $ou, "user" => $u[$ou], "orders" => $bo[$ou], "uu" => $core->url("i", "users", $ou), "value" => $core->currency->money(abs($s[$ou]))));
                if ($bo[$ou]) {
                    $core->tpl->block("body", "user.bad");
                }
            }
            $core->tpl->block("body", "user.fin", array("id" => $c["cash_id"], "wmr" => $c["cash_descr"], "value" => sprintf($core->currency->format, abs($c["cash_value"])), "accept" => $core->url("ia", "outs", $c["cash_id"], "accept"), "decline" => $core->url("ia", "outs", $c["cash_id"], "decline"), "time" => smartdate($c["cash_time"])));
        }
        unset($t);
        unset($trs);
    } else {
        $core->tpl->block("body", "nofin", array());
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}

?>