<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function configlist($core)
{
    $conflist = array(1 => array("name" => "basic", "icon" => "cog", "page" => "config-basic"), 2 => array("name" => "sites", "icon" => "sitemap", "page" => "config-sites"), 3 => array("name" => "advanced", "icon" => "cogs", "page" => "config-advanced"), 4 => array("name" => "money", "icon" => "money", "page" => "config-money"), 5 => array("name" => "domain", "icon" => "share-alt", "page" => "config-domain"), 6 => array("name" => "banph", "icon" => "phone", "page" => "config-banph"), 7 => array("name" => "banip", "icon" => "barcode", "page" => "config-banip"), 8 => array("name" => "diag", "icon" => "heartbeat", "page" => "config-diag"));
    $conflist = $core->filter("configlist", $conflist);
    switch (BOXSKIN) {
        case "primary":
            $bg = "light-blue";
            break;
        case "success":
            $bg = "green";
            break;
        case "danger":
            $bg = "red";
            break;
        case "warning":
            $bg = "yellow";
            break;
        case "info":
            $bg = "aqua";
            break;
        default:
            $bg = "green";
    }
    $core->site->bc($core->lang["configs_h"]);
    $core->site->pt($core->lang["configs_d"]);
    $core->site->header();
    $core->tpl->load("body", "config", defined("HACК_TPL_CONFIG") ? HACK : false);
    $core->tpl->vars("body", array("go" => $core->lang["configs_go"], "bg" => $bg, "btn" => BOXSKIN));
    foreach ($conflist as $c) {
        $core->tpl->block("body", "config", array("name" => $core->lang["config_" . $c["name"]], "descr" => $core->lang["config_" . $c["name"] . "_d"], "icon" => $c["icon"] ? $c["icon"] : "cogs", "url" => $core->u(array($c["page"]))));
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}
function configpage_basic($core)
{
    $domain = $core->server["HTTP_HOST"] ? $core->server["HTTP_HOST"] : $core->server["SERVER_NAME"];
    $dmbase = substr($domain, 0, 4) === "www." ? substr($domain, 4) : $domain;
    $tzl = timezone_identifiers_list();
    $tz = array();
    foreach ($tzl as $t) {
        $tz[$t] = $t;
    }
    $ctz = defined("TIMEZONE") ? TIMEZONE : @ini_get("date.timezone");
    if (!$ctz) {
        $ctz = date_default_timezone_get();
    }
    if (!$ctz) {
        $ctz = "Europe/Moscow";
    }
    $configs = array("site" => array("name" => array("text", "text", defined("SITENAME") ? SITENAME : "AlterCPA"), "nice" => array("text", "code", defined("SITENICE") ? SITENICE : "Alter<b>CPA</b>"), "short" => array("text", "code", defined("SITESHORT") ? SITESHORT : "A<b>C</b>"), "mail" => array("email", "email", defined("SITEMAIL") ? SITEMAIL : "info@" . $dmbase), "copy" => array("text", "code", defined("SITECOPY") ? SITECOPY : ""), "tz" => array("select", "text", $ctz, $tz)), "url" => array("base" => array("text", "text", defined("BASEURL") ? BASEURL : "http://" . $domain . "/"), "api" => array("text", "text", defined("APIURL") ? APIURL : "")), "mail" => array("from" => array("email", "email", defined("MAIL_FROM") ? MAIL_FROM : "noreply@" . $dmbase), "smtp" => array("checkbox", "bool", defined("MAIL_SERVER") ? true : false), "server" => array("text", "text", defined("MAIL_SERVER") ? MAIL_SERVER : "ssl://smtp.yandex.net"), "port" => array("number", "int", defined("MAIL_PORT") ? MAIL_PORT : 465), "user" => array("text", "text", defined("MAIL_USER") ? MAIL_USER : "noreply@" . $dmbase), "pass" => array("text", "text", defined("MAIL_PASS") ? MAIL_PASS : "password"), "domain" => array("text", "text", defined("MAIL_DOMAIN") ? MAIL_DOMAIN : $dmbase)), "register" => array("disable" => array("checkbox", "bool", defined("NOREGISTER") ? true : false), "noref" => array("checkbox", "bool", defined("HACK_NOREF") ? true : false), "hideref" => array("checkbox", "bool", defined("HACK_HIDEREF") ? true : false), "contact" => array("checkbox", "bool", defined("CHECKCONTACT") ? true : false)));
    require_once PATH_MODS . "config-page.php";
    configs_page($core, $configs, array("page" => "config-basic", "title" => $core->lang["config_basic_h"]));
}
function configpage_sites($core)
{
    $domain = $core->server["HTTP_HOST"] ? $core->server["HTTP_HOST"] : $core->server["SERVER_NAME"];
    $dmbase = substr($domain, 0, 4) === "www." ? substr($domain, 4) : $domain;
    $dmkey = md5(microtime() . rand());
    $configs = array("redirect" => array("domain" => array("text", "text", defined("LANDSURL") ? LANDSURL : $dmbase), "force" => array("checkbox", "bool", false), "flow" => array("text", "text", defined("REDURLGO") ? REDURLGO : "go"), "test" => array("text", "text", defined("REDURLST") ? REDURLST : "to"), "park" => array("checkbox", "bool", true), "ip" => array("text", "text", defined("PARKIP") ? PARKIP : $core->server["SERVER_ADDR"])), "sites" => array("domain" => array("text", "text", defined("LANDSURL") ? LANDSURL : "land." . $dmbase), "control" => array("text", "text", defined("LANDSCTRL") ? LANDSCTRL : "http://land." . $dmbase . "/control.php"), "key" => array("text", "text", defined("CONTROL") ? CONTROL : $dmkey), "park" => array("checkbox", "bool", false), "ip" => array("text", "text", "")), "space" => array("domain" => array("text", "text", defined("SPACEURL") ? SPACEURL : "blog." . $dmbase), "control" => array("text", "text", defined("SPACECTRL") ? SPACECTRL : "http://blog." . $dmbase . "/control.php"), "key" => array("text", "text", defined("CONTROL") ? CONTROL : $dmkey), "park" => array("checkbox", "bool", false), "ip" => array("text", "text", "")));
    require_once PATH_MODS . "config-page.php";
    configs_page($core, $configs, array("page" => "config-sites", "title" => $core->lang["config_sites_h"]));
}
function configpage_advanced($core)
{
    $configs = array("clicks" => array("life" => array("number", "int", defined("CLICKLIFE") ? CLICKLIFE : 60), "good" => array("number", "int", defined("GOODCLICK") ? GOODCLICK * 5 : 10), "server" => array("checkbox", "bool", defined("CLICKSERVER") ? true : false), "host" => array("text", "text", defined("CLICKSRV_HOST") ? CLICKSRV_HOST : "localhost"), "port" => array("number", "int", defined("CLICKSRV_PORT") ? CLICKSRV_PORT : 1862), "key" => array("text", "text", defined("CLICKSRV_KEY") ? CLICKSRV_KEY : md5(microtime() . rand()))), "lead" => array("life" => array("number", "int", defined("LEADLIFE") ? LEADLIFE : 60), "stat" => array("number", "int", defined("STATPERIOD") ? STATPERIOD : 15), "click" => array("checkbox", "bool", 0)), "offer" => array("page" => array("number", "int", defined("OFFERS_PER_PAGE") ? OFFERS_PER_PAGE : 30), "allow" => array("mselect", "ints", "", $core->lang["offer_src"]), "deny" => array("mselect", "ints", "", $core->lang["offer_src"])), "hide" => array("flows" => array("checkbox", "bool", 0), "split" => array("checkbox", "bool", 0), "domain" => array("checkbox", "bool", 0), "postback" => array("checkbox", "bool", 0), "offers" => array("checkbox", "bool", 0), "offerext" => array("checkbox", "bool", 0), "offercmp" => array("checkbox", "bool", 0), "lead" => array("checkbox", "bool", 0), "date" => array("checkbox", "bool", 0), "hour" => array("checkbox", "bool", 0), "offer" => array("checkbox", "bool", 0), "flow" => array("checkbox", "bool", 0), "utm" => array("checkbox", "bool", 0), "geo" => array("checkbox", "bool", 0), "ext" => array("checkbox", "bool", 0), "site" => array("checkbox", "bool", 0), "click" => array("checkbox", "bool", 0), "news" => array("checkbox", "bool", 0), "int" => array("checkbox", "bool", 0)), "statcol" => array("cr" => array("checkbox", "bool", 1), "epc" => array("checkbox", "bool", 1), "app" => array("checkbox", "bool", 1), "space" => array("checkbox", "bool", 1), "suni" => array("checkbox", "bool", 1), "sbad" => array("checkbox", "bool", 1), "stime" => array("checkbox", "bool", 1), "per" => array("checkbox", "bool", 1), "clicks" => array("checkbox", "bool", 1), "unique" => array("checkbox", "bool", 1), "bad" => array("checkbox", "bool", 1), "time" => array("checkbox", "bool", 1), "ca" => array("checkbox", "bool", 1), "cw" => array("checkbox", "bool", 1), "cc" => array("checkbox", "bool", 1), "ct" => array("checkbox", "bool", 1), "cx" => array("checkbox", "bool", 1), "ma" => array("checkbox", "bool", 1), "mw" => array("checkbox", "bool", 1), "mc" => array("checkbox", "bool", 1), "mt" => array("checkbox", "bool", 1), "ba" => array("checkbox", "bool", 0), "bb" => array("checkbox", "bool", 0), "flow" => array("checkbox", "bool", 1), "site" => array("checkbox", "bool", 1), "geo" => array("checkbox", "bool", 1), "utm" => array("checkbox", "bool", 1), "audio" => array("checkbox", "bool", 1)));
    $core->site->set("select2");
    require_once PATH_MODS . "config-page.php";
    configs_page($core, $configs, array("page" => "config-advanced", "title" => $core->lang["config_advanced_h"]));
}
function configpage_money($core)
{
    if (defined("DEFCUR")) {
        $cur = DEFCUR;
        if (is_numeric($cur)) {
            $cur = $core->currency->code($cur);
        }
    } else {
        $cur = "rub";
    }
    $configs = array("money" => array("currency" => array("select", "link", $cur, $core->currency->codes), "format" => array("checkbox", "bool", defined("CURFORMAT") && CURFORMAT == "%d" ? true : false), "minout" => array("number", "int", defined("MINFINANCE") ? MINFINANCE : 100), "key" => array("text", "link", defined("OXRKEY") ? OXRKEY : "")));
    $options = array("page" => "config-money", "title" => $core->lang["config_money_h"]);
    require_once PATH_MODS . "config-page.php";
    configs_actions($core, $configs, $options);
    if ($core->get["action"] == "exchange") {
        $core->currency->update();
        $core->go($core->u("config-money", "message=ok"));
    }
    $core->site->bc($core->lang["configs_h"], $core->u("config"));
    $core->site->bc($options["title"]);
    if ($options["pagetitle"]) {
        $core->site->pt($options["pagetitle"]);
    }
    $core->site->set("tablesorter");
    $core->site->header();
    configs_form($core, $configs, $options);
    $core->tpl->load("body", "config-money", defined("HACК_TPL_CONFIGMONEY") ? HACK : false);
    $core->tpl->vars("body", array("title" => $core->lang["config_money_tbl"], "currency" => $core->lang["currency"], "code" => $core->lang["code"], "curf" => strtoupper($core->currency->code($core->currency->default)), "curt" => $core->currency->prnt(1), "update" => $core->lang["update"], "url" => $core->u("config-money", "action=exchange")));
    foreach ($core->currency->names as $c => $n) {
        $cc = $core->currency->rawconv(1, $c);
        if (0 >= $cc) {
            continue;
        }
        $core->tpl->block("body", "item", array("name" => $n, "code" => strtoupper($c), "from" => $cc ? sprintf("%0.6f", $cc) : false, "to" => $cc ? sprintf("%0.6f", 1 / $cc) : false));
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}
function configpage_design($core)
{
    $configs = array();
    require_once PATH_MODS . "config-page.php";
    configs_page($core, $configs, array("page" => "config-design", "title" => $core->lang["config_design_h"]));
}
function configpage_domain($core)
{
    $core->site->bc($core->lang["configs_h"], $core->u("config"));
    $core->site->bc($core->lang["config_domain"]);
    $core->site->pt($core->lang["config_domain_h"]);
    require_once PATH_MODS . "wm-domain.php";
    wm_domain_page($core, array("page" => "config-domain", "user" => 0, "auth" => 1, "descr" => $core->lang["config_domain_t"]));
}

?>