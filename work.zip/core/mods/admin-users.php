<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function admin_users($core, $config = array())
{
    $id = (int) $core->get["id"];
    if (isset($core->get["action"])) {
        switch ($core->get["action"]) {
            case "add":
                $email = $core->text->email($core->post["email"]);
                if (!$email) {
                    $core->go($core->url("mm", "users", "add-e"));
                }
                $name = explode("@", $email);
                if ($config["manager"] && !$config["vip"]) {
                    $man = $config["manager"];
                } else {
                    if (function_exists("choose_manager")) {
                        $man = choose_manager($core);
                    } else {
                        $man = $core->db->field("SELECT user_id FROM " . DB_USER . " WHERE user_work = -2 ORDER BY RAND() LIMIT 1");
                    }
                }
                $data = array("user_name" => $name[0], "user_mail" => $email, "user_pass" => $core->user->pass(microtime() . rand()), "user_level" => 0, "user_man" => $man, "user_api" => md5(rand() . time() . rand()));
                if ($core->db->add(DB_USER, $data)) {
                    $uid = $core->db->lastid();
                    $core->go($core->url("im", "users", $uid, "add-ok"));
                } else {
                    $core->go($core->url("mm", "users", "add-e"));
                }
            case "edit":
                $data = array("user_name" => $core->text->line($core->post["name"]), "user_wmr" => $core->text->line($core->post["wmr"]), "user_ban" => $id == 1 ? 0 : ($core->post["ban"] ? 1 : 0), "user_warn" => $id == 1 ? 0 : ($core->post["warn"] ? 1 : 0), "user_vip" => $core->post["vip"] ? 1 : 0, "user_push" => $core->post["push"] ? 1 : 0);
                if ($email = $core->text->email($core->post["email"])) {
                    $data["user_mail"] = $email;
                }
                if ($core->post["pass"]) {
                    $data["user_pass"] = $core->user->pass($core->post["pass"]);
                }
                if ($config["manager"]) {
                    $u = $core->user->get($id);
                    if ($u["user_work"] == 0 || $u["user_man"] == $config["manager"]) {
                        if ($u["user_man"] != $config["manager"] && !$config["vip"]) {
                            $core->go($core->url("mm", "users", "access"));
                        }
                    } else {
                        $core->go($core->url("mm", "users", "access"));
                    }
                } else {
                    $data["user_man"] = (int) $core->post["man"];
                    $data["user_level"] = $id == 1 ? 1 : ($core->post["level"] ? 1 : 0);
                    $data["user_work"] = (int) $core->post["work"];
                    $data["user_ext"] = (int) $core->post["ext"];
                    $data["user_comp"] = $comp = (int) $core->post["comp"];
                    $data["user_compad"] = $core->post["compad"] ? 1 : 0;
                }
                if ($core->user->set($id, $data)) {
                    $core->user->meta($id, array("skype" => $core->text->line($core->post["skype"]), "telegram" => $core->text->line($core->post["telegram"]), "vk" => $core->text->line($core->post["vk"]), "whatsapp" => $core->text->line($core->post["whatsapp"]), "from" => $core->text->line($core->post["from"])));
                    if (!$config["manager"]) {
                        require_once PATH_LIB . "finance.php";
                        $f = new Finance($core);
                        $money = (int) $core->post["money"];
                        if ($money) {
                            $type = 0 < $money ? 1 : 5;
                            $f->add($id, 0, $money, $type, $core->lang["admin"]);
                        } else {
                            $f->recount($id);
                        }
                    }
                    if ($comp) {
                        $core->cpa->clear("mans", $comp);
                    }
                    $core->cpa->clear("allman");
                    $core->go($core->url("mm", "users", "edit-ok"));
                } else {
                    $core->go($core->url("mm", "users", "edit-e"));
                }
            case "del":
                if ($id != 1 && !$config["manager"]) {
                    $core->db->query("DELETE FROM " . DB_CLICK . " WHERE user_id = '" . $id . "'");
                    $core->db->query("DELETE FROM " . DB_STATS . " WHERE user_id = '" . $id . "'");
                    $core->db->query("DELETE FROM " . DB_FLOW . " WHERE user_id = '" . $id . "'");
                    $core->db->query("DELETE FROM " . DB_SUPP . " WHERE supp_user = '" . $id . "'");
                    $core->db->query("UPDATE " . DB_ORDER . " SET wm_id = 0, flow_id = 0 WHERE wm_id = '" . $id . "'");
                    $comp = $core->db->field("SELECT user_comp FROM " . DB_USER . " WHERE user_id = '" . $id . "' LIMIT 1");
                    if ($core->db->query("DELETE FROM " . DB_USER . " WHERE user_id = '" . $id . "'")) {
                        $core->cpa->clear("mans", $comp);
                        $core->cpa->clear("allman");
                        $core->go($core->url("mm", "users", "del-ok"));
                    } else {
                        $core->go($core->url("mm", "users", "del-e"));
                    }
                } else {
                    $core->go($core->url("mm", "users", "access"));
                }
        }
    }
    if (isset($core->get["message"])) {
        switch ($core->get["message"]) {
            case "add-ok":
                $core->site->info("info", "done_user_add");
                break;
            case "edit-ok":
                $core->site->info("info", "done_user_edit");
                break;
            case "del-ok":
                $core->site->info("info", "done_user_del");
                break;
            case "add-e":
                $core->site->info("error", "error_user_add");
                break;
            case "edit-e":
                $core->site->info("error", "error_user_edit");
                break;
            case "del-e":
                $core->site->info("error", "error_user_del");
                break;
            case "access":
                $core->site->info("error", "access_denied");
                break;
        }
    }
    $isadm = $config["manager"] ? false : true;
    if ($id) {
        $user = $core->db->row("SELECT * FROM " . DB_USER . " WHERE user_id = '" . $id . "' LIMIT 1");
        if ($config["manager"]) {
            if ($user["user_work"] == 0 || $user["user_man"] == $config["manager"]) {
                if ($user["user_man"] != $config["manager"] && !$config["vip"]) {
                    $core->go($core->url("mm", "users", "access"));
                }
            } else {
                $core->go($core->url("mm", "users", "access"));
            }
        }
        $core->site->bc($core->lang["admin_user_h"], $core->url("m", "users"));
        $core->site->bc($user["user_name"]);
        $core->site->header();
        if ($isadm) {
            $work = array();
            foreach ($core->lang["user_works"] as $i => $v) {
                $work[] = array("name" => $v, "value" => $i, "select" => $user["user_work"] == $i);
            }
            $comps = $core->cpa->get("compa");
            $comp = array(array("name" => "---", "value" => 0));
            foreach ($comps as $i => $c) {
                $comp[] = array("name" => $c, "value" => $i, "select" => $i == $user["user_comp"]);
            }
            $exts = $core->cpa->get("exts");
            $ext = array(array("name" => "---", "value" => 0));
            foreach ($exts as $i => $c) {
                $ext[] = array("name" => $c, "value" => $i, "select" => $i == $user["user_ext"]);
            }
            $mans = $core->db->icol("SELECT user_id, user_name FROM " . DB_USER . " WHERE user_work = 2 OR user_work = -2 ORDER BY user_work ASC, user_name ASC");
            $man = array(array("name" => "---", "value" => 0));
            foreach ($mans as $i => $c) {
                $man[] = array("name" => $c, "value" => $i, "select" => $i == $user["user_man"]);
            }
        }
        $meta = unserialize($user["user_meta"]);
        $field = array(array("type" => "text", "length" => 100, "name" => "name", "head" => $core->lang["user_name"], "value" => $user["user_name"]), array("type" => "text", "length" => 100, "name" => "email", "head" => $core->lang["user_email"], "value" => $user["user_mail"]), array("type" => "text", "length" => 32, "name" => "pass", "head" => $core->lang["user_pass"]), array("type" => "text", "length" => 100, "name" => "wmr", "head" => $core->lang["user_wmr"], "value" => $user["user_wmr"]), array("type" => "text", "length" => 50, "name" => "skype", "head" => $core->lang["user_skype"], "value" => $meta["skype"]), array("type" => "text", "length" => 50, "name" => "telegram", "head" => $core->lang["user_telegram"], "value" => $meta["telegram"]), array("type" => "text", "length" => 50, "name" => "whatsapp", "head" => $core->lang["user_whatsapp"], "value" => $meta["whatsapp"]), array("type" => "text", "length" => 50, "name" => "vk", "head" => $core->lang["user_vk"], "value" => $meta["vk"]), array("type" => "text", "name" => "api_id\" readonly=\"readonly", "head" => $core->lang["user_api"], "value" => $user["user_id"]), array("type" => "text", "name" => "api_key\" readonly=\"readonly", "head" => $core->lang["user_key"], "value" => $user["user_api"]), array("type" => "checkbox", "name" => "push", "head" => $core->lang["user_push"], "descr" => $core->lang["user_push_d"], "checked" => $user["user_push"]), array("type" => "checkbox", "name" => "ban", "head" => $core->lang["user_ban"], "descr" => $core->lang["user_ban_d"], "checked" => $user["user_ban"]), array("type" => "checkbox", "name" => "warn", "head" => $core->lang["user_warn"], "descr" => $core->lang["user_warn_d"], "checked" => $user["user_warn"]), $isadm ? array("type" => "select", "name" => "man", "head" => $core->lang["user_man"], "descr" => $core->lang["user_man_d"], "value" => $man) : NULL, $isadm ? array("type" => "select", "name" => "work", "head" => $core->lang["user_work"], "descr" => $core->lang["user_work_d"], "value" => $work) : NULL, $isadm ? array("type" => "checkbox", "name" => "level", "head" => $core->lang["user_level"], "descr" => $core->lang["user_level_d"], "checked" => $user["user_level"]) : NULL, array("type" => "checkbox", "name" => "vip", "head" => $core->lang["comp_vip"], "descr" => $core->lang["comp_vip_d"], "checked" => $user["user_vip"]), $isadm ? array("type" => "select", "name" => "ext", "head" => $core->lang["agency"], "value" => $ext) : NULL, $isadm ? array("type" => "select", "name" => "comp", "head" => $core->lang["company"], "value" => $comp) : NULL, $isadm ? array("type" => "checkbox", "name" => "compad", "head" => $core->lang["user_compad"], "descr" => $core->lang["user_compad_d"], "checked" => $user["user_compad"]) : NULL, $isadm ? array("type" => "text", "length" => 7, "name" => "money", "head" => $core->lang["user_money"], "descr" => $core->lang["user_money_d"]) : NULL, array("type" => "text", "length" => 50, "name" => "from", "head" => $core->lang["user_from"], "descr" => $core->lang["user_from_d"], "value" => $meta["from"]));
        $core->site->form("useredit", $core->url("ia", "users", $id, "edit"), $core->lang["user_edit"], $field);
        $core->site->footer();
    } else {
        $today = date("Ymd");
        $m1m = date("Ymd", strtotime("-2 weeks"));
        $m2m = date("Ymd", strtotime("-1 months"));
        $where = array();
        if (isset($core->get["s"]) && $core->get["s"]) {
            require_once PATH_CORE . "search.php";
            $search = new SearchWords($core->get["s"]);
            if ($s = $search->get()) {
                $where[] = $search->field(array("user_name", "user_mail"));
            } else {
                $s = false;
            }
        } else {
            $s = false;
        }
        if ($config["manager"]) {
            if ($config["vip"]) {
                $where[] = "( user_work = 0 OR user_man = '" . $config["manager"] . "' )";
            } else {
                $where[] = "user_man = '" . $config["manager"] . "'";
            }
            $l = $c = false;
        } else {
            if (isset($core->get["l"]) && $core->get["l"] != "") {
                $l = (int) $core->get["l"];
                $where[] = "user_work = '" . $l . "'";
            } else {
                $l = NULL;
            }
            if (isset($core->get["c"]) && $core->get["c"]) {
                $c = (int) $core->get["c"];
                $where[] = "user_comp = '" . $c . "'";
            } else {
                $c = false;
            }
        }
        $where = count($where) ? implode(" AND ", $where) : "1";
        $page = 0 < $core->get["page"] ? (int) $core->get["page"] : 1;
        $sh = 30;
        $st = $sh * ($page - 1);
        $users = $core->db->field("SELECT COUNT(*) FROM " . DB_USER . " WHERE " . $where);
        $user = $users ? $core->db->data("SELECT * FROM " . DB_USER . " WHERE " . $where . " ORDER BY user_work DESC, user_id ASC LIMIT " . $st . ", " . $sh) : array();
        $comp = $core->cpa->get("compa");
        $ext = $core->cpa->get("exts");
        $core->site->bc($core->lang["admin_user_h"], $core->url("m", "users"));
        $core->site->header();
        $core->tpl->load("body", "users", defined("HACK_TPL_USERS") ? HACK : false);
        $core->tpl->vars("body", array("isadm" => $isadm, "name" => $core->lang["user"], "email" => $core->lang["email"], "vip" => $core->lang["iamvip"], "level" => $core->lang["level"], "comp" => $core->lang["company"], "name" => $core->lang["user"], "cash" => $core->lang["cash"], "date" => $core->lang["date"], "action" => $core->lang["action"], "enter" => $core->lang["enter"], "edit" => $core->lang["edit"], "del" => $core->lang["del"], "confirm" => $core->lang["confirm"], "u_add" => $core->url("ma", "users", "add"), "add" => $core->lang["add"], "s" => $s, "pages" => pages($core->url("m", "users?") . ($c ? "c=" . $c . "&" : "") . ($l !== NULL ? "l=" . $l . "&" : "") . ($s ? "s=" . $s : ""), $users, $sh, $page, sprintf($core->lang["shown"], $st + 1, min($st + $sh, $users), $users)), "shown" => sprintf($core->lang["shown"], $st + 1, min($st + $sh, $users), $users), "search" => $core->lang["search"], "find" => $core->lang["find"], "s_order" => $core->lang["menu_order"], "s_offers" => $core->lang["menu_offers"], "s_domain" => $core->lang["menu_domain"], "s_flows" => $core->lang["menu_sub_flow"], "s_postback" => $core->lang["menu_sub_postback"], "s_split" => $core->lang["menu_split"], "s_leads" => $core->lang["menu_sub_leads"], "s_stats" => $core->lang["menu_sub_stats"], "s_hour" => $core->lang["menu_sub_hourstat"], "s_offer" => $core->lang["menu_sub_offerstat"], "s_flow" => $core->lang["menu_sub_flowstat"], "s_geo" => $core->lang["menu_sub_geostat"], "s_utm" => $core->lang["menu_sub_utm"], "s_exti" => $core->lang["menu_sub_exti"], "s_click" => $core->lang["menu_sub_click"], "s_anal" => $core->lang["menu_sub_analytics"], "s_analc" => $core->lang["menu_sub_analytics-calls"], "s_anald" => $core->lang["menu_sub_analytics-delivery"], "s_trans" => $core->lang["menu_sub_trans"]));
        foreach ($comp as $ci => $cn) {
            $core->tpl->block("body", "comp", array("name" => $cn, "value" => $ci, "select" => $c == $ci ? "selected=\"selected\"" : ""));
        }
        foreach ($core->lang["user_works"] as $li => $ln) {
            $core->tpl->block("body", "level", array("name" => $ln, "value" => $li, "select" => $l !== NULL && $l == $li ? "selected=\"selected\"" : ""));
        }
        foreach ($user as &$i) {
            $key = $core->user->recoverid($i["user_id"], $i["user_mail"], $i["user_pass"]);
            $core->tpl->block("body", "user", array("id" => $i["user_id"], "name" => $search ? $search->highlight($i["user_name"]) : $i["user_name"], "email" => $search ? $search->highlight($i["user_mail"]) : $i["user_mail"], "mailto" => $i["user_mail"], "vip" => $i["user_vip"] ? $core->lang["iamvip"] : "", "level" => $i["user_level"] ? "<b class=\"text-success\" title=\"" . $core->lang["admin"] . "\">" . $core->lang["user_works"][$i["user_work"]] . "</b>" : $core->lang["user_works"][$i["user_work"]], "icon" => $i["user_ban"] ? "fa-exclamation-circle text-danger" : ($i["user_warn"] ? "fa-exclamation-triangle text-warning" : "fa-check-circle text-success"), "icontype" => $i["user_ban"] ? $core->lang["user_ban"] : ($i["user_warn"] ? $core->lang["user_warn"] : ""), "u_level" => $core->url("m", "users?l=") . $i["user_work"] . ($c ? "&c=" . $c : "") . ($s ? "&s=" . $s : ""), "cash" => $core->currency->money($i["user_cash"]), "cr" => $i["user_cr"] < 10 ? sprintf("%0.2f", $i["user_cr"]) : sprintf("%0.1f", $i["user_cr"]), "crc" => $i["user_cr"] < 10 ? $i["user_cr"] < 5 ? "green" : "yellow" : (20 < $i["user_cr"] ? "red fat" : "red"), "epc" => money($i["user_epc"]), "comp" => $i["user_comp"] ? $i["user_compad"] ? "<b class=\"text-success\" title=\"" . $core->lang["admin"] . "\">" . $comp[$i["user_comp"]] . "</b>" : $comp[$i["user_comp"]] : ($i["user_ref"] ? $core->user->get($i["user_ref"], "user_name") : $ext[$i["user_ext"]]), "u_comp" => $core->url("m", "users?c=") . $i["user_comp"] . ($l !== NULL ? "&l=" . $l : "") . ($s ? "&s=" . $s : ""), "stitle" => $i["supp_last"] ? $i["supp_admin"] ? sprintf($core->lang["support_news"], $i["supp_admin"]) : ($i["supp_type"] ? $i["supp_new"] ? $core->lang["support_ur"] : $core->lang["support_ok"] : $core->lang["support_ua"]) : $core->lang["support"], "sclass" => $i["supp_last"] ? $i["supp_admin"] ? "danger" : ($i["supp_type"] ? $i["supp_new"] ? "default" : "success" : "warning") : "info", "ip" => $i["user_ip"] ? int2ip($i["user_ip"]) : "", "date" => $i["user_date"] ? date2form($i["user_date"]) : "", "dclass" => $i["user_date"] == $today ? "success fat" : ($i["user_date"] < $m1m ? $i["user_date"] < $m2m ? "danger" : "warning" : ""), "support" => $core->url("i", "supporthq", $i["user_id"]), "enter" => $core->uri("", array("recoverpass" => $key)), "edit" => $core->url("i", "users", $i["user_id"]), "del" => $isadm ? $core->url("ia", "users", $i["user_id"], "del") : false, "u_order" => $core->url("m", "order") . "?wm=" . $i["user_id"], "u_offers" => $core->url("m", "offers") . "?wm=" . $i["user_id"], "u_domain" => $i["user_work"] == 0 || $i["user_work"] == 2 || $i["user_work"] == -2 ? $core->url("m", "domain") . "?wm=" . $i["user_id"] : false, "u_flows" => $i["user_work"] == 0 || $i["user_work"] == 2 || $i["user_work"] == -2 ? $core->url("m", "flow") . "?wm=" . $i["user_id"] : false, "u_split" => $i["user_work"] == 0 || $i["user_work"] == 2 || $i["user_work"] == -1 || $i["user_work"] == -2 ? $core->url("m", "split") . "?wm=" . $i["user_id"] : false, "u_postback" => $i["user_work"] == 0 || $i["user_work"] == 2 || $i["user_work"] == -1 || $i["user_work"] == -2 ? $core->url("m", "postback") . "?wm=" . $i["user_id"] : false, "u_stats" => $core->url("m", "stats") . "?wm=" . $i["user_id"], "u_hour" => $core->url("m", "hourstat") . "?wm=" . $i["user_id"], "u_leads" => $core->url("m", "leads") . "?wm=" . $i["user_id"], "u_offer" => $core->url("m", "offerstat") . "?wm=" . $i["user_id"], "u_flow" => $core->url("m", "flowstat") . "?wm=" . $i["user_id"], "u_geo" => $core->url("m", "geostat") . "?wm=" . $i["user_id"], "u_utm" => $core->url("m", "utm") . "?wm=" . $i["user_id"], "u_exti" => $i["user_ext"] ? $core->url("m", "exti") . "?wm=" . $i["user_id"] : false, "u_click" => $core->url("m", "click") . "?wm=" . $i["user_id"], "u_anal" => $core->url("m", "analytics") . "?wm=" . $i["user_id"], "u_analc" => $core->url("m", "analytics-calls") . "?wm=" . $i["user_id"], "u_anald" => $core->url("m", "analytics-delivery") . "?wm=" . $i["user_id"], "u_trans" => $core->url("m", "trans") . "?f=" . $i["user_id"]));
        }
        unset($d);
        $core->tpl->output("body");
        $core->site->footer();
    }
    $core->stop();
}

?>