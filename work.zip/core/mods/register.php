<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

if (defined("HACK_REGISTER")) {
    require_once PATH . HACK . "/hack/register.php";
    if (function_exists("sethack_register")) {
        sethack_register($core);
    }
}
$re = $fe = $le = false;
$ok = isset($core->get["ok"]) ? true : false;
if (isset($core->post["in_user"]) || isset($core->post["in_pass"])) {
    $le = 1;
}
if ($le) {
    $ok = false;
}
if (!$core->config("register", "disable")) {
    if ($core->post["register"]) {
        $ok = false;
        $email = $core->text->email($core->post["email"]);
        $name = $core->text->line($core->post["name"]);
        $pass = $core->user->pass($core->post["pass"]);
        $ptxt = $core->text->line($core->post["pass"]);
        $ref = (int) $core->post["ref"];
        if ($core->config("register", "noref")) {
            $ref = 0;
        }
        if ($ref) {
            $rd = $core->user->get($ref);
            if (!$rd["user_id"]) {
                $ref = 0;
            }
        } else {
            $ref = 0;
        }
        if (function_exists("choose_manager")) {
            $man = choose_manager($core);
        } else {
            $man = $core->db->field("SELECT user_id FROM " . DB_USER . " WHERE user_work = -2 ORDER BY RAND() LIMIT 1");
        }
        $u = $core->db->field("SELECT user_id FROM " . DB_USER . " WHERE user_mail = '" . $email . "' LIMIT 1");
        if (!$u && $email) {
            if (4 <= strlen($ptxt)) {
                if (4 <= strlen($name)) {
                    $data = array("user_name" => $name, "user_mail" => $email, "user_pass" => $pass, "user_api" => md5(microtime()), "user_ref" => $ref, "user_man" => $man);
                    $data = $core->filter("register_data", $data);
                    if ($core->db->add(DB_USER, $data)) {
                        $core->post["in_user"] = $email;
                        $core->post["in_pass"] = $ptxt;
                        $core->user->login($core);
                        $core->go($core->url("m", "profile"));
                    } else {
                        $re = 4;
                    }
                } else {
                    $re = 3;
                }
            } else {
                $re = 2;
            }
        } else {
            $re = 1;
        }
    } else {
        $re = 0;
    }
}
if ($core->post["passrecover"]) {
    $ok = false;
    $email = $core->text->email($core->post["passrecover"]);
    $u = $email ? $core->db->row("SELECT * FROM " . DB_USER . " WHERE user_mail = '" . $email . "' LIMIT 1") : NULL;
    if ($u["user_id"]) {
        $key = $core->user->recoverid($u["user_id"], $u["user_mail"], $u["user_pass"]);
        $title = sprintf($core->lang["mail_recover_h"], $core->config("site", "name"));
        $text = sprintf($core->lang["mail_recover_t"], $core->uri("", array("recoverpass" => $key)));
        $core->email->send($u["user_mail"], $title, $text);
        $core->go("/forgot?ok");
    } else {
        $fe = 1;
    }
} else {
    if ($core->get["recoverpass"]) {
        $core->go("/");
    }
}
if ($core->get["logout"]) {
    $core->go("/");
}
if ($ref = (int) $core->get["from"]) {
    $core->sset("ref", $ref);
    $core->go($core->config("url", "base"));
} else {
    $ref = $core->session["ref"];
}
$issmall = false;
if (!defined("HACK_HOME")) {
    $issmall = true;
}
$reqpath = explode("?", $core->server["REQUEST_URI"]);
if ($reqpath[0] != "/") {
    $issmall = true;
}
if ($issmall) {
    $core->process("login_before");
    $section = "login";
    if ($re || $core->get["m"] == "register") {
        $section = "register";
    }
    if ($fe || $core->get["m"] == "forgot") {
        $section = "forgot";
    }
    if ($le) {
        $section = "login";
    }
    $core->process("login_before");
    $core->tpl->load("login", "login", defined("HACK_TPL_LOGIN") ? HACK : false);
    $core->tpl->vars("login", array("site" => $core->config("site", "name"), "title" => $core->config("site", "nice") ? $core->config("site", "nice") : $core->config("site", "name"), "login" => $core->lang["login_page"], "enter" => $core->lang["login_enter"], "reg" => $core->lang["reg_page"], "register" => $core->lang["reg_do"], "user" => $core->lang["login_user"], "mail" => $core->lang["login_mail"], "pass" => $core->lang["login_pass"], "forgot" => $core->lang["forgot_pass"], "recover" => $core->lang["forgot_recover"], "formail" => $core->lang["forgot_email"], "cancel" => $core->lang["cancel"], "ref" => $ref, "er" . $re => "bad", "re" => $re ? $core->lang["reg_error"][$re] : false, "fe" => $fe ? $core->lang["forgot_error"] : false, "le" => $le ? $core->lang["login_error"] : false, "ok" => $ok ? $core->lang["forgot_ok"] : false, "canreg" => $core->config("register", "disable") ? false : true, "section" => $section, "jquery" => $core->url("js", "jquery")));
    if (!defined("HACK_NOSTYLE")) {
        $core->tpl->block("login", "style", array("css" => $core->url("css", "style")));
    }
    if (defined("HACK_MYSTYLE")) {
        $core->tpl->block("login", "style", array("css" => $core->url("mcss", HACK, "style")));
    }
    if (!defined("HACK_NOFONTS")) {
        $core->tpl->block("login", "style", array("css" => $core->url("css", "fa")));
    }
    $core->process("login_after");
    $core->tpl->output("login");
    $core->stop();
} else {
    require_once PATH . HACK . "/hack/home.php";
}

?>