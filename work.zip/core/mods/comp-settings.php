<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function company_stages($core, $comp, $mode = false)
{
    $action = $core->text->link($core->get["action"]);
    $id = (int) $core->get["id"];
    switch ($action) {
        case "add":
            $data = array("comp_id" => $comp, "stage_slug" => $core->text->link($core->post["name"]), "stage_name" => $core->text->line($core->post["name"]), "stage_group" => (int) $core->post["group"]);
            if (!$data["stage_name"]) {
                $core->go($mode ? $core->url("im", "comp-stage", $comp, "error") : $core->url("mm", "comp-stages", "error"));
            }
            if (!$data["stage_group"]) {
                $core->go($mode ? $core->url("im", "comp-stage", $comp, "error") : $core->url("mm", "comp-stages", "error"));
            }
            if ($core->db->add(DB_STAGE, $data)) {
                $uid = $core->db->lastid();
                $core->cpa->clear("stage", $comp);
                $core->go($mode ? $core->url("im", "comp-stage-edit", $uid, "ok") : $core->url("im", "comp-stages", $uid, "ok"));
            } else {
                $core->go($mode ? $core->url("im", "comp-stage", $comp, "error") : $core->url("mm", "comp-stages", "error"));
            }
        case "export":
            $data = array();
            $sl = $core->cpa->get("stage", $comp);
            foreach ($sl as $s) {
                $data[$s["stage_slug"]] = array("name" => $s["stage_name"], "group" => (int) $s["stage_group"], "auto" => (bool) $s["stage_auto"], "from" => (int) $s["stage_from"], "to" => (int) $s["stage_from"], "why" => $s["stage_why"]);
            }
            header("Content-type: application/json");
            header("Content-disposition: attachment; filename=stages" . $comp . ".json");
            echo json_encode($data, defined("JSON_UNESCAPED_UNICODE") ? JSON_UNESCAPED_UNICODE : 0);
            $core->stop();
        case "import":
            $s2s = $core->db->icol("SELECT stage_slug, stage_id FROM " . DB_STAGE . " WHERE comp_id = '" . $comp . "'");
            $stage = json_decode(file_get_contents($core->files["stage"]["tmp_name"]), true);
            foreach ($stage as $i => $s) {
                $data = array("stage_name" => addslashes($s["name"]), "stage_group" => $s["group"], "stage_auto" => $s["auto"], "stage_from" => $s["from"], "stage_to" => $s["to"], "stage_why" => addslashes($s["why"]));
                if (!$s2s[$i]) {
                    $data["comp_id"] = $comp;
                    $data["stage_slug"] = $i;
                    $core->db->add(DB_STAGE, $data);
                } else {
                    $core->db->edit(DB_STAGE, $data, array("stage_id" => $s2s[$i]));
                }
            }
            $core->cpa->clear("stage", $comp);
            msgo($core, "ok");
    }
    if ($core->get["message"]) {
        switch ($core->get["message"]) {
            case "ok":
                $core->site->info("info", "done_basic");
                break;
            case "error":
                $core->site->info("error", "error_basic");
                break;
        }
    }
    if ($id && !$mode) {
        $s = $core->db->row("SELECT * FROM " . DB_STAGE . " WHERE stage_id = '" . $id . "' LIMIT 1");
        if ($s["comp_id"] != $comp) {
            $core->go($core->url("mm", "", "access"));
        }
        company_stage_form($core, $comp, $s, $mode);
    }
    $core->site->bc($core->lang["comp_stages"]);
    $core->site->page = $core->lang["comp_stages_h"];
    $core->site->header();
    $core->tpl->load("body", "comp-stage", defined("HACK_TPL_COMPSTAGE") ? HACK : false);
    $core->tpl->vars("body", array("text" => $core->text->lines($core->lang["comp_stages_t"]), "u_add" => $mode ? $core->url("ia", "comp-stage", $comp, "add") : $core->url("ma", "comp-stages", "add"), "u_import" => $mode ? $core->url("ia", "comp-stage", $comp, "import") : $core->url("ma", "comp-stages", "import"), "u_export" => $mode ? $core->url("ia", "comp-stage", $comp, "export") : $core->url("ma", "comp-stages", "export"), "name" => $core->lang["name"], "group" => $core->lang["group"], "slug" => $core->lang["slug"], "type" => $core->lang["type"], "action" => $core->lang["action"], "edit" => $core->lang["edit"], "del" => $core->lang["del"], "confirm" => $core->lang["confirm"], "add" => $core->lang["add"], "import" => $core->lang["import"], "export" => $core->lang["export"], "noitems" => $core->lang["noitems"], "auto" => $core->lang["stage_auto_ok"], "manual" => $core->lang["stage_auto_no"]));
    $stage = $core->cpa->get("stage", $comp);
    if ($stage) {
        foreach ($stage as $s) {
            $core->tpl->block("body", "item", array("id" => $s["stage_id"], "name" => $s["stage_name"], "slug" => $s["stage_slug"], "gid" => $s["stage_group"], "group" => $core->lang["statusgroup"][$s["stage_group"]], "auto" => $s["stage_auto"], "edit" => $mode ? $core->url("i", "comp-stage-edit", $s["stage_id"]) : $core->url("i", "comp-stages", $s["stage_id"]), "del" => $mode ? $core->url("ia", "comp-stage-edit", $s["stage_id"], "del") : $core->url("ia", "comp-stages", $s["stage_id"], "del")));
        }
    } else {
        $core->tpl->block("body", "noitem");
    }
    foreach ($core->lang["statusgroup"] as $v => $n) {
        $core->tpl->block("body", "group", array("v" => $v, "n" => $n));
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}
function company_stage_form($core, $comp, $s, $mode = false)
{
    $action = $core->text->link($core->get["action"]);
    $id = $s["stage_id"];
    switch ($action) {
        case "edit":
            if ($s["comp_id"] != $comp) {
                $core->go($core->url("mm", "", "access"));
            }
            $data = array("stage_slug" => $core->text->link($core->post["slug"]), "stage_name" => $core->text->line($core->post["name"]), "stage_auto" => $core->post["auto"] ? 1 : 0, "stage_from" => (int) $core->post["from"], "stage_to" => (int) $core->post["to"], "stage_why" => $core->text->code($core->post["why"]));
            if (!$data["stage_name"]) {
                $core->go($mode ? $core->url("im", "comp-stage", $comp, "error") : $core->url("mm", "comp-stages", "error"));
            }
            if (!$data["stage_slug"]) {
                $data["stage_slug"] = $core->text->link($data["stage_name"]);
            }
            if ($core->db->edit(DB_STAGE, $data, array("stage_id" => $id))) {
                $core->cpa->clear("stage", $comp);
                $core->go($mode ? $core->url("im", "comp-stage", $comp, "ok") : $core->url("mm", "comp-stages", "ok"));
            } else {
                $core->go($mode ? $core->url("im", "comp-stage", $comp, "error") : $core->url("mm", "comp-stages", "error"));
            }
        case "del":
            if ($s["comp_id"] != $comp) {
                $core->go($core->url("mm", "", "access"));
            }
            if ($core->db->del(DB_STAGE, array("stage_id" => $id))) {
                $core->db->edit(DB_ORDER, array("stage_id" => 0), array("stage_id" => $id));
                $core->cpa->clear("stage", $comp);
                msgo($core, "ok");
            } else {
                msgo($core, "error");
            }
    }
    $core->site->bc($core->lang["comp_stages"], $mode ? $core->url("i", "comp-stage", $comp) : $core->url("m", "comp-stages"));
    $core->site->bc($s["stage_name"]);
    $core->site->header();
    $status = array("&mdash;");
    $status += $core->lang["statuso"];
    $action = $mode ? $core->url("ia", "comp-stage-edit", $id, "edit") : $core->url("ia", "comp-stages", $id, "edit");
    $field = array(array("type" => "line", "value" => $core->text->lines($core->lang["comp_stage_edit_t"])), array("type" => "text", "length" => 50, "name" => "name", "head" => $core->lang["name"], "value" => $s["stage_name"]), array("type" => "text", "length" => 50, "name" => "slug", "head" => $core->lang["slug"], "value" => $s["stage_slug"]), array("type" => "checkbox", "name" => "auto", "head" => $core->lang["stage_auto"], "descr" => $core->lang["stage_auto_d"], "checked" => $s["stage_auto"]), array("type" => "select", "name" => "from", "head" => $core->lang["stage_from"], "value" => $s["stage_from"], "options" => $status), array("type" => "select", "name" => "to", "head" => $core->lang["stage_to"], "value" => $s["stage_to"], "options" => $status), array("type" => "textarea", "rows" => 4, "name" => "why", "head" => $core->lang["script"], "value" => $s["stage_why"]));
    $core->site->form("compstage", $action, $core->lang["comp_stage_edit_h"], $field);
    $core->site->footer();
    $core->stop();
}
function company_delivery($core, $comp, $mode = false)
{
    if ($core->get["action"] == "save") {
        $config = $core->cpa->dlsave($comp);
        $data = array("comp_config" => addslashes(serialize($config)));
        if ($core->db->edit(DB_COMP, $data, "comp_id = '" . $comp . "'")) {
            $core->cpa->clear("cc", $comp);
            $core->go($core->url("mm", $mode ? "comps" : "comp-delivery", "ok"));
        } else {
            $core->go($core->url("mm", $mode ? "comps" : "comp-delivery", "error"));
        }
    }
    if ($core->get["message"]) {
        switch ($core->get["message"]) {
            case "ok":
                $core->site->info("info", "done_basic");
                break;
            case "error":
                $core->site->info("error", "error_basic");
                break;
        }
    }
    $core->site->bc($core->lang["comp_delivery_h"]);
    $core->site->header();
    $action = $mode ? $core->url("ia", "comp-delivery", $comp, "save") : $core->url("ma", "comp-delivery", "save");
    $core->site->form("compdelivery", $action, $core->lang["comp_delivery_h"], $core->cpa->dlform($comp));
    $core->site->footer();
    $core->stop();
}

?>