<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function wm_stats_date($core)
{
    if ($core->config("hide", "date")) {
        $core->go($core->url("mm", "", "access"));
    }
    $today = date("Ymd");
    $week1 = date("Ymd", strtotime("-2 week"));
    $csv = $core->get["show"] == "csv" ? 1 : 0;
    extract(params($core, array("to" => "date", "from" => "date", "o", "f", "t", "a")));
    if (!$to || $today < $to) {
        $to = $today;
    }
    if ($to < $from) {
        $from = $to;
    }
    if (!$from) {
        $from = $week1;
    }
    $canuser = $core->user->level || $core->user->work == -2;
    $wm = (int) $core->get["wm"];
    if ($canuser && $wm) {
        $user = $wm;
        $udt = $core->user->get($wm);
        $ext = $udt["user_ext"];
        $uinfo = sprintf($core->lang["stat_user"], $udt["user_name"], $udt["user_mail"]);
        $core->site->info("text", $uinfo);
    } else {
        $user = $core->user->id;
        $ext = $core->user->ext;
    }
    if ($canuser) {
        $all = $a ? true : false;
    } else {
        $all = false;
    }
    if (!$all) {
        if ($ext) {
            $where = "ext_id = '" . $ext . "'";
            if ($o) {
                $where .= " AND offer_id = '" . $o . "'";
            }
        } else {
            $flows = $o ? $core->db->icol("SELECT flow_id, flow_name FROM " . DB_FLOW . " WHERE user_id = '" . $user . "' AND offer_id = '" . $o . "'") : $core->cpa->get("flows", $user);
            if ($f) {
                $fu = $core->cpa->get("flow", $f, "user_id");
                if ($fu != $user) {
                    return array("status" => "error", "error" => "access");
                }
                $where = "flow_id = '" . $f . "'";
            } else {
                $where = $o ? "user_id = '" . $user . "' AND offer_id = '" . $o . "'" : "user_id = '" . $user . "'";
            }
        }
    } else {
        $where = $o ? "offer_id = '" . $o . "'" : "1";
    }
    $params = array();
    if ($user) {
        $params["ext"] = $user;
    }
    if (isset($core->get["w"]) && ($w = (int) $core->get["w"])) {
        $params["w"] = $w;
    }
    if (isset($core->get["s"]) && ($w = (int) $core->get["s"])) {
        $params["s"] = $w;
    }
    if ($t) {
        $params["t"] = $t;
        $where .= " AND test_id = '" . $t . "'";
    }
    $oname = $core->cpa->get("offersa");
    $offer = $core->offer->names($user);
    require_once PATH_MODS . "wm-api.php";
    $stats = $where ? wm_stats_daily($core, $from, $to, $where, $params) : array();
    foreach ($stats as &$s) {
        $s["name"] = date2show("d.m.Y", $s["id"]);
        $s["url"] = date2show("Y-m-d", $s["id"]);
        $s["leadu"] = $core->url("m", "leads?from=") . date2form($s["id"]) . "&to=" . date2form($s["id"]) . ($o ? "&o=" . $o : "") . ($f ? "&f=" . $f : "") . ($wm ? "&wm=" . $wm : "");
    }
    $core->site->bc($core->lang["menu_sub_stats"]);
    $core->site->page = $core->lang["stats_h"];
    $core->site->set("select2");
    if ($csv) {
        header("Content-type: text/csv");
        header("Content-disposition: attachment;filename=stats.csv");
    } else {
        $core->site->header();
    }
    if ($csv) {
        $core->tpl->load("body", "csv-stats");
    } else {
        $core->tpl->load("body", "stats-date", defined("HACK_TPL_STATS_DATE") ? HACK : false);
    }
    $core->tpl->vars("body", array("date" => $core->lang["date"], "flow" => $core->lang["flow"], "offer" => $core->lang["offer"], "show" => $core->lang["show"], "from" => date2form($from), "to" => date2form($to), "t" => $t, "wm" => $wm, "all" => $all ? "checked=\"checked\"" : "", "alls" => $canuser ? 1 : 0, "u_csv" => $core->url("m", "stats?show=csv&from=") . date2form($from) . "&to=" . date2form($to) . ($o ? "&o=" . $o : "") . ($f ? "&f=" . $f : "") . ($wm ? "&wm=" . $wm : ""), "u_week" => $core->url("m", "stats?from=") . date("Y-m-d", strtotime("-6 days")) . "&to=" . date("Y-m-d") . ($o ? "&o=" . $o : "") . ($f ? "&f=" . $f : "") . ($wm ? "&wm=" . $wm : ""), "u_month" => $core->url("m", "stats?from=") . date("Y-m-d", strtotime("-1 month")) . "&to=" . date("Y-m-d") . ($o ? "&o=" . $o : "") . ($f ? "&f=" . $f : "") . ($wm ? "&wm=" . $wm : "")));
    foreach ($offer as $of => $n) {
        $core->tpl->block("body", "offer", array("name" => $n, "value" => $of, "select" => $of == $o ? "selected=\"selected\"" : ""));
    }
    if ($flows) {
        foreach ($flows as $fl => $n) {
            $core->tpl->block("body", "flow", array("name" => $n, "value" => $fl, "select" => $fl == $f ? "selected=\"selected\"" : ""));
        }
    }
    wm_stats_block($core, $stats);
    $core->tpl->output("body", $csv ? "windows-1251" : false);
    if (!$csv) {
        $core->site->footer();
    }
    $core->stop();
}
function wm_stats_offer($core)
{
    if ($core->config("hide", "offer")) {
        $core->go($core->url("mm", "", "access"));
    }
    $today = date("Ymd");
    $yest = strtotime("-1 day");
    $week1 = date("Ymd", strtotime("-6 days"));
    extract(params($core, array("to" => "date", "from" => "date", "a")));
    if (!$to || $today < $to) {
        $to = $today;
    }
    if ($to < $from) {
        $from = $to;
    }
    if (!$from) {
        $from = $week1;
    }
    $canuser = $core->user->level || $core->user->work == -2;
    $wm = (int) $core->get["wm"];
    if ($canuser && $wm) {
        $user = $wm;
        $udt = $core->user->get($wm);
        $ext = $udt["user_ext"];
        $uinfo = sprintf($core->lang["stat_user"], $udt["user_name"], $udt["user_mail"]);
        $core->site->info("text", $uinfo);
    } else {
        $user = $core->user->id;
        $ext = $core->user->ext;
    }
    if ($canuser) {
        $all = $a ? true : false;
    } else {
        $all = false;
    }
    $csv = $core->get["show"] == "csv" ? 1 : 0;
    $oname = $core->cpa->get("offersa");
    $offer = $core->offer->names($user);
    if (!$all) {
        if (!$ext) {
            $flow = $core->cpa->get("flows", $user);
            $flows = implode(", ", array_keys($flow));
            $where = "user_id = '" . $user . "'";
        } else {
            $where = "ext_id = '" . $ext . "'";
        }
    } else {
        $where = "1";
    }
    require_once PATH_MODS . "wm-api.php";
    $stats = wm_stats_load($core, "offer_id", $from, $to, $where);
    foreach ($stats as $i => &$s) {
        $s["name"] = $oname[$i];
        $s["leadu"] = $core->url("m", "leads?from=") . date2form($from) . "&to=" . date2form($to) . "&o=" . $i . ($wm ? "&wm=" . $wm : "");
    }
    $core->site->bc($core->lang["menu_sub_offerstat"]);
    $core->site->page = $core->lang["stats_offer"];
    if ($csv) {
        header("Content-type: text/csv");
        header("Content-disposition: attachment;filename=offerstat.csv");
    } else {
        $core->site->header();
    }
    $core->tpl->load("body", "stats-offer", defined("HACK_TPL_STATS_OFFER") ? HACK : false);
    $core->tpl->vars("body", array("today" => $core->lang["today"], "yesterday" => $core->lang["yesterday"], "offer" => $core->lang["offer"], "from" => date2form($from), "to" => date2form($to), "wm" => $wm, "all" => $all ? "checked=\"checked\"" : "", "alls" => $canuser ? 1 : 0, "u_today" => $core->url("m", "offerstat?from=") . date("Y-m-d") . "&to=" . date("Y-m-d") . ($t ? "&t=" . $t : "") . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : ""), "u_yesterday" => $core->url("m", "offerstat?from=") . date("Y-m-d", $yest) . "&to=" . date("Y-m-d", $yest) . ($t ? "&t=" . $t : "") . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : ""), "u_week" => $core->url("m", "offerstat?from=") . date("Y-m-d", strtotime("-6 days")) . "&to=" . date("Y-m-d") . ($t ? "&t=" . $t : "") . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : ""), "u_month" => $core->url("m", "offerstat?from=") . date("Y-m-d", strtotime("-1 month")) . "&to=" . date("Y-m-d") . ($t ? "&t=" . $t : "") . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : ""), "u_csv" => $core->url("m", "offerstat?show=csv&from=") . date2form($from) . "&to=" . date2form($to) . ($wm ? "&wm=" . $wm : "")));
    wm_stats_block($core, $stats);
    $core->tpl->output("body", $csv ? "windows-1251" : false);
    if (!$csv) {
        $core->site->footer();
    }
    $core->stop();
}
function wm_stats_flows($core)
{
    if ($core->config("hide", "flow")) {
        $core->go($core->url("mm", "", "access"));
    }
    $today = date("Ymd");
    $yest = strtotime("-1 day");
    $week1 = date("Ymd", strtotime("-6 days"));
    extract(params($core, array("to" => "date", "from" => "date")));
    if (!$to || $today < $to) {
        $to = $today;
    }
    if ($to < $from) {
        $from = $to;
    }
    if (!$from) {
        $from = $week1;
    }
    $canuser = $core->user->level || $core->user->work == -2;
    $wm = (int) $core->get["wm"];
    if ($canuser && $wm) {
        $user = $wm;
        $udt = $core->user->get($wm);
        $ext = $udt["user_ext"];
        $uinfo = sprintf($core->lang["stat_user"], $udt["user_name"], $udt["user_mail"]);
        $core->site->info("text", $uinfo);
    } else {
        $user = $core->user->id;
        $ext = $core->user->ext;
    }
    $csv = $core->get["show"] == "csv" ? 1 : 0;
    $oname = $core->cpa->get("offersa");
    $offer = $core->offer->names($user);
    $flow = $core->cpa->get("flows", $user);
    $flows = implode(", ", array_keys($flow));
    $where = "user_id = '" . $user . "'";
    require_once PATH_MODS . "wm-api.php";
    $stats = wm_stats_load($core, "flow_id", $from, $to, $where);
    foreach ($stats as $i => &$s) {
        if (isset($flow[$s["id"]])) {
            $oid = $core->cpa->get("flow", $s["id"], "offer_id");
            $s["name"] = $flow[$s["id"]];
            $s["sub"] = $oname[$oid];
            $s["subid"] = $oid;
            $s["leadu"] = $core->url("m", "leads?from=") . date2form($from) . "&to=" . date2form($to) . "&f=" . $i . ($wm ? "&wm=" . $wm : "");
        } else {
            unset($stats[$i]);
        }
    }
    $core->site->bc($core->lang["menu_sub_flowstat"]);
    $core->site->page = $core->lang["stats_flow"];
    if ($csv) {
        header("Content-type: text/csv");
        header("Content-disposition: attachment;filename=flowstat.csv");
    } else {
        $core->site->header();
    }
    $core->tpl->load("body", "stats-flow", defined("HACK_TPL_STATS_FLOW") ? HACK : false);
    $core->tpl->vars("body", array("today" => $core->lang["today"], "yesterday" => $core->lang["yesterday"], "flow" => $core->lang["flow"], "offer" => $core->lang["offer"], "from" => date2form($from), "to" => date2form($to), "wm" => $wm, "u_today" => $core->url("m", "flowstat?from=") . date("Y-m-d") . "&to=" . date("Y-m-d") . ($o ? "&o=" . $o : "") . ($t ? "&t=" . $t : "") . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : ""), "u_yesterday" => $core->url("m", "flowstat?from=") . date("Y-m-d", $yest) . "&to=" . date("Y-m-d", $yest) . ($o ? "&o=" . $o : "") . ($t ? "&t=" . $t : "") . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : ""), "u_week" => $core->url("m", "flowstat?from=") . date("Y-m-d", strtotime("-6 days")) . "&to=" . date("Y-m-d") . ($o ? "&o=" . $o : "") . ($t ? "&t=" . $t : "") . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : ""), "u_month" => $core->url("m", "flowstat?from=") . date("Y-m-d", strtotime("-1 month")) . "&to=" . date("Y-m-d") . ($o ? "&o=" . $o : "") . ($t ? "&t=" . $t : "") . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : ""), "u_csv" => $core->url("m", "flowstat?show=csv&from=") . date2form($from) . "&to=" . date2form($to) . ($wm ? "&wm=" . $wm : "")));
    wm_stats_block($core, $stats, 2);
    $core->tpl->output("body", $csv ? "windows-1251" : false);
    if (!$csv) {
        $core->site->footer();
    }
    $core->stop();
}
function wm_stats_geo($core)
{
    if ($core->config("hide", "geo")) {
        $core->go($core->url("mm", "", "access"));
    }
    $today = date("Ymd");
    $yest = strtotime("-1 day");
    $week1 = date("Ymd", strtotime("-6 days"));
    extract(params($core, array("to" => "date", "from" => "date", "o", "f", "t", "a")));
    if (!$to || $today < $to) {
        $to = $today;
    }
    if ($to < $from) {
        $from = $to;
    }
    if (!$from) {
        $from = $week1;
    }
    $canuser = $core->user->level || $core->user->work == -2;
    $wm = (int) $core->get["wm"];
    if ($canuser && $wm) {
        $user = $wm;
        $udt = $core->user->get($wm);
        $ext = $udt["user_ext"];
        $uinfo = sprintf($core->lang["stat_user"], $udt["user_name"], $udt["user_mail"]);
        $core->site->info("text", $uinfo);
    } else {
        $user = $core->user->id;
        $ext = $core->user->ext;
    }
    if ($canuser) {
        $all = $a ? true : false;
    } else {
        $all = false;
    }
    $oname = $core->cpa->get("offersa");
    $offer = $all ? $oname : $core->offer->names($user);
    if (!$all) {
        if ($ext) {
            $where = "ext_id = '" . $ext . "'";
            if ($o) {
                $where .= " AND offer_id = '" . $o . "'";
            }
        } else {
            if ($f) {
                $fu = $core->cpa->get("flow", $f, "user_id");
                if ($fu != $user) {
                    return array("status" => "error", "error" => "access");
                }
                $where = "flow_id = '" . $f . "'";
                $flows = $o ? $core->db->icol("SELECT flow_id, flow_name FROM " . DB_FLOW . " WHERE user_id = '" . $user . "' AND offer_id = '" . $o . "'") : $core->cpa->get("flows", $user);
            } else {
                if ($o) {
                    $flows = $core->db->icol("SELECT flow_id, flow_name FROM " . DB_FLOW . " WHERE user_id = '" . $user . "' AND offer_id = '" . $o . "'");
                } else {
                    $flows = $core->cpa->get("flows", $user);
                }
                $where = $o ? "user_id = '" . $user . "' AND offer_id = '" . $o . "'" : "user_id = '" . $user . "'";
            }
        }
    } else {
        $where = $o ? "offer_id = '" . $o . "'" : "1";
    }
    if ($t) {
        $where .= " AND test_id = '" . $t . "'";
    }
    require_once PATH_MODS . "wm-api.php";
    $stats = wm_stats_load($core, "click_geo", $from, $to, $where);
    foreach ($stats as $i => &$s) {
        $s["name"] = $core->lang["country"][$i];
        $s["leadu"] = $core->url("m", "leads?from=") . date2form($from) . "&to=" . date2form($to) . "&geo=" . $i . ($o ? "&o=" . $o : "") . ($f ? "&f=" . $f : "") . ($t ? "&t=" . $t : "") . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : "");
    }
    $core->site->set("select2");
    $core->site->bc($core->lang["menu_sub_geostat"]);
    $core->site->page = $core->lang["stats_geo"];
    $core->site->header();
    $core->tpl->load("body", "stats-geo", defined("HACK_TPL_STATS_GEO") ? HACK : false);
    $core->tpl->vars("body", array("today" => $core->lang["today"], "yesterday" => $core->lang["yesterday"], "geo" => $core->lang["order_country"], "offer" => $core->lang["offer"], "flow" => $flows ? $core->lang["flow"] : false, "showall" => $core->lang["showall"], "from" => date2form($from), "to" => date2form($to), "wm" => $wm, "all" => $all ? "checked=\"checked\"" : "", "alls" => $canuser ? 1 : 0, "u_today" => $core->url("m", "geostat?from=") . date("Y-m-d") . "&to=" . date("Y-m-d") . ($o ? "&o=" . $o : "") . ($f ? "&f=" . $f : "") . ($t ? "&t=" . $t : "") . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : ""), "u_yesterday" => $core->url("m", "geostat?from=") . date("Y-m-d", $yest) . "&to=" . date("Y-m-d", $yest) . ($o ? "&o=" . $o : "") . ($f ? "&f=" . $f : "") . ($t ? "&t=" . $t : "") . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : ""), "u_week" => $core->url("m", "geostat?from=") . date("Y-m-d", strtotime("-6 days")) . "&to=" . date("Y-m-d") . ($o ? "&o=" . $o : "") . ($f ? "&f=" . $f : "") . ($t ? "&t=" . $t : "") . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : ""), "u_month" => $core->url("m", "geostat?from=") . date("Y-m-d", strtotime("-1 month")) . "&to=" . date("Y-m-d") . ($o ? "&o=" . $o : "") . ($f ? "&f=" . $f : "") . ($t ? "&t=" . $t : "") . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : "")));
    foreach ($offer as $of => $n) {
        $core->tpl->block("body", "offer", array("name" => $n, "value" => $of, "select" => $of == $o ? "selected=\"selected\"" : ""));
    }
    if ($flows) {
        foreach ($flows as $fl => $n) {
            $core->tpl->block("body", "flow", array("name" => $n, "value" => $fl, "select" => $fl == $f ? "selected=\"selected\"" : ""));
        }
    }
    wm_stats_block($core, $stats);
    $core->tpl->output("body", $csv ? "windows-1251" : false);
    if (!$csv) {
        $core->site->footer();
    }
    $core->stop();
}
function wm_stats_hour($core)
{
    if ($core->config("hide", "hour")) {
        $core->go($core->url("mm", "", "access"));
    }
    $today = date("Ymd");
    $yest = strtotime("-1 day");
    $week1 = date("Ymd", strtotime("-6 days"));
    extract(params($core, array("to" => "date", "from" => "date", "o", "f", "t", "a")));
    if (!$to || $today < $to) {
        $to = $today;
    }
    if ($to < $from) {
        $from = $to;
    }
    if (!$from) {
        $from = $week1;
    }
    $canuser = $core->user->level || $core->user->work == -2;
    $wm = (int) $core->get["wm"];
    if ($canuser && $wm) {
        $user = $wm;
        $udt = $core->user->get($wm);
        $ext = $udt["user_ext"];
        $uinfo = sprintf($core->lang["stat_user"], $udt["user_name"], $udt["user_mail"]);
        $core->site->info("text", $uinfo);
    } else {
        $user = $core->user->id;
        $ext = $core->user->ext;
    }
    if ($canuser) {
        $all = $a ? true : false;
    } else {
        $all = false;
    }
    $oname = $core->cpa->get("offersa");
    $offer = $all ? $oname : $core->offer->names($user);
    if (!$all) {
        if ($ext) {
            $where = "ext_id = '" . $ext . "'";
            if ($o) {
                $where .= " AND offer_id = '" . $o . "'";
            }
        } else {
            if ($f) {
                $fu = $core->cpa->get("flow", $f, "user_id");
                if ($fu != $user) {
                    return array("status" => "error", "error" => "access");
                }
                $where = "flow_id = '" . $f . "'";
                $flows = $o ? $core->db->icol("SELECT flow_id, flow_name FROM " . DB_FLOW . " WHERE user_id = '" . $user . "' AND offer_id = '" . $o . "'") : $core->cpa->get("flows", $user);
            } else {
                if ($o) {
                    $flows = $core->db->icol("SELECT flow_id, flow_name FROM " . DB_FLOW . " WHERE user_id = '" . $user . "' AND offer_id = '" . $o . "'");
                } else {
                    $flows = $core->cpa->get("flows", $user);
                }
                $where = $o ? "user_id = '" . $user . "' AND offer_id = '" . $o . "'" : "user_id = '" . $user . "'";
            }
        }
    } else {
        $where = $o ? "offer_id = '" . $o . "'" : "1";
    }
    if ($t) {
        $where .= " AND test_id = '" . $t . "'";
    }
    require_once PATH_MODS . "wm-api.php";
    $names = array("00:00-00:59", "01:00-01:59", "02:00-02:59", "03:00-03:59", "04:00-04:59", "05:00-05:59", "06:00-06:59", "07:00-07:59", "08:00-08:59", "09:00-09:59", "10:00-10:59", "11:00-11:59", "12:00-12:59", "13:00-13:59", "14:00-14:59", "15:00-15:59", "16:00-16:59", "17:00-17:59", "18:00-18:59", "19:00-19:59", "20:00-20:59", "21:00-21:59", "22:00-22:59", "23:00-23:59");
    $stats = wm_stats_load($core, "click_hour", $from, $to, $where, array("names" => $names, "transform" => "hour"));
    ksort($stats);
    foreach ($stats as $i => &$s) {
        $s["leadu"] = $core->url("m", "leads?from=") . date2form($from) . "&to=" . date2form($to) . "&h=" . $i . ($wm ? "&wm=" . $wm : "");
    }
    $core->site->bc($core->lang["menu_sub_hourstat"]);
    $core->site->page = $core->lang["stats_hour"];
    $core->site->set("select2");
    $core->site->header();
    $core->tpl->load("body", "stats-hour", defined("HACK_TPL_STATS_HOUR") ? HACK : false);
    $core->tpl->vars("body", array("today" => $core->lang["today"], "yesterday" => $core->lang["yesterday"], "time" => $core->lang["time"], "offer" => $core->lang["offer"], "flow" => $flows ? $core->lang["flow"] : false, "showall" => $core->lang["showall"], "from" => date2form($from), "to" => date2form($to), "wm" => $wm, "all" => $all ? "checked=\"checked\"" : "", "alls" => $canuser ? 1 : 0, "u_today" => $core->url("m", "hourstat?from=") . date("Y-m-d") . "&to=" . date("Y-m-d") . ($o ? "&o=" . $o : "") . ($f ? "&f=" . $f : "") . ($t ? "&t=" . $t : "") . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : ""), "u_yesterday" => $core->url("m", "hourstat?from=") . date("Y-m-d", $yest) . "&to=" . date("Y-m-d", $yest) . ($o ? "&o=" . $o : "") . ($f ? "&f=" . $f : "") . ($t ? "&t=" . $t : "") . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : ""), "u_week" => $core->url("m", "hourstat?from=") . date("Y-m-d", strtotime("-6 days")) . "&to=" . date("Y-m-d") . ($o ? "&o=" . $o : "") . ($f ? "&f=" . $f : "") . ($t ? "&t=" . $t : "") . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : ""), "u_month" => $core->url("m", "hourstat?from=") . date("Y-m-d", strtotime("-1 month")) . "&to=" . date("Y-m-d") . ($o ? "&o=" . $o : "") . ($f ? "&f=" . $f : "") . ($t ? "&t=" . $t : "") . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : "")));
    foreach ($offer as $of => $n) {
        $core->tpl->block("body", "offer", array("name" => $n, "value" => $of, "select" => $of == $o ? "selected=\"selected\"" : ""));
    }
    if ($flows) {
        foreach ($flows as $fl => $n) {
            $core->tpl->block("body", "flow", array("name" => $n, "value" => $fl, "select" => $fl == $f ? "selected=\"selected\"" : ""));
        }
    }
    wm_stats_block($core, $stats);
    $core->tpl->output("body", $csv ? "windows-1251" : false);
    if (!$csv) {
        $core->site->footer();
    }
    $core->stop();
}
function wm_stats_utm($core)
{
    if ($core->config("hide", "utm")) {
        $core->go($core->url("mm", "", "access"));
    }
    $today = date("Ymd");
    $week1 = date("Ymd", strtotime("-6 days"));
    extract(params($core, array("to" => "date", "from" => "date", "o", "f", "a", "t")));
    if (!$to || $today < $to) {
        $to = $today;
    }
    if ($to < $from) {
        $from = $to;
    }
    if (!$from) {
        $from = $today;
    }
    $canuser = $core->user->level || $core->user->work == -2;
    $wm = (int) $core->get["wm"];
    if ($canuser && $wm) {
        $user = $wm;
        $udt = $core->user->get($wm);
        $ext = $udt["user_ext"];
        $uinfo = sprintf($core->lang["stat_user"], $udt["user_name"], $udt["user_mail"]);
        $core->site->info("text", $uinfo);
    } else {
        $user = $core->user->id;
        $ext = $core->user->ext;
    }
    if ($canuser) {
        $all = $a ? true : false;
    } else {
        $all = false;
    }
    $us = isset($core->get["us"]) ? $core->text->line($core->get["us"]) : NULL;
    $uc = isset($core->get["uc"]) ? $core->text->line($core->get["uc"]) : NULL;
    $un = isset($core->get["un"]) ? $core->text->line($core->get["un"]) : NULL;
    $ut = isset($core->get["ut"]) ? $core->text->line($core->get["ut"]) : NULL;
    $um = isset($core->get["um"]) ? $core->text->line($core->get["um"]) : NULL;
    $u = $core->text->link($core->get["u"]);
    if (!$u) {
        $u = $core->session["utm"];
        if (!$u) {
            $u = "snctm";
        }
    } else {
        $core->sset("utm", $u);
    }
    for ($i = 0; $i < 5; $i++) {
        $ua = $u[$i];
        $uo = "u" . $ua;
        $uf = "utm" . $ua;
        if (!isset($uo)) {
            break;
        }
    }
    $deep = $i < 4 ? true : false;
    $short = $core->get["ajax"] ? true : false;
    $oname = $core->cpa->get("offersa");
    $offer = $core->offer->names($user);
    if (!$all) {
        if ($ext) {
            $where = "ext_id = '" . $ext . "'";
            if ($o) {
                $where .= " AND offer_id = '" . $o . "'";
            }
        } else {
            if ($f) {
                $fu = $core->cpa->get("flow", $f, "user_id");
                if ($fu != $user) {
                    return array("status" => "error", "error" => "access");
                }
                $where = "flow_id = '" . $f . "'";
                $flows = $o ? $core->db->icol("SELECT flow_id, flow_name FROM " . DB_FLOW . " WHERE user_id = '" . $user . "' AND offer_id = '" . $o . "'") : $core->cpa->get("flows", $user);
            } else {
                if ($o) {
                    $flows = $core->db->icol("SELECT flow_id, flow_name FROM " . DB_FLOW . " WHERE user_id = '" . $user . "' AND offer_id = '" . $o . "'");
                } else {
                    $flows = $core->cpa->get("flows", $user);
                }
                $where = $o ? "user_id = '" . $user . "' AND offer_id = '" . $o . "'" : "user_id = '" . $user . "'";
            }
        }
    } else {
        $where = $o ? "offer_id = '" . $o . "'" : "1";
    }
    if (!$short) {
        $core->site->bc($core->lang["menu_sub_utm"]);
        $core->site->page = $core->lang["stats_utm"];
        $core->site->set("select2");
        $core->site->header();
        $core->tpl->block("body", "face");
        if ($core->user->level) {
            $core->tpl->block("body", "face.alls");
        }
        for ($i = 0; $i < 5; $i++) {
            $core->tpl->block("body", "face.utm", array("id" => $u[$i], "name" => $core->lang["utms"][$u[$i]]));
        }
        foreach ($offer as $of => $n) {
            $core->tpl->block("body", "face.offer", array("name" => $n, "value" => $of, "select" => $of == $o ? "selected=\"selected\"" : ""));
        }
        if ($flows) {
            foreach ($flows as $fl => $n) {
                $core->tpl->block("body", "face.flow", array("name" => $n, "value" => $fl, "select" => $fl == $f ? "selected=\"selected\"" : ""));
            }
        }
    }
    $upr = "u=" . $u;
    if ($o) {
        $upr .= "&o=" . $o;
    }
    if ($t) {
        $upr .= "&t=" . $t;
    }
    if ($f) {
        $upr .= "&f=" . $f;
    }
    if ($all) {
        $upr .= "&a=1";
    }
    if (isset($us)) {
        $upr .= "&us=" . $us;
    }
    if (isset($uc)) {
        $upr .= "&uc=" . $uc;
    }
    if (isset($un)) {
        $upr .= "&un=" . $un;
    }
    if (isset($ut)) {
        $upr .= "&ut=" . $ut;
    }
    if (isset($um)) {
        $upr .= "&um=" . $um;
    }
    if ($where) {
        if ($t) {
            $where .= " AND test_id = '" . $t . "' ";
        }
        if (isset($us)) {
            $where .= " AND utms32 = '" . sprintf("%u", crc32($us)) . "' ";
        }
        if (isset($uc)) {
            $where .= " AND utmc32 = '" . sprintf("%u", crc32($uc)) . "' ";
        }
        if (isset($un)) {
            $where .= " AND utmn32 = '" . sprintf("%u", crc32($un)) . "' ";
        }
        if (isset($ut)) {
            $where .= " AND utmt32 = '" . sprintf("%u", crc32($ut)) . "' ";
        }
        if (isset($um)) {
            $where .= " AND utmm32 = '" . sprintf("%u", crc32($um)) . "' ";
        }
        require_once PATH_MODS . "wm-api.php";
        $stats = wm_stats_load($core, $uf, $from, $to, $where);
        foreach ($stats as $d => &$s) {
            $s["url"] = $deep ? $core->url("m", "utm?from=") . date2form($from) . "&to=" . date2form($to) . "&" . $upr . "&" . $uo . "=" . $d . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : "") : false;
            $s["leadu"] = $core->url("m", "leads?from=") . date2form($from) . "&to=" . date2form($to) . "&" . $upr . "&" . $uo . "=" . $d . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : "");
            $s["name"] = $d ? $d : $core->lang["na"];
        }
    } else {
        $stats = array();
    }
    $core->tpl->load("body", "stats-utm", defined("HACK_TPL_STATS_UTM") ? HACK : false);
    $core->tpl->vars("body", array("tid" => md5(microtime()), "today" => $core->lang["today"], "src" => $core->lang["utms"][$ua], "utmo" => $core->lang["utmo"], "utmi" => $core->lang["stat_move"], "utma" => $core->lang["utma"], "utmm" => $core->lang["utmm"], "showall" => $core->lang["showall"], "flow" => $flows ? $core->lang["flow"] : false, "offer" => $core->lang["offer"], "from" => date2form($from), "to" => date2form($to), "u" => $u, "t" => $t, "wm" => $wm, "all" => $all ? "checked=\"checked\"" : "", "u_today" => $core->url("m", "utm?from=") . date("Y-m-d") . "&to=" . date("Y-m-d") . "&" . $upr . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : ""), "u_yest" => $core->url("m", "utm?from=") . date("Y-m-d", strtotime("-1 day")) . "&to=" . date("Y-m-d", strtotime("-1 day")) . "&" . $upr . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : ""), "u_week" => $core->url("m", "utm?from=") . date("Y-m-d", strtotime("-6 days")) . "&to=" . date("Y-m-d") . "&" . $upr . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : ""), "u_month" => $core->url("m", "utm?from=") . date("Y-m-d", strtotime("-1 month")) . "&to=" . date("Y-m-d") . "&" . $upr . ($wm ? "&wm=" . $wm : "") . ($all ? "&a=1" : "")));
    wm_stats_block($core, $stats);
    $core->tpl->output("body");
    if (!$short) {
        $core->site->footer();
    }
    $core->stop();
}
function wm_stats_ext($core)
{
    if ($core->config("hide", "ext")) {
        $core->go($core->url("mm", "", "access"));
    }
    $today = date("Ymd");
    $week1 = date("Ymd", strtotime("-6 days"));
    extract(params($core, array("to" => "date", "from" => "date", "o", "t")));
    if (!$to || $today < $to) {
        $to = $today;
    }
    if ($to < $from) {
        $from = $to;
    }
    if (!$from) {
        $from = $today;
    }
    $ei = isset($core->get["ei"]) ? $core->text->line($core->get["ei"]) : NULL;
    $es = isset($core->get["es"]) ? $core->text->line($core->get["es"]) : NULL;
    $canuser = $core->user->level || $core->user->work == -2;
    $wm = (int) $core->get["wm"];
    if ($canuser && $wm) {
        $user = $wm;
        $udt = $core->user->get($wm);
        $ext = $udt["user_ext"];
        $uinfo = sprintf($core->lang["stat_user"], $udt["user_name"], $udt["user_mail"]);
        $core->site->info("text", $uinfo);
    } else {
        $user = $core->user->id;
        $ext = $core->user->ext;
    }
    $u = $core->text->link($core->get["u"]);
    if (!$u) {
        $u = $core->session["exts"];
        if (!$u) {
            $u = "is";
        }
    } else {
        $core->sset("exts", $u);
    }
    for ($i = 0; $i < 2; $i++) {
        $ea = $u[$i];
        $eo = "e" . $ea;
        $ef = $ea == "i" ? "ext_uid" : "ext_src";
        if (!isset($eo)) {
            break;
        }
    }
    $deep = $i < 1 ? true : false;
    $short = $core->get["ajax"] ? true : false;
    $oname = $core->cpa->get("offersa");
    $offer = $core->offer->names($user);
    $where = "ext_id = '" . $ext . "'";
    if ($o) {
        $where .= " AND offer_id = '" . $o . "'";
    }
    if (!$short) {
        $core->site->bc($core->lang["menu_sub_exti"]);
        $core->site->page = $core->lang["stats_ext"];
        $core->site->set("select2");
        $core->site->header();
        $core->tpl->block("body", "face");
        if ($core->user->level) {
            $core->tpl->block("body", "face.alls");
        }
        for ($i = 0; $i < 2; $i++) {
            $core->tpl->block("body", "face.utm", array("id" => $u[$i], "name" => $core->lang["exti"][$u[$i]]));
        }
        foreach ($offer as $of => $n) {
            $core->tpl->block("body", "face.offer", array("name" => $n, "value" => $of, "select" => $of == $o ? "selected=\"selected\"" : ""));
        }
    }
    $upr = "u=" . $u;
    if ($o) {
        $upr .= "&o=" . $o;
    }
    if ($t) {
        $upr .= "&t=" . $t;
    }
    if (isset($ei)) {
        $upr .= "&ei=" . $ei;
    }
    if (isset($es)) {
        $upr .= "&es=" . $es;
    }
    if ($where) {
        if ($t) {
            $where .= " AND test_id = '" . $t . "' ";
        }
        if (isset($ei)) {
            $where .= " AND ext_uid = '" . $ei . "' ";
        }
        if (isset($es)) {
            $where .= " AND ext_src = '" . $es . "' ";
        }
        require_once PATH_MODS . "wm-api.php";
        $stats = wm_stats_load($core, $ef, $from, $to, $where);
        foreach ($stats as $d => &$s) {
            $s["url"] = $deep ? $core->url("m", "exti?from=") . date2form($from) . "&to=" . date2form($to) . "&" . $upr . "&" . $eo . "=" . $d . ($wm ? "&wm=" . $wm : "") : false;
            $s["leadu"] = $core->url("m", "leads?from=") . date2form($from) . "&to=" . date2form($to) . "&" . $upr . "&" . $eo . "=" . $d . ($wm ? "&wm=" . $wm : "");
            $s["name"] = $d ? $d : $core->lang["na"];
        }
    } else {
        $stats = array();
    }
    $core->tpl->load("body", "stats-utm", defined("HACK_TPL_STATS_UTM") ? HACK : false);
    $core->tpl->vars("body", array("tid" => md5(microtime()), "src" => $core->lang["exti"][$ea], "utmo" => $core->lang["utmo"], "utmi" => $core->lang["stat_move"], "utma" => $core->lang["utma"], "utmm" => $core->lang["utmm"], "showall" => $core->lang["showall"], "offer" => $core->lang["offer"], "from" => date2form($from), "to" => date2form($to), "u" => $u, "t" => $t, "wm" => $wm, "u_today" => $core->url("m", "exti?from=") . date("Y-m-d") . "&to=" . date("Y-m-d") . "&" . $upr . ($wm ? "&wm=" . $wm : ""), "u_yest" => $core->url("m", "exti?from=") . date("Y-m-d", strtotime("-1 day")) . "&to=" . date("Y-m-d", strtotime("-1 day")) . "&" . $upr . ($wm ? "&wm=" . $wm : ""), "u_week" => $core->url("m", "exti?from=") . date("Y-m-d", strtotime("-6 days")) . "&to=" . date("Y-m-d") . "&" . $upr . ($wm ? "&wm=" . $wm : ""), "u_month" => $core->url("m", "exti?from=") . date("Y-m-d", strtotime("-1 month")) . "&to=" . date("Y-m-d") . "&" . $upr . ($wm ? "&wm=" . $wm : "")));
    wm_stats_block($core, $stats);
    $core->tpl->output("body");
    if (!$short) {
        $core->site->footer();
    }
    $core->stop();
}
function wm_stats_site($core)
{
    if ($core->config("hide", "site")) {
        $core->go($core->url("mm", "", "access"));
    }
    $today = date("Ymd");
    $week1 = date("Ymd", strtotime("-6 days"));
    extract(params($core, array("to" => "date", "from" => "date", "o", "f", "t", "all")));
    if (!$to || $today < $to) {
        $to = $today;
    }
    if ($to < $from) {
        $from = $to;
    }
    if (!$from) {
        $from = $today;
    }
    $ss = isset($core->get["ss"]) ? (int) $core->get["ss"] : NULL;
    $sp = isset($core->get["sp"]) ? (int) $core->get["sp"] : NULL;
    $canuser = $core->user->level || $core->user->work == -2;
    $wm = (int) $core->get["wm"];
    if ($canuser && $wm) {
        $user = $wm;
        $udt = $core->user->get($wm);
        $ext = $udt["user_ext"];
        $uinfo = sprintf($core->lang["stat_user"], $udt["user_name"], $udt["user_mail"]);
        $core->site->info("text", $uinfo);
    } else {
        $user = $core->user->id;
        $ext = $core->user->ext;
    }
    if ($canuser) {
        if ($all) {
            $param["all"] = 1;
        } else {
            $all = false;
        }
    } else {
        $all = false;
    }
    if (!$all) {
        if ($ext) {
            $where = "ext_id = '" . $ext . "'";
            if ($o) {
                $where .= " AND offer_id = '" . $o . "'";
            }
        } else {
            if ($f) {
                $fu = $core->cpa->get("flow", $f, "user_id");
                if ($fu != $user) {
                    return array("status" => "error", "error" => "access");
                }
                $where = "flow_id = '" . $f . "'";
                $flows = $o ? $core->db->icol("SELECT flow_id, flow_name FROM " . DB_FLOW . " WHERE user_id = '" . $user . "' AND offer_id = '" . $o . "'") : $core->cpa->get("flows", $user);
            } else {
                if ($o) {
                    $flows = $core->db->icol("SELECT flow_id, flow_name FROM " . DB_FLOW . " WHERE user_id = '" . $user . "' AND offer_id = '" . $o . "'");
                } else {
                    $flows = $core->cpa->get("flows", $user);
                }
                $where = $o ? "user_id = '" . $user . "' AND offer_id = '" . $o . "'" : "user_id = '" . $user . "'";
            }
        }
    } else {
        $where = $o ? "offer_id = '" . $o . "'" : "1";
    }
    $u = $core->text->link($core->get["u"]);
    if (!$u) {
        $u = $core->session["sitecl"];
        if (!$u) {
            $u = "sp";
        }
    } else {
        $core->sset("sitecl", $u);
    }
    for ($i = 0; $i < 2; $i++) {
        $ea = $u[$i];
        $eo = "s" . $ea;
        $ef = $ea == "s" ? "site_id" : "space_id";
        if (!isset($eo)) {
            break;
        }
    }
    $deep = $i < 1 ? true : false;
    $short = $core->get["ajax"] ? true : false;
    $oname = $core->cpa->get("offersa");
    $sname = $core->cpa->get("siteurls");
    $offer = $core->offer->names($user);
    if (!$short) {
        $core->site->bc($core->lang["menu_sub_site"]);
        $core->site->page = $core->lang["stats_site"];
        $core->site->set("select2");
        $core->site->header();
        $core->tpl->block("body", "face");
        if ($core->user->level) {
            $core->tpl->block("body", "face.alls");
        }
        for ($i = 0; $i < 2; $i++) {
            $core->tpl->block("body", "face.utm", array("id" => $u[$i], "name" => $core->lang["stti"][$u[$i]]));
        }
        foreach ($offer as $of => $n) {
            $core->tpl->block("body", "face.offer", array("name" => $n, "value" => $of, "select" => $of == $o ? "selected=\"selected\"" : ""));
        }
        if ($flows) {
            foreach ($flows as $fl => $n) {
                $core->tpl->block("body", "face.flow", array("name" => $n, "value" => $fl, "select" => $fl == $f ? "selected=\"selected\"" : ""));
            }
        }
    }
    $upr = "u=" . $u;
    if ($o) {
        $upr .= "&o=" . $o;
    }
    if ($f) {
        $upr .= "&f=" . $f;
    }
    if ($t) {
        $upr .= "&t=" . $t;
    }
    if (isset($ss)) {
        $upr .= "&ss=" . $ss;
    }
    if (isset($sp)) {
        $upr .= "&sp=" . $sp;
    }
    if ($t) {
        $where .= " AND test_id = '" . $t . "' ";
    }
    $qp = array();
    if (isset($ss)) {
        $qp["w"] = $ss;
    }
    if (isset($sp)) {
        $qp["s"] = $sp;
    }
    require_once PATH_MODS . "wm-api.php";
    $stats = wm_stats_load($core, $ef, $from, $to, $where, $qp);
    foreach ($stats as $d => &$s) {
        $s["url"] = $deep ? $core->url("m", "site?from=") . date2form($from) . "&to=" . date2form($to) . "&" . $upr . "&" . $eo . "=" . $d . ($wm ? "&wm=" . $wm : "") . ($all ? "&all=1" : "") : false;
        $s["leadu"] = $core->url("m", "leads?from=") . date2form($from) . "&to=" . date2form($to) . "&" . $upr . "&" . $eo . "=" . $d . ($wm ? "&wm=" . $wm : "") . ($all ? "&all=1" : "");
        $s["name"] = $sname[$d] ? $sname[$d] : $core->lang["na"];
    }
    $core->tpl->load("body", "stats-utm", defined("HACK_TPL_STATS_UTM") ? HACK : false);
    $core->tpl->vars("body", array("tid" => md5(microtime()), "src" => $core->lang["stti"][$ea], "utmo" => $core->lang["utmo"], "utmi" => $core->lang["stat_move"], "utma" => $core->lang["utma"], "utmm" => $core->lang["utmm"], "showall" => $core->lang["showall"], "offer" => $core->lang["offer"], "flow" => $flows ? $core->lang["flow"] : false, "from" => date2form($from), "to" => date2form($to), "u" => $u, "t" => $t, "wm" => $wm, "all" => $all ? "checked=\"checked\"" : "", "alls" => $canuser ? 1 : 0, "u_today" => $core->url("m", "site?from=") . date("Y-m-d") . "&to=" . date("Y-m-d") . "&" . $upr . ($wm ? "&wm=" . $wm : "") . ($all ? "&all=1" : ""), "u_yest" => $core->url("m", "site?from=") . date("Y-m-d", strtotime("-1 day")) . "&to=" . date("Y-m-d", strtotime("-1 day")) . "&" . $upr . ($wm ? "&wm=" . $wm : "") . ($all ? "&all=1" : ""), "u_week" => $core->url("m", "site?from=") . date("Y-m-d", strtotime("-6 days")) . "&to=" . date("Y-m-d") . "&" . $upr . ($wm ? "&wm=" . $wm : "") . ($all ? "&all=1" : ""), "u_month" => $core->url("m", "site?from=") . date("Y-m-d", strtotime("-1 month")) . "&to=" . date("Y-m-d") . "&" . $upr . ($wm ? "&wm=" . $wm : "") . ($all ? "&all=1" : "")));
    wm_stats_block($core, $stats);
    $core->tpl->output("body");
    if (!$short) {
        $core->site->footer();
    }
    $core->stop();
}
function wm_stats_leads($core)
{
    if ($core->config("hide", "lead")) {
        $core->go($core->url("mm", "", "access"));
    }
    $page = 1 < $core->get["page"] ? (int) $core->get["page"] : 1;
    $param = array();
    $canuser = $core->user->level || $core->user->work == -2;
    $wm = (int) $core->get["wm"];
    if ($canuser && $wm) {
        $user = $wm;
        $param["wm"] = $wm;
        $udt = $core->user->get($wm);
        $ext = $udt["user_ext"];
        $uinfo = sprintf($core->lang["stat_user"], $udt["user_name"], $udt["user_mail"]);
        $core->site->info("text", $uinfo);
    } else {
        $user = $core->user->id;
        $ext = $core->user->ext;
    }
    if ($canuser) {
        if ($a = (int) $core->get["a"]) {
            $param["a"] = 1;
            $where = array();
        } else {
            $where = array("wm_id = '" . $user . "'");
        }
    } else {
        $where = array("wm_id = '" . $user . "'");
    }
    if (isset($core->get["from"]) && $core->get["from"]) {
        $param["from"] = date2form(form2date($core->get["from"]));
        $from = $param["from"];
        $ds = strtotime($from . " 00:00:00");
        $where[] = " order_time >= '" . $ds . "'";
    } else {
        $from = false;
    }
    if (isset($core->get["to"]) && $core->get["to"]) {
        $param["to"] = date2form(form2date($core->get["to"]));
        $to = $param["to"];
        $dt = strtotime($to . " 23:59:59");
        $where[] = " order_time <= '" . $dt . "'";
    } else {
        $to = false;
    }
    if (isset($core->get["h"]) && $core->get["h"] != "") {
        $param["h"] = (int) $core->get["h"];
        $hh = $param["h"];
        $where[] = " FROM_UNIXTIME( order_time, '%H' ) = '" . $hh . "'";
    } else {
        $hh = NULL;
    }
    if (isset($core->get["o"]) && $core->get["o"]) {
        $param["o"] = (int) $core->get["o"];
        $o = $param["o"];
        $where[] = " offer_id = '" . $o . "' ";
    } else {
        $o = false;
    }
    if (isset($core->get["f"]) && $core->get["f"]) {
        $param["f"] = (int) $core->get["f"];
        $f = $param["f"];
        $where[] = " flow_id = '" . $f . "' ";
    } else {
        $f = false;
    }
    if (isset($core->get["w"]) && $core->get["w"]) {
        $param["w"] = (int) $core->get["w"];
        $w = $param["w"];
        $where[] = " site_id = '" . $w . "' ";
    } else {
        $w = false;
    }
    if (isset($core->get["p"]) && $core->get["p"]) {
        $param["p"] = (int) $core->get["p"];
        $p = $param["p"];
        $where[] = " space_id = '" . $p . "' ";
    } else {
        $p = false;
    }
    if (isset($core->get["t"]) && $core->get["t"]) {
        $param["t"] = (int) $core->get["t"];
        $t = $param["t"];
        $where[] = " test_id = '" . $t . "' ";
    } else {
        $t = false;
    }
    if (isset($core->get["geo"]) && $core->get["geo"]) {
        $param["geo"] = $core->text->link($core->get["geo"]);
        $geo = $param["geo"];
        $where[] = " order_country = '" . $geo . "' ";
    } else {
        $geo = false;
    }
    if (isset($core->get["us"])) {
        $param["us"] = $core->text->line($core->get["us"]);
        $where[] = "utms32 = '" . sprintf("%u", crc32($param["us"])) . "'";
    }
    if (isset($core->get["uc"])) {
        $param["uc"] = $core->text->line($core->get["uc"]);
        $where[] = "utmc32 = '" . sprintf("%u", crc32($param["uc"])) . "'";
    }
    if (isset($core->get["un"])) {
        $param["un"] = $core->text->line($core->get["un"]);
        $where[] = "utmn32 = '" . sprintf("%u", crc32($param["un"])) . "'";
    }
    if (isset($core->get["ut"])) {
        $param["ut"] = $core->text->line($core->get["ut"]);
        $where[] = "utmt32 = '" . sprintf("%u", crc32($param["ut"])) . "'";
    }
    if (isset($core->get["um"])) {
        $param["um"] = $core->text->line($core->get["um"]);
        $where[] = "utmm32 = '" . sprintf("%u", crc32($param["um"])) . "'";
    }
    if (isset($core->get["ei"])) {
        $param["ei"] = $core->text->line($core->get["ei"]);
        $where[] = "ext_uid = '" . $param["ei"] . "'";
    }
    if (isset($core->get["es"])) {
        $param["es"] = (int) $core->get["es"];
        $where[] = "ext_src = '" . $param["es"] . "'";
    }
    if (isset($core->get["s"]) && ($s = $core->get["s"])) {
        switch ($s) {
            case "w":
                $where[] = "order_webstat IN ( " . implode(",", waitstatus()) . " )";
                break;
            case "c":
                $where[] = "order_webstat = 5 AND order_reason NOT IN ( " . implode(",", trashreason()) . " )";
                break;
            case "t":
                $where[] = "( order_webstat = 12 OR ( order_webstat = 5 AND order_reason IN ( " . implode(",", trashreason()) . " ) ) )";
                break;
            case "a":
                $where[] = "order_webstat IN ( " . implode(",", approvestatus()) . " )";
                break;
            default:
                $s = (int) $core->get["s"];
                $where[] = "order_webstat = '" . $s . "'";
                break;
        }
    } else {
        $s = false;
    }
    if ($s) {
        $param["s"] = $s;
    }
    $where = $where ? " WHERE " . implode(" AND ", $where) : "";
    $sh = 30;
    $st = ($page - 1) * $sh;
    $orders = $core->db->field("SELECT COUNT(*) FROM " . DB_ORDER . " " . $where);
    $order = $orders ? $core->db->data("SELECT * FROM " . DB_ORDER . " " . $where . " ORDER BY order_id DESC LIMIT " . $st . ", " . $sh) : array();
    $flow = $core->db->icol("SELECT flow_id, flow_name FROM " . DB_FLOW . " WHERE user_id = '" . $user . "' " . ($o ? " AND offer_id = '" . $o . "' " : "") . " ORDER BY flow_name ASC");
    $oname = $core->cpa->get("offersa");
    $offer = $core->offer->names($user);
    $sids = $core->db->col("SELECT DISTINCT site_id FROM " . DB_ORDER . " WHERE wm_id = '" . $user . "'");
    $site = array();
    foreach ($sids as $ss) {
        $site[$ss] = $core->cpa->get("site", $ss, "site_url");
    }
    $core->site->bc($core->lang["menu_sub_leads"]);
    $core->site->page = $core->lang["stats_lead"];
    $core->site->set("select2");
    $core->site->header();
    if ($core->user->ext) {
        $cols = defined("COLS_EXT") ? COLS_EXT : 7;
        if ($core->config("statcol", "site")) {
            $cols += 1;
        }
        if ($core->config("statcol", "geo")) {
            $cols += 1;
        }
    } else {
        $cols = defined("COLS_LEAD") ? COLS_LEAD : 5;
        if ($core->config("statcol", "flow")) {
            $cols += 1;
        }
        if ($core->config("statcol", "site")) {
            $cols += 1;
        }
        if ($core->config("statcol", "geo")) {
            $cols += 1;
        }
        if ($core->config("statcol", "utm")) {
            $cols += 1;
        }
    }
    if ($core->user->ext) {
        $core->tpl->load("body", "stats-ext", defined("HACK_TPL_STATS_EXT") ? HACK : false);
    } else {
        $core->tpl->load("body", "stats-lead", defined("HACK_TPL_STATS_LEAD") ? HACK : false);
    }
    $core->tpl->vars("body", array("nostats" => $core->lang["nostats"], "date" => $core->lang["date"], "lfrom" => $core->lang["anal_from"], "lto" => $core->lang["anal_to"], "flow" => $core->lang["flow"], "offer" => $core->lang["offer"], "status" => $core->lang["status"], "show" => $core->lang["show"], "site" => $core->lang["site"], "space" => $core->lang["stat_spaces"], "price" => $core->lang["cash"], "country" => $core->lang["order_country"], "reason" => $core->lang["order_reason"], "comment" => $core->lang["comment"], "hold" => $core->lang["offer_hold"], "lall" => $core->lang["stat_all"], "all" => $param["a"] ? "checked=\"checked\"" : "", "alls" => $canuser ? 1 : 0, "cols" => $cols, "cflow" => $core->config("statcol", "flow"), "csite" => $core->config("statcol", "site"), "cgeo" => $core->config("statcol", "geo"), "cutm" => $core->config("statcol", "utm"), "from" => $from, "to" => $to, "t" => $param["t"], "p" => $param["p"], "us" => $param["us"], "uc" => $param["uc"], "un" => $param["un"], "ut" => $param["ut"], "um" => $param["um"], "ei" => $param["ei"], "es" => $param["es"], "wm" => $param["wm"], "u_stat" => $core->url("m", "stats"), "stat" => $core->lang["stats_date"], "pages" => pages($core->url("m", "leads?") . http_build_query($param), $orders, $sh, $page, sprintf($core->lang["shown"], $st + 1, min($st + $sh, $orders), $orders)), "shown" => sprintf($core->lang["shown"], $st + 1, min($st + $sh, $orders), $orders)));
    foreach ($offer as $of => $n) {
        $core->tpl->block("body", "offer", array("name" => $n, "value" => $of, "select" => $of == $o ? "selected=\"selected\"" : ""));
    }
    foreach ($flow as $fl => $n) {
        $core->tpl->block("body", "flow", array("name" => $n, "value" => $fl, "select" => $fl == $f ? "selected=\"selected\"" : ""));
    }
    foreach ($site as $sl => $n) {
        $core->tpl->block("body", "site", array("name" => $n, "value" => $sl, "select" => $sl == $w ? "selected=\"selected\"" : ""));
    }
    foreach ($core->lang["stat_status"] as $st => $n) {
        $core->tpl->block("body", "status", array("name" => $n, "value" => $st, "select" => $st == $s ? "selected=\"selected\"" : ""));
    }
    if ($orders && $core->config("statcol", "audio")) {
        $oid = $audio = array();
        foreach ($order as $r) {
            if ($r["has_audio"]) {
                $oid[] = $r["order_id"];
            }
        }
        if ($oid) {
            $al = $core->db->data("SELECT * FROM " . DB_AUDIO . " WHERE order_id IN ( " . implode(",", $oid) . " )");
            foreach ($al as $a) {
                $audio[$a["order_id"]][] = array("src" => $a["audio_src"], "mp3" => $a["audio_mp3"], "ogg" => $a["audio_ogg"], "wav" => $a["audio_wav"]);
            }
        }
    } else {
        $audio = false;
    }
    if ($orders) {
        foreach ($order as $r) {
            if ($r["order_webstat"] == 5) {
                $reason = $r["order_reason"] ? $core->lang["reasono"][$r["order_reason"]] : false;
            } else {
                if ($r["order_webstat"] == 12) {
                    $reason = $core->lang["noreasonfraud"];
                } else {
                    $reason = false;
                }
            }
            if ($r["order_webstat"] == 4) {
                $hold = $core->text->timeleft($r["order_auto"]);
                if (!$hold) {
                    $hold = $core->text->smartdate($r["order_auto"]);
                }
            } else {
                $hold = false;
            }
            $core->tpl->block("body", "order", array("id" => $r["order_id"], "offer" => $oname[$r["offer_id"]], "u_offer" => $core->u("leads", parset($param, "o", $r["offer_id"])), "site" => $r["site_id"] ? $core->cpa->get("site", $r["site_id"], "site_url") : false, "u_site" => $core->u("leads", parset($param, "w", $r["site_id"])), "space" => $r["space_id"] ? $core->cpa->get("site", $r["space_id"], "site_url") : false, "u_space" => $core->u("leads", parset($param, "p", $r["space_id"])), "flow" => $flow[$r["flow_id"]], "u_flow" => $core->u("leads", parset($param, "f", $r["flow_id"])), "ip" => int2ip($r["order_ip"]), "country" => $r["order_country"] ? $r["order_country"] : "zz", "geo" => $core->lang["country"][$r["order_country"]], "u_geo" => $core->u("leads", parset($param, "geo", $r["order_country"])), "time" => smartdate($r["order_time"]), "stid" => $r["order_webstat"] < 6 || $r["order_webstat"] == 12 ? $r["order_webstat"] : 10, "status" => $r["order_webstat"] < 6 || $r["order_webstat"] == 12 ? $core->lang["statuso"][$r["order_webstat"]] : $core->lang["statusok"], "u_status" => $core->u("leads", parset($param, "s", $r["order_webstat"])), "price" => $r["cash_wm"] ? $core->currency->money($r["cash_wm"]) : "", "reason" => $reason, "comment" => $r["order_shave"] ? false : $r["order_comment"], "check" => $r["order_check"] ? $core->lang["stat_check"] : false, "hold" => $r["order_shave"] ? $hold : false, "us" => $r["utms"], "uus" => $core->u("leads", parset($param, "us", $r["utms"])), "uc" => $r["utmc"], "uuc" => $core->u("leads", parset($param, "uc", $r["utmc"])), "un" => $r["utmn"], "uun" => $core->u("leads", parset($param, "un", $r["utmn"])), "ut" => $r["utmt"], "uut" => $core->u("leads", parset($param, "ut", $r["utmt"])), "um" => $r["utmm"], "uum" => $core->u("leads", parset($param, "um", $r["utmm"])), "ei" => $r["ext_uid"], "uei" => $core->u("leads", parset($param, "ei", $r["ext_uid"])), "es" => $r["ext_src"], "ues" => $core->u("leads", parset($param, "es", $r["ext_src"])), "audio" => $audio && $r["has_audio"] && !$r["order_shave"] ? true : false));
            if ($r["has_audio"]) {
                foreach ($audio[$r["order_id"]] as $a) {
                    $core->tpl->block("body", "order.audio", $a);
                }
            }
        }
    } else {
        $core->tpl->block("body", "nostat");
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}
function wm_stats_click($core)
{
    if ($core->config("hide", "click")) {
        $core->go($core->url("mm", "", "access"));
    }
    $page = 1 < $core->get["page"] ? (int) $core->get["page"] : 1;
    $param = array();
    $canuser = $core->user->level || $core->user->work == -2;
    $wm = (int) $core->get["wm"];
    if ($canuser && $wm) {
        $user = $wm;
        $param["wm"] = $wm;
        $udt = $core->user->get($wm);
        $ext = $udt["user_ext"];
        $uinfo = sprintf($core->lang["stat_user"], $udt["user_name"], $udt["user_mail"]);
        $core->site->info("text", $uinfo);
    } else {
        $user = $core->user->id;
        $ext = $core->user->ext;
    }
    if ($canuser) {
        if ($a = (int) $core->get["all"]) {
            $param["all"] = 1;
            $where = array();
        } else {
            $where = $ext ? array("ext_id = '" . $ext . "'") : array("user_id = '" . $user . "'");
        }
    } else {
        $where = $ext ? array("ext_id = '" . $ext . "'") : array("user_id = '" . $user . "'");
    }
    if (isset($core->get["from"]) && $core->get["from"]) {
        $param["from"] = date2form(form2date($core->get["from"]));
        $from = $param["from"];
        $ds = form2date($from);
        $where[] = " click_date >= '" . $ds . "'";
    } else {
        $from = false;
    }
    if (isset($core->get["to"]) && $core->get["to"]) {
        $param["to"] = date2form(form2date($core->get["to"]));
        $to = $param["to"];
        $dt = form2date($to);
        $where[] = " click_date <= '" . $dt . "'";
    } else {
        $to = false;
    }
    if (isset($core->get["o"]) && $core->get["o"]) {
        $param["o"] = (int) $core->get["o"];
        $o = $param["o"];
        $where[] = " offer_id = '" . $o . "' ";
    } else {
        $o = false;
    }
    if (isset($core->get["f"]) && $core->get["f"]) {
        $param["f"] = (int) $core->get["f"];
        $f = $param["f"];
        $where[] = " flow_id = '" . $f . "' ";
    } else {
        $f = false;
    }
    if (isset($core->get["w"]) && $core->get["w"]) {
        $param["w"] = (int) $core->get["w"];
        $w = $param["w"];
        $where[] = " site_id = '" . $w . "' ";
    } else {
        $w = false;
    }
    if (isset($core->get["t"]) && $core->get["t"]) {
        $param["t"] = (int) $core->get["t"];
        $t = $param["t"];
        $where[] = " test_id = '" . $t . "' ";
    } else {
        $t = false;
    }
    if (isset($core->get["geo"]) && $core->get["geo"]) {
        $param["geo"] = $core->text->link($core->get["geo"]);
        $geo = $param["geo"];
        $where[] = " click_geo = '" . $geo . "' ";
    } else {
        $geo = false;
    }
    if (isset($core->get["us"])) {
        $param["us"] = $core->text->line($core->get["us"]);
        $where[] = "utms32 = '" . sprintf("%u", crc32($param["us"])) . "'";
    }
    if (isset($core->get["uc"])) {
        $param["uc"] = $core->text->line($core->get["uc"]);
        $where[] = "utmc32 = '" . sprintf("%u", crc32($param["uc"])) . "'";
    }
    if (isset($core->get["un"])) {
        $param["un"] = $core->text->line($core->get["un"]);
        $where[] = "utmn32 = '" . sprintf("%u", crc32($param["un"])) . "'";
    }
    if (isset($core->get["ut"])) {
        $param["ut"] = $core->text->line($core->get["ut"]);
        $where[] = "utmt32 = '" . sprintf("%u", crc32($param["ut"])) . "'";
    }
    if (isset($core->get["um"])) {
        $param["um"] = $core->text->line($core->get["um"]);
        $where[] = "utmm32 = '" . sprintf("%u", crc32($param["um"])) . "'";
    }
    if (isset($core->get["ei"])) {
        $param["ei"] = $core->text->line($core->get["ei"]);
        $where[] = "ext_uid = '" . $param["ei"] . "'";
    }
    if (isset($core->get["es"])) {
        $param["es"] = (int) $core->get["es"];
        $where[] = "ext_src = '" . $param["es"] . "'";
    }
    $where = $where ? implode(" AND ", $where) : "1";
    $sh = 30;
    $st = ($page - 1) * $sh;
    $clicks = $core->db->field("SELECT COUNT(*) FROM " . DB_CLICK . " WHERE " . $where);
    $click = $clicks ? $core->db->data("SELECT * FROM " . DB_CLICK . " WHERE " . $where . " ORDER BY click_id DESC LIMIT " . $st . ", " . $sh) : array();
    $oname = $core->cpa->get("offersa");
    $offer = $a ? $oname : $core->offer->names($user);
    if ($a || $ext) {
        $flow = array();
        if ($ext) {
            $sids = $core->db->col("SELECT DISTINCT site_id FROM " . DB_CLICK . " WHERE ext_id = '" . $ext . "'");
            $site = array();
            foreach ($sids as $ss) {
                $site[$ss] = $core->cpa->get("site", $ss, "site_url");
            }
        } else {
            $site = $core->db->icol("SELECT site_id, site_url FROM " . DB_SITE);
        }
    } else {
        $flow = $core->db->icol("SELECT flow_id, flow_name FROM " . DB_FLOW . " WHERE user_id = '" . $user . "' " . ($o ? " AND offer_id = '" . $o . "' " : "") . " ORDER BY flow_name ASC");
        $sids = $core->db->col("SELECT DISTINCT site_id FROM " . DB_CLICK . " WHERE user_id = '" . $user . "'");
        $site = array();
        foreach ($sids as $ss) {
            $site[$ss] = $core->cpa->get("site", $ss, "site_url");
        }
    }
    asort($site);
    $core->site->bc($core->lang["menu_sub_click"]);
    $core->site->page = $core->lang["stats_click"];
    $core->site->set("select2");
    $core->site->header();
    $core->tpl->load("body", "stats-click", defined("HACK_TPL_STASTS_CLICK") ? HACK : false);
    $core->tpl->vars("body", array("nostats" => $core->lang["nostats"], "date" => $core->lang["date"], "timer" => $core->lang["stat_timer"], "lfrom" => $core->lang["anal_from"], "lto" => $core->lang["anal_to"], "flow" => $flow ? $core->lang["flow"] : false, "offer" => $core->lang["offer"], "show" => $core->lang["show"], "site" => $core->lang["site"], "space" => $core->lang["stat_spaces"], "source" => $core->lang["source"], "unique" => $core->lang["stat_unique"], "lall" => $core->lang["stat_all"], "all" => $param["all"] ? "checked=\"checked\"" : "", "alls" => $canuser ? 1 : 0, "from" => $from, "to" => $to, "t" => $param["t"], "us" => $param["us"], "uc" => $param["uc"], "un" => $param["un"], "ut" => $param["ut"], "um" => $param["um"], "ei" => $param["ei"], "es" => $param["es"], "wm" => $param["wm"], "u_stat" => $core->url("m", "stats"), "stat" => $core->lang["stats_date"], "pages" => pages($core->url("m", "click?") . http_build_query($param), $clicks, $sh, $page, sprintf($core->lang["shown"], $st + 1, min($st + $sh, $clicks), $clicks)), "shown" => sprintf($core->lang["shown"], $st + 1, min($st + $sh, $clicks), $clicks)));
    foreach ($offer as $of => $n) {
        $core->tpl->block("body", "offer", array("name" => $n, "value" => $of, "select" => $of == $o ? "selected=\"selected\"" : ""));
    }
    foreach ($flow as $fl => $n) {
        $core->tpl->block("body", "flow", array("name" => $n, "value" => $fl, "select" => $fl == $f ? "selected=\"selected\"" : ""));
    }
    foreach ($site as $sl => $n) {
        $core->tpl->block("body", "site", array("name" => $n, "value" => $sl, "select" => $sl == $w ? "selected=\"selected\"" : ""));
    }
    if ($clicks) {
        foreach ($click as $r) {
            $core->tpl->block("body", "click", array("id" => $r["click_id"], "offer" => $oname[$r["offer_id"]], "unique" => $r["click_unique"], "space" => $r["click_space"], "type" => $r["click_space"] ? $core->lang["stat_spaces"] : $core->lang["stat_land"], "u_offer" => $core->url("m", "click?") . parset($param, "o", $r["offer_id"]), "site" => $r["site_id"] ? $core->cpa->get("site", $r["site_id"], "site_url") : false, "u_site" => $core->url("m", "click?") . parset($param, "w", $r["site_id"]), "flow" => $flow[$r["flow_id"]], "u_flow" => $core->url("m", "click?") . parset($param, "f", $r["flow_id"]), "ip" => int2ip($r["click_ip"]), "geo" => $r["click_geo"] ? $r["click_geo"] : "zz", "u_geo" => $core->url("m", "click?") . parset($param, "geo", $r["click_geo"]), "country" => $core->lang["country"][$r["click_geo"]], "date" => smartdate($r["click_time"]), "time" => $r["click_good"] ? 5 * $r["click_good"] : false, "us" => $r["utms"], "uus" => $core->url("m", "click?") . parset($param, "us", $r["utms"]), "uc" => $r["utmc"], "uuc" => $core->url("m", "click?") . parset($param, "uc", $r["utmc"]), "un" => $r["utmn"], "uun" => $core->url("m", "click?") . parset($param, "un", $r["utmn"]), "ut" => $r["utmt"], "uut" => $core->url("m", "click?") . parset($param, "ut", $r["utmt"]), "um" => $r["utmm"], "uum" => $core->url("m", "click?") . parset($param, "um", $r["utmm"]), "ei" => $r["ext_uid"], "uei" => $core->url("m", "click?") . parset($param, "ei", $r["ext_uid"]), "es" => $r["ext_src"], "ues" => $core->url("m", "click?") . parset($param, "es", $r["ext_src"])));
        }
    } else {
        $core->tpl->block("body", "nostat");
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}
function wm_stats_block($core, $stats, $base = false)
{
    $core->tpl->vars("body", array("nostats" => $core->lang["nostats"], "type" => $core->lang["type"], "total" => $core->lang["total"], "show" => $core->lang["show"], "source" => $core->lang["source"], "stats" => $core->lang["stats"], "lfrom" => $core->lang["anal_from"], "lto" => $core->lang["anal_to"], "today" => $core->lang["anal_today"], "yesterday" => $core->lang["anal_yest"], "day7" => $core->lang["anal_day7"], "day30" => $core->lang["anal_day30"], "day90" => $core->lang["anal_day90"], "lall" => $core->lang["stat_all"], "land" => $core->lang["stat_land"], "spaces" => $core->lang["stat_spaces"], "clicks" => $core->lang["stat_clicks"], "unique" => $core->lang["stat_unique"], "failure" => $core->lang["stat_failure"], "timer" => $core->lang["stat_time"], "transfer" => $core->lang["stat_transfer"], "conversion" => $core->lang["stat_conversion"], "approve" => $core->lang["stat_approve"], "ba" => $core->lang["stat_ba"], "bb" => $core->lang["stat_bb"], "totals" => $core->lang["stat_total"], "wait" => $core->lang["stat_wait"], "accept" => $core->lang["stat_accept"], "cancel" => $core->lang["stat_cancel"], "trash" => $core->lang["stat_trash"], "buyout" => $core->lang["stat_buyout"], "count" => $core->lang["stat_count"], "cash" => $core->lang["stat_cash"], "hasstats" => $stats ? true : false));
    $sc = array();
    $cl = wp_stats_cl($core, $base);
    $cc = $core->config("statcol");
    foreach ($cl as $ca => $cb) {
        $sc["x" . $ca] = $cb;
    }
    foreach ($cc as $ca => $cb) {
        $sc["z" . $ca] = $cb ? 1 : 0;
    }
    $core->tpl->vars("body", $sc);
    if ($stats) {
        $t = array("space" => 0, "suni" => 0, "sgood" => 0, "stime" => 0, "clicks" => 0, "unique" => 0, "good" => 0, "time" => 0, "ca" => 0, "cw" => 0, "cc" => 0, "ct" => 0, "cx" => 0, "ma" => 0, "mw" => 0, "mc" => 0, "mt" => 0, "cb" => 0, "cr" => 0);
        $tf = array_keys($t);
        foreach ($stats as $d => &$s) {
            $tc = max((int) $s["suni"], (int) $s["unique"]);
            $ts = $tc ? $s["ct"] / $tc * 1000 : 0;
            $cls = 100 < $tc ? $ts < 1 ? "red" : ($ts < 10 ? "yellow" : "") : "";
            foreach ($tf as $ttf) {
                if ($s[$ttf]) {
                    $t[$ttf] += $s[$ttf];
                }
            }
            $core->tpl->block("body", "stat", array("class" => $cls, "uid" => md5($s["leadu"]), "id" => $s["id"], "name" => $s["name"], "url" => $s["url"], "subid" => $s["subid"], "sub" => $s["sub"], "suburl" => $s["suburl"], "cr" => $tc ? sprintf("%0.2f", $s["ct"] / $tc * 100) : 0, "epc" => $tc ? sprintf("%0.2f", $s["ma"] / $tc) : "-", "epcr" => $tc ? sprintf("%0.2f", $s["ma"] / $tc) : 0, "app" => $s["ct"] ? sprintf("%d", $s["ca"] * 100 / $s["ct"]) : 0, "spaces" => (int) $s["space"], "suni" => (int) $s["suni"], "sbad" => sprintf("%d", $s["space"] ? ($s["space"] - $s["sgood"]) / $s["space"] * 100 : 0), "stime" => sprintf("%d", $s["stime"] * 5), "per" => $s["suni"] ? sprintf("%d", $s["unique"] / $s["suni"] * 100) : 0, "clicks" => (int) $s["clicks"], "unique" => (int) $s["unique"], "bad" => sprintf("%d", $s["clicks"] ? ($s["clicks"] - $s["good"]) / $s["clicks"] * 100 : 0), "time" => sprintf("%d", $s["time"] * 5), "ca" => (int) $s["ca"], "cw" => (int) $s["cw"], "cc" => (int) $s["cc"], "ct" => (int) $s["ct"], "cx" => (int) $s["cx"], "ua" => $s["leadu"] . "&s=a", "uw" => $s["leadu"] . "&s=w", "uc" => $s["leadu"] . "&s=c", "ux" => $s["leadu"] . "&s=t", "ut" => $s["leadu"], "ma" => $core->currency->mval($s["ma"]), "mw" => $core->currency->mval($s["mw"]), "mc" => $core->currency->mval($s["mc"]), "mt" => $core->currency->mval($s["mt"]), "mar" => (int) $s["ma"], "mwr" => (int) $s["mw"], "mcr" => (int) $s["mc"], "mtr" => (int) $s["mt"], "ba" => sprintf("%0.1f", $s["ca"] ? $s["cb"] / $s["ca"] * 100 : 0), "bb" => sprintf("%0.1f", $s["cb"] ? $s["cb"] / ($s["cb"] + $s["cr"]) * 100 : 0)));
        }
        unset($d);
        unset($s);
        $sc = count($stats);
        if (1 < $sc) {
            $cl = max($t["suni"], $t["unique"]);
            $core->tpl->block("body", "total", array("cr" => $cl ? sprintf("%0.2f", $t["ct"] / $cl * 100) : 0, "epc" => $cl ? sprintf("%0.2f", $t["ma"] / $cl) : "-", "epcr" => $cl ? sprintf("%0.2f", $t["ma"] / $cl) : 0, "app" => $t["ct"] ? sprintf("%d", $t["ca"] * 100 / $t["ct"]) : 0, "spaces" => (int) $t["space"], "suni" => (int) $t["suni"], "sbad" => sprintf("%d", $t["space"] ? ($t["space"] - $t["sgood"]) / $t["space"] * 100 : 0), "stime" => sprintf("%d", $t["stime"] * 5 / $sc), "per" => $t["suni"] ? sprintf("%d", $t["unique"] / $t["suni"] * 100) : 0, "clicks" => (int) $t["clicks"], "unique" => (int) $t["unique"], "bad" => sprintf("%d", $t["clicks"] ? ($t["clicks"] - $t["good"]) / $t["clicks"] * 100 : 0), "time" => sprintf("%d", $t["time"] * 5 / $sc), "ca" => (int) $t["ca"], "cw" => (int) $t["cw"], "cc" => (int) $t["cc"], "ct" => (int) $t["ct"], "cx" => (int) $t["cx"], "ma" => $core->currency->mval($t["ma"]), "mw" => $core->currency->mval($t["mw"]), "mc" => $core->currency->mval($t["mc"]), "mt" => $core->currency->mval($t["mt"]), "mar" => (int) $t["ma"], "mwr" => (int) $t["mw"], "mcr" => (int) $t["mc"], "mtr" => (int) $t["mt"], "ba" => sprintf("%0.1f", $t["ca"] ? $t["cb"] / $t["ca"] * 100 : 0), "bb" => sprintf("%0.1f", $t["cb"] ? $t["cb"] / ($t["cb"] + $t["cr"]) * 100 : 0)));
        }
    } else {
        $core->tpl->block("body", "nostat");
    }
}
function wp_stats_cl($core, $base)
{
    $c = array("space" => 0, "land" => 0, "conv" => 0, "lt" => 0, "la" => 0, "lw" => 0, "lc" => 0, "lb" => 0);
    $s = $core->config("statcol");
    if ($s["space"]) {
        $c["space"] += 1;
    }
    if ($s["suni"]) {
        $c["space"] += 1;
    }
    if ($s["sbad"]) {
        $c["space"] += 1;
    }
    if ($s["stime"]) {
        $c["space"] += 1;
    }
    if ($s["per"]) {
        $c["space"] += 1;
    }
    if ($s["clicks"]) {
        $c["land"] += 1;
    }
    if ($s["unique"]) {
        $c["land"] += 1;
    }
    if ($s["bad"]) {
        $c["land"] += 1;
    }
    if ($s["time"]) {
        $c["land"] += 1;
    }
    if ($s["cr"]) {
        $c["conv"] += 1;
    }
    if ($s["epc"]) {
        $c["conv"] += 1;
    }
    if ($s["app"]) {
        $c["conv"] += 1;
    }
    if ($s["ct"]) {
        $c["lt"] += 1;
    }
    if ($s["mt"]) {
        $c["lt"] += 1;
    }
    if ($s["ca"]) {
        $c["la"] += 1;
    }
    if ($s["ma"]) {
        $c["la"] += 1;
    }
    if ($s["cx"]) {
        $c["lc"] += 1;
    }
    if ($s["cc"]) {
        $c["lc"] += 1;
    }
    if ($s["mc"]) {
        $c["lc"] += 1;
    }
    if ($s["cw"]) {
        $c["lw"] += 1;
    }
    if ($s["mw"]) {
        $c["lw"] += 1;
    }
    if ($s["ba"]) {
        $c["lb"] += 1;
    }
    if ($s["bb"]) {
        $c["lb"] += 1;
    }
    $c["total"] = array_sum($c) + ($base ? $base : 1);
    return $c;
}

?>