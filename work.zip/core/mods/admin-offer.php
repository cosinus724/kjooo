<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function admin_offer($core)
{
    $action = isset($core->get["action"]) ? $core->text->link($core->get["action"]) : NULL;
    $id = isset($core->get["id"]) ? (int) $core->get["id"] : 0;
    switch ($action) {
        case "add":
            $name = $core->text->line($core->post["name"]);
            $sql = "INSERT INTO " . DB_OFFER . " SET offer_name = '" . $name . "'";
            if ($core->db->query($sql)) {
                $id = $core->db->lastid();
                $core->cpa->clear("offers");
                $core->cpa->clear("offersa");
                $core->go($core->url("im", "offer", $id, "add-ok"));
            } else {
                $core->go($core->url("mm", "offer", "add-e"));
            }
        case "edit":
            $wl = "";
            $wll = $core->post["wl"] ? preg_split("/[\\s,]+/", $core->post["wl"], -1, PREG_SPLIT_NO_EMPTY) : array();
            foreach ($wll as $o) {
                $wl .= strpos($o, "-") ? " ext" . $o : " user" . $o;
            }
            $wl = trim($wl);
            $bl = "";
            $bll = $core->post["bl"] ? preg_split("/[\\s,]+/", $core->post["bl"], -1, PREG_SPLIT_NO_EMPTY) : array();
            foreach ($bll as $o) {
                $bl .= strpos($o, "-") ? " ext" . $o : " user" . $o;
            }
            $bl = trim($bl);
            $data = array("offer_active" => $core->post["active"] ? 1 : 0, "offer_private" => (int) $core->post["private"], "offer_wl" => $wl, "offer_bl" => $bl, "offer_block" => $core->post["block"] ? 1 : 0, "cat_id" => (int) $core->post["cat"], "cat_sub" => (int) $core->post["sub"], "offer_home" => $core->post["home"] ? 1 : 0, "offer_sort" => (int) $core->post["sort"], "offer_excl" => $core->post["excl"] ? 1 : 0, "offer_recom" => $core->post["recom"] ? 1 : 0, "offer_name" => $core->text->line($core->post["name"]), "offer_descr" => $core->text->line($core->post["descr"]), "offer_info" => $core->text->code($core->post["info"]), "offer_full" => $core->text->code($core->post["full"]), "offer_text" => $core->text->line($core->post["text"]), "offer_line" => $core->text->code($core->post["line"]), "offer_call" => $core->text->code($core->post["call"]), "offer_country" => $core->text->codeline($core->post["country"]), "offer_allow" => $core->text->intline($core->post["allow"]), "offer_deny" => $core->text->intline($core->post["deny"]), "offer_hold" => (int) $core->post["hold"], "offer_vars" => $core->post["vars"] ? 1 : 0, "offer_delivery" => $core->post["delivery"] ? 1 : 0, "offer_paramurl" => $core->text->line($core->post["paramurl"]), "in_default" => (int) $core->post["in_default"], "in_script" => $core->text->line($core->post["in_script"]), "out_default" => (int) $core->post["out_default"], "out_comps" => $core->text->intline($core->post["out_comps"]), "out_script" => $core->text->line($core->post["out_script"]), "bad_script" => $core->text->line($core->post["bad_script"]));
            if ($core->db->edit(DB_OFFER, $data, "offer_id = '" . $id . "'")) {
                if ($core->files["image"]["name"]) {
                    $ii = getimagesize($core->files["image"]["tmp_name"]);
                    if ($ii[2] == IMG_JPG) {
                        move_uploaded_file($core->files["image"]["tmp_name"], sprintf(OFFER_FILE, $id));
                    }
                }
                $core->cpa->clear("offer", $id);
                $core->cpa->clear("ofp", $id);
                $core->cpa->clear("offers");
                $core->cpa->clear("offersa");
                $core->cpa->clear("offerauth");
                $core->cpa->clear("offercat");
                $core->cpa->clear("offersub");
                $core->cpa->clear("offergeo");
                $core->uncache("offer.price" . $id);
                $core->go($core->url("mm", "offer", "edit-ok"));
            } else {
                $core->go($core->url("mm", "offer", "edit-e"));
            }
        case "del":
            $sql = "DELETE FROM " . DB_OFFER . " WHERE offer_id = '" . $id . "'";
            if ($core->db->query($sql)) {
                $core->db->query("DELETE FROM " . DB_STORE . " WHERE offer_id = '" . $id . "'");
                $core->db->query("DELETE FROM " . DB_PRICE . " WHERE offer_id = '" . $id . "'");
                $core->db->query("DELETE FROM " . DB_ORDER . " WHERE offer_id = '" . $id . "'");
                $core->db->query("DELETE FROM " . DB_FLOW . " WHERE offer_id = '" . $id . "'");
                $core->db->query("DELETE FROM " . DB_STATS . " WHERE offer_id = '" . $id . "'");
                $core->db->query("DELETE FROM " . DB_SITE . " WHERE offer_id = '" . $id . "'");
                $core->db->query("DELETE FROM " . DB_LOAD . " WHERE offer_id = '" . $id . "'");
                $core->cpa->clear("offer", $id);
                $core->cpa->clear("offers");
                $core->cpa->clear("offersa");
                $core->cpa->clear("offerauth");
                $core->cpa->clear("offercat");
                $core->cpa->clear("offersub");
                $core->cpa->clear("offergeo");
                $core->uncache("offer.price" . $id);
                $core->go($core->url("mm", "offer", "del-ok"));
            } else {
                $core->go($core->url("mm", "offer", "del-e"));
            }
        case "export":
            $data = array("source" => $core->server["HTTP_HOST"], "offer" => $core->db->row("SELECT * FROM " . DB_OFFER . " WHERE offer_id = '" . $id . "' LIMIT 1"), "sites" => $core->db->data("SELECT * FROM " . DB_SITE . " WHERE offer_id = '" . $id . "'"), "price" => $core->db->data("SELECT * FROM " . DB_PRICE . " WHERE offer_id = '" . $id . "'"), "vars" => $core->db->data("SELECT * FROM " . DB_VARS . " WHERE offer_id = '" . $id . "'"));
            header("Content-type: application/json");
            header("Content-disposition: attachment; filename=offer" . $id . ".json");
            echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            $core->stop();
        case "params":
            $param = array();
            foreach ($core->post["param"] as $u => $v1) {
                $u = (int) $u;
                $v1 = $core->text->link($v1);
                $v2 = (string) trim(stripslashes($core->post["value"][$u]));
                if ($v1) {
                    $param[$v1] = $v2;
                }
            }
            $param = addslashes(serialize($param));
            if ($core->db->edit(DB_OFFER, array("offer_pars" => $param), "offer_id = '" . $id . "'")) {
                $core->cpa->clear("offer", $id);
                $core->cpa->clear("ofp", $id);
                $core->go($core->url("mm", "offer", "edit-ok"));
            } else {
                $core->go($core->url("mm", "offer", "edit-e"));
            }
        case "prt":
            $price = $core->cpa->get("price", $id);
            foreach ($core->post["prt"] as $u => $v) {
                $u = (int) $u;
                if ($v = round($core->text->float($v), 2)) {
                    $price[$u] = $v;
                } else {
                    unset($price[$u]);
                }
            }
            $price = addslashes(serialize($price));
            if ($core->db->edit(DB_OFFER, array("offer_prt" => $price), "offer_id = '" . $id . "'")) {
                $core->cpa->clear("offer", $id);
                $core->cpa->clear("price", $id);
                $core->go($core->url("mm", "offer", "edit-ok"));
            } else {
                $core->go($core->url("mm", "offer", "edit-e"));
            }
        case "wl":
            $u = (int) $core->get["user"];
            if (!$u) {
                $core->go($core->u("offer", "message=error"));
            }
            $wl = $core->db->field("SELECT offer_wl FROM " . DB_OFFER . " WHERE offer_id = '" . $id . "' LIMIT 1");
            $wl = explode(" ", $wl);
            $wl[] = "user" . $u;
            $wl = array_unique($wl);
            sort($wl);
            $core->db->edit(DB_OFFER, array("offer_wl" => implode(" ", $wl)), array("offer_id" => $id));
            $core->cpa->clear("offerauth");
            $core->go($core->u("offer", "message=ok"));
    }
    $message = isset($core->get["message"]) ? $core->text->link($core->get["message"]) : NULL;
    switch ($message) {
        case "ok":
            $core->site->info("info", "done_basic");
            break;
        case "add-ok":
            $core->site->info("info", "done_offer_add");
            break;
        case "edit-ok":
            $core->site->info("info", "done_offer_edit");
            break;
        case "del-ok":
            $core->site->info("info", "done_offer_del");
            break;
        case "error":
            $core->site->info("error", "error_basic");
            break;
        case "add-e":
            $core->site->info("error", "error_offer_add");
            break;
        case "edit-e":
            $core->site->info("error", "error_offer_edit");
            break;
        case "del-e":
            $core->site->info("error", "error_offer_del");
            break;
    }
    if ($id) {
        $offer = $core->db->row("SELECT * FROM " . DB_OFFER . " WHERE offer_id = '" . $id . "' LIMIT 1");
        $comps = $core->cpa->get("compa");
        $comp = array("&mdash;");
        if (is_array($comps)) {
            $comp += $comps;
        }
        $wl = array();
        $ol = explode(" ", $offer["offer_wl"]);
        foreach ($ol as $oi) {
            if ($oi = trim($oi)) {
                if (substr($oi, 0, 3) == "ext") {
                    $oq = explode("-", substr($oi, 3), 2);
                    $ei = (int) $oq[0];
                    if ($ei) {
                        $wl[] = substr($oi, 3);
                    }
                } else {
                    if (substr($oi, 0, 4) == "user") {
                        $ui = (int) substr($oi, 4);
                        if ($ui) {
                            $wl[] = $ui;
                        }
                    }
                }
            }
        }
        $wl = implode(", ", $wl);
        $bl = array();
        $ol = explode(" ", $offer["offer_bl"]);
        foreach ($ol as $oi) {
            if ($oi = trim($oi)) {
                if (substr($oi, 0, 3) == "ext") {
                    $oq = explode("-", substr($oi, 3), 2);
                    $ei = (int) $oq[0];
                    if ($ei) {
                        $bl[] = substr($oi, 3);
                    }
                } else {
                    if (substr($oi, 0, 4) == "user") {
                        $ui = (int) substr($oi, 4);
                        if ($ui) {
                            $bl[] = $ui;
                        }
                    }
                }
            }
        }
        $bl = implode(", ", $bl);
        $core->site->bc($core->lang["offers_h"], $core->url("m", "offer"));
        $core->site->bc($offer["offer_name"]);
        $core->site->set("select2");
        $core->site->header();
        $field = array(array("type" => "text", "length" => 100, "name" => "name", "head" => $core->lang["offer_name"], "descr" => $core->lang["offer_name_d"], "value" => $offer["offer_name"]), array("type" => "text", "length" => 200, "name" => "text", "head" => $core->lang["offer_text"], "descr" => $core->lang["offer_text_d"], "value" => $offer["offer_text"]), array("type" => "text", "length" => 200, "name" => "descr", "head" => $core->lang["offer_descr"], "descr" => $core->lang["offer_descr_d"], "value" => $offer["offer_descr"]), array("type" => "head", "value" => $core->lang["offer_position"]), array("type" => "select", "name" => "cat", "head" => $core->lang["div"], "value" => $offer["cat_id"], "options" => $core->lang["offer_cats"]), defined("OFFERSUBS") ? array("type" => "select", "name" => "sub", "head" => $core->lang["subdiv"], "value" => $offer["cat_sub"], "options" => $core->lang["offer_subs"]) : NULL, array("type" => "text", "length" => 5, "name" => "sort", "head" => $core->lang["offer_sort"], "descr" => $core->lang["offer_sort_d"], "value" => $offer["offer_sort"]), array("type" => "file", "name" => "image", "head" => $core->lang["logo"], "descr" => "JPEG 400x250px"), array("type" => "checkbox", "name" => "excl", "head" => $core->lang["offer_excl"], "descr" => $core->lang["offer_excl_d"], "checked" => $offer["offer_excl"]), array("type" => "checkbox", "name" => "recom", "head" => $core->lang["offer_recom"], "descr" => $core->lang["offer_recom_d"], "checked" => $offer["offer_recom"]), array("type" => "checkbox", "name" => "home", "head" => $core->lang["offer_home"], "descr" => $core->lang["offer_home_d"], "checked" => $offer["offer_home"]), array("type" => "head", "value" => $core->lang["offer_parameters"]), array("type" => "mselect", "name" => "country", "head" => $core->lang["offer_country"], "descr" => $core->lang["offer_country_d"], "value" => $offer["offer_country"], "options" => $core->lang["country"]), array("type" => "mselect", "name" => "allow", "head" => $core->lang["offer_src_allow"], "value" => $offer["offer_allow"], "options" => $core->lang["offer_src"]), array("type" => "mselect", "name" => "deny", "head" => $core->lang["offer_src_deny"], "value" => $offer["offer_deny"], "options" => $core->lang["offer_src"]), array("type" => "number", "min" => 0, "max" => 255, "name" => "hold", "head" => $core->lang["offer_hold"], "descr" => $core->lang["offer_hold_d"], "value" => $offer["offer_hold"] ? $offer["offer_hold"] : ""), array("type" => "checkbox", "name" => "vars", "head" => $core->lang["offer_vars"], "descr" => $core->lang["offer_vars_d"], "checked" => $offer["offer_vars"]), array("type" => "checkbox", "name" => "delivery", "head" => $core->lang["offer_delivery"], "descr" => $core->lang["offer_delivery_d"], "checked" => $offer["offer_delivery"]), array("type" => "text", "length" => 200, "name" => "paramurl", "head" => $core->lang["offer_paramurl"], "descr" => $core->lang["offer_paramurl_d"], "value" => $offer["offer_paramurl"]), array("type" => "head", "value" => $core->lang["offer_access"]), array("type" => "checkbox", "name" => "active", "head" => $core->lang["active"], "descr" => $core->lang["offer_active_d"], "checked" => $offer["offer_active"]), array("type" => "select", "name" => "private", "head" => $core->lang["offer_private"], "descr" => $core->lang["offer_private_d"], "value" => $offer["offer_private"], "options" => $core->lang["offer_privates"]), array("type" => "text", "name" => "wl", "head" => $core->lang["offer_wl"], "descr" => $core->lang["offer_bl_d"], "value" => $wl), array("type" => "text", "name" => "bl", "head" => $core->lang["offer_bl"], "descr" => $core->lang["offer_bl_d"], "value" => $bl), array("type" => "checkbox", "name" => "block", "head" => $core->lang["offer_block"], "descr" => $core->lang["offer_block_d"], "checked" => $offer["offer_block"]), array("type" => "head", "value" => $core->lang["offer_in"]), array("type" => "select", "name" => "in_default", "head" => $core->lang["io_default"], "descr" => $core->lang["io_default_d"], "value" => $offer["in_default"], "options" => $comp), array("type" => "textarea", "rows" => 7, "name" => "in_script", "head" => $core->lang["io_script"], "descr" => $core->lang["io_script_d"], "value" => $offer["in_script"]), array("type" => "head", "value" => $core->lang["offer_out"]), array("type" => "select", "name" => "out_default", "head" => $core->lang["io_default"], "descr" => $core->lang["io_default_d"], "value" => $offer["out_default"], "options" => $comp), array("type" => "mselect", "name" => "out_comps", "head" => $core->lang["io_comps"], "descr" => $core->lang["io_comps_d"], "value" => $offer["out_comps"], "options" => $core->cpa->get("comps")), array("type" => "textarea", "rows" => 7, "name" => "out_script", "head" => $core->lang["io_script"], "descr" => $core->lang["io_script_d"], "value" => $offer["out_script"]), array("type" => "head", "value" => $core->lang["offer_bad"]), array("type" => "textarea", "rows" => 7, "name" => "bad_script", "head" => $core->lang["io_script"], "descr" => $core->lang["io_script_d"], "value" => $offer["bad_script"]), array("type" => "head", "value" => $core->lang["offer_info"]), array("type" => "mces", "name" => "info", "head" => $core->lang["offer_info"], "value" => $offer["offer_info"]), array("type" => "mcea", "name" => "full", "head" => $core->lang["offer_full"], "value" => $offer["offer_full"]), array("type" => "mcea", "name" => "call", "head" => $core->lang["offer_call"], "descr" => $core->lang["offer_call_d"], "value" => $offer["offer_call"]), array("type" => "code", "lang" => "htmlmixed,xml,javascript,css", "mime" => "text/html", "name" => "line", "head" => $core->lang["offer_line"], "descr" => $core->lang["offer_line_d"], "value" => $offer["offer_line"]));
        $core->site->form("edit", $core->url("ia", "offer", $id, "edit"), $core->lang["offer_edit_h"], $field);
        $core->site->footer();
    } else {
        $where = $params = array();
        if (isset($core->get["s"]) && $core->get["s"]) {
            require_once PATH_CORE . "search.php";
            $search = new SearchWords($core->get["s"]);
            if ($s = $search->get()) {
                $where[] = " (" . $search->field(array("offer_id", "offer_name", "offer_text")) . ") ";
            } else {
                $search = $s = false;
            }
        } else {
            $search = $s = false;
        }
        if ($cat = (int) $_GET["c"]) {
            $where[] = "cat_id = '" . $cat . "'";
            $params["c"] = $cat;
        } else {
            $cat = false;
        }
        if ($ic = (int) $_GET["ic"]) {
            $where[] = "in_default = '" . $ic . "'";
            $params["ic"] = $ic;
        } else {
            $ic = false;
        }
        if ($geo = $core->text->link($core->get["geo"])) {
            $where[] = "offer_country LIKE '%" . $geo . "%'";
            $params["geo"] = $geo;
        } else {
            $geo = false;
        }
        $page = max(1, (int) $core->get["page"]);
        $sh = $core->config("offer", "page");
        if (!$sh) {
            $sh = 30;
        }
        $st = $sh * ($page - 1);
        $where = $where ? " WHERE " . implode(" AND ", $where) : "";
        $oc = $core->db->field("SELECT COUNT(*) FROM " . DB_OFFER . " " . $where);
        $offer = $oc ? $core->db->data("SELECT offer_id, cat_id, offer_excl, offer_recom, offer_name, offer_active, offer_block, offer_private, in_default, offer_delivery, offer_vars FROM " . DB_OFFER . " " . $where . " ORDER BY offer_sort DESC, offer_name ASC LIMIT " . $st . ", " . $sh) : array();
        $comp = $core->cpa->get("compa");
        $core->site->bc($core->lang["offers_h"], $core->url("m", "offer"));
        $core->site->header();
        $core->tpl->load("body", "offer-list", defined("HACK_TPL_OFLIST") ? HACK : false);
        $core->tpl->vars("body", array("title" => $core->lang["offers_h"], "name" => $core->lang["name"], "type" => $core->lang["type"], "cat" => $core->lang["cat"], "comp" => $core->lang["company"], "price" => $core->lang["price"], "prt" => $core->lang["prices"], "prices" => $core->lang["offer_prices"], "vars" => $core->lang["goods"], "param" => $core->lang["params"], "sites" => $core->lang["sites"], "action" => $core->lang["action"], "edit" => $core->lang["settings"], "del" => $core->lang["del"], "confirm" => $core->lang["confirms"], "import" => $core->lang["import"], "export" => $core->lang["export"], "test" => $core->lang["offer_test"], "load" => $core->lang["download"], "add" => $core->lang["offer_add"], "active" => $core->lang["active"], "private" => $core->lang["offer_private"], "block" => $core->lang["offer_block"], "cats" => $core->lang["cat"], "country" => $core->lang["order_country"], "u_add" => $core->url("ma", "offer", "add"), "u_load" => $core->url("m", "offer-load"), "u_import" => $core->url("m", "offer-import"), "u_search" => $core->url("m", "offer"), "s" => $s, "pages" => $oc ? pages($core->u("offer", $params), $oc, $sh, $page, sprintf($core->lang["shown"], $st + 1, min($st + $sh, $oc), $oc)) : false, "search" => $core->lang["search"], "find" => $core->lang["find"]));
        foreach ($core->lang["offer_cats"] as $ci => $cn) {
            $core->tpl->block("body", "cat", array("id" => $ci, "name" => $cn, "select" => $ci == $cat));
        }
        foreach ($comp as $ci => $cn) {
            $core->tpl->block("body", "comp", array("id" => $ci, "name" => $cn, "select" => $ci == $ic));
        }
        foreach ($core->lang["country"] as $ci => $cn) {
            $core->tpl->block("body", "geo", array("id" => $ci, "name" => $cn, "select" => $ci == $geo));
        }
        foreach ($offer as &$i) {
            $ccc = $core->lang["offer_cats"][$i["cat_id"]];
            if ($i["offer_excl"]) {
                $ccc = "<b>" . $ccc . "</b>";
            }
            $core->tpl->block("body", "item", array("id" => $i["offer_id"], "name" => $i["offer_name"], "cat" => $ccc, "active" => $i["offer_block"] ? false : $i["offer_active"], "block" => $i["offer_block"], "private" => $i["offer_block"] ? false : $i["offer_private"], "vars" => $i["offer_vars"] ? $core->url("i", "offer-vars", $i["offer_id"]) : false, "tid" => $i["offer_delivery"], "type" => $core->lang["offertype"][$i["offer_delivery"]], "comp" => $i["in_default"] ? $comp[$i["in_default"]] : false, "sites" => $core->url("i", "offer-sites", $i["offer_id"]), "prices" => $core->url("i", "offer-prices", $i["offer_id"]), "prt" => $core->url("i", "offer-prt", $i["offer_id"]), "param" => $core->url("i", "offer-pars", $i["offer_id"]), "edit" => $core->url("i", "offer", $i["offer_id"]), "del" => $core->url("ia", "offer", $i["offer_id"], "del"), "test" => $core->url("i", "offer-test", $i["offer_id"]), "load" => $core->url("i", "offer-load", 0) . "?offer=" . $i["offer_id"], "import" => $core->url("i", "offer-import", $i["offer_id"]), "export" => $core->url("ia", "offer", $i["offer_id"], "export")));
        }
        unset($d);
        $core->tpl->output("body");
        $core->site->footer();
    }
    $core->stop();
}
function admin_offer_prt($core, $id)
{
    $offer = $core->db->row("SELECT * FROM " . DB_OFFER . " WHERE offer_id = '" . $id . "' LIMIT 1");
    $prt = $offer["offer_prt"] ? unserialize($offer["offer_prt"]) : array();
    $core->site->bc($core->lang["offers_h"], $core->url("m", "offer"));
    $core->site->bc(sprintf($core->lang["offer_prt_h"], $offer["offer_name"]));
    $core->site->header();
    $field = array(array("type" => "line", "value" => $core->text->lines($core->lang["offer_prt_t"])));
    $cids = $core->currency->geoline($offer["offer_country"]);
    foreach ($core->currency->data as $i => $n) {
        if (in_array($i, $cids)) {
            $descr = array();
            if (is_array($n[1])) {
                foreach ($n[1] as $c) {
                    $descr[] = "<span class=\"flagname\"><img src=\"/core/images/flag/" . $c . ".png\" alt=\"" . $c . "\" title=\"" . $c . "\" align=\"top\" /> " . $core->lang["country"][$c] . "</span>";
                }
            } else {
                $descr[] = "<span class=\"flagname\"><img src=\"/core/images/flag/" . $n[1] . ".png\" alt=\"" . $n[1] . "\" title=\"" . $n[1] . "\" align=\"top\" /> " . $core->lang["country"][$n[1]] . "</span>";
            }
            $descr = "ID: " . $i . " - " . strtoupper($core->currency->code($i)) . ". " . implode(" ", $descr);
            $field[] = array("type" => "number", "name" => "prt[" . $i . "]", "head" => $core->currency->name($i), "descr" => $descr, "value" => $prt[$i], "step" => 0.01);
        }
    }
    $core->site->form("offeradd", $core->url("ia", "offer", $id, "prt"), sprintf($core->lang["offer_prt_h"], $offer["offer_name"]), $field);
    $core->site->footer();
    $core->stop();
}
function admin_offer_pars($core, $id)
{
    $offer = $core->db->row("SELECT * FROM " . DB_OFFER . " WHERE offer_id = '" . $id . "' LIMIT 1");
    $pars = $offer["offer_pars"] ? unserialize($offer["offer_pars"]) : array();
    $core->site->bc($core->lang["offers_h"], $core->url("m", "offer"));
    $core->site->bc(sprintf($core->lang["offer_pars_h"], $offer["offer_name"]));
    $core->site->header();
    $core->tpl->load("body", "param", defined("HACK_TPL_PARAM") ? HACK : false);
    $core->tpl->vars("body", array("title" => sprintf($core->lang["offer_pars_h"], $offer["offer_name"]), "u_save" => $core->url("ia", "offer", $id, "params"), "save" => $core->lang["save"], "name" => $core->lang["name"], "value" => $core->lang["value"]));
    $i = 1;
    foreach ($pars as $k => $v) {
        $core->tpl->block("body", "param", array("id" => $i, "name" => $k, "val" => $v ? $v : ""));
        $i++;
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}

?>