<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function admin_menu($core, $menu)
{
    $menu["analytics"] = array("analytics", "analytics-calls", "analytics-delivery", "business", "dynamics");
    $menu["config"] = array("config", "offer", "comps", "ext", "users", "trans", "outs");
    $menu[] = "supporthq";
    return $menu;
}
function admin_module($core)
{
    $module = $core->get["m"] ? $core->get["m"] : NULL;
    $id = $core->post["id"] ? (int) $core->post["id"] : ($core->get["id"] ? (int) $core->get["id"] : 0);
    switch ($module) {
        case "files":
            require_once PATH_MODS . "admin-common.php";
            admin_files($core);
        case "users":
            require_once PATH_MODS . "admin-users.php";
            admin_users($core, array());
        case "offer":
            require_once PATH_MODS . "admin-offer.php";
            admin_offer($core);
        case "offer-prt":
            if (!$id) {
                $core->go($core->url("m", "offer"));
            }
            require_once PATH_MODS . "admin-offer.php";
            admin_offer_prt($core, $id);
        case "offer-pars":
            if (!$id) {
                $core->go($core->url("m", "offer"));
            }
            require_once PATH_MODS . "admin-offer.php";
            admin_offer_pars($core, $id);
        case "offer-vars":
            if (!$id) {
                $core->go($core->url("m", "offer"));
            }
            require_once PATH_MODS . "admin-offer-vars.php";
            admin_offer_vars($core, $id);
        case "offer-var":
            if (!$id) {
                $core->go($core->url("m", "offer"));
            }
            require_once PATH_MODS . "admin-offer-vars.php";
            admin_offer_var($core, $id);
        case "offer-vpar":
            if (!$id) {
                $core->go($core->url("m", "offer"));
            }
            require_once PATH_MODS . "admin-offer-vars.php";
            admin_offer_vpar($core, $id);
        case "offer-prices":
            if (!$id) {
                $core->go($core->url("m", "offer"));
            }
            require_once PATH_MODS . "admin-offer-price.php";
            admin_offer_prices($core, $id);
        case "offer-price":
            if (!$id) {
                $core->go($core->url("m", "offer"));
            }
            require_once PATH_MODS . "admin-offer-price.php";
            admin_offer_price($core, $id);
        case "offer-sites":
            if (!$id) {
                $core->go($core->url("m", "offer"));
            }
            require_once PATH_MODS . "admin-offer-site.php";
            admin_offer_sites($core, $id);
        case "offer-site":
            if (!$id) {
                $core->go($core->url("m", "offer"));
            }
            require_once PATH_MODS . "admin-offer-site.php";
            admin_offer_site($core, $id);
        case "offer-import":
            require_once PATH_MODS . "admin-offer-tools.php";
            admin_offer_import($core);
        case "offer-load":
            require_once PATH_MODS . "admin-offer-tools.php";
            admin_offer_load($core);
        case "offer-test":
            require_once PATH_MODS . "admin-offer-tools.php";
            admin_offer_test($core);
        case "integration":
            if ($id) {
                $core->site->bc($core->lang["admin_comp_h"], $core->url("m", "comps"));
                $core->site->bc($core->cpa->get("compa", 0, $id), $core->url("i", "comps", $id));
                require_once PATH_MODS . "comp-int.php";
                company_integration($core, $id, true);
            }
        case "comp-delivery":
            if ($id) {
                $core->site->bc($core->lang["admin_comp_h"], $core->url("m", "comps"));
                $core->site->bc($core->cpa->get("compa", 0, $id), $core->url("i", "comps", $id));
                require_once PATH_MODS . "comp-settings.php";
                company_delivery($core, $id, true);
            }
        case "comp-stage":
            if ($id) {
                $core->site->bc($core->lang["admin_comp_h"], $core->url("m", "comps"));
                $core->site->bc($core->cpa->get("compa", 0, $id), $core->url("i", "comps", $id));
                require_once PATH_MODS . "comp-settings.php";
                company_stages($core, $id, true);
            }
        case "comp-stage-edit":
            if ($id) {
                $s = $core->db->row("SELECT * FROM " . DB_STAGE . " WHERE stage_id = '" . $id . "' LIMIT 1");
                $core->site->bc($core->lang["admin_comp_h"], $core->url("m", "comps"));
                $core->site->bc($core->cpa->get("compa", 0, $s["comp_id"]), $core->url("i", "comps", $s["comp_id"]));
                require_once PATH_MODS . "comp-settings.php";
                company_stage_form($core, $s["comp_id"], $s, true);
            }
        case "comps":
            require_once PATH_MODS . "admin-comp.php";
            admin_comp($core);
        case "integration-log":
            $core->site->bc($core->lang["admin_comp_h"], $core->url("m", "comps"));
            require_once PATH_MODS . "comp-int.php";
            integration_log($core, $core->user->comp);
        case "ext":
            require_once PATH_MODS . "admin-ext.php";
            admin_ext($core);
        case "news-add":
            require_once PATH_MODS . "admin-news.php";
            admin_news_add($core);
        case "news":
            require_once PATH_MODS . "admin-news.php";
            if (!admin_news($core)) {
                break;
            }
        case "supporthq":
            require_once PATH_MODS . "admin-support.php";
            admin_support($core, array());
        case "outs":
            require_once PATH_MODS . "admin-money.php";
            admin_outs($core);
        case "trans":
            require_once PATH_MODS . "admin-money.php";
            admin_trans($core);
        case "analytics":
            require_once PATH_MODS . "analytics-order.php";
            analytics_order($core, "analytics");
        case "analytics-calls":
            require_once PATH_MODS . "analytics-calls.php";
            analytics_calls($core, "analytics-calls");
        case "analytics-delivery":
            require_once PATH_MODS . "analytics-delivery.php";
            analytics_delivery($core, "analytics-delivery");
        case "dynamics":
            require_once PATH_MODS . "admin-money.php";
            admin_dynamics($core);
        case "business":
            require_once PATH_MODS . "admin-money.php";
            admin_business($core);
        case "config":
            require_once PATH_MODS . "config.php";
            configlist($core);
        case "config-basic":
            require_once PATH_MODS . "config.php";
            configpage_basic($core);
        case "config-sites":
            require_once PATH_MODS . "config.php";
            configpage_sites($core);
        case "config-advanced":
            require_once PATH_MODS . "config.php";
            configpage_advanced($core);
        case "config-money":
            require_once PATH_MODS . "config.php";
            configpage_money($core);
        case "config-domain":
            require_once PATH_MODS . "config.php";
            configpage_domain($core);
        case "config-design":
            require_once PATH_MODS . "config.php";
            configpage_design($core);
        case "config-banph":
            require_once PATH_MODS . "config-bl.php";
            configpage_banph($core);
        case "config-banip":
            require_once PATH_MODS . "config-bl.php";
            configpage_banip($core);
        case "config-diag":
            require_once PATH_MODS . "config-service.php";
            configpage_diag($core);
    }
    return false;
}

?>