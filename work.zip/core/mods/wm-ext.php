<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function external_menu($core, $menu)
{
    $stats = array();
    if (!$core->config("hide", "date")) {
        $stats[] = "stats";
    }
    if (!$core->config("hide", "hour")) {
        $stats[] = "hourstat";
    }
    if (!$core->config("hide", "offer")) {
        $stats[] = "offerstat";
    }
    if (!$core->config("hide", "site")) {
        $stats[] = "site";
    }
    if (!$core->config("hide", "geo")) {
        $stats[] = "geostat";
    }
    if (!$core->config("hide", "utm")) {
        $stats[] = "utm";
    }
    if (!$core->config("hide", "ext")) {
        $stats[] = "exti";
    }
    if (!$core->config("hide", "click")) {
        $stats[] = "click";
    }
    if (!$core->config("hide", "lead")) {
        $menu[] = "leads";
    }
    if ($stats) {
        $menu["stats"] = $stats;
    }
    if (!$core->config("hide", "split")) {
        $menu[] = "split";
    }
    if (!$core->config("hide", "offerext")) {
        $menu[] = "offers";
    }
    return $menu;
}
function external_module($core)
{
    $module = $core->get["m"] ? $core->get["m"] : NULL;
    if ($module == "split" || $module == "split-edit" || $module == "split-test") {
        require_once PATH_MODS . "wm-split.php";
        wm_split($core);
    }
    require_once PATH_MODS . "wm-stats.php";
    switch ($module) {
        case "stats":
            wm_stats_date($core);
        case "hourstat":
            wm_stats_hour($core);
        case "offerstat":
            wm_stats_offer($core);
        case "geostat":
            wm_stats_geo($core);
        case "utm":
            wm_stats_utm($core);
        case "exti":
            wm_stats_ext($core);
        case "click":
            wm_stats_click($core);
        default:
            wm_stats_leads($core);
    }
}

?>