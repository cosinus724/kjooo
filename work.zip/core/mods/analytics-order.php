<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function analytics_order($core, $url, $cfg = array())
{
    $cmp = isset($cfg["cmp"]) ? $cfg["cmp"] : false;
    $mgr = isset($cfg["manager"]) ? $cfg["manager"] : false;
    $vip = isset($cfg["vip"]) ? $cfg["vip"] : false;
    $csv = $core->get["show"] == "csv" ? 1 : 0;
    $today = date("Ymd");
    $yest = date("Ymd", strtotime("-1 day"));
    $week1 = date("Ymd", strtotime("-6 days"));
    $month = date("Ymd", strtotime("-1 month"));
    $month3 = date("Ymd", strtotime("-3 months"));
    extract(params($core, array("to" => "date", "from" => "date")));
    if (!$to || $today < $to) {
        $to = $today;
    }
    if ($to < $from) {
        $from = $to;
    }
    if (!$from) {
        $from = $today;
    }
    $ff = strtotime(date2form($from) . " 00:00:00");
    $tt = strtotime(date2form($to) . " 23:59:59");
    $param = $where = array();
    $param["from"] = date2form($from);
    $param["to"] = date2form($to);
    $where[] = "order_time BETWEEN '" . $ff . "' AND '" . $tt . "'";
    if ($o = (int) $core->get["o"]) {
        $param["o"] = $o;
        $where[] = "offer_id = '" . $o . "'";
    } else {
        $o = false;
    }
    if ($geo = $core->text->link($core->get["geo"])) {
        $param["geo"] = $geo;
        $where[] = "order_country = '" . $geo . "'";
    } else {
        $geo = false;
    }
    if ($mgr && !$vip) {
        $wml = $core->db->col("SELECT user_id FROM " . DB_USER . " WHERE user_man = '" . $mgr . "'");
        if ($wml) {
            $wm = (int) $core->get["wm"];
            if ($wm && in_array($wm, $wml)) {
                $param["wm"] = $wm;
                $where[] = "wm_id = '" . $wm . "'";
            } else {
                $where[] = "wm_id IN ( " . implode(",", $wml) . " )";
            }
        } else {
            $where[] = "wm_id = -1";
        }
    } else {
        if ($wm = (int) $core->get["wm"]) {
            $param["wm"] = $wm;
            $where[] = "wm_id = '" . $wm . "'";
        } else {
            $wm = false;
        }
    }
    if ($src = (int) $core->get["src"]) {
        $param["src"] = $src;
        $where[] = "ext_src = '" . $src . "'";
    } else {
        $src = false;
    }
    if ($cmp || ($cc = (int) $core->get["c"])) {
        if (!$cmp) {
            $param["c"] = $cc;
        }
        $where[] = $cmp ? "comp_id = '" . $cmp . "'" : "comp_id = '" . $cc . "'";
    } else {
        $cc = false;
    }
    $where = implode(" AND ", $where);
    $oname = $core->cpa->get("offersa");
    $offer = $cmp ? $core->offer->names($core->user->id) : $oname;
    $comps = $core->cpa->get("compa");
    $bc = $bw = $bo = $bg = array();
    $total = $line = array("total" => 0, "wait" => 0, "call" => 0, "hold" => 0, "cancel" => 0, "trash" => 0, "accept" => 0, "ma" => array(), "mc" => array(), "mi" => 0, "mo" => 0);
    $total["name"] = $core->lang["anal_total"];
    $st = 0;
    $sh = 1000;
    while (true) {
        $csd = $core->db->data("SELECT offer_id, wm_id, comp_id, cc_id, order_time, order_status, order_shave, order_reason, order_country, price_total, price_cur, cash_wm, cash_pay, cash_etc FROM " . DB_ORDER . " WHERE " . $where . " LIMIT " . $st . ", " . $sh);
        $oc = $csd ? count($csd) : 0;
        if (!$oc) {
            break;
        }
        foreach ($csd as $c) {
            $ic = (int) $c["comp_id"];
            $iq = (int) $c["cc_id"];
            $iw = (int) $c["wm_id"];
            $io = (int) $c["offer_id"];
            $ig = $c["order_country"];
            if (!isset($bc[$ic])) {
                $bc[$ic] = $line;
                $bc[$ic]["name"] = $comps[$ic];
                $bc[$ic]["u"] = $core->url("m", "order?") . parset($param, "c", $ic);
            }
            if ($iq && !isset($bc[$iq])) {
                $bc[$iq] = $line;
                $bc[$iq]["name"] = $comps[$iq];
                $bc[$iq]["u"] = $core->url("m", "order?") . parset($param, "c", $iq);
            }
            if (!isset($bw[$iw])) {
                $bw[$iw] = $line;
                $bw[$iw]["name"] = $iw ? $cmp ? $iw : $core->user->get($iw, "user_name") : $core->lang["anal_search"];
                $bw[$iw]["u"] = $core->url("m", "order?") . parset($param, "wm", $iw);
            }
            if (!isset($bo[$io])) {
                $bo[$io] = $line;
                $bo[$io]["name"] = $oname[$io];
                $bo[$io]["u"] = $core->url("m", "order?") . parset($param, "o", $io);
            }
            if (!isset($bg[$ig])) {
                $bg[$ig] = $line;
                $bg[$ig]["name"] = $core->lang["country"][$ig];
                $bg[$ig]["u"] = $core->url("m", "order?") . parset($param, "geo", $ig);
            }
            $total["total"] += 1;
            $bc[$ic]["total"] += 1;
            $bw[$iw]["total"] += 1;
            $bo[$io]["total"] += 1;
            $bg[$ig]["total"] += 1;
            if (istrash($c["order_status"], $c["order_reason"])) {
                $total["trash"] += 1;
                $bc[$ic]["trash"] += 1;
                $bw[$iw]["trash"] += 1;
                $bo[$io]["trash"] += 1;
                $bg[$ig]["trash"] += 1;
            } else {
                if ($c["order_status"] == 5) {
                    $total["cancel"] += 1;
                    $bc[$ic]["cancel"] += 1;
                    $bw[$iw]["cancel"] += 1;
                    $bo[$io]["cancel"] += 1;
                    $bg[$ig]["cancel"] += 1;
                } else {
                    if ($c["order_status"] < 3) {
                        $total["wait"] += 1;
                        $bc[$ic]["wait"] += 1;
                        $bw[$iw]["wait"] += 1;
                        $bo[$io]["wait"] += 1;
                        $bg[$ig]["wait"] += 1;
                    } else {
                        if ($c["order_status"] == 3) {
                            $total["call"] += 1;
                            $bc[$ic]["call"] += 1;
                            $bw[$iw]["call"] += 1;
                            $bo[$io]["call"] += 1;
                            $bg[$ig]["call"] += 1;
                        } else {
                            if ($c["order_status"] == 4) {
                                $total["hold"] += 1;
                                $bc[$ic]["hold"] += 1;
                                $bw[$iw]["hold"] += 1;
                                $bo[$io]["hold"] += 1;
                                $bg[$ig]["hold"] += 1;
                            } else {
                                $total["accept"] += 1;
                                $bc[$ic]["accept"] += 1;
                                $bw[$iw]["accept"] += 1;
                                $bo[$io]["accept"] += 1;
                                $bg[$ig]["accept"] += 1;
                                $total["mc"][$c["price_cur"]] += 1;
                                $bc[$ic]["mc"][$c["price_cur"]] += 1;
                                $bw[$iw]["mc"][$c["price_cur"]] += 1;
                                $bo[$io]["mc"][$c["price_cur"]] += 1;
                                $bg[$ig]["mc"][$c["price_cur"]] += 1;
                                $total["ma"][$c["price_cur"]] += $c["price_total"];
                                $bc[$ic]["ma"][$c["price_cur"]] += $c["price_total"];
                                $bw[$iw]["ma"][$c["price_cur"]] += $c["price_total"];
                                $bo[$io]["ma"][$c["price_cur"]] += $c["price_total"];
                                $bg[$ig]["ma"][$c["price_cur"]] += $c["price_total"];
                                $total["mi"] += $c["cash_pay"];
                                $bc[$ic]["mi"] += $c["cash_pay"];
                                $bw[$iw]["mi"] += $c["cash_pay"];
                                $bo[$io]["mi"] += $c["cash_pay"];
                                $bg[$ig]["mi"] += $c["cash_pay"];
                                $total["mo"] += $c["cash_etc"];
                                $bc[$ic]["mo"] += $c["cash_etc"];
                                $bw[$iw]["mo"] += $c["cash_etc"];
                                $bo[$io]["mo"] += $c["cash_etc"];
                                $bg[$ig]["mo"] += $c["cash_etc"];
                                if (!$c["order_shave"]) {
                                    $total["mo"] += $c["cash_wm"];
                                    $bc[$ic]["mo"] += $c["cash_wm"];
                                    $bw[$iw]["mo"] += $c["cash_wm"];
                                    $bo[$io]["mo"] += $c["cash_wm"];
                                    $bg[$ig]["mo"] += $c["cash_wm"];
                                }
                                if ($iq) {
                                    $bc[$iq]["accept"] += 1;
                                    $bc[$iq]["mc"][$c["price_cur"]] += 1;
                                    $bc[$iq]["ma"][$c["price_cur"]] += $c["price_total"];
                                    $bc[$iq]["mi"] += $c["cash_pay"];
                                    $bc[$iq]["mo"] += $c["cash_etc"];
                                    if (!$c["order_shave"]) {
                                        $bc[$iq]["mo"] += $c["cash_wm"];
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if ($oc == $sh) {
            $st += $sh;
        } else {
            break;
        }
    }
    $core->site->bc($core->lang["menu_sub_" . $url] ? $core->lang["menu_sub_" . $url] : $core->lang["menu_" . $url], $core->url("m", $url));
    $core->site->set("select2");
    if ($csv) {
        header("Content-type: text/csv; charset=windows-1251");
        header("Content-disposition: attachment;filename=analytics-orders.csv");
    } else {
        $core->site->header();
    }
    if ($csv) {
        $core->tpl->load("body", "csv-analytics-main");
    } else {
        $core->tpl->load("body", "analytics-main", defined("HACK_TPL_ANALYTICS") ? HACK : false);
    }
    $core->tpl->vars("body", array("descr" => $core->lang["descr"], "who" => $core->lang["anal_who"], "count" => $core->lang["anal_count"], "process" => $core->lang["anal_process"], "wait" => $core->lang["anal_wait"], "call" => $core->lang["anal_call"], "hold" => $core->lang["anal_hold"], "cancel" => $core->lang["anal_cancel"], "trash" => $core->lang["anal_trash"], "accept" => $core->lang["anal_accept"], "bill" => $core->lang["anal_bill"], "mbill" => $core->lang["anal_mbill"], "tbill" => $core->lang["anal_tbill"], "finance" => $core->lang["anal_finance"], "income" => $core->lang["anal_income"], "outcome" => $core->lang["anal_outcome"], "upcome" => $core->lang["anal_upcome"], "from" => date2form($from), "to" => date2form($to), "admin" => $cmp ? false : true, "wm" => $wm, "src" => $src, "lfrom" => $core->lang["anal_from"], "lto" => $core->lang["anal_to"], "offer" => $core->lang["offer"], "comp" => $core->lang["company"], "country" => $core->lang["order_country"], "show" => $core->lang["show"], "noitem" => $core->lang["anal_noitem"], "today" => $core->lang["anal_today"], "yest" => $core->lang["anal_yest"], "day7" => $core->lang["anal_day7"], "day30" => $core->lang["anal_day30"], "day90" => $core->lang["anal_day90"], "u_search" => $core->url("m", $url), "u_csv" => $core->url("m", $url) . "?" . parset($param, "show", "csv"), "u_today" => $core->url("m", $url) . "?" . parmult($param, array("from" => date2form($today), "to" => date2form($today))), "u_yest" => $core->url("m", $url) . "?" . parmult($param, array("from" => date2form($yest), "to" => date2form($yest))), "u_day7" => $core->url("m", $url) . "?" . parmult($param, array("from" => date2form($week1), "to" => date2form($today))), "u_day30" => $core->url("m", $url) . "?" . parmult($param, array("from" => date2form($month), "to" => date2form($today))), "u_day90" => $core->url("m", $url) . "?" . parmult($param, array("from" => date2form($month3), "to" => date2form($today)))));
    foreach ($offer as $i => $of) {
        $core->tpl->block("body", "offer", array("name" => $of, "value" => $i, "select" => $o == $i ? "selected=\"selected\"" : ""));
    }
    foreach ($comps as $i => $of) {
        $core->tpl->block("body", "comp", array("name" => $of, "value" => $i, "select" => $cc == $i ? "selected=\"selected\"" : ""));
    }
    foreach ($core->lang["country"] as $i => $of) {
        $core->tpl->block("body", "country", array("name" => $of, "value" => $i, "select" => $geo == $i ? "selected=\"selected\"" : ""));
    }
    if ($total["total"]) {
        $core->tpl->block("body", "block");
        analyticline($core, $total);
        if (!($cmp || $cc)) {
            usort($bc, "analyticsort");
            $core->tpl->block("body", "block", array("head" => $core->lang["anal_comps"]));
            foreach ($bc as $l) {
                analyticline($core, $l);
            }
        }
        if (!$wm) {
            usort($bw, "analyticsort");
            $core->tpl->block("body", "block", array("head" => $core->lang["anal_users"]));
            foreach ($bw as $l) {
                analyticline($core, $l);
            }
        }
        if (!$o) {
            usort($bo, "analyticsort");
            $core->tpl->block("body", "block", array("head" => $core->lang["anal_offer"]));
            foreach ($bo as $l) {
                analyticline($core, $l);
            }
        }
        if (!$geo) {
            usort($bg, "analyticsort");
            $core->tpl->block("body", "block", array("head" => $core->lang["anal_geo"]));
            foreach ($bg as $l) {
                analyticline($core, $l);
            }
        }
    } else {
        $core->tpl->block("body", "no");
    }
    $core->tpl->output("body", $csv ? "windows-1251" : false);
    if (!$csv) {
        $core->site->footer();
    }
    $core->stop();
}
function analyticsort($a, $b)
{
    return strcmp($a["name"], $b["name"]);
}
function analyticline($core, $l)
{
    $to = $l["wait"] + $l["call"] + $l["hold"] + $l["cancel"] + $l["accept"];
    $ao = defined("HOLDISAPPROVE") ? $l["hold"] + $l["accept"] : $l["accept"];
    $core->tpl->block("body", "block.row", array("name" => $l["name"], "u" => $l["u"], "total" => $l["total"], "wait" => $l["wait"], "call" => $l["call"], "hold" => $l["hold"], "cancel" => $l["cancel"], "cancelper" => sprintf("%0.1f", $to ? $l["cancel"] * 100 / $to : 0), "trash" => $l["trash"], "trashper" => sprintf("%0.1f", $l["total"] ? $l["trash"] * 100 / $l["total"] : 0), "accept" => $l["accept"], "approve" => sprintf("%0.1f", $to ? $ao * 100 / $to : 0), "mi" => $core->currency->money($l["mi"]), "mo" => $core->currency->money($l["mo"]), "mt" => $core->currency->money($l["mi"] - $l["mo"]), "pmi" => round($l["mi"], 2), "pmo" => round($l["mi"], 2), "pmt" => round($l["mo"], 2)));
    ksort($l["mc"]);
    foreach ($l["mc"] as $cu => $cc) {
        if ($l["ma"][$cu]) {
            $core->tpl->block("body", "block.row.mn", array("c" => $core->currency->code($cu), "m" => ceil($l["ma"][$cu] / $cc), "t" => round($l["ma"][$cu], 2)));
        }
    }
}

?>