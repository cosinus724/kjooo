<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function admin_offer_prices($core, $id)
{
    $action = isset($core->get["action"]) ? $core->text->link($core->get["action"]) : NULL;
    $id = isset($core->get["id"]) ? (int) $core->get["id"] : 0;
    switch ($action) {
        case "add":
            $data = array("offer_id" => $id, "price_name" => $core->text->line($core->post["name"]));
            if ($core->db->add(DB_PRICE, $data)) {
                $pid = $core->db->lastid();
                $core->go($core->url("i", "offer-price", $pid));
            } else {
                $core->go($core->url("im", "offer-prices", $id, "add-e"));
            }
        case "sort":
            $srt = explode(",", $core->get["srt"]);
            foreach ($srt as $i => $s) {
                $core->db->edit(DB_PRICE, array("price_sort" => (int) $i), "price_id = '" . $s . "'");
            }
            $core->cpa->clear("prices", $id);
            $core->uncache("offer.price" . $id);
            $core->go($core->url("im", "offer-prices", $id, "edit-ok"));
    }
    $message = isset($core->get["message"]) ? $core->text->link($core->get["message"]) : NULL;
    switch ($message) {
        case "add-ok":
            $core->site->info("info", "done_add");
            break;
        case "edit-ok":
            $core->site->info("info", "done_edit");
            break;
        case "del-ok":
            $core->site->info("info", "done_del");
            break;
        case "add-e":
            $core->site->info("error", "error_add");
            break;
        case "edit-e":
            $core->site->info("error", "error_edit");
            break;
        case "del-e":
            $core->site->info("error", "error_del");
            break;
    }
    $core->site->bc($core->lang["offers_h"], $core->url("m", "offer"));
    $core->site->bc(sprintf($core->lang["offer_prices_h"], $core->cpa->get("offersa", 0, $id)));
    $core->site->js("jquery");
    $core->site->js("jquery-sortable");
    $core->site->header();
    $core->tpl->load("body", "price", defined("HACK_TPL_PRICE") ? HACK : false);
    $core->tpl->vars("body", array("title" => sprintf($core->lang["offer_prices_h"], $core->cpa->get("offersa", 0, $id)), "text" => $core->text->lines($core->lang["offer_prices_t"]), "u_sort" => $core->url("ia", "offer-prices", $id, "sort") . "&srt=", "u_add" => $core->url("ia", "offer-prices", $id, "add"), "add" => $core->lang["add"], "name" => $core->lang["name"], "edit" => $core->lang["edit"], "del" => $core->lang["del"], "confirm" => $core->lang["confirm"], "cond" => $core->lang["price_line_cond"], "pay" => $core->lang["price_line_pay"], "final" => $core->lang["price_line_final"], "partner" => $core->lang["price_line_partner"], "comp" => $core->lang["price_line_comp"]));
    $pr = $core->cpa->get("prices", $id);
    $ins = array("any", "vip", "ext", "prt");
    $inp = array("user", "star", "users", "user-secret");
    $ous = array("cm", "cc");
    $oup = array("building", "phone");
    if ($pr) {
        foreach ($pr as $p) {
            if ($p["price_geo"]) {
                $geo = explode(",", $p["price_geo"]);
                $geo = "<img src=\"/core/images/flag/" . implode(".png\" /> <img src=\"/core/images/flag/", $geo) . ".png\" />";
            } else {
                $geo = false;
            }
            if (!$p["price_inid"]) {
                $inv = $core->lang["price_in_" . $ins[$p["price_in"]]];
            } else {
                $inv = $core->user->get($p["price_inid"], "user_name");
            }
            if (!$p["price_outid"]) {
                $outv = $core->lang["price_out_" . $ous[$p["price_out"]]];
            } else {
                $outv = $core->user->get($p["price_outid"], "user_name");
            }
            $cur = $p["price_cur"] ? $core->currency->id($p["price_cur"]) : NULL;
            if ($p["wmset"]) {
                $wm = array();
                $wu = isset($cur) ? $core->currency->show($p["wmup"], $cur) : $core->currency->prnt($p["wmup"]);
                $wx = isset($cur) ? $core->currency->show($p["wmxs"], $cur) : $core->currency->prnt($p["wmxs"]);
                if (0 < $p["wmper"]) {
                    $wm[] = sprintf("%0.2f%%", $p["wmper"]);
                }
                if (0 < $p["wm"]) {
                    $wm[] = isset($cur) ? $core->currency->show($p["wm"], $cur) : $core->currency->prnt($p["wm"]);
                }
                if (0 < $p["wmup"]) {
                    $wm[] = $p["wmlim"] ? sprintf($core->lang["price_line_upl"], $wu, $p["wmlim"]) : sprintf($core->lang["price_line_up"], $wu);
                }
                if (0 < $p["wmxs"]) {
                    $wm[] = $p["wmxl"] ? sprintf($core->lang["price_line_xsl"], $wx, $p["wmxl"]) : sprintf($core->lang["price_line_xs"], $wx);
                }
                $wm = $wm ? implode(" + ", $wm) : $core->lang["price_line_null"];
            } else {
                $wm = false;
            }
            if ($p["payset"]) {
                $pay = array();
                $pu = isset($cur) ? $core->currency->show($p["payup"], $cur) : $core->currency->prnt($p["payup"]);
                $px = isset($cur) ? $core->currency->show($p["payxs"], $cur) : $core->currency->prnt($p["payxs"]);
                if (0 < $p["payper"]) {
                    $pay[] = sprintf("%0.2f%%", $p["payper"]);
                }
                if (0 < $p["pay"]) {
                    $pay[] = isset($cur) ? $core->currency->show($p["pay"], $cur) : $core->currency->prnt($p["pay"]);
                }
                if (0 < $p["payup"]) {
                    $pay[] = $p["paylim"] ? sprintf($core->lang["price_line_upl"], $pu, $p["paylim"]) : sprintf($core->lang["price_line_up"], $pu);
                }
                if (0 < $p["payxs"]) {
                    $pay[] = $p["payxl"] ? sprintf($core->lang["price_line_xsl"], $px, $p["payxl"]) : sprintf($core->lang["price_line_xs"], $px);
                }
                $pay = $pay ? implode(" + ", $pay) : $core->lang["price_line_null"];
            } else {
                $pay = false;
            }
            if ($p["parset"]) {
                $partner = array();
                if (0 < $p["partper"]) {
                    $partner[] = sprintf("%0.2f%%", $p["partper"]);
                }
                if (0 < $p["partner"]) {
                    $partner[] = isset($cur) ? $core->currency->show($p["partner"], $cur) : $core->currency->prnt($p["partner"]);
                }
                $partner = $partner ? implode(" + ", $partner) : $core->lang["price_line_null"];
            } else {
                $partner = false;
            }
            if ($p["price_in"] == 2) {
                $wmn = $core->lang["price_line_ext"];
            } else {
                if ($p["price_out"]) {
                    $wmn = $core->lang["price_line_cc"];
                } else {
                    $wmn = $core->lang["price_line_wm"];
                }
            }
            $core->tpl->block("body", "price", array("id" => $p["price_id"], "name" => $p["price_name"], "pub" => $p["price_pub"] ? "isok" : "", "inc" => $p["price_in"], "ini" => $p["price_inid"], "inv" => $inv, "inp" => $inp[$p["price_in"]], "outc" => $p["price_out"], "outi" => $p["price_outid"], "outv" => $outv, "outp" => $oup[$p["price_out"]], "geo" => $geo, "mobile" => $p["price_mobile"] ? $core->lang["price_mobile_s"][$p["price_mobile"]] : false, "promo" => $p["price_promo"] ? $core->lang["price_promo_s"][$p["price_promo"]] : false, "deliv" => $p["price_deliv"] ? $core->lang["price_deliv_s"][$p["price_deliv"]] : false, "bad" => $p["price_bad"] ? $core->lang["price_bad_s"][$p["price_bad"]] : false, "last" => $p["price_last"], "wmn" => $wmn, "wm" => $wm, "pay" => $pay, "partner" => $partner, "edit" => $core->url("i", "offer-price", $p["price_id"]), "del" => $core->url("ia", "offer-price", $p["price_id"], "del")));
        }
    } else {
        $core->tpl->block("body", "noitems");
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}
function admin_offer_price($core, $id)
{
    $action = isset($core->get["action"]) ? $core->text->link($core->get["action"]) : NULL;
    switch ($action) {
        case "edit":
            $in = $core->text->link($core->post["in"]);
            $intp = substr($in, 0, 3);
            $inid = (int) substr($in, 3);
            switch ($intp) {
                case "prt":
                    $in = 3;
                    break;
                case "ext":
                    $in = 2;
                    break;
                case "vip":
                    $in = 1;
                    break;
                default:
                    $in = 0;
            }
            $out = $core->text->link($core->post["out"]);
            $outtp = substr($out, 0, 2);
            $outid = (int) substr($out, 2);
            switch ($outtp) {
                case "cc":
                    $out = 1;
                    break;
                case "cm":
                    $out = 0;
                    break;
                default:
                    $out = 0;
            }
            $wmid = array();
            $wmls = explode(",", $core->post["wmid"]);
            foreach ($wmls as $w) {
                if ($w = trim($w)) {
                    $wmid[] = $w;
                }
            }
            $data = array("price_name" => $core->text->line($core->post["name"]), "price_in" => $in, "price_inid" => $inid, "price_out" => $out, "price_outid" => $outid, "price_mobile" => (int) $core->post["mobile"], "price_bad" => (int) $core->post["bad"], "price_promo" => (int) $core->post["promo"], "price_deliv" => (int) $core->post["deliv"], "price_geo" => $core->text->codeline($core->post["geo"]), "price_wmid" => $wmid ? implode(",", $wmid) : false, "price_last" => $core->post["last"] ? 1 : 0, "price_cur" => $core->text->link($core->post["cur"]), "wmset" => $core->post["wmset"] ? 1 : 0, "wm" => $core->text->float($core->post["wm"]), "wmup" => $core->text->float($core->post["wmup"]), "wmlim" => (int) $core->post["wmlim"], "wmxs" => $core->text->float($core->post["wmxs"]), "wmxl" => (int) $core->post["wmxl"], "wmper" => $core->text->float($core->post["wmper"]), "payset" => $core->post["payset"] ? 1 : 0, "pay" => $core->text->float($core->post["pay"]), "payup" => $core->text->float($core->post["payup"]), "paylim" => (int) $core->post["paylim"], "payxs" => $core->text->float($core->post["payxs"]), "payxl" => (int) $core->post["payxl"], "payper" => $core->text->float($core->post["payper"]), "parset" => $core->post["parset"] ? 1 : 0, "partner" => $core->text->float($core->post["partner"]), "partper" => $core->text->float($core->post["partper"]));
            if ($core->db->edit(DB_PRICE, $data, "price_id = '" . $id . "'")) {
                $oid = $core->db->field("SELECT offer_id FROM " . DB_PRICE . " WHERE price_id = '" . $id . "' LIMIT 1");
                $core->cpa->clear("offer", $oid);
                $core->cpa->clear("prices", $oid);
                $core->uncache("offer.price" . $oid);
                $core->go($core->url("im", "offer-prices", $oid, "edit-ok"));
            } else {
                $core->go($core->url("im", "offer-prices", $oid, "edit-e"));
            }
        case "del":
            $oid = $core->db->field("SELECT offer_id FROM " . DB_PRICE . " WHERE price_id = '" . $id . "' LIMIT 1");
            $core->db->del(DB_PRICE, "price_id = '" . $id . "'");
            $core->cpa->clear("offer", $oid);
            $core->cpa->clear("prices", $oid);
            $core->uncache("offer.price" . $oid);
            $core->go($core->url("im", "offer-prices", $oid, "del-ok"));
    }
    $p = $core->db->row("SELECT * FROM " . DB_PRICE . " WHERE price_id = '" . $id . "' LIMIT 1");
    $ins = array("any", "vip", "ext", "prt");
    $iv = $ins[$p["price_in"]] . $p["price_inid"];
    $in = array(array("value" => "any0", "name" => $core->lang["price_in_any"], "select" => $iv == "any0"), array("value" => "vip0", "name" => $core->lang["price_in_vip"], "select" => $iv == "vip0"));
    $vips = $core->db->icol("SELECT user_id, user_name FROM " . DB_USER . " WHERE user_vip = 1 ORDER BY user_name ASC");
    foreach ($vips as $v => $n) {
        $in[] = array("value" => "vip" . $v, "name" => "&mdash; " . $n, "select" => $iv == "vip" . $v);
    }
    $in[] = array("value" => "ext0", "name" => $core->lang["price_in_ext"], "select" => $iv == "ext0");
    $exts = $core->cpa->get("exts");
    foreach ($exts as $v => $n) {
        if ($q = $core->cpa->get("ext", $v, "user_id")) {
            $in[] = array("value" => "ext" . $q, "name" => "&mdash; " . $n, "select" => $iv == "ext" . $q);
        }
    }
    $in[] = array("value" => "prt0", "name" => $core->lang["price_in_prt"], "select" => $iv == "prt0");
    foreach ($vips as $v => $n) {
        $in[] = array("value" => "prt" . $v, "name" => "&mdash; " . $n, "select" => $iv == "prt" . $v);
    }
    $ous = array("cm", "cc");
    $ov = $ous[$p["price_out"]] . $p["price_outid"];
    $out = array(array("value" => "cm0", "name" => $core->lang["price_out_cm"], "select" => $ov == "cm0"));
    $comps = $core->cpa->get("comps");
    foreach ($comps as $v => $n) {
        if ($q = $core->cpa->get("comp", $v, "user_id")) {
            $out[] = array("value" => "cm" . $q, "name" => "&mdash; " . $n, "select" => $ov == "cm" . $q);
        }
    }
    $out[] = array("value" => "cc0", "name" => $core->lang["price_out_cc"], "select" => $ov == "cc0");
    $ccs = $core->cpa->get("ccs");
    foreach ($ccs as $v => $n) {
        if ($q = $core->cpa->get("comp", $v, "user_id")) {
            $out[] = array("value" => "cc" . $q, "name" => "&mdash; " . $n, "select" => $ov == "cc" . $q);
        }
    }
    $core->site->bc($core->lang["offers_h"], $core->url("m", "offer"));
    $core->site->bc($core->cpa->get("offersa", 0, $p["offer_id"]), $core->url("i", "offer-prices", $p["offer_id"]));
    $core->site->set("select2");
    $core->site->header();
    $curs = array("" => $core->lang["price_cur_def"]);
    foreach ($core->currency->codes as $ci => $cn) {
        $curs[$ci] = $cn;
    }
    $field = array(array("type" => "text", "length" => 100, "name" => "name", "head" => $core->lang["name"], "descr" => $core->lang["price_name_d"], "value" => $p["price_name"]), array("type" => "head", "value" => $core->lang["price_conditions"]), array("type" => "select", "name" => "in", "head" => $core->lang["price_in"], "descr" => $core->lang["price_in_d"], "value" => $in), array("type" => "select", "name" => "out", "head" => $core->lang["price_out"], "descr" => $core->lang["price_out_d"], "value" => $out), array("type" => "select", "name" => "mobile", "head" => $core->lang["price_mobile"], "descr" => $core->lang["price_mobile_d"], "value" => $p["price_mobile"], "options" => $core->lang["price_mobile_s"]), array("type" => "select", "name" => "bad", "head" => $core->lang["price_bad"], "descr" => $core->lang["price_bad_d"], "value" => $p["price_bad"], "options" => $core->lang["price_bad_s"]), array("type" => "select", "name" => "promo", "head" => $core->lang["price_promo"], "descr" => $core->lang["price_promo_d"], "value" => $p["price_promo"], "options" => $core->lang["price_promo_s"]), array("type" => "select", "name" => "deliv", "head" => $core->lang["price_deliv"], "descr" => $core->lang["price_deliv_d"], "value" => $p["price_deliv"], "options" => $core->lang["price_deliv_s"]), array("type" => "mselect", "name" => "geo", "head" => $core->lang["price_geo"], "descr" => $core->lang["price_geo_d"], "value" => $p["price_geo"], "options" => $core->lang["country"]), array("type" => "text", "length" => 100, "name" => "wmid", "head" => $core->lang["price_wmid"], "descr" => $core->lang["price_wmid_d"], "value" => $p["price_wmid"]), array("type" => "select", "name" => "cur", "head" => $core->lang["currency"], "value" => $p["price_cur"], "options" => $curs), array("type" => "checkbox", "name" => "last", "head" => $core->lang["price_last"], "descr" => $core->lang["price_last_d"], "checked" => $p["price_last"]), array("type" => "head", "value" => $core->lang["price_pay"]), array("type" => "line", "value" => $core->text->lines($core->lang["price_pay_d"])), array("type" => "checkbox", "name" => "payset", "head" => $core->lang["price_set"], "descr" => $core->lang["price_set_d"], "checked" => $p["payset"]), array("type" => "number", "step" => 0.01, "min" => 0, "name" => "pay", "head" => $core->lang["price_sum"], "descr" => $core->lang["price_sum_d"], "value" => $p["pay"]), array("type" => "number", "step" => 0.01, "min" => 0, "name" => "payup", "head" => $core->lang["price_up"], "descr" => $core->lang["price_up_d"], "value" => $p["payup"]), array("type" => "number", "name" => "paylim", "head" => $core->lang["price_lim"], "descr" => $core->lang["price_lim_d"], "value" => $p["paylim"]), array("type" => "number", "step" => 0.01, "min" => 0, "name" => "payxs", "head" => $core->lang["price_xs"], "descr" => $core->lang["price_xs_d"], "value" => $p["payxs"]), array("type" => "number", "name" => "payxl", "head" => $core->lang["price_xl"], "descr" => $core->lang["price_xl_d"], "value" => $p["payxl"]), array("type" => "number", "step" => 0.01, "min" => 0, "max" => 0, "name" => "payper", "head" => $core->lang["price_per"], "descr" => $core->lang["price_per_d"], "value" => $p["payper"]), array("type" => "head", "value" => $core->lang["price_wm"]), array("type" => "line", "value" => $core->text->lines($core->lang["price_wm_d"])), array("type" => "checkbox", "name" => "wmset", "head" => $core->lang["price_set"], "descr" => $core->lang["price_set_d"], "checked" => $p["wmset"]), array("type" => "number", "step" => 0.01, "name" => "wm", "head" => $core->lang["price_sum"], "descr" => $core->lang["price_sum_d"], "value" => $p["wm"]), array("type" => "number", "step" => 0.01, "name" => "wmup", "head" => $core->lang["price_up"], "descr" => $core->lang["price_up_d"], "value" => $p["wmup"]), array("type" => "number", "name" => "wmlim", "head" => $core->lang["price_lim"], "descr" => $core->lang["price_lim_d"], "value" => $p["wmlim"]), array("type" => "number", "step" => 0.01, "name" => "wmxs", "head" => $core->lang["price_xs"], "descr" => $core->lang["price_xs_d"], "value" => $p["wmxs"]), array("type" => "number", "name" => "wmxl", "head" => $core->lang["price_xl"], "descr" => $core->lang["price_xl_d"], "value" => $p["wmxl"]), array("type" => "number", "step" => 0.01, "min" => 0, "max" => 0, "name" => "wmper", "head" => $core->lang["price_per"], "descr" => $core->lang["price_per_d"], "value" => $p["wmper"]), array("type" => "head", "value" => $core->lang["price_part"]), array("type" => "line", "value" => $core->text->lines($core->lang["price_part_d"])), array("type" => "checkbox", "name" => "parset", "head" => $core->lang["price_set"], "descr" => $core->lang["price_set_d"], "checked" => $p["parset"]), array("type" => "number", "step" => 0.01, "name" => "partner", "head" => $core->lang["price_sum"], "descr" => $core->lang["price_sum_d"], "value" => $p["partner"]), array("type" => "number", "step" => 0.01, "min" => 0, "max" => 0, "name" => "partper", "head" => $core->lang["price_per"], "descr" => $core->lang["price_per_d"], "value" => $p["partper"]));
    $core->site->form("oprice", $core->url("ia", "offer-price", $id, "edit"), $core->lang["offer_price_edit_h"], $field);
    $core->site->footer();
    $core->stop();
}

?>