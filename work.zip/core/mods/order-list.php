<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function order_counts($core)
{
    $c = $core->user->comp;
    if (!$c) {
        return false;
    }
    $tm = time();
    $mt = $tm - 60;
    $u = $core->user->id;
    $a = $core->cpa->team();
    $ofl = $a["offer"] ? " AND offer_id IN ( " . implode(",", $a["offer"]) . " )" : "";
    $stl = array();
    if ($a["mod"] || $a["admin"] || $a["root"] || $a["call"] == 1 || $a["call"] == 2 || $a["call"] == 3 || $a["call"] == 4 || $a["call"] == 5) {
        $stl[] = 1;
    }
    if ($a["mod"] || $a["admin"] || $a["root"] || $a["call"] == 1 || $a["call"] == 2 || $a["call"] == 3 || $a["call"] == 4 || $a["call"] == 5) {
        $stl[] = 2;
    }
    if ($a["mod"] || $a["admin"] || $a["root"] || $a["call"] == 1 || $a["call"] == 2 || $a["call"] == 3 || $a["call"] == 4 || $a["call"] == 6) {
        $stl[] = 3;
    }
    if ($a["call"] == 2 || $a["call"] == 4 || $a["call"] == 7) {
        $stl[] = 4;
    }
    if ($a["mod"] || $a["admin"] || $a["root"] || $a["pack"] == 2) {
        $stl[] = 6;
    }
    if ($a["mod"] || $a["admin"] || $a["root"] || $a["send"] == 2) {
        $stl[] = 7;
    }
    if ($a["mod"] || $a["admin"] || $a["root"] || $a["delivery"] == 2) {
        $stl[] = 9;
    }
    $stl = $stl ? implode(",", $stl) : false;
    $oc = $stl ? $core->db->icol("SELECT order_status, COUNT(*) FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND order_status IN ( " . $stl . " ) AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) GROUP BY order_status") : array();
    if ($a["mod"] || $a["admin"] || $a["root"] || $a["delivery"] == 2) {
        $twc = $core->db->field("SELECT COUNT(*) FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND order_status = 8 AND track_warn = 1 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' )");
        if ($twc) {
            $oc[8] = $twc;
        }
    }
    $ot = array_sum($oc);
    if ($ot) {
        $os = array();
        foreach ($oc as $o => $c) {
            if ($c) {
                $os[] = numinf($core->lang["ordercount" . $o], $c);
            }
        }
        $os = implode(" ", $os);
    } else {
        $os = $core->lang["ordercount0"];
    }
    return array("counts" => $oc, "line" => $os, "total" => $ot);
}
function order_module_list($core, $page)
{
    $teamauth = $core->cpa->team();
    $action = $core->post["action"] ? $core->text->link($core->post["action"]) : $core->text->link($core->get["action"]);
    if ($action) {
        switch ($action) {
            case "notify":
                $tm = time();
                $prev = (int) $core->get["prev"];
                if ($core->user->comp) {
                    echo json_encode(array("previous" => $tm, "ords" => $core->db->field("SELECT COUNT(*) FROM " . DB_ORDER . " WHERE order_status = 1 AND order_time >= '" . $prev . "' AND comp_id = '" . $core->user->comp . "'"), "recs" => $core->db->field("SELECT COUNT(*) FROM " . DB_ORDER . " WHERE order_status IN ( 3, 4 ) AND order_recall BETWEEN '" . $prev . "' AND '" . $tm . "' AND comp_id = '" . $core->user->comp . "'")));
                } else {
                    echo "false";
                }
                $core->stop();
            case "callcount":
                echo json_encode(order_counts($core));
                $core->stop();
            case "bulk":
                if ($core->post["move"] && ($core->user->work == 2 || $core->user->level)) {
                    $ids = array();
                    foreach ($_POST["ids"] as $i) {
                        if ($i = (int) $i) {
                            $ids[] = $i;
                        }
                    }
                    if (!$ids) {
                        msgo($core, "error");
                    }
                    $idsl = implode(",", $ids);
                    $sc = (int) $core->post["sc"];
                    $rs = $core->post["rs"] ? 1 : 0;
                    $mc = $core->post["mc"] ? 1 : 0;
                    if ($mc && $sc) {
                        $uid = $core->cpa->get("comp", $sc, "user_id");
                        if (!$uid) {
                            msgo($core, "error");
                        }
                        $utr = array($uid);
                        $ctr = $core->db->col("SELECT comp_id FROM " . DB_ORDER . " WHERE order_id IN ( " . $idsl . " )");
                        $ctr = array_unique($ctr);
                        foreach ($ctr as $cc) {
                            if ($uu = $core->cpa->get("comp", $cc, "user_id")) {
                                $utr[] = $u;
                            }
                        }
                        $core->db->query("UPDATE " . DB_ORDER . " SET comp_id = " . $sc . " WHERE order_id IN ( " . $idsl . " )");
                        $core->db->query("UPDATE " . DB_CALL . " SET comp_id = " . $sc . " WHERE order_id IN ( " . $idsl . " )");
                        $core->db->query("UPDATE " . DB_CHANGE . " SET user_id = " . $uid . " WHERE order_id IN ( " . $idsl . " ) AND user_id != 0");
                        $core->db->query("UPDATE " . DB_CASH . " SET user_id = " . $uid . " WHERE order_id IN ( " . $idsl . " ) AND cash_type = 2");
                        if ($rs) {
                            $core->db->query("UPDATE " . DB_ORDER . " SET ext_oid = 0, ext_check = 0 WHERE order_id IN ( " . $idsl . " )");
                        }
                        require_once PATH_LIB . "finance.php";
                        $f = new Finance($core);
                        foreach ($utr as $u) {
                            $f->recount($u);
                        }
                    } else {
                        if ($rs) {
                            if ($sc) {
                                $core->db->query("UPDATE " . DB_ORDER . " SET comp_id = " . $sc . ", user_id = 0, order_status = 1, order_webstat = 1, order_reason = 0, ext_oid = 0 WHERE order_id IN ( " . $idsl . " )");
                            } else {
                                $core->db->query("UPDATE " . DB_ORDER . " SET order_status = 1, user_id = 0, order_webstat = 1, order_reason = 0, ext_oid = 0 WHERE order_id IN ( " . $idsl . " )");
                            }
                        } else {
                            if ($sc) {
                                $core->db->query("UPDATE " . DB_ORDER . " SET comp_id = " . $sc . " WHERE order_id IN ( " . $idsl . " )");
                            }
                        }
                    }
                } else {
                    $st = $core->text->link($_POST["status"]);
                    if ($st == "accept") {
                        $ch = array("accept" => 1);
                    } else {
                        if (substr($st, 0, 6) == "status") {
                            $st = (int) substr($st, 6);
                            $ch = array("status" => $st);
                        } else {
                            if (substr($st, 0, 6) == "cancel") {
                                $st = (int) substr($st, 6);
                                $ch = array("status" => 5, "reason" => $st);
                            } else {
                                msgo($core, "error");
                            }
                        }
                    }
                    require_once PATH_MODS . "order-edit.php";
                    foreach ($_POST["ids"] as $i) {
                        if ($i = (int) $i) {
                            order_edit($core, $i, $ch);
                        }
                    }
                }
                msgo($core, "save");
        }
    }
    $where = $param = array();
    if ($core->user->level) {
        if ($c = (int) $core->get["c"]) {
            $param["c"] = $c;
            $where[] = "comp_id = '" . $c . "'";
        } else {
            $c = false;
        }
    } else {
        if ($core->cpa->get("comp", $core->user->comp, "comp_type")) {
            $where[] = "( comp_id = '" . $core->user->comp . "' OR cc_id = '" . $core->user->comp . "' )";
        } else {
            $where[] = "comp_id = '" . $core->user->comp . "'";
        }
        $manager = $core->cpa->get("mans", $core->user->comp);
    }
    if (isset($core->get["wm"]) && $core->get["wm"] != "") {
        $wm = (int) $core->get["wm"];
        $param["wm"] = $wm;
        $where[] = "wm_id = '" . $wm . "'";
    } else {
        $wm = NULL;
    }
    if ($src = $core->text->link($core->get["src"])) {
        $param["src"] = $src;
        $where[] = "ext_src = '" . $src . "'";
    }
    if ($geo = $core->text->link($core->get["geo"])) {
        $param["geo"] = $geo;
        $where[] = "order_country = '" . $geo . "'";
    }
    if (isset($core->get["s"]) && $core->get["s"]) {
        $s = $core->text->line($core->get["s"]);
        if (preg_match("#^([0-9]+)\\.([0-9]+)\\.([0-9]+)\\.([0-9]+)\$#i", $s) && ($ips = ip2int($s))) {
            $where[] = " order_ip = '" . $ips . "' ";
        } else {
            if (preg_match("#^[0-9]{11}\$#i", $s)) {
                $where[] = " order_phone = '" . $s . "' ";
            } else {
                if (is_numeric($core->get["s"]) && ($oid = (int) $core->get["s"])) {
                    $oid = $core->db->field("SELECT order_id FROM " . DB_ORDER . " WHERE order_id = '" . $oid . "' LIMIT 1");
                    if ($oid) {
                        $core->go($core->url("i", "order", $oid));
                    }
                }
                require_once PATH_CORE . "search.php";
                $search = new SearchWords($core->get["s"]);
                if ($s = $search->get()) {
                    $where[] = "(" . $search->field(array("order_name", "order_phone", "order_addr", "order_street", "order_city", "order_area", "ext_uid", "ext_oid")) . ")";
                } else {
                    $s = false;
                }
            }
        }
        $param["s"] = $s;
    } else {
        $s = false;
    }
    if ($o = (int) $core->get["o"]) {
        $param["o"] = $o;
        $where[] = "offer_id = '" . $o . "'";
    }
    if ($from = $core->get["from"]) {
        $dd = explode("-", $from);
        $ds = mktime(0, 0, 0, $dd[1], $dd[2], $dd[0]);
        $param["from"] = $from;
        $where[] = "order_time > '" . $ds . "'";
    } else {
        $from = false;
    }
    if ($to = $core->get["to"]) {
        $dd = explode("-", $to);
        $de = mktime(23, 59, 59, $dd[1], $dd[2], $dd[0]);
        $param["to"] = $to;
        $where[] = "order_time < '" . $de . "'";
    } else {
        $to = false;
    }
    if (isset($core->get["f"]) && $core->get["f"] != "") {
        $f = (int) $core->get["f"];
        $param["f"] = $f;
    } else {
        $fs = array();
        if ($teamauth["call"]) {
            switch ($teamauth["call"]) {
                case 6:
                    $fs[] = 3;
                    break;
                case 7:
                    $fs[] = 4;
                    break;
                default:
                    $fs[] = 100;
            }
        }
        if ($teamauth["pack"]) {
            $fs[] = 6;
        }
        if ($teamauth["send"]) {
            $fs[] = 7;
        }
        if ($teamauth["delivery"]) {
            $fs[] = 101;
        }
        $f = count($fs) == 1 ? $fs[0] : -1;
    }
    if ($f != "") {
        if (99 < $f || $f < 0) {
            switch ($f) {
                case 100:
                    $where[] = "order_status > 0 AND order_status < 6";
                    break;
                case 101:
                    $where[] = "order_status IN ( 8, 9 )";
                    break;
                case 102:
                    $where[] = "order_check = 1";
                    break;
                case 103:
                    $where[] = "order_status = 10 AND promo_code != 0 AND promo_status = 0";
                    break;
            }
        } else {
            $where[] = "order_status = '" . $f . "'";
        }
    }
    if ($sg = (int) $core->get["sg"]) {
        $param["sg"] = $sg;
        $where[] = "order_stage = '" . $sg . "'";
    } else {
        $sg = false;
    }
    if ($core->cando("order_list_param")) {
        $param = $core->filter("order_list_param", $param);
    }
    if ($core->cando("order_list_where")) {
        $where = $core->filter("order_list_where", $where, $param);
    }
    $where = count($where) ? " WHERE " . implode(" AND ", $where) : "";
    $sh = 20;
    $csv = $core->get["mode"] == "csv" ? 1 : 0;
    if (!$csv) {
        $st = $sh * ($page - 1);
        $orders = $core->db->field("SELECT COUNT(*) FROM " . DB_ORDER . $where);
        $order = $orders ? $core->db->data("SELECT * FROM " . DB_ORDER . " " . $where . " ORDER BY order_status ASC, order_id DESC LIMIT " . $st . ", " . $sh) : false;
    } else {
        $order = $core->db->data("SELECT * FROM " . DB_ORDER . " " . $where . " ORDER BY order_status ASC, order_time DESC");
    }
    $company = $core->user->comp ? $core->cpa->get("comp", $core->user->comp) : false;
    $oname = $core->cpa->get("offersa");
    $offer = $core->user->level || $core->user->work == 2 ? $oname : $core->offer->names($core->user->id);
    $vars = array();
    $core->site->bc($core->lang["orders_h"], $core->url("m", "order"));
    $core->site->set("select2");
    if (!$csv) {
        $core->site->header();
    }
    $core->tpl->load("body", $csv ? "csv-orders" : "orders", defined("HACK_TPL_ORDERS") ? HACK : false);
    $core->tpl->vars("body", array("offer" => $core->lang["offer"], "phone" => $core->lang["phone"], "name" => $core->lang["username"], "company" => $core->lang["company"], "address" => $core->lang["address"], "time" => $core->lang["time"], "price" => $core->lang["price"], "status" => $core->lang["status"], "action" => $core->lang["action"], "pay" => $core->lang["pay"], "edit" => $core->lang["edit"], "del" => $core->lang["del"], "date" => $core->lang["date"], "save" => $core->lang["save"], "confirm" => $core->lang["confirma"], "packed" => $core->lang["order_packed"], "track_code" => $core->lang["track_code"], "track_send" => $core->lang["track_send"], "track_confirm" => $core->lang["track_confirm"], "info" => $core->lang["inf"], "noitems" => $core->lang["noitems"], "work" => $core->lang["order_work"], "pack" => $core->lang["order_pack"], "accept" => $core->lang["order_accept"], "acceptit" => $core->lang["accept"], "cancel" => $core->lang["order_cancel"], "later" => $core->lang["order_later"], "showall" => $core->lang["order_showall"], "nextcall" => $core->lang["log_next"], "pickup" => $core->lang["order_pick_up"], "pickupany" => $core->lang["order_pick_smth"], "pick_confirm" => $core->lang["order_pick_confirm"], "o_pickup" => $core->lang["order_pick_up_smth"], "promo_accept" => $core->lang["promo_accept"], "promo_decline" => $core->lang["promo_decline"], "promo_confirma" => $core->lang["promo_confirma"], "promo_confirmd" => $core->lang["promo_confirmd"], "u_check" => $core->url("ma", "order", "callcount"), "u_pickup" => $core->url("ma", "order", "pickup"), "u_csv" => $core->url("m", "?") . parset($param, "mode", "csv"), "u_bulk" => $core->url("ma", "order", "bulk"), "move" => $core->user->work == 2 || $core->user->level ? $core->lang["order_move"] : false, "move_rs" => $core->lang["order_move_rs"], "move_mc" => $core->lang["order_move_mc"], "isadm" => $core->user->level || $core->user->work == 2 ? 1 : 0, "isca" => $core->user->level || $core->user->work == 2 || $core->user->compad ? 1 : 0, "filter" => $core->lang["filter"], "search" => $core->lang["search"], "find" => $core->lang["find"], "from" => $from, "to" => $to, "s" => $search ? $search->get() : $s, "wm" => $param["wm"], "src" => $param["src"], "geo" => $param["geo"], "f" => $param["f"], "sg" => $param["sg"], "pages" => pages($core->url("m", "?") . http_build_query($param), $orders, $sh, $page, sprintf($core->lang["shown"], $st + 1, min($st + $sh, $orders), $orders)), "shown" => sprintf($core->lang["shown"], $st + 1, min($st + $sh, $orders), $orders)));
    foreach ($param as $i => $pv) {
        $core->tpl->vars("body", array("param_" . $i => $pv));
    }
    if ($core->user->work < 2) {
        $teamauth = $core->cpa->team();
        if ($teamauth["root"] || $teamauth["admin"] || $teamauth["mod"] || $teamauth["call"] || $teamauth["pack"] || $teamauth["send"] || $teamauth["delivery"]) {
            $core->tpl->block("body", "pickitup", order_counts($core));
        }
    }
    foreach ($core->lang["statuso"] as $i => $st) {
        $core->tpl->block("body", "status", array("id" => $i, "name" => $st, "value" => $i, "select" => $f != "" && $f == $i ? "selected=\"selected\"" : ""));
    }
    foreach ($core->lang["statusl"] as $i => $st) {
        $core->tpl->block("body", "statuslist", array("id" => $i, "name" => $st, "url" => $core->url("m", "order?") . parset($param, "f", $i), "cls" => $f == $i ? "fat" : ""));
    }
    $comp = $core->cpa->get("compa");
    if ($core->user->level) {
        $core->tpl->block("body", "comps");
        foreach ($comp as $ci => $cn) {
            $core->tpl->block("body", "comps.c", array("name" => $cn, "value" => $ci, "select" => $c == $ci ? "selected=\"selected\"" : ""));
        }
    }
    foreach ($offer as $i => $of) {
        $core->tpl->block("body", "offer", array("name" => $of, "value" => $i, "select" => $o == $i ? "selected=\"selected\"" : ""));
    }
    if (0 < $param["f"] && ($core->user->comp || $param["c"])) {
        $stages = $core->cpa->stages($param["c"] ? $param["c"] : $core->user->comp, $param["f"]);
        if ($stages) {
            $core->tpl->block("body", "stages");
            foreach ($stages as $i => $st) {
                $core->tpl->block("body", "stages.one", array("id" => $i, "active" => $i == $sg, "name" => $st, "url" => $core->url("m", "order?") . parset($param, "sg", $i == $sg ? 0 : $i)));
            }
        }
    }
    $mxmt = time() - 60;
    $callscheme = ($callscheme = $core->cpa->get("comp", $core->user->comp, "callscheme")) ? $callscheme : "tel:+%s";
    $astl = array();
    if ($order) {
        foreach ($order as &$r) {
            $addr = $r["order_addr"];
            if ($r["order_street"]) {
                $addr = $r["order_street"] . ", " . $addr;
            }
            if ($r["order_city"]) {
                $addr = $r["order_city"] . ", " . $addr;
            }
            if ($r["order_area"]) {
                $addr = $r["order_area"] . ", " . $addr;
            }
            if ($r["order_index"]) {
                $addr = $r["order_index"] . ", " . $addr;
            }
            $addr = trim($addr, ", ");
            $uid = $r["wm_id"];
            $user = $uid ? $core->user->get($uid) : array();
            if ($core->user->work == 2) {
                $uname = $user["user_name"];
                if (!($r["ext_id"] || $user["user_vip"])) {
                    $uname = $core->text->cut($user["user_mail"], 20);
                }
            } else {
                $uname = $r["wm_id"];
            }
            if ($mxmt < $r["mark_time"]) {
                $mngr = $manager[$r["mark_id"]];
                $mrcl = "order-boss";
                $mrkr = $r["mark_id"] == $core->user->id ? "<abbr title=\"" . date("d.m.Y H:i:s", $r["mark_time"]) . "\" class=\"accept green\">Моё!</abbr>" : "<abbr title=\"" . date("d.m.Y H:i:s", $r["mark_time"]) . "\" class=\"warn red\">Занят</abbr>";
            } else {
                $mrkr = false;
                $mrcl = "order-user";
                $mngr = $manager[$r["user_id"]];
            }
            $stages = $r["order_stage"] ? $core->cpa->stages($r["comp_id"], -1, 1) : array();
            $canmove = $core->order->canmove($r["order_status"], $r["offer_id"]);
            $canedit = $core->order->canedit($r["order_status"], $r["offer_id"]);
            foreach ($canmove as $ai => $at) {
                $astl[$ai] = true;
            }
            $xz = array("id" => $r["order_id"], "oid" => $r["offer_id"], "offer" => $oname[$r["offer_id"]], "ip" => int2ip($r["order_ip"]), "country" => $r["order_country"] ? $r["order_country"] : ($r["geoip_country"] ? $r["geoip_country"] : "zz"), "name" => $search ? $search->highlight($r["order_name"]) : $r["order_name"], "email" => $search ? $search->highlight($r["order_email"]) : $r["order_email"], "rawmail" => $r["order_email"], "addr" => $search ? $search->highlight($addr) : $addr, "comment" => $r["order_comment"], "phone" => $search ? $search->highlight($r["order_phone"]) : $r["order_phone"], "phone_call" => sprintf($callscheme, $r["order_phone"]), "count" => $r["order_count"], "price" => $core->currency->show($r["price_total"], $r["price_cur"]), "price_csv" => (int) $r["price_total"], "time" => smartdate($r["order_time"]), "stid" => $r["order_status"], "status" => $core->lang["statuso"][$r["order_status"]], "stage" => $r["order_stage"] ? $stages[$r["order_stage"]] : false, "mrkr" => $mrkr, "actcls" => $r["order_status"] == 1 || $r["order_status"] == 7 && !$r["track_code"] ? "no-padding" : "", "manager" => $mngr, "mrcl" => $mrcl, "paid" => $r["paid_ok"], "paidinfo" => $core->lang["order_paid"][$r["paid_ok"]] . ($r["paid_time"] ? " - " . smartdate($r["paid_time"]) : ""), "calls" => $r["order_calls"] ? sprintf(" <small title=\"%s\" class=\"red\">(%s)</small>", $core->lang["order_calls"], $r["order_calls"]) : "", "delivery" => $r["order_delivery"], "delivern" => $core->lang["delivery"][$r["order_delivery"]], "track_code" => $r["track_code"], "uid" => $uid, "uname" => $uid ? $user["user_level"] ? "<b>" . $uname . "</b>" : $uname : $core->lang["order_src_sh"], "uclass" => $r["order_check"] ? "warn" : ($uid ? $r["ext_id"] ? "ext" : ($user["user_vip"] ? "vip" : "user") : "search"), "extu" => $r["ext_uid"], "exts" => $r["ext_src"], "exto" => $r["ext_oid"], "comment" => strtr($r["order_comment"], array("\n" => " ", "\r" => "", "\"" => "\"\"\"")), "cando" => $core->order->cando($r["order_status"], $r["offer_id"]), "edit" => $core->url("i", "order", $r["order_id"]), "u_wm" => $core->url("m", "order?") . parset($param, "wm", $r["wm_id"]), "u_comp" => $core->url("m", "order?") . parset($param, "c", $r["comp_id"]), "u_status" => $core->url("m", "order?") . parset($param, "f", $r["order_status"]), "u_offer" => $core->url("m", "order?") . parset($param, "o", $r["offer_id"]), "u_stage" => $core->url("m", "order?") . parset($param, "sg", $r["order_stage"]));
            if ($r["order_meta"]) {
                $meta = unserialize($r["order_meta"]);
                foreach ($meta as $mk => $mv) {
                    $xz["meta" . $mk] = $mv;
                }
            }
            $core->tpl->block("body", "ord", $xz);
            if ($r["order_status"] == 1 && $canmove[2]) {
                $core->tpl->block("body", "ord.pickup", array("u" => $core->url("ia", "order", $r["order_id"], "pickup")));
                if ($core->user->level) {
                    $core->tpl->block("body", "ord.pickup.move", array("u" => $core->url("ia", "order", $r["order_id"], "move")));
                    foreach ($comp as $v => $n) {
                        $core->tpl->block("body", "ord.pickup.move.comp", array("val" => $v, "name" => $n));
                    }
                }
            }
            if (1 < $r["order_status"] && $r["order_status"] < 4) {
                $ncls = "grey";
                if ($r["order_recall"]) {
                    $ncls = "fat red";
                    if ($next = $core->text->timeleft($r["order_recall"])) {
                        $next = sprintf($core->lang["call_next_in"], $next);
                        $tl = $r["order_recall"] - time();
                        $ncls = 600 < $tl ? "green" : "yellow";
                    } else {
                        $next = $core->text->smartdate($r["order_recall"]);
                    }
                } else {
                    $next = $core->lang["call_next_no"];
                }
                $core->tpl->block("body", "ord.next", array("cls" => $ncls, "text" => $next));
            }
            if ($r["order_status"] == 4) {
                $ncls = "fat red";
                if ($r["order_auto"]) {
                    $ncls = "yellow";
                    if ($next = $core->text->timeleft($r["order_auto"])) {
                        $ncls = "green";
                        $next = sprintf($core->lang["call_next_in"], $next);
                    } else {
                        $next = $core->text->smartdate($r["order_auto"]);
                    }
                } else {
                    $next = $core->lang["call_next_no"];
                }
                $core->tpl->block("body", "ord.auto", array("cls" => $ncls, "text" => $next));
            }
            if ($r["order_status"] == 5) {
                $core->tpl->block("body", "ord.cancel", array("reason" => $r["order_reason"] ? $core->lang["reasono"][$r["order_reason"]] : ($r["order_comment"] ? sprintf($core->lang["noreason_comment"], $r["order_comment"]) : $core->lang["noreason"]), "creason" => $r["order_reason"] ? $core->lang["reasono"][$r["order_reason"]] : ($r["order_comment"] ? strtr($r["order_comment"], array("\r" => "", "\n" => "")) : $core->lang["noreason"])));
            }
            if ($r["order_status"] == 6) {
                $items = $r["order_items"] ? unserialize($r["order_items"]) : false;
                $iline = "";
                if ($items) {
                    if (!count($vars[$r["offer_id"]])) {
                        $vrs = $core->cpa->get("vars", $r["offer_id"]);
                        $vars[$r["offer_id"]] = array();
                        foreach ($vrs as $w) {
                            $vars[$r["offer_id"]][$w["var_id"]] = $w["var_short"];
                        }
                    }
                    foreach ($items as $k => $x) {
                        $iline .= " " . $vars[$r["offer_id"]][$k] . ": " . $x[0] . " ";
                    }
                }
                $core->tpl->block("body", "ord.pack", array("items" => $iline));
            }
            if ($r["order_status"] == 7 && !$r["track_code"] && $canedit) {
                $hastrack = false;
                $core->tpl->block("body", "ord.send", array("u" => $core->url("ia", "order", $r["order_id"], "send")));
            } else {
                $hastrack = true;
            }
            if (5 < $r["order_status"] && $r["order_status"] < 8 && $hastrack) {
                $dlo = $core->cpa->dloptions($r);
                if ($dlo) {
                    foreach ($dlo as $dloi) {
                        $core->tpl->block("body", "ord.dlo", $dloi);
                    }
                }
            }
            if ($r["order_status"] == 8 || $r["order_status"] == 9) {
                $core->tpl->block("body", "ord.track", array("type" => $core->lang["delivery"][$r["order_delivery"]], "stid" => $r["track_status"], "status" => $core->lang["dlstatus"][$r["track_status"]], "date" => $r["track_date"] ? smartdate($r["track_date"]) : false));
            }
            if ($r["order_status"] == 10 && $r["promo_code"] && $r["promo_status"] == 0) {
                $core->tpl->block("body", "ord.promo", array("accept" => $core->url("ia", "order", $r["order_id"], "promo-acc"), "decline" => $core->url("ia", "order", $r["order_id"], "promo-dec"), "code" => $r["promo_code"], "phone" => depromo($r["promo_code"])));
            }
            if ($core->user->level) {
                $core->tpl->block("body", "ord.comp", array("id" => $r["comp_id"], "name" => $comp[$r["comp_id"]]));
            } else {
                $core->tpl->block("body", "ord.ip");
            }
        }
    } else {
        $core->tpl->block("body", "noord");
    }
    unset($r);
    unset($order);
    if ($astl) {
        $core->tpl->vars("body", array("moveblock" => true, "moveacc" => $astl[100], "movedec" => $astl[5]));
        foreach ($core->lang["statuso"] as $i => $v) {
            if ($astl[$i]) {
                $core->tpl->block("body", "movest", array("i" => $i, "n" => $v));
            }
        }
        if ($astl[5]) {
            foreach ($core->lang["reasono"] as $i => $v) {
                $core->tpl->block("body", "movers", array("i" => $i, "n" => $v));
            }
        }
    }
    if ($csv) {
        header("Content-type: text/csv; charset=windows-1251");
        header("Content-disposition: attachment; filename=orders.csv");
        $core->tpl->output("body", "windows-1251//IGNORE");
    } else {
        $core->tpl->output("body");
        $core->site->footer();
    }
}

?>