<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function wm_flow($core)
{
    $message = isset($core->get["message"]) ? $core->text->link($core->get["message"]) : false;
    $action = isset($core->get["action"]) ? $core->text->link($core->get["action"]) : false;
    $id = isset($core->get["id"]) ? (int) $core->get["id"] : false;
    if ($core->config("hide", "flows")) {
        $core->go($core->u("", array("message" => "access")));
    }
    $canuser = $core->user->level || $core->user->work == -2;
    $wm = isset($core->post["wm"]) ? (int) $core->post["wm"] : (int) $core->get["wm"];
    if ($canuser && $wm) {
        $user = $wm;
        $udt = $core->user->get($wm);
        $uinfo = sprintf($core->lang["stat_user"], $udt["user_name"], $udt["user_mail"]);
        $core->site->info("text", $uinfo);
    } else {
        $user = $core->user->id;
        $wm = NULL;
    }
    switch ($message) {
        case "ok":
            $core->site->info("info", "done_flow_ok");
            break;
        case "save":
            $core->site->info("info", "done_flow_save");
            break;
        case "del":
            $core->site->info("info", "done_flow_del");
            break;
        case "error":
            $core->site->info("error", "error_flow");
            break;
        case "access":
            $core->site->info("error", "access_denied");
            break;
    }
    switch ($action) {
        case "add":
            $oid = $core->flow->add($user, $id);
            if ($oid) {
                if (0 < $oid) {
                    $core->go($core->u(array("flow", $oid), array("message" => "ok", "wm" => $wm)));
                } else {
                    $core->go($core->u("offers", array("message" => "inactive")));
                }
            } else {
                $core->go($core->u("flow", array("message" => "error", "wm" => $wm)));
            }
        case "edit":
            $user = $canuser ? $user : -1;
            $result = $core->flow->edit($user, $id, $core->post);
            if ($result) {
                if (0 < $result) {
                    $core->go($core->u("flow", array("message" => "save", "wm" => $wm)));
                } else {
                    $core->go($core->u("flow", array("message" => "access", "wm" => $wm)));
                }
            } else {
                $core->go($core->u("flow", array("message" => "error", "wm" => $wm)));
            }
        case "ajax":
            $user = $canuser ? $user : -1;
            $result = $core->flow->edit($user, $id, $core->post);
            if (0 < $result) {
                $f = $core->db->get(DB_FLOW, array("flow_id" => $id));
                echo $core->flow->makeurl($core->flow->make($f));
            } else {
                echo "error";
            }
            $core->stop();
        case "del":
            $user = $canuser ? $user : -1;
            $result = $core->flow->del($user, $id);
            if ($result) {
                if (0 < $result) {
                    $core->go($core->u("flow", array("message" => "del", "wm" => $wm)));
                } else {
                    $core->go($core->u("flow", array("message" => "access", "wm" => $wm)));
                }
            } else {
                $core->go($core->u("flow", array("message" => "error", "wm" => $wm)));
            }
    }
    if ($id) {
        wm_flow_page($core, $id, $canuser && $wm ? $wm : false);
    }
    $where = array("user_id = '" . $user . "'");
    $param = array();
    if ($canuser && $wm) {
        $param["wm"] = $wm;
    }
    if (isset($core->get["s"]) && $core->get["s"]) {
        require_once PATH_CORE . "search.php";
        $search = new SearchWords($core->get["s"]);
        if ($s = $search->get()) {
            $where[] = $search->field(array("flow_name"));
        } else {
            $s = false;
        }
    } else {
        $s = false;
    }
    if ($o = (int) $core->get["o"]) {
        $param["o"] = $o;
        $where[] = "offer_id = '" . $o . "'";
    } else {
        $o = false;
    }
    $where = implode(" AND ", $where);
    $page = 0 < $core->get["page"] ? (int) $core->get["page"] : 1;
    $sh = 30;
    $st = $sh * ($page - 1);
    $fc = $core->db->field("SELECT COUNT(*) FROM " . DB_FLOW . " WHERE " . $where);
    $flow = $fc ? $core->db->data("SELECT * FROM " . DB_FLOW . " WHERE " . $where . " ORDER BY flow_id DESC LIMIT " . $st . ", " . $sh) : array();
    $core->site->bc($core->lang["menu_flow"], $core->u("flow", array("wm" => $wm)));
    $core->site->set("select2");
    $core->site->header();
    $core->tpl->load("body", "flows", defined("HACK_TPL_FLOWS") ? HACK : false);
    $core->tpl->vars("body", array("text" => $core->text->lines($core->lang["flows_text"]), "noflows" => $core->lang["noflows"], "pages" => pages($core->u("flow", $param), $fc, $sh, $page, sprintf($core->lang["shown"], $st + 1, min($st + $sh, $fc), $fc)), "s" => $s, "wm" => $wm, "search" => $core->lang["search"], "find" => $core->lang["find"], "link" => $core->lang["link"], "flow" => $core->lang["flow"], "name" => $core->lang["name"], "action" => $core->lang["action"], "total" => $core->lang["total"], "offer" => $core->lang["offer"], "stats" => $core->lang["stats"], "edit" => $core->lang["settings"], "del" => $core->lang["del"], "confirm" => $core->lang["flow_confirm"], "s_leads" => $core->lang["menu_sub_leads"], "s_stats" => $core->lang["menu_sub_stats"], "s_hour" => $core->lang["menu_sub_hourstat"], "s_geo" => $core->lang["menu_sub_geostat"], "s_utm" => $core->lang["menu_sub_utm"], "s_site" => $core->lang["menu_sub_site"], "s_click" => $core->lang["menu_sub_click"]));
    $oname = $core->cpa->get("offersa");
    $offer = $core->offer->names($user);
    foreach ($offer as $of => $n) {
        $core->tpl->block("body", "offer", array("name" => $n, "value" => $of, "select" => $of == $o ? "selected=\"selected\"" : ""));
    }
    if ($flow) {
        foreach ($flow as $f) {
            $core->tpl->block("body", "flow", array("id" => $f["flow_id"], "name" => $search ? $search->highlight($f["flow_name"]) : $f["flow_name"], "offer" => $oname[$f["offer_id"]], "u_offer" => $core->u("flow", parset($param, "o", $f["offer_id"])), "url" => $core->flow->makeurl($core->flow->make($f)), "cr" => $f["flow_convert"], "epc" => $core->currency->prntf("%0.2f", $f["flow_epc"]), "total" => $core->currency->money($f["flow_total"]), "edit" => $core->u(array("flow", $f["flow_id"]), array("wm" => $wm)), "del" => $core->u(array("flow", $f["flow_id"]), array("action" => "del", "wm" => $wm)), "stats" => $core->u("stats", array("wm" => $wm, "f" => $f["flow_id"])), "leads" => $core->u("leads", array("wm" => $wm, "f" => $f["flow_id"])), "hour" => $core->u("hourstat", array("wm" => $wm, "f" => $f["flow_id"])), "geo" => $core->u("geostat", array("wm" => $wm, "f" => $f["flow_id"])), "utm" => $core->u("utm", array("wm" => $wm, "f" => $f["flow_id"])), "site" => $core->u("site", array("wm" => $wm, "f" => $f["flow_id"])), "click" => $core->u("click", array("wm" => $wm, "f" => $f["flow_id"]))));
        }
    } else {
        $core->tpl->block("body", "noitem");
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}
function wm_flow_page($core, $id, $wm = NULL)
{
    $f = $core->db->row("SELECT * FROM " . DB_FLOW . " WHERE flow_id = '" . $id . "' LIMIT 1");
    if ($wm) {
        if ($f["user_id"] != $wm) {
            $core->go($core->u("", "message=access"));
        }
    } else {
        if ($f["user_id"] != $core->user->id) {
            $core->go($core->u("", "message=access"));
        }
    }
    if (!$wm) {
        $wm = NULL;
    }
    $lands = $core->cpa->get("lands", $f["offer_id"]);
    $space = $core->cpa->get("space", $f["offer_id"]);
    $dr = $core->domain->get($f["user_id"]);
    $core->site->bc($core->lang["menu_flow"], $core->u("flow", array("wm" => $wm)));
    $core->site->bc($f["flow_name"]);
    $core->site->pt($core->lang["flow_edit_h"]);
    $core->site->header();
    $core->tpl->load("body", "flow", defined("HACK_TPL_FLOW") ? HACK : false);
    $core->tpl->vars("body", array("u_save" => $core->u(array("flow", $id), array("action" => "edit", "wm" => $wm)), "u_ajax" => $core->u(array("flow", $id), array("action" => "ajax", "wm" => $wm)), "u_log" => $core->u("postback", array("f" => $id, "wm" => $wm)), "name" => strtr($f["flow_name"], array("\"" => "&quot;")), "url" => $core->flow->makeurl($core->flow->make($f)), "tbu" => strtr($f["flow_url"], array("\"" => "&quot;")), "pbu" => strtr($f["flow_pbu"], array("\"" => "&quot;")), "cb" => $f["flow_cb"], "mtrk" => $f["flow_mtrk"], "fb" => $f["flow_fb"], "vk" => $f["flow_vk"], "ga" => $f["flow_ga"], "utms" => $f["flow_utms"], "utmc" => $f["flow_utmc"], "utmn" => $f["flow_utmn"], "utmt" => $f["flow_utmt"], "utmm" => $f["flow_utmm"], "parkrd" => $core->config("redirect", "park") ? $dr["domain"]["red"] ? 1 : 0 : 0, "parkst" => $core->config("sites", "park") ? $dr["domain"]["site"] ? 1 : 0 : 0, "parksp" => $core->config("space", "park") ? $dr["domain"]["space"] ? 1 : 0 : 0, "hasspace" => $space ? true : false, "nospace" => $f["flow_space"] ? 0 : 1, "lname" => $core->lang["name"], "lsave" => $core->lang["save"], "lsaved" => $core->lang["done_flow_save"], "lurl" => $core->lang["url"], "lflowurl" => $core->lang["flow_link"], "lflowurld" => $core->lang["flow_link_d"], "lapprove" => $core->lang["offer_approve"], "lsites" => $core->lang["flow_land"], "lspace" => $core->lang["flow_space"], "lnospace" => $core->lang["flow_nospace"], "ldefault" => $core->lang["flow_redirect_o"], "ldrd" => $core->lang["flow_redirect"], "lcb" => $core->lang["flow_comeback"], "ltbu" => $core->lang["flow_url"], "ltbud" => $core->lang["flow_url_d"], "lpbu" => $core->lang["flow_pbu"], "lpbud" => $core->lang["flow_pbu_d"], "lutms" => $core->lang["flow_utms"], "lutmc" => $core->lang["flow_utmc"], "lutmn" => $core->lang["flow_utmn"], "lutmt" => $core->lang["flow_utmt"], "lutmm" => $core->lang["flow_utmm"], "lmtrk" => $core->lang["flow_mtrk"], "lmtrkd" => $core->lang["flow_mtrk_d"], "lga" => $core->lang["flow_ga"], "lgad" => $core->lang["flow_ga_d"], "lvk" => $core->lang["flow_vk"], "lvkd" => $core->lang["flow_vk_d"], "lfb" => $core->lang["flow_fb"], "lfbd" => $core->lang["flow_fb_d"]));
    if ($dr["domain"]["red"]) {
        foreach ($dr["domain"]["red"] as $di => $dm) {
            $core->tpl->block("body", "drd", array("n" => $dm, "v" => $di, "s" => $di == $f["domain_id"]));
        }
    }
    if ($dr["domain"]["site"]) {
        foreach ($dr["domain"]["site"] as $di => $dm) {
            $core->tpl->block("body", "dst", array("n" => $dm, "v" => $di, "s" => $di == $f["domain_site"]));
        }
    }
    if ($dr["domain"]["space"]) {
        foreach ($dr["domain"]["space"] as $di => $dm) {
            $core->tpl->block("body", "dsp", array("n" => $dm, "v" => $di, "s" => $di == $f["domain_space"]));
        }
    }
    if ($lands) {
        foreach ($lands as $s) {
            $core->tpl->block("body", "land", array("id" => $s["site_id"], "ch" => $s["site_id"] == $f["flow_site"], "url" => $s["site_url"], "name" => $s["site_name"] ? $s["site_name"] : $s["site_url"], "appr" => 0 < $s["site_approve"] ? sprintf("%0.1f", $s["site_approve"]) : false, "cr" => 0 < $s["site_convert"] ? sprintf("%0.2f", $s["site_convert"]) : false, "epc" => 0 < $s["site_epc"] ? $core->currency->prntf("%0.2f", $s["site_epc"]) : false, "mb" => $s["site_mobile"], "mbt" => $core->lang["site_mobiles"][$s["site_mobile"]]));
        }
    }
    if ($space) {
        foreach ($space as $s) {
            $core->tpl->block("body", "space", array("id" => $s["site_id"], "ch" => $s["site_id"] == $f["flow_space"], "url" => $s["site_url"], "name" => $s["site_name"] ? $s["site_name"] : $s["site_url"], "appr" => 0 < $s["site_approve"] ? sprintf("%0.1f", $s["site_approve"]) : false, "cr" => 0 < $s["site_convert"] ? sprintf("%0.2f", $s["site_convert"]) : false, "epc" => 0 < $s["site_epc"] ? $core->currency->prntf("%0.2f", $s["site_epc"]) : false, "mb" => $s["site_mobile"], "mbt" => $core->lang["site_mobiles"][$s["site_mobile"]]));
        }
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}

?>