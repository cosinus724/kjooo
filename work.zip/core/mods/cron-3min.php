<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function cron3min($core)
{
    set_time_limit(1865);
    require_once PATH_MODS . "cron-load.php";
    loadsites($core, 1);
}

?>