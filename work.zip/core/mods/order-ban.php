<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function ban_ip($core, $ip, $raw = false)
{
    if (!$raw) {
        $ip = ip2int($ip);
    }
    if (!$ip) {
        return false;
    }
    $bans = $core->db->field("SELECT `times` FROM " . DB_BAN_IP . " WHERE `ip` = '" . $ip . "' LIMIT 1");
    if ($bans) {
        if (9 < $bans) {
            $core->db->query("UPDATE " . DB_BAN_IP . " SET `times` = `times` + 1, `status` = 1 WHERE `ip` = '" . $ip . "'");
        } else {
            $core->db->query("UPDATE " . DB_BAN_IP . " SET `times` = `times` + 1 WHERE `ip` = '" . $ip . "'");
        }
    } else {
        $core->db->add(DB_BAN_IP, array("ip" => $ip, "times" => 1));
    }
}
function ban_phone($core, $phone)
{
    $phone = preg_replace("#([^0-9]+)#", "", $phone);
    if (!$phone) {
        return false;
    }
    $bans = $core->db->field("SELECT `times` FROM " . DB_BAN_PH . " WHERE `phone` = '" . $phone . "' LIMIT 1");
    if ($bans) {
        if (9 < $bans) {
            $core->db->query("UPDATE " . DB_BAN_PH . " SET `times` = `times` + 1, `status` = 1 WHERE `phone` = '" . $phone . "'");
        } else {
            $core->db->query("UPDATE " . DB_BAN_PH . " SET `times` = `times` + 1 WHERE `phone` = '" . $phone . "'");
        }
    } else {
        $core->db->add(DB_BAN_PH, array("phone" => $phone, "times" => 1));
    }
}
function check_ip_bans($core, $ips, $istext = false)
{
    if (!$ips) {
        return array();
    }
    if ($istext) {
        $ips = array_map($ips, "ip2int");
    }
    $ips = array_unique($ips);
    sort($ips);
    if (count($ips)) {
        return $core->db->icol("SELECT `ip`, `times` FROM " . DB_BAN_IP . " WHERE `ip` IN ( " . implode(", ", $ips) . " )");
    }
    return array();
}
function check_phone_bans($core, $phones)
{
    if (!$phones) {
        return array();
    }
    $ph = array();
    foreach ($phones as $p) {
        if ($p = preg_replace("#([^0-9]+)#", "", $p)) {
            $ph[] = $p;
        }
    }
    $ph = array_unique($ph);
    sort($ph);
    if (count($ph)) {
        return $core->db->icol("SELECT `phone`, `times` FROM " . DB_BAN_PH . " WHERE `phone` IN ( '" . implode("', '", $ph) . "' )");
    }
    return array();
}

?>