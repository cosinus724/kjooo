<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function company_menu($core, $menu)
{
    $menu["company"] = array("company", "ca-calls", "ca-order", "ca-delivery");
    $menu["config"] = array("teams", "personel", "compset", "comp-delivery", "comp-stages");
    if (!$core->config("hide", "int")) {
        $menu["config"][] = "integration";
        $menu["config"][] = "integration-log";
    }
    return $menu;
}
function company_action($core)
{
    $action = $core->get["a"] ? $core->get["a"] : NULL;
    $id = $core->post["id"] ? (int) $core->post["id"] : ($core->get["id"] ? (int) $core->get["id"] : 0);
    $ci = $core->user->comp;
    switch ($action) {
        case "comp-info":
            $edit = array("comp_name" => $core->text->line($core->post["name"]), "comp_mailto" => $core->text->email($core->post["mailto"]), "callscheme" => $core->text->line($core->post["callscheme"]), "autoaccept" => $core->post["autoaccept"] ? 1 : 0, "ccp_day" => (int) $core->post["ccp_day"], "ccp_night" => (int) $core->post["ccp_night"], "ccp_sale" => (int) $core->post["ccp_sale"], "ccp_upsale" => $core->text->line($core->post["ccp_upsale"]));
            if ($core->db->edit(DB_COMP, $edit, "comp_id = '" . $core->user->comp . "'")) {
                $core->cpa->clear("comp", $core->user->comp);
                $core->cpa->clear("comps");
                $core->cpa->clear("compa");
                $core->cpa->clear("ccs");
                $core->go($core->url("mm", "compset", "ok"));
            } else {
                $core->go($core->url("mm", "compset", "error"));
            }
        case "comp-user-add":
            $name = $core->text->line($core->post["name"]);
            $email = $core->text->email($core->post["email"]);
            $pass = $core->user->pass(trim($core->post["pass"]));
            $team = (int) $core->post["team"];
            $uid = $core->db->field("SELECT user_id FROM " . DB_USER . " WHERE user_mail = '" . $email . "' LIMIT 1");
            if (!$uid) {
                $sql = "INSERT INTO " . DB_USER . " SET user_name = '" . $name . "', user_mail = '" . $email . "', user_pass = '" . $pass . "', user_work = 1, user_comp = '" . $ci . "', user_team = '" . $team . "'";
                if ($name && $email && trim($core->post["pass"]) && $core->db->query($sql)) {
                    $uid = $core->db->lastid();
                    $core->cpa->clear("mans", $core->user->comp);
                    $core->cpa->clear("allman");
                    $core->go($core->url("im", "personel", $uid, "ok"));
                } else {
                    $core->go($core->url("mm", "personel", "error"));
                }
            } else {
                $core->go($core->url("mm", "personel", "exists"));
            }
        case "comp-user-edit":
            $user = $core->db->row("SELECT * FROM " . DB_USER . " WHERE user_id = '" . $id . "' LIMIT 1");
            if ($user["user_comp"] && $user["user_comp"] == $ci) {
                $email = $core->text->email($core->post["email"]);
                if ($email != $user["user_mail"]) {
                    $uid = $core->db->field("SELECT user_id FROM " . DB_USER . " WHERE user_mail = '" . $email . "' LIMIT 1");
                    if ($uid) {
                        $core->go($core->url("mm", "personel", "exists"));
                    }
                }
                $data = array("user_name" => $core->text->line($core->post["name"]), "user_mail" => $email, "user_ban" => $core->post["ban"] ? 1 : 0, "user_compad" => $core->post["compad"] ? 1 : 0, "user_team" => (int) $core->post["team"], "user_teamlead" => $core->post["teamlead"] ? 1 : 0);
                if ($pass = trim($core->post["pass"])) {
                    $data["user_pass"] = $core->user->pass($pass);
                }
                if ($data["user_ban"] && $id == $core->user->id) {
                    $core->go($core->url("mm", "personel", "access"));
                }
                if (!$data["user_compad"] && $id == $core->user->id) {
                    $core->go($core->url("mm", "personel", "access"));
                }
                if ($core->user->set($id, $data)) {
                    $core->cpa->clear("mans", $core->user->comp);
                    $core->cpa->clear("allman");
                    $core->go($core->url("mm", "personel", "ok"));
                } else {
                    $core->go($core->url("mm", "personel", "error"));
                }
            } else {
                $core->go($core->url("mm", "personel", "access"));
            }
        case "comp-user-del":
            $user = $core->db->row("SELECT * FROM " . DB_USER . " WHERE user_id = '" . $id . "' LIMIT 1");
            if ($id != 1 && $id != $core->user->id && $user["user_comp"] == $ci) {
                $core->db->query("DELETE FROM " . DB_CASH . " WHERE user_id = '" . $id . "'");
                if ($core->db->query("DELETE FROM " . DB_USER . " WHERE user_id = '" . $id . "'")) {
                    $core->cpa->clear("mans", $core->user->comp);
                    $core->cpa->clear("allman");
                    $core->go($core->url("mm", "personel", "ok"));
                } else {
                    $core->go($core->url("mm", "personel", "error"));
                }
            } else {
                $core->go($core->url("mm", "personel", "access"));
            }
        case "team-add":
            $name = $core->text->line($core->post["name"]);
            if (!$name) {
                $core->go($core->url("mm", "teams", "error"));
            }
            $data = array("team_name" => $name, "comp_id" => $ci);
            if ($core->db->add(DB_TEAM, $data)) {
                $ti = $core->db->lastid();
                $core->cpa->clear("teams", $ci);
                $core->go($core->url("im", "teams", $ti, "ok"));
            } else {
                $core->go($core->url("mm", "teams", "error"));
            }
        case "team-edit":
            $tc = $core->db->field("SELECT comp_id FROM " . DB_TEAM . " WHERE team_id = '" . $id . "' LIMIT 1");
            if ($tc != $ci) {
                $core->go($core->url("mm", "teams", "access"));
            }
            $offer = array();
            if ($ol = $core->post["offer"]) {
                foreach ($ol as $o) {
                    if ($o = (int) trim($o)) {
                        $offer[] = $o;
                    }
                }
                $offer = array_unique($offer);
                sort($offer);
            }
            $data = array("team_name" => $core->text->line($core->post["name"]), "team_call" => (int) $core->post["call"], "team_pack" => (int) $core->post["pack"], "team_send" => (int) $core->post["send"], "team_delivery" => (int) $core->post["delivery"], "team_mod" => $core->post["mod"] ? 1 : 0, "team_offer" => $core->text->intline($core->post["offer"]), "pay_use" => $core->post["pay_use"] ? 1 : 0, "pay_day" => (int) $core->post["pay_day"], "pay_night" => (int) $core->post["pay_night"], "pay_sale" => (int) $core->post["pay_sale"], "pay_upsale" => $core->text->line($core->post["pay_upsale"]));
            if ($core->db->edit(DB_TEAM, $data, "team_id = '" . $id . "'")) {
                $core->cpa->clear("team", $id);
                $core->cpa->clear("teams", $ci);
                $core->go($core->url("mm", "teams", "ok"));
            } else {
                $core->go($core->url("mm", "teams", "error"));
            }
        case "team-del":
            $tc = $core->db->field("SELECT comp_id FROM " . DB_TEAM . " WHERE team_id = '" . $id . "' LIMIT 1");
            if ($tc == $ci) {
                if ($core->db->query("DELETE FROM " . DB_TEAM . " WHERE team_id = '" . $id . "' LIMIT 1")) {
                    $core->db->query("UPDATE " . DB_USER . " SET user_team = 0, user_teamlead = 0 WHERE user_team = '" . $id . "'");
                    $core->cpa->clear("teams", $ci);
                    $core->go($core->url("mm", "teams", "ok"));
                } else {
                    $core->go($core->url("mm", "teams", "error"));
                }
            } else {
                $core->go($core->url("mm", "teams", "access"));
            }
    }
    return false;
}
function company_module($core)
{
    $module = $core->get["m"] ? $core->get["m"] : NULL;
    $id = $core->post["id"] ? (int) $core->post["id"] : ($core->get["id"] ? (int) $core->get["id"] : 0);
    $page = 0 < $core->get["page"] ? (int) $core->get["page"] : 1;
    $message = $core->get["message"] ? $core->get["message"] : NULL;
    $ci = $core->user->comp;
    $comp = $core->cpa->get("comp", $ci);
    switch ($module) {
        case "compset":
            switch ($message) {
                case "ok":
                    $core->site->info("info", "done_basic");
                    break;
                case "error":
                    $core->site->info("info", "error_basic");
                    break;
                case "access":
                    $core->site->info("error", "access_denied");
                    break;
            }
            $core->site->bc($core->lang["company"], $core->url("m", "comp"));
            $core->site->bc($core->lang["comp_info_h"]);
            $core->site->header();
            $field = array(array("type" => "text", "length" => 100, "name" => "name", "head" => $core->lang["name"], "value" => $comp["comp_name"]), array("type" => "email", "length" => 100, "name" => "mailto", "head" => $core->lang["comp_mailto"], "descr" => $core->lang["comp_mailto_d"], "value" => $comp["comp_mailto"]), array("type" => "text", "name" => "callscheme", "head" => $core->lang["comp_callscheme"], "descr" => $core->lang["comp_callscheme_d"], "value" => $comp["callscheme"]), array("type" => "checkbox", "name" => "autoaccept", "head" => $core->lang["comp_autoaccept"], "descr" => $core->lang["comp_autoaccept_d"], "checked" => $comp["autoaccept"]), array("type" => "head", "value" => $core->lang["comp_ccp"]), array("type" => "line", "value" => $core->text->lines($core->lang["comp_ccp_d"])), array("type" => "text", "name" => "ccp_day", "head" => $core->lang["comp_ccp_day"], "descr" => $core->lang["comp_ccp_day_d"], "value" => $comp["ccp_day"]), array("type" => "text", "name" => "ccp_night", "head" => $core->lang["comp_ccp_night"], "descr" => $core->lang["comp_ccp_night_d"], "value" => $comp["ccp_night"]), array("type" => "text", "name" => "ccp_sale", "head" => $core->lang["comp_ccp_sale"], "descr" => $core->lang["comp_ccp_sale_d"], "value" => $comp["ccp_sale"]), array("type" => "text", "name" => "ccp_upsale", "head" => $core->lang["comp_ccp_upsale"], "descr" => $core->lang["comp_ccp_upsale_d"], "value" => $comp["ccp_upsale"]));
            $core->site->form("comp", $core->url("a", "comp-info", ""), $core->lang["comp_info_h"], $field);
            $core->site->footer();
            $core->stop();
        case "company":
            require_once PATH_MODS . "comp-calls.php";
            callstat($core, "company");
        case "comp-stages":
            require_once PATH_MODS . "comp-settings.php";
            company_stages($core, $core->user->comp, false);
        case "ca-calls":
            require_once PATH_MODS . "analytics-calls.php";
            analytics_calls($core, "ca-calls", array("cmp" => $core->user->comp));
        case "ca-order":
            require_once PATH_MODS . "analytics-order.php";
            analytics_order($core, "ca-order", array("cmp" => $core->user->comp));
        case "ca-delivery":
            require_once PATH_MODS . "analytics-delivery.php";
            analytics_delivery($core, "ca-delivery", array("cmp" => $core->user->comp));
        case "comp-delivery":
            require_once PATH_MODS . "comp-settings.php";
            company_delivery($core, $core->user->comp, false);
        case "integration":
            require_once PATH_MODS . "comp-int.php";
            company_integration($core, $core->user->comp, false);
        case "integration-log":
            require_once PATH_MODS . "comp-int.php";
            integration_log($core, $core->user->comp);
        case "teams":
            switch ($message) {
                case "ok":
                    $core->site->info("info", "done_basic");
                    break;
                case "error":
                    $core->site->info("info", "error_basic");
                    break;
                case "access":
                    $core->site->info("error", "access_denied");
                    break;
            }
            if ($id) {
                $t = $core->cpa->get("team", $id);
                $core->site->bc($core->lang["company"], $core->url("m", "comp"));
                $core->site->bc($core->lang["teams"], $core->url("m", "teams"));
                $core->site->bc($t["team_name"]);
                $core->site->set("select2");
                $core->site->header();
                $field = array(array("type" => "line", "value" => $core->text->lines($core->lang["company_team_edit_t"])), array("type" => "text", "length" => 100, "name" => "name", "head" => $core->lang["name"], "value" => $t["team_name"]), array("type" => "select", "name" => "call", "head" => $core->lang["team_call"], "options" => $core->lang["team_calls"], "value" => $t["team_call"]), array("type" => "select", "name" => "pack", "head" => $core->lang["team_pack"], "options" => $core->lang["team_access"], "value" => $t["team_pack"]), array("type" => "select", "name" => "send", "head" => $core->lang["team_send"], "options" => $core->lang["team_access"], "value" => $t["team_send"]), array("type" => "select", "name" => "delivery", "head" => $core->lang["team_delivery"], "options" => $core->lang["team_access"], "value" => $t["team_delivery"]), array("type" => "mselect", "name" => "offer", "head" => $core->lang["team_offer"], "descr" => $core->lang["team_offer_d"], "options" => $core->offer->names($core->user->id), "value" => $t["team_offer"]), array("type" => "checkbox", "name" => "mod", "head" => $core->lang["team_mod"], "descr" => $core->lang["team_mod_d"], "checked" => $t["team_mod"]), array("type" => "head", "value" => $core->lang["comp_ccp"]), array("type" => "line", "value" => $core->text->lines($core->lang["comp_ccp_d"])), array("type" => "checkbox", "name" => "pay_use", "head" => $core->lang["comp_ccp_use"], "descr" => $core->lang["comp_ccp_use_d"], "checked" => $t["pay_use"]), array("type" => "text", "name" => "pay_day", "head" => $core->lang["comp_ccp_day"], "descr" => $core->lang["comp_ccp_day_d"], "value" => $t["pay_day"]), array("type" => "text", "name" => "pay_night", "head" => $core->lang["comp_ccp_night"], "descr" => $core->lang["comp_ccp_night_d"], "value" => $t["pay_night"]), array("type" => "text", "name" => "pay_sale", "head" => $core->lang["comp_ccp_sale"], "descr" => $core->lang["comp_ccp_sale_d"], "value" => $t["pay_sale"]), array("type" => "text", "name" => "pay_upsale", "head" => $core->lang["comp_ccp_upsale"], "descr" => $core->lang["comp_ccp_upsale_d"], "value" => $t["pay_upsale"]));
                $core->site->form("useradd", $core->url("a", "team-edit", $id), $core->lang["company_team_edit_h"], $field);
                $core->site->footer();
            } else {
                $teams = $core->db->data("SELECT * FROM " . DB_TEAM . " WHERE comp_id = '" . $ci . "' ORDER BY team_name ASC");
                $core->site->bc($core->lang["company"], $core->url("m", "comp"));
                $core->site->bc($core->lang["teams"]);
                $core->site->header();
                $core->tpl->load("body", "list", defined("HACK_TPL_LIST") ? HACK : false);
                $core->tpl->vars("body", array("title" => $core->lang["company_teams_h"], "text" => $core->text->lines($core->lang["company_teams_t"]), "name" => $core->lang["name"], "info" => $core->lang["access"], "action" => $core->lang["action"], "edit" => $core->lang["edit"], "del" => $core->lang["del"], "confirm" => $core->lang["confirm"], "add" => $core->lang["add"], "u_add" => $core->url("a", "team-add", "")));
                if ($teams) {
                    foreach ($teams as $t) {
                        $auths = array();
                        if ($t["team_call"]) {
                            $auths[] = " <span title=\"" . $core->lang["team_calls"][$t["team_call"]] . "\" class=\"status status3\">" . $core->lang["team_call"] . "</span>";
                        }
                        if ($t["team_pack"]) {
                            $auths[] = " <span title=\"" . $core->lang["team_access"][$t["team_pack"]] . "\" class=\"status status6\">" . $core->lang["team_pack"] . "</span>";
                        }
                        if ($t["team_send"]) {
                            $auths[] = " <span title=\"" . $core->lang["team_access"][$t["team_send"]] . "\" class=\"status status7\">" . $core->lang["team_send"] . "</span>";
                        }
                        if ($t["team_delivery"]) {
                            $auths[] = " <span title=\"" . $core->lang["team_access"][$t["team_delivery"]] . "\" class=\"status status8\">" . $core->lang["team_delivery"] . "</span>";
                        }
                        if ($t["team_mod"]) {
                            $auths[] = " <span class=\"status status10\">" . $core->lang["team_mod"] . "</span>";
                        }
                        if ($auths) {
                            $auths = implode(" ", $auths);
                        } else {
                            $auths = "<span class=\"status status1\">" . $core->lang["team_readonly"] . "</span>";
                        }
                        $core->tpl->block("body", "item", array("id" => $t["team_id"], "name" => $t["team_name"], "info" => $auths, "url" => $core->url("i", "teams", $t["team_id"]), "edit" => $core->url("i", "teams", $t["team_id"]), "del" => $core->url("a", "team-del", $t["team_id"])));
                    }
                } else {
                    $core->tpl->block("body", "noitem");
                }
                $core->tpl->output("body");
                $core->site->footer();
            }
            $core->stop();
        case "personel":
            switch ($message) {
                case "ok":
                    $core->site->info("info", "done_basic");
                    break;
                case "error":
                    $core->site->info("info", "error_basic");
                    break;
                case "exists":
                    $core->site->info("error", "error_user_exist");
                    break;
                case "access":
                    $core->site->info("error", "access_denied");
                    break;
            }
            if ($id) {
                $user = $core->db->row("SELECT * FROM " . DB_USER . " WHERE user_id = '" . $id . "' LIMIT 1");
                if ($user["user_comp"] != $ci) {
                    $core->go($core->url("mm", "personel", "access"));
                }
                $teams = $core->cpa->get("teams", $ci);
                if ($teams) {
                    $teamsel = select($teams, $user["user_team"]);
                    array_unshift($teamsel, array("value" => 0, "name" => "&mdash;"));
                } else {
                    $teamsel = false;
                }
                $core->site->bc($core->lang["company"], $core->url("m", "comp"));
                $core->site->bc($core->lang["personel"], $core->url("m", "personel"));
                $core->site->bc($user["user_name"]);
                $core->site->header();
                $field = array(array("type" => "text", "length" => 100, "name" => "name", "head" => $core->lang["user_name"], "descr" => $core->lang["user_name_d"], "value" => $user["user_name"]), array("type" => "checkbox", "name" => "ban", "head" => $core->lang["user_ban"], "descr" => $core->lang["user_ban_d"], "checked" => $user["user_ban"]), array("type" => "text", "length" => 100, "name" => "email", "head" => $core->lang["user_email"], "descr" => $core->lang["user_email_d"], "value" => $user["user_mail"]), array("type" => "pass", "length" => 32, "name" => "pass", "head" => $core->lang["user_pass"], "descr" => $core->lang["user_pass_d"]), array("type" => "checkbox", "name" => "compad", "head" => $core->lang["user_compad"], "descr" => $core->lang["user_compad_d"], "checked" => $user["user_compad"]));
                if ($teamsel) {
                    $field[] = array("type" => "select", "name" => "team", "head" => $core->lang["user_team"], "descr" => $core->lang["user_team_d"], "value" => $teamsel);
                    $field[] = array("type" => "checkbox", "name" => "teamlead", "head" => $core->lang["user_teamlead"], "descr" => $core->lang["user_teamlead_d"], "checked" => $user["user_teamlead"]);
                }
                $core->site->form("useredit", $core->url("a", "comp-user-edit", $id), $core->lang["user_edit"], $field);
                $core->site->footer();
            } else {
                $mans = $core->db->data("SELECT * FROM " . DB_USER . " WHERE user_comp = '" . $ci . "' ORDER BY user_name ASC");
                $teams = $core->cpa->get("teams", $ci);
                $core->site->bc($core->lang["company"], $core->url("m", "comp"));
                $core->site->bc($core->lang["personel"]);
                $core->site->header();
                $core->tpl->load("body", "list", defined("HACK_TPL_LIST") ? HACK : false);
                $core->tpl->vars("body", array("title" => $core->lang["company_personel_h"], "text" => $core->text->lines($core->lang["company_personel_t"]), "name" => $core->lang["name"], "info" => $core->lang["access"], "action" => $core->lang["action"], "level" => $core->lang["level"], "edit" => $core->lang["edit"], "del" => $core->lang["del"], "confirm" => $core->lang["confirm"]));
                foreach ($mans as &$i) {
                    if ($i["user_ban"]) {
                        $level = "<b class=\"warn red\">" . $core->lang["ban"] . "</b>";
                    } else {
                        if ($i["user_team"]) {
                            $tg = $i["user_teamlead"] ? "b" : "span";
                            $tc = $i["user_compad"] ? "boss" : "teams";
                            $level = "<" . $tg . " class=\"" . $tc . "\">" . $teams[$i["user_team"]] . "</" . $tg . ">";
                        } else {
                            if ($i["user_compad"]) {
                                $level = "<b class=\"boss\">" . $core->lang["admin"] . "</b>";
                            } else {
                                $level = $core->lang["user_works"][1];
                            }
                        }
                    }
                    $core->tpl->block("body", "item", array("id" => $i["user_id"], "name" => $i["user_name"], "more" => "<a href=\"mailto:" . $i["user_mail"] . "\" class=\"small grey\">" . $i["user_mail"] . "</a>", "info" => $level, "url" => $core->url("i", "personel", $i["user_id"]), "edit" => $core->url("i", "personel", $i["user_id"]), "del" => $core->url("a", "comp-user-del", $i["user_id"])));
                }
                unset($i);
                unset($mans);
                $core->tpl->output("body");
                if ($teams) {
                    $teamsel = select($teams);
                    array_unshift($teamsel, array("value" => 0, "name" => "&mdash;"));
                } else {
                    $teamsel = false;
                }
                $field = array(array("type" => "text", "length" => 100, "name" => "name", "head" => $core->lang["user_name"], "descr" => $core->lang["user_name_d"]), array("type" => "text", "length" => 100, "name" => "email", "head" => $core->lang["user_email"], "descr" => $core->lang["user_email_d"]), array("type" => "pass", "length" => 32, "name" => "pass", "head" => $core->lang["user_pass"], "descr" => $core->lang["user_pass_d"]));
                if ($teamsel) {
                    $field[] = array("type" => "select", "name" => "team", "head" => $core->lang["user_team"], "descr" => $core->lang["user_team_d"], "value" => $teamsel);
                }
                $core->site->form("useradd", $core->url("a", "comp-user-add", ""), $core->lang["comp_user_add"], $field, $core->lang["create"]);
                $core->site->footer();
            }
            $core->stop();
    }
    return false;
}

?>