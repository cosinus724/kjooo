<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function api($core, $app, $func, $type, $id)
{
    $apps = array("wm" => array("flows", "offers", "sites", "stats", "click", "lead", "add", "edit", "del", "push"), "comp" => array("list", "edit", "status", "retrack", "delivery", "goods"), "ext" => array("add", "list", "info"));
    $app = $core->text->link($app);
    $func = $core->text->link($func);
    $type = $core->text->link($type);
    if ($id) {
        $ids = explode("-", $id, 2);
        $id = (int) $ids[0];
        $key = $core->text->link($ids[1]);
    } else {
        $id = $key = false;
    }
    if ($app == "sale") {
        $app = "comp";
    }
    define("APIMODE", true);
    if (defined("HACK_API")) {
        include PATH . HACK . "/hack/api.php";
    }
    if (isset($apps[$app]) && in_array($func, $apps[$app])) {
        if ($id && $key) {
            $uk = $core->user->get($id, "user_api");
            if ($uk != $key) {
                $ck = hash_hmac("sha1", http_build_query($core->post), $uk);
                $auth = $ck == $key ? 1 : 0;
            } else {
                $auth = 1;
            }
        } else {
            $auth = 0;
        }
    } else {
        $auth = 1;
    }
    if ($auth) {
        $fname = "api_" . $app . "_" . $func;
        if (function_exists($fname)) {
            $result = $fname($core, $id);
        } else {
            $result = array("status" => "error", "error" => "func");
        }
    } else {
        $result = array("status" => "error", "error" => "key");
    }
    switch ($type) {
        case "raw":
            header("Content-type: text/plain; charset=utf-8");
            echo $result;
            break;
        case "text":
            header("Content-type: text/plain; charset=utf-8");
            echo http_build_query($result);
            break;
        case "xml":
            header("Content-type: application/xml; charset=utf-8");
            echo array2xml($result, $func);
            break;
        case "json":
            header("Content-type: application/json; charset=utf-8");
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
            break;
        case "jsonpp":
            header("Content-type: application/json; charset=utf-8");
            echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            break;
        default:
            header("Content-type: text/plain; charset=utf-8");
            echo serialize($result);
    }
}
function api_guess_status($core)
{
    $st = $core->text->link($core->post["status"] ? $core->post["status"] : $core->get["status"]);
    $sta = $core->text->link($core->post["sta"] ? $core->post["sta"] : $core->get["sta"]);
    $stc = $core->text->link($core->post["stc"] ? $core->post["stc"] : $core->get["stc"]);
    $stt = $core->text->link($core->post["stt"] ? $core->post["stt"] : $core->get["stt"]);
    $sth = $core->text->link($core->post["sth"] ? $core->post["sth"] : $core->get["sth"]);
    $stw = $core->text->link($core->post["stw"] ? $core->post["stw"] : $core->get["stw"]);
    $stn = $core->text->link($core->post["stn"] ? $core->post["stn"] : $core->get["stn"]);
    if (!$st) {
        return false;
    }
    if ($stn && $st == $stn) {
        return array("status" => 1);
    }
    if ($sta && $st == $sta) {
        return array("accept" => 1);
    }
    if ($stc && $st == $stc) {
        return array("status" => 5);
    }
    if ($stt && $st == $stt) {
        return array("status" => 5, "reason" => 6);
    }
    if ($sth && $st == $sth) {
        return array("hold" => true);
    }
    if ($stw && $st == $stw) {
        return array("status" => 3);
    }
    switch ($st) {
        case "a":
        case "accept":
        case "accepted":
        case "approve":
        case "approved":
        case "confirm":
        case "confirmed":
        case "1":
            return array("accept" => 1);
        case "h":
        case "hold":
        case "holding":
            return array("hold" => true);
        case "c":
        case "d":
        case "decline":
        case "declined":
        case "cancel":
        case "cancelled":
        case "canceled":
        case "rejected":
        case "reject":
        case "-1":
            return array("status" => 5);
        case "t":
        case "trash":
        case "error":
        case "wrong":
        case "bad":
            return array("status" => 5, "reason" => 6);
    }
    return false;
}
function api_site_auth($core)
{
    $token = $core->post["token"] ? $core->post["token"] : $core->get["token"];
    $tx = explode("-", $token);
    $sid = (int) $tx[0];
    $key = $core->text->link($tx[1]);
    if (!$sid) {
        return false;
    }
    $sk = $core->cpa->get("site", $sid, "site_key");
    return $key == $sk ? $sid : false;
}
function api_site_add($core, $user)
{
    $sid = api_site_auth($core);
    if (!$sid) {
        return array("status" => "error", "error" => "auth");
    }
    $fields = array("offer", "from", "flow", "test", "exti", "extu", "exts", "exto", "country", "name", "phone", "email", "index", "area", "city", "street", "addr", "ip", "ua", "count", "discount", "comm", "more", "promo", "currency", "mobile", "bad", "meta", "base", "delivery", "delpr", "total", "us", "uc", "um", "un", "ut", "params", "accept");
    $data = array();
    foreach ($fields as $f) {
        if (isset($core->post[$f])) {
            $data[$f] = $core->post[$f];
        }
    }
    $data["site"] = $sid;
    if (!$data["offer"]) {
        return array("status" => "error", "error" => "nooffer");
    }
    if (!$data["phone"]) {
        return array("status" => "error", "error" => "nophone");
    }
    if (isset($data["currency"]) && !is_numeric($data["currency"])) {
        $cur = strtolower($data["currency"]);
        if ($core->currency->id($cur)) {
            $data["currency"] = $core->currency->id($cur);
        } else {
            $data["currency"] = $core->currency->country($data["country"]);
        }
    } else {
        if (!isset($data["currency"])) {
            $data["currency"] = $core->currency->country($data["country"]);
        }
    }
    require_once PATH_MODS . "order-add.php";
    $oid = neworder($core, $data, $core->files["file"] ? $core->files["file"] : false);
    if (is_numeric($oid)) {
        return array("status" => "ok", "id" => $oid);
    }
    return array("status" => "error", "error" => $oid);
}
function api_site_paid($core, $user)
{
    $sid = api_site_auth($core);
    if (!$sid) {
        return array("status" => "error", "error" => "auth");
    }
    $oid = isset($core->post["order"]) ? (int) $core->post["order"] : (int) $core->get["order"];
    if (!$oid) {
        return array("status" => "error", "error" => "no-id");
    }
    $od = $core->db->row("SELECT offer_id, site_id, order_status FROM " . DB_ORDER . " WHERE order_id = '" . $oid . "' LIMIT 1");
    if (!$od) {
        return array("status" => "error", "error" => "bad-id");
    }
    if ($od["site_id"] != $sid) {
        $oid = $core->cpa->get("site", $sid, "offer_id");
        if ($od["offer_id"] != $oid) {
            return array("status" => "error", "error" => "wrong-site");
        }
    }
    $type = isset($core->post["type"]) ? (int) $core->post["type"] : (int) $core->get["type"];
    $from = isset($core->post["from"]) ? $core->text->line($core->post["from"]) : $core->text->line($core->get["from"]);
    $changes = array("paid" => $type, "paidfrom" => $from);
    if (!$od["order_status"]) {
        $changes["status"] = 1;
    }
    require_once PATH_MODS . "order-edit.php";
    define("INTHEWORK", true);
    if (order_edit($core, $oid, $changes)) {
        return array("status" => "ok");
    }
    return array("status" => "error", "error" => "db");
}
function api_site_click($core, $user)
{
    $sid = api_site_auth($core);
    if (!$sid) {
        return array("status" => "error", "error" => "auth");
    }
    $cid = (int) $core->get["click"];
    if (!$cid) {
        return array("status" => "error", "error" => "no-id");
    }
    $c = $core->db->row("SELECT * FROM " . DB_CLICK . " WHERE click_id = '" . $cid . "' LIMIT 1");
    if ($c) {
        $order = array("offer" => $core->cpa->get("site", $sid, "offer_id"), "site" => $c["click_space"] ? $c["site_sib"] : $c["site_id"], "from" => $c["click_space"] ? $c["site_id"] : $c["site_sib"], "flow" => $c["flow_id"], "test" => $c["test_id"], "click" => $c["click_id"], "ip" => int2ip($c["click_ip"]), "phone" => "1234567890", "country" => $c["click_geo"], "exti" => $c["ext_id"], "extu" => $c["ext_uid"], "exts" => $c["ext_src"], "us" => $c["utms"], "uc" => $c["utmc"], "un" => $c["utmn"], "ut" => $c["utmt"], "um" => $c["utmm"]);
    } else {
        $o = $core->db->row("SELECT * FROM " . DB_ORDER . " WHERE click_id = '" . $cid . "' LIMIT 1");
        if (!$o) {
            return array("status" => "error", "error" => "bad-id");
        }
        $order = array("offer" => $core->cpa->get("site", $sid, "offer_id"), "site" => $o["site_id"], "from" => $o["space_id"], "flow" => $o["flow_id"], "test" => $o["test_id"], "click" => $o["click_id"], "ip" => int2ip($o["order_ip"]), "phone" => $o["order_phone"], "country" => $o["order_country"], "exti" => $o["ext_id"], "extu" => $o["ext_uid"], "exts" => $o["ext_src"], "us" => $o["utms"], "uc" => $o["utmc"], "un" => $o["utmn"], "ut" => $o["utmt"], "um" => $o["utmm"]);
    }
    if (isset($core->get["accept"])) {
        $order["accept"] = $core->get["accept"] ? true : false;
    }
    if (isset($core->get["name"])) {
        $order["name"] = $core->text->anum($core->get["name"]);
    }
    if (isset($core->get["phone"])) {
        $order["phone"] = $core->text->number($core->get["phone"]);
    }
    if (isset($core->get["email"])) {
        $order["email"] = $core->text->email($core->get["email"]);
    }
    if (isset($core->get["country"])) {
        $order["country"] = $core->text->link($core->get["country"]);
    }
    if (isset($core->get["base"])) {
        $order["base"] = $core->text->float($core->get["base"]);
    }
    if (isset($core->get["count"])) {
        $order["count"] = (int) $core->get["count"];
    }
    if (isset($core->get["delpr"])) {
        $order["delpr"] = $core->text->float($core->get["delpr"]);
    }
    if (isset($core->get["comment"])) {
        $order["comm"] = $core->text->line($core->get["comment"]);
    }
    if (isset($core->get["mobile"])) {
        $order["mobile"] = $core->get["mobile"] ? 1 : 0;
    }
    if (isset($core->get["bad"])) {
        $order["bad"] = $core->get["bad"] ? 1 : 0;
    }
    if (isset($core->get["exto"])) {
        $order["exto"] = $core->text->link($core->get["exto"]);
    }
    if (isset($core->post["accept"])) {
        $order["accept"] = $core->post["accept"] ? true : false;
    }
    if (isset($core->post["name"])) {
        $order["name"] = $core->text->anum($core->post["name"]);
    }
    if (isset($core->post["phone"])) {
        $order["phone"] = $core->text->number($core->post["phone"]);
    }
    if (isset($core->post["email"])) {
        $order["email"] = $core->text->email($core->post["email"]);
    }
    if (isset($core->post["country"])) {
        $order["country"] = $core->text->link($core->post["country"]);
    }
    if (isset($core->post["base"])) {
        $order["base"] = $core->text->float($core->post["base"]);
    }
    if (isset($core->post["count"])) {
        $order["count"] = (int) $core->post["count"];
    }
    if (isset($core->post["delpr"])) {
        $order["delpr"] = $core->text->float($core->post["delpr"]);
    }
    if (isset($core->post["mobile"])) {
        $order["mobile"] = $core->post["mobile"] ? 1 : 0;
    }
    if (isset($core->post["bad"])) {
        $order["bad"] = $core->post["bad"] ? 1 : 0;
    }
    if (isset($core->post["comment"])) {
        $order["comm"] = $core->text->line($core->post["comment"]);
    }
    if (isset($core->post["exto"])) {
        $order["exto"] = $core->text->link($core->post["exto"]);
    }
    if (isset($core->get["curr"]) || isset($core->post["curr"])) {
        $order["currency"] = isset($core->post["curr"]) ? (int) $core->post["curr"] : (int) $core->get["curr"];
    } else {
        if (isset($core->get["currency"]) || isset($core->post["currency"])) {
            $ci = isset($core->post["currency"]) ? $core->text->link($core->post["currency"]) : $core->text->link($core->get["currency"]);
            $order["currency"] = $core->currency->id($ci);
        } else {
            $order["currency"] = $core->currency->country($order["country"]);
        }
    }
    require_once PATH_MODS . "order-add.php";
    define("INTHEWORK", true);
    $oid = neworder($core, $order);
    if (is_numeric($oid)) {
        $st = api_guess_status($core);
        if ($st && $st["status"] != 1) {
            require_once PATH_MODS . "order-edit.php";
            order_edit($core, $oid, $st);
        }
        return array("status" => "ok", "id" => $oid);
    }
    return array("status" => "error", "error" => $oid);
}
function api_site_status($core, $user)
{
    $sid = api_site_auth($core);
    if (!$sid) {
        return array("status" => "error", "error" => "auth");
    }
    $cid = isset($core->post["click"]) ? (int) $core->post["click"] : (int) $core->get["click"];
    if (!$cid) {
        return array("status" => "error", "error" => "no-id");
    }
    $exto = isset($core->post["exto"]) ? $core->text->link($core->post["exto"]) : $core->text->link($core->get["exto"]);
    if ($exto) {
        $od = $core->db->row("SELECT order_id, offer_id, site_id FROM " . DB_ORDER . " WHERE click_id = '" . $cid . "' AND ext_oid = '" . $exto . "' LIMIT 1");
    } else {
        $od = $core->db->row("SELECT order_id, offer_id, site_id FROM " . DB_ORDER . " WHERE click_id = '" . $cid . "' LIMIT 1");
    }
    if (!$od) {
        return array("status" => "error", "error" => "bad-id");
    }
    if ($od["site_id"] != $sid) {
        $oid = $core->cpa->get("site", $sid, "offer_id");
        if ($od["offer_id"] != $oid) {
            return array("status" => "error", "error" => "wrong-site");
        }
    }
    $changes = api_guess_status($core);
    if (!$changes) {
        return array("status" => "error", "error" => "bad-status");
    }
    if ($changes["status"] == 1) {
        return api_site_click($core, $user);
    }
    if (isset($core->get["name"])) {
        $changes["name"] = $core->text->anum($core->get["name"]);
    }
    if (isset($core->get["phone"])) {
        $changes["phone"] = $core->text->number($core->get["phone"]);
    }
    if (isset($core->get["email"])) {
        $changes["email"] = $core->text->email($core->get["email"]);
    }
    if (isset($core->get["country"])) {
        $changes["country"] = $core->text->link($core->get["country"]);
    }
    if (isset($core->get["base"])) {
        $changes["base"] = $core->text->float($core->get["base"]);
    }
    if (isset($core->get["count"])) {
        $changes["count"] = (int) $core->get["count"];
    }
    if (isset($core->get["delpr"])) {
        $changes["delpr"] = $core->text->float($core->get["delpr"]);
    }
    if (isset($core->get["comment"])) {
        $changes["comment"] = $core->text->line($core->get["comment"]);
    }
    if (isset($core->get["reason"])) {
        $changes["reason"] = (int) $core->get["reason"];
    }
    if (isset($core->get["mobile"])) {
        $changes["mobile"] = $core->get["mobile"] ? 1 : 0;
    }
    if (isset($core->get["bad"])) {
        $changes["bad"] = $core->get["bad"] ? 1 : 0;
    }
    if (isset($core->post["name"])) {
        $changes["name"] = $core->text->anum($core->post["name"]);
    }
    if (isset($core->post["phone"])) {
        $changes["phone"] = $core->text->number($core->post["phone"]);
    }
    if (isset($core->post["email"])) {
        $changes["email"] = $core->text->email($core->post["email"]);
    }
    if (isset($core->post["country"])) {
        $changes["country"] = $core->text->link($core->post["country"]);
    }
    if (isset($core->post["base"])) {
        $changes["base"] = $core->text->float($core->post["base"]);
    }
    if (isset($core->post["count"])) {
        $changes["count"] = (int) $core->post["count"];
    }
    if (isset($core->post["delpr"])) {
        $changes["delpr"] = $core->text->float($core->post["delpr"]);
    }
    if (isset($core->post["comment"])) {
        $changes["comment"] = $core->text->line($core->post["comment"]);
    }
    if (isset($core->post["reason"])) {
        $changes["reason"] = (int) $core->post["reason"];
    }
    if (isset($core->post["mobile"])) {
        $changes["mobile"] = $core->post["mobile"] ? 1 : 0;
    }
    if (isset($core->post["bad"])) {
        $changes["bad"] = $core->post["bad"] ? 1 : 0;
    }
    if (isset($core->get["curr"]) || isset($core->post["curr"])) {
        $changes["currency"] = isset($core->post["curr"]) ? (int) $core->post["curr"] : (int) $core->get["curr"];
    } else {
        if (isset($core->get["currency"]) || isset($core->post["currency"])) {
            $ci = isset($core->post["currency"]) ? $core->text->link($core->post["currency"]) : $core->text->link($core->get["currency"]);
            $changes["currency"] = $core->currency->id($ci);
        }
    }
    require_once PATH_MODS . "order-edit.php";
    define("INTHEWORK", true);
    if (order_edit($core, $od["order_id"], $changes)) {
        return array("status" => "ok");
    }
    return array("status" => "error", "error" => "db");
}
function api_wm_add($core, $user)
{
    $offer = isset($core->post["offer"]) ? (int) $core->post["offer"] : (int) $core->get["offer"];
    if (!$offer) {
        return array("status" => "error", "error" => "no-id");
    }
    $oid = $core->flow->add($user, $offer);
    if ($oid) {
        if (0 < $oid) {
            return array("status" => "ok", "id" => $oid);
        }
        return array("status" => "error", "error" => "offer-inactive");
    }
    return array("status" => "error", "error" => "request-error");
}
function api_wm_edit($core, $user)
{
    $flow = isset($core->post["flow"]) ? (int) $core->post["flow"] : (int) $core->get["flow"];
    if (!$flow) {
        return array("status" => "error", "error" => "no-id");
    }
    $result = $core->flow->edit($user, $flow, $core->post);
    if ($result) {
        if (0 < $result) {
            return array("status" => "ok");
        }
        return array("status" => "error", "error" => "access-denied");
    }
    return array("status" => "error", "error" => "request-error");
}
function api_wm_del($core, $user)
{
    $flow = isset($core->post["flow"]) ? (int) $core->post["flow"] : (int) $core->get["flow"];
    if (!$flow) {
        return array("status" => "error", "error" => "no-id");
    }
    $result = $core->flow->del($user, $flow);
    if ($result) {
        if (0 < $result) {
            return array("status" => "ok");
        }
        return array("status" => "error", "error" => "access-denied");
    }
    return array("status" => "error", "error" => "request-error");
}
function api_wm_flows($core, $user)
{
    $oid = (int) $core->post["offer"];
    $flows = $core->db->data("SELECT * FROM " . DB_FLOW . " WHERE user_id = '" . $user . "'" . ($oid ? " AND offer_id = '" . $oid . "' " : ""));
    $offer = $core->cpa->get("offersa");
    $result = array();
    foreach ($flows as $f) {
        $result[(int) $f["flow_id"]] = array("id" => (int) $f["flow_id"], "url" => $core->flow->url($f["flow_id"]), "offer" => (int) $f["offer_id"], "offername" => $offer[$f["offer_id"]], "name" => $f["flow_name"], "epc" => (double) $f["flow_epc"], "cr" => (double) $f["flow_convert"], "total" => (double) $f["flow_total"], "site" => (int) $f["flow_site"], "siteurl" => $f["flow_site"] ? $core->cpa->get("site", $f["flow_site"], "site_url") : false, "space" => (int) $f["flow_space"], "spaceurl" => $f["flow_space"] ? $core->cpa->get("site", $f["flow_space"], "site_url") : false, "traffback" => $f["flow_url"], "postback" => $f["flow_pbu"], "metrika" => $f["flow_mtrk"], "google" => $f["flow_ga"], "vkcom" => $f["flow_vk"], "facebook" => $f["flow_fb"], "utm_source" => $f["flow_utms"], "utm_campaign" => $f["flow_utmc"], "utm_content" => $f["flow_utmn"], "utm_term" => $f["flow_utmt"], "utm_medium" => $f["flow_utmm"]);
    }
    unset($f);
    unset($flows);
    return $result;
}
function api_wm_push($core, $user)
{
    $ud = $core->user->get($user);
    if (!$ud["user_push"]) {
        return array("status" => "error", "error" => "access");
    }
    $fields = array("offer", "site", "flow", "from", "country", "name", "phone", "email", "index", "area", "city", "street", "addr", "ip", "ua", "count", "discount", "comm", "more", "promo", "currency", "mobile", "bad", "meta", "base", "total", "us", "uc", "um", "un", "ut", "params");
    $data = array();
    foreach ($fields as $f) {
        if (isset($core->post[$f])) {
            $data[$f] = $core->post[$f];
        }
    }
    if ($data["flow"]) {
        $flow = $core->cpa->get("flow", $data["flow"]);
        if ($flow["user_id"] != $user) {
            return array("status" => "error", "error" => "badflow");
        }
        if (!$data["offer"]) {
            return array("status" => "error", "error" => "nooffer");
        }
        if (!$data["phone"]) {
            return array("status" => "error", "error" => "nophone");
        }
        if (isset($data["currency"]) && !is_numeric($data["currency"])) {
            $cur = strtolower($data["currency"]);
            if ($core->currency->id($cur)) {
                $data["currency"] = $core->currency->id($cur);
            } else {
                if ($data["country"]) {
                    $data["currency"] = $core->currency->country($data["country"]);
                }
            }
        } else {
            if (!isset($data["currency"]) && $data["country"]) {
                $data["currency"] = $core->currency->country($data["country"]);
            }
        }
        require_once PATH_MODS . "order-add.php";
        $oid = neworder($core, $data);
        if (is_numeric($oid)) {
            return array("status" => "ok", "id" => $oid);
        }
        return array("status" => "error", "error" => $oid);
    }
    return array("status" => "error", "error" => "noflow");
}
function api_wm_offers($core, $user)
{
    $result = array();
    $offer = isset($core->post["offer"]) ? (int) $core->post["offer"] : (int) $core->get["offer"];
    $where = $offer ? "offer_id = '" . $offer . "'" : "offer_active = 1";
    $offers = $core->db->data("SELECT * FROM " . DB_OFFER . " WHERE " . $where . " ORDER BY offer_name ASC");
    foreach ($offers as &$o) {
        if (!$o["offer_active"]) {
            continue;
        }
        if (!$core->offer->auth($o["offer_id"], $user)) {
            continue;
        }
        $of = array("id" => (int) $o["offer_id"], "cid" => (int) $o["cat_id"], "cat" => $core->lang["offer_cats"][$o["cat_id"]], "name" => $o["offer_text"] ? $o["offer_text"] : $o["offer_name"], "short" => $o["offer_name"], "epc" => (double) sprintf("%0.2f", $o["offer_epc"]), "cr" => (double) sprintf("%0.2f", $o["offer_convert"]), "appr" => (double) sprintf("%0.2f", $o["offer_approve"]), "geo" => array(), "land" => array(), "space" => array());
        $geo = $core->offer->price($o["offer_id"], $user);
        foreach ($geo as $gi => $g) {
            $of["geo"][$gi] = array("code" => $g["code"], "name" => $g["name"], "price" => $g["lp"], "currency" => $core->currency->code($g["lc"]), "cr" => (double) $g["cr"], "epc" => (double) $g["epcv"], "approve" => (double) $g["appr"], "desktop" => array("base" => (double) $g["dsk"], "upsale" => (double) $g["dsku"], "xsale" => (double) $g["dskx"], "percent" => (double) $g["dskp"], "currency" => isset($g["dskc"]) && $g["dskc"] !== false ? $core->currency->code($g["dskc"]) : $core->currency->code($core->currency->default)), "mobile" => array("base" => (double) $g["mob"], "upsale" => (double) $g["mobu"], "xsale" => (double) $g["mobx"], "percent" => (double) $g["mobp"], "currency" => isset($g["mobc"]) && $g["mobc"] !== false ? $core->currency->code($g["mobc"]) : $core->currency->code($core->currency->default)));
        }
        $sites = $core->cpa->get("sites", $o["offer_id"]);
        foreach ($sites as $s) {
            $of[$s["site_type"] == 1 ? "space" : "land"][(int) $s["site_id"]] = array("id" => (int) $s["site_id"], "url" => "http://" . trim($s["site_url"], "/") . "/", "epc" => (double) sprintf("%0.2f", $s["site_epc"]), "cr" => (double) sprintf("%0.2f", $s["site_convert"] * 100), "approve" => (double) sprintf("%0.2f", $s["site_approve"]), "mobile" => (int) $s["site_mobile"], "default" => (bool) $s["site_default"]);
        }
        unset($sites);
        unset($s);
        $result[(int) $o["offer_id"]] = $of;
    }
    unset($o);
    unset($offers);
    return $result;
}
function api_wm_pub($core, $user = false)
{
    $offers = $core->db->data("SELECT offer_id, cat_id, offer_name, offer_descr, offer_text, offer_country, offer_prt FROM " . DB_OFFER . " WHERE offer_active = 1 AND offer_private IN ( 0, 2 ) AND offer_block = 0 ORDER BY offer_sort DESC, offer_name ASC");
    $defurl = $core->db->icol("SELECT offer_id, site_url FROM " . DB_SITE . " WHERE site_type IN ( 0, 2 ) AND site_default = 1");
    $result = array();
    foreach ($offers as &$o) {
        if (!$defurl[$o["offer_id"]]) {
            $uu = $core->db->field("SELECT site_url FROM " . DB_SITE . " WHERE site_type IN ( 0, 2 ) AND offer_id = '" . $o["offer_id"] . "' LIMIT 1");
        } else {
            $uu = $defurl[$o["offer_id"]];
        }
        $geo = explode(",", $o["offer_country"]);
        $price = array();
        $prt = unserialize($o["offer_prt"]);
        foreach ($geo as $g) {
            $price[$g] = $prt[$core->currency->country($g)];
        }
        $result[(int) $o["offer_id"]] = array("cat" => $o["cat_id"], "category" => $core->lang["offer_cats"][$o["cat_id"]], "id" => (int) $o["offer_id"], "name" => $o["offer_descr"] ? $o["offer_descr"] : ($o["offer_text"] ? $o["offer_text"] : $o["offer_name"]), "url" => $uu, "image" => $core->config("url", "base") . "data/offer/" . $o["offer_id"] . ".jpg", "imgt" => @filemtime(PATH . "data/offer/" . $o["offer_id"] . ".jpg"), "geo" => $geo, "price" => $price);
    }
    unset($o);
    unset($offers);
    return $result;
}
function api_wm_cpad($core, $user)
{
    $offers = $core->db->data("SELECT * FROM " . DB_OFFER . " WHERE offer_active = 1 AND offer_private = 0 ORDER BY offer_name ASC");
    $defurl = $core->db->icol("SELECT offer_id, site_url FROM " . DB_SITE . " WHERE site_type IN ( 0, 2 ) AND site_default = 1");
    $result = array();
    foreach ($offers as &$o) {
        if (!$defurl[$o["offer_id"]]) {
            $uu = $core->db->field("SELECT site_url FROM " . DB_SITE . " WHERE site_type IN ( 0, 2 ) AND offer_id = '" . $o["offer_id"] . "' LIMIT 1");
        } else {
            $uu = $defurl[$o["offer_id"]];
        }
        $oid = (int) $o["offer_id"];
        $result[$oid] = array("id" => (int) $o["offer_id"], "title" => $o["offer_name"], "url" => $uu, "description" => $o["offer_text"], "postclick" => 30, "geo" => array("country" => array()), "goals" => array(), "landings" => array(), "transits" => array(), "cats" => array(array("catId" => $o["cat_id"], "title" => $core->lang["offer_cats"][$o["cat_id"]])));
        $geo = $o["offer_country"] ? explode(",", $o["offer_country"]) : array("ru");
        foreach ($geo as $g) {
            if ($g = trim($g)) {
                $result[$oid]["geo"]["country"][] = array("code" => strtoupper($g), "name" => $core->lang["country"][$g]);
            }
        }
        $price = $core->offer->price($oid);
        foreach ($price as $p) {
            if ($p["dsk"] != $p["mob"]) {
                if ($p["dsk"]) {
                    $result[$oid]["goals"][] = array("title" => "Подтверждённый заказ " . strtoupper($p["code"]) . " Web", "profit" => $p["dsk"], "currency" => "RUB", "geo" => strtoupper($p["code"]));
                }
                if ($p["mob"]) {
                    $result[$oid]["goals"][] = array("title" => "Подтверждённый заказ " . strtoupper($p["code"]) . " Mobile", "profit" => $p["mob"], "currency" => "RUB", "geo" => strtoupper($p["code"]));
                }
            } else {
                $result[$oid]["goals"][] = array("title" => "Подтверждённый заказ " . strtoupper($p["code"]), "profit" => $p["dsk"], "currency" => "RUB", "geo" => strtoupper($p["code"]));
            }
        }
        $lands = $core->cpa->get("lands", $o["offer_id"]);
        foreach ($lands as $s) {
            $result[$oid]["landings"][] = array("url" => "http://" . $s["site_url"], "title" => $s["site_name"] ? $s["site_name"] : $s["site_url"]);
        }
        $space = $core->cpa->get("space", $o["offer_id"]);
        foreach ($space as $s) {
            $result[$oid]["transits"][] = array("url" => "http://" . $s["site_url"], "title" => $s["site_name"] ? $s["site_name"] : $s["site_url"]);
        }
    }
    unset($o);
    unset($offers);
    return $result;
}
function api_wm_land($core, $user = false)
{
    $id = (int) $core->get["oid"];
    if (!$id) {
        return false;
    }
    $lands = $core->cpa->get("lands", $id);
    $space = $core->cpa->get("space", $id);
    $default = 0;
    $elands = $espace = array();
    foreach ($lands as $l) {
        if (!$default) {
            $default = $l["site_id"];
        }
        if ($l["site_default"]) {
            $default = $l["site_id"];
        }
        $elands[$l["site_id"]] = "http://" . $l["site_url"] . "/?";
    }
    foreach ($space as $l) {
        $espace[$l["site_url"]] = (int) $l["site_id"];
    }
    return array("default" => $default, "lands" => $elands, "space" => $espace);
}
function api_wm_sites($core, $user = false)
{
    $result = array("land" => array(), "space" => array());
    $offer = isset($core->post["offer"]) ? (int) $core->post["offer"] : (int) $core->get["offer"];
    if (!$core->offer->auth($offer, $user)) {
        return $result;
    }
    $sites = $core->cpa->get("sites", $offer);
    foreach ($sites as $s) {
        $result[$s["site_type"] == 1 ? "space" : "land"][(int) $s["site_id"]] = array("id" => (int) $s["site_id"], "url" => "http://" . trim($s["site_url"], "/") . "/", "epc" => sprintf("%0.2f", $s["site_epc"]), "cr" => sprintf("%0.2f", $s["site_convert"] * 100), "approve" => sprintf("%0.2f", $s["site_approve"]), "mobile" => (int) $s["site_mobile"]);
    }
    unset($sites);
    unset($s);
    return $result;
}
function api_wm_stats($core, $user)
{
    $today = date("Ymd");
    $week1 = date("Ymd", strtotime("-6 days"));
    $u = $core->user->get($user);
    extract(params($core, array("to" => "date", "from" => "date", "offer", "flow")));
    if (!$to || $today < $to) {
        $to = $today;
    }
    if ($to < $from) {
        $from = $to;
    }
    if (!$from) {
        $from = $week1;
    }
    if ($u["user_ext"]) {
        $where = "ext_id = '" . $u["user_ext"] . "'";
        if ($offer) {
            $where .= " AND offer_id = '" . $offer . "'";
        }
    } else {
        if ($flow) {
            $fu = $core->cpa->get("flow", $flow, "user_id");
            if ($fu != $user) {
                return array("status" => "error", "error" => "access");
            }
            $where = "flow_id = '" . $flow . "'";
        } else {
            $where = "user_id = '" . $u["user_id"] . "'";
            if ($offer) {
                $where .= " AND offer_id = '" . $offer . "'";
            }
        }
    }
    if ($where) {
        require_once PATH_MODS . "wm-api.php";
        return wm_stats_daily($core, $from, $to, $where);
    }
    return array();
}
function api_wm_click($core, $user)
{
    $where = array();
    $param = array();
    $today = date("Ymd");
    $week1 = date("Ymd", strtotime("-6 days"));
    extract(params($core, array("to" => "date", "from" => "date", "item" => "text", "offer", "flow", "site", "utms" => "text", "utmc" => "text", "utmn" => "text", "utmt" => "text", "utmm" => "text", "exti", "extu" => "text", "exts")));
    if (!$to || $today < $to) {
        $to = $today;
    }
    if ($to < $from) {
        $from = $to;
    }
    if (!$from) {
        $from = $week1;
    }
    $u = $core->user->get($user);
    if ($u["user_ext"]) {
        $where[] = "ext_id = '" . $u["user_ext"] . "'";
    } else {
        $where[] = "user_id = '" . $user . "'";
    }
    switch ($item) {
        case "offer":
            $type = "offer_id";
            $param["namelist"] = $core->cpa->get("offersa");
            break;
        case "flow":
            $type = "flow_id";
            $param["namelist"] = $core->cpa->get("flows", $user);
            break;
        case "site":
            $type = "site_id";
            $param["namelist"] = $core->cpa->get("sites");
            break;
        case "extu":
            $type = "ext_uid";
            break;
        case "exts":
            $type = "ext_src";
            break;
        case "utms":
            $type = "utms32";
            $param["name"] = "utms";
            break;
        case "utmc":
            $type = "utmc32";
            $param["name"] = "utmc";
            break;
        case "utmn":
            $type = "utmn32";
            $param["name"] = "utmn";
            break;
        case "utmt":
            $type = "utmt32";
            $param["name"] = "utmt";
            break;
        case "utmm":
            $type = "utmm32";
            $param["name"] = "utmm";
            break;
        default:
            return array();
    }
    if ($offer = (int) $offer) {
        $where[] = "offer_id = '" . $offer . "'";
    }
    if ($flow = (int) $flow) {
        $where[] = "flow_id = '" . $flow . "'";
    }
    if ($site = (int) $site) {
        $where[] = "site_id = '" . $site . "'";
    }
    if ($extu = addslashes(mb_substr(filter_var(stripslashes($extu), FILTER_SANITIZE_STRING), 0, 250))) {
        $where[] = "ext_uid = '" . $extu . "'";
    }
    if ($exts = addslashes(mb_substr(filter_var(stripslashes($exts), FILTER_SANITIZE_STRING), 0, 250))) {
        $where[] = "ext_src = '" . $exts . "'";
    }
    if ($utms) {
        $where[] = "utms = '" . sprintf("%u", crc32($utms)) . "'";
    }
    if ($utmc) {
        $where[] = "utms = '" . sprintf("%u", crc32($utmc)) . "'";
    }
    if ($utmn) {
        $where[] = "utms = '" . sprintf("%u", crc32($utmn)) . "'";
    }
    if ($utmt) {
        $where[] = "utms = '" . sprintf("%u", crc32($utmt)) . "'";
    }
    if ($utmm) {
        $where[] = "utms = '" . sprintf("%u", crc32($utmm)) . "'";
    }
    $where = implode(" AND ", $where);
    require_once PATH_MODS . "wm-api.php";
    return wm_stats_load($core, $type, $from, $to, $where, $param);
}
function api_wm_lead($core, $user)
{
    $where = array();
    $result = array();
    extract(params($core, array("day" => "date", "offer", "flow", "site", "status")));
    $where[] = "wm_id = '" . $user . "'";
    if ($offer) {
        $where[] = " offer_id = '" . $offer . "' ";
    }
    if ($site) {
        $where[] = " site_id = '" . $site . "' ";
    }
    if ($flow) {
        $where[] = " flow_id = '" . $flow . "' ";
    }
    $idsg = $core->post["ids"] ? explode(",", $core->post["ids"]) : ($core->get["ids"] ? explode(",", $core->get["ids"]) : array());
    $ids = array();
    foreach ($idsg as $i) {
        if ($i = (int) $i) {
            $ids[] = $i;
        }
    }
    $idsl = implode(",", $ids);
    if ($idsl) {
        $where[] = "order_id IN ( " . $idsl . " )";
    } else {
        if (!$day) {
            $day = date("Ymd");
        }
    }
    if ($day) {
        $d = date2form($day);
        $ds = strtotime($d . " 00:00:00");
        $de = strtotime($d . " 23:59:59");
        $where[] = " order_time BETWEEN '" . $ds . "' AND '" . $de . "' ";
    }
    switch ($status) {
        case "w":
            $where[] = "order_webstat IN ( " . implode(",", waitstatus()) . " )";
            break;
        case "c":
            $where[] = "order_webstat IN ( 5, 12 )";
            break;
        case "a":
            $where[] = "order_webstat IN ( " . implode(",", approvestatus()) . " )";
            break;
    }
    $where = implode(" AND ", $where);
    $order = $core->db->data("SELECT order_id, order_webstat, order_status, order_reason, order_auto, order_time, offer_id, flow_id, site_id, space_id, order_ip, order_comment, cash_wm, utms, utmn, utmc, utmt, utmm FROM " . DB_ORDER . " WHERE " . $where . " ORDER BY order_id DESC");
    foreach ($order as &$r) {
        $result[] = array("id" => (int) $r["order_id"], "time" => $r["order_time"], "stage" => whatstage($r["order_webstat"], $r["order_reason"]), "status" => (int) $r["order_webstat"], "reason" => (int) $r["order_reason"], "reason_text" => $r["order_reason"] ? $core->lang["reasono"][$r["order_reason"]] : ($r["order_webstat"] == 5 || $r["order_webstat"] == 12 ? $core->lang["noreason"] : ""), "hold" => (int) $r["order_auto"], "cash" => (double) $r["cash_wm"], "comment" => $o["order_status"] == $o["order_webstat"] ? $o["order_comment"] : "", "offer" => (int) $r["offer_id"], "offer_name" => $core->cpa->get("offer", $r["offer_id"], "offer_name"), "flow" => (int) $r["flow_id"], "site" => (int) $r["site_id"], "site_url" => $r["site_id"] ? $core->cpa->get("site", $r["site_id"], "site_url") : false, "space" => (int) $r["space_id"], "space_url" => $r["space_id"] ? $core->cpa->get("site", $r["space_id"], "site_url") : false, "ip" => int2ip($r["order_ip"]), "utm_source" => $r["utms"], "utm_content" => $r["utmn"], "utm_campaign" => $r["utmc"], "utm_medium" => $r["utmm"], "utm_term" => $r["utmt"]);
    }
    unset($r);
    unset($order);
    return $result;
}
function api_comp_list($core, $user)
{
    $ud = $core->user->get($user);
    $cid = $ud["user_comp"];
    if (!$cid) {
        return array("status" => "error", "error" => "access-denied");
    }
    $cmp = $core->cpa->get("comp", $cid);
    if ($cmp["comp_block"] && $ud["user_cash"] < $cmp["comp_block"]) {
        return array("status" => "error", "error" => "no-money");
    }
    $where = array("comp_id = '" . $cid . "'");
    if ($s = $core->post["status"] ? (int) $core->post["status"] : (int) $core->get["status"]) {
        if ($s < 0) {
            switch ($s) {
                case -1:
                    $where[] = "order_status NOT IN ( 5, 12 )";
                    break;
                case -2:
                    $where[] = "order_status < 5";
                    break;
                case -3:
                    $where[] = "order_status > 5 AND order_status < 12";
                    break;
            }
        } else {
            $where[] = "order_status = '" . $s . "'";
        }
    }
    if ($sg = (int) $core->get["stage"]) {
        $where[] = "order_stage = '" . $sg . "'";
    }
    if ($sg = (int) $core->post["stage"]) {
        $where[] = "order_stage = '" . $sg . "'";
    }
    if (isset($core->get["stagename"]) && ($sg = $core->cpa->stagebyslug($core->text->link($core->get["stagename"])))) {
        $where[] = "order_stage = '" . $sg . "'";
    }
    if (isset($core->post["stagename"]) && ($sg = $core->cpa->stagebyslug($core->text->link($core->post["stagename"])))) {
        $where[] = "order_stage = '" . $sg . "'";
    }
    if (isset($core->get["trackon"])) {
        $where[] = "track_on = '" . (int) $core->get["trackon"] . "'";
    }
    if (isset($core->post["trackon"])) {
        $where[] = "track_on = '" . (int) $core->post["trackon"] . "'";
    }
    if (isset($core->get["delivery"])) {
        $where[] = "order_delivery = '" . (int) $core->get["delivery"] . "'";
    }
    if (isset($core->post["delivery"])) {
        $where[] = "order_delivery = '" . (int) $core->post["delivery"] . "'";
    }
    $f = $core->post["from"] ? (int) $core->post["from"] : (int) $core->get["from"];
    $t = $core->post["to"] ? (int) $core->post["to"] : (int) $core->get["to"];
    if (!($f && $t)) {
        if ($f) {
            $where[] = "order_time > '" . $f . "'";
        }
        if ($t) {
            $where[] = "order_time < '" . $t . "'";
        }
    } else {
        $where[] = "order_time BETWEEN '" . $f . "' AND '" . $t . "'";
    }
    if ($id = $core->post["oid"] ? $core->post["oid"] : $core->get["oid"]) {
        $ids = explode(",", $id);
    } else {
        $ids = $core->post["ids"] ? $core->post["ids"] : $core->get["ids"];
    }
    if ($ids) {
        $ids = array_map("intval", $ids);
        if (1 < count($ids)) {
            $where[] = "order_id IN ( " . implode(", ", $ids) . " )";
        } else {
            if ($ids) {
                $where[] = "order_id = '" . $ids[0] . "'";
            }
        }
    }
    if ($eid = $core->post["eid"] ? $core->post["eid"] : $core->get["eid"]) {
        $eids = explode(",", $eid);
    } else {
        $eids = $core->post["eids"] ? $core->post["eids"] : $core->get["eids"];
    }
    if ($eids) {
        $eids = array_map("intval", $eids);
        if (1 < count($eids)) {
            $where[] = "ext_oid IN ( " . implode(", ", $eids) . " )";
        } else {
            if ($eids) {
                $where[] = "ext_oid = '" . $eids[0] . "'";
            }
        }
    }
    if ($o = $core->post["offer"] ? (int) $core->post["offer"] : (int) $core->get["offer"]) {
        $where[] = "offer_id = '" . $o . "'";
    }
    if ($o = $core->post["after"] ? (int) $core->post["after"] : (int) $core->get["after"]) {
        $where[] = "order_id > '" . $s . "'";
    }
    $items = array();
    $where = implode(" AND ", $where);
    $query = $core->db->start("SELECT * FROM " . DB_ORDER . " WHERE " . $where);
    while ($o = $core->db->one($query)) {
        $items[] = array("id" => (int) $o["order_id"], "ext" => (int) $o["ext_oid"], "offer" => (int) $o["offer_id"], "offername" => $core->cpa->get("offersa", 0, $o["offer_id"]), "wm" => (int) $o["wm_id"], "status" => (int) $o["order_status"], "reason" => (int) $o["order_reason"], "check" => (int) $o["order_check"], "calls" => (int) $o["order_calls"], "site" => (int) $o["site_id"], "siteurl" => $o["site_id"] ? $core->cpa->get("site", $o["site_id"], "site_url") : false, "space" => (int) $o["space_id"], "spaceurl" => $o["space_id"] ? $core->cpa->get("site", $o["space_id"], "site_url") : false, "ip" => int2ip($o["order_ip"]), "time" => (int) $o["order_time"], "name" => $o["order_name"], "gender" => (int) $o["order_gender"], "phone" => $o["order_phone"], "country" => $o["order_country"], "index" => $o["order_index"], "addr" => $o["order_addr"], "area" => $o["order_area"], "city" => $o["order_city"], "street" => $o["order_street"], "comment" => $o["order_comment"], "count" => (int) $o["order_count"], "items" => $o["order_items"] ? unserialize($o["order_items"]) : false, "delivery" => (int) $o["order_delivery"], "discount" => (int) $o["order_discount"], "currency" => $core->currency->code($o["price_cur"]), "base" => $o["price_base"], "more" => $o["price_more"], "delpr" => $o["price_delivery"], "price" => $o["price_total"]);
    }
    $core->db->stop($query);
    return $items;
}
function api_comp_edit($core, $user)
{
    $ud = $core->user->get($user);
    $cid = $ud["user_comp"];
    if (!$cid) {
        return array("status" => "error", "error" => "access-denied");
    }
    $cmp = $core->cpa->get("comp", $cid);
    if ($cmp["comp_block"] && $ud["user_cash"] < $cmp["comp_block"]) {
        return array("status" => "error", "error" => "no-money");
    }
    $core->user->load($ud);
    $id = $core->post["oid"] ? (int) $core->post["oid"] : (int) $core->get["oid"];
    $eid = $core->post["eid"] ? (int) $core->post["eid"] : (int) $core->get["eid"];
    if (!($id || $eid)) {
        return array("status" => "error", "error" => "orderid");
    }
    $order = $id ? $core->db->row("SELECT * FROM " . DB_ORDER . " WHERE comp_id = '" . $cid . "' AND order_id = '" . $id . "' LIMIT 1") : $core->db->row("SELECT * FROM " . DB_ORDER . " WHERE comp_id = '" . $cid . "' AND ext_oid = '" . $eid . "' LIMIT 1");
    if (!$order["order_id"]) {
        return array("status" => "error", "error" => "access");
    }
    $data = array();
    if (isset($core->get["accept"])) {
        $data["accept"] = (int) $core->get["accept"];
    }
    if (isset($core->get["status"])) {
        $data["status"] = (int) $core->get["status"];
    }
    if (isset($core->get["stage"])) {
        $data["stage"] = (int) $core->get["stage"];
    }
    if (isset($core->get["reason"])) {
        $data["reason"] = (int) $core->get["reason"];
    }
    if (isset($core->get["check"])) {
        $data["check"] = (int) $core->get["check"];
    }
    if (isset($core->get["track"])) {
        $data["track"] = $core->text->line($core->get["track"]);
    }
    if (isset($core->get["trackon"])) {
        $data["trackon"] = (int) $core->get["trackon"];
    }
    if (isset($core->get["calls"])) {
        $data["calls"] = (int) $core->get["calls"];
    }
    if (isset($core->post["accept"])) {
        $data["accept"] = (int) $core->post["accept"];
    }
    if (isset($core->post["status"])) {
        $data["status"] = (int) $core->post["status"];
    }
    if (isset($core->post["reason"])) {
        $data["reason"] = (int) $core->post["reason"];
    }
    if (isset($core->post["check"])) {
        $data["check"] = (int) $core->post["check"];
    }
    if (isset($core->post["track"])) {
        $data["track"] = $core->text->line($core->post["track"]);
    }
    if (isset($core->post["trackon"])) {
        $data["trackon"] = (int) $core->post["trackon"];
    }
    if (isset($core->post["calls"])) {
        $data["calls"] = (int) $core->post["calls"];
    }
    if (isset($core->post["name"])) {
        $data["name"] = $core->text->line($core->post["name"]);
    }
    if (isset($core->post["phone"])) {
        $data["phone"] = $core->text->line($core->post["phone"]);
    }
    if (isset($core->post["addr"])) {
        $data["addr"] = $core->text->line($core->post["addr"]);
    }
    if (isset($core->post["index"])) {
        $data["index"] = $core->text->line($core->post["index"]);
    }
    if (isset($core->post["area"])) {
        $data["area"] = $core->text->line($core->post["area"]);
    }
    if (isset($core->post["city"])) {
        $data["city"] = $core->text->line($core->post["city"]);
    }
    if (isset($core->post["street"])) {
        $data["street"] = $core->text->line($core->post["street"]);
    }
    if (isset($core->post["delivery"])) {
        $data["delivery"] = (int) $core->post["delivery"];
    }
    if (isset($core->post["discount"])) {
        $data["discount"] = (int) $core->post["discount"];
    }
    if (isset($core->post["count"])) {
        $data["count"] = (int) $core->post["count"];
    }
    if (isset($core->post["items"])) {
        $data["items"] = $core->post["items"];
    }
    if (isset($core->post["base"])) {
        $data["base"] = $core->text->float($core->post["base"]);
    }
    if (isset($core->post["delpr"])) {
        $data["delpr"] = $core->text->float($core->post["delpr"]);
    }
    if (isset($core->post["more"])) {
        $data["more"] = $core->text->float($core->post["more"]);
    }
    if (isset($core->post["comment"])) {
        $data["comment"] = $core->text->line($core->post["comment"]);
    }
    if (isset($core->post["message"])) {
        $data["message"] = $core->text->line($core->post["message"]);
    }
    require_once PATH_MODS . "order-edit.php";
    return order_edit($core, $order["order_id"], $data, $order) ? array("status" => "ok") : array("status" => "error", "error" => "edit");
}
function api_comp_status($core, $user)
{
    $ud = $core->user->get($user);
    $cid = $ud["user_comp"];
    if (!$cid) {
        return array("status" => "error", "error" => "access-denied");
    }
    $cmp = $core->cpa->get("comp", $cid);
    if ($cmp["comp_block"] && $ud["user_cash"] < $cmp["comp_block"]) {
        return array("status" => "error", "error" => "no-money");
    }
    $core->user->load($ud);
    $id = $core->post["oid"] ? (int) $core->post["oid"] : (int) $core->get["oid"];
    $eid = $core->post["eid"] ? (int) $core->post["eid"] : (int) $core->get["eid"];
    if (!($id || $eid)) {
        return array("status" => "error", "error" => "orderid");
    }
    $order = $id ? $core->db->row("SELECT * FROM " . DB_ORDER . " WHERE comp_id = '" . $cid . "' AND order_id = '" . $id . "' LIMIT 1") : $core->db->row("SELECT * FROM " . DB_ORDER . " WHERE comp_id = '" . $cid . "' AND ext_oid = '" . $eid . "' LIMIT 1");
    if (!$order["order_id"]) {
        return array("status" => "error", "error" => "access");
    }
    $changes = api_guess_status($core);
    if (!$changes) {
        return array("status" => "error", "error" => "bad-status");
    }
    if (isset($core->get["name"])) {
        $changes["name"] = $core->text->anum($core->get["name"]);
    }
    if (isset($core->get["phone"])) {
        $changes["phone"] = $core->text->number($core->get["phone"]);
    }
    if (isset($core->get["email"])) {
        $changes["email"] = $core->text->email($core->get["email"]);
    }
    if (isset($core->get["country"])) {
        $changes["country"] = $core->text->link($core->get["country"]);
    }
    if (isset($core->get["base"])) {
        $changes["base"] = $core->text->float($core->get["base"]);
    }
    if (isset($core->get["count"])) {
        $changes["count"] = (int) $core->get["count"];
    }
    if (isset($core->get["delpr"])) {
        $changes["delpr"] = $core->text->float($core->get["delpr"]);
    }
    if (isset($core->get["comment"])) {
        $changes["comment"] = $core->text->line($core->get["comment"]);
    }
    if (isset($core->post["name"])) {
        $changes["name"] = $core->text->anum($core->post["name"]);
    }
    if (isset($core->post["phone"])) {
        $changes["phone"] = $core->text->number($core->post["phone"]);
    }
    if (isset($core->post["email"])) {
        $changes["email"] = $core->text->email($core->post["email"]);
    }
    if (isset($core->post["country"])) {
        $changes["country"] = $core->text->link($core->post["country"]);
    }
    if (isset($core->post["base"])) {
        $changes["base"] = $core->text->float($core->post["base"]);
    }
    if (isset($core->post["count"])) {
        $changes["count"] = (int) $core->post["count"];
    }
    if (isset($core->post["delpr"])) {
        $changes["delpr"] = $core->text->float($core->post["delpr"]);
    }
    if (isset($core->post["comment"])) {
        $changes["comment"] = $core->text->line($core->post["comment"]);
    }
    if (isset($core->get["curr"]) || isset($core->post["curr"])) {
        $changes["currency"] = isset($core->post["curr"]) ? (int) $core->post["curr"] : (int) $core->get["curr"];
    } else {
        if (isset($core->get["currency"]) || isset($core->post["currency"])) {
            $ci = isset($core->post["currency"]) ? $core->text->link($core->post["currency"]) : $core->text->link($core->get["currency"]);
            $changes["currency"] = $core->currency->id($ci);
        }
    }
    require_once PATH_MODS . "order-edit.php";
    return order_edit($core, $order["order_id"], $changes, $order) ? array("status" => "ok") : array("status" => "error", "error" => "edit");
}
function api_comp_retrack($core, $user)
{
    $ud = $core->user->get($user);
    $cid = $ud["user_comp"];
    if (!$cid) {
        return array("status" => "error", "error" => "access-denied");
    }
    $cmp = $core->cpa->get("comp", $cid);
    if ($cmp["comp_block"] && $ud["user_cash"] < $cmp["comp_block"]) {
        return array("status" => "error", "error" => "no-money");
    }
    $core->user->load($ud);
    $id = $core->post["oid"] ? (int) $core->post["oid"] : (int) $core->get["oid"];
    $eid = $core->post["eid"] ? (int) $core->post["eid"] : (int) $core->get["eid"];
    if (!($id || $eid)) {
        return array("status" => "error", "error" => "orderid");
    }
    if ($id) {
        $cc = $core->db->field("SELECT comp_id FROM " . DB_ORDER . " WHERE order_id = '" . $id . "' LIMIT 1");
        $otp = $cc == $cid ? $id : 0;
    } else {
        $otp = $core->db->field("SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $cid . "' AND ext_oid = '" . $eid . "' LIMIT 1");
    }
    if (!$otp) {
        return array("status" => "error", "error" => "access");
    }
    return $core->cpa->dltrack($otp) ? array("status" => "ok") : array("status" => "error", "error" => "edit");
}
function api_comp_delivery($core, $user)
{
    $ud = $core->user->get($user);
    $cid = $ud["user_comp"];
    if (!$cid) {
        return array("status" => "error", "error" => "access-denied");
    }
    $cmp = $core->cpa->get("comp", $cid);
    if ($cmp["comp_block"] && $ud["user_cash"] < $cmp["comp_block"]) {
        return array("status" => "error", "error" => "no-money");
    }
    $core->user->load($ud);
    $data = $core->cpa->dltypes($cid);
    foreach ($data as $i => &$d) {
        $d["name"] = $core->lang["delivery"][$i];
    }
    return $data;
}
function api_comp_goods($core, $user)
{
    $ud = $core->user->get($user);
    $cid = $ud["user_comp"];
    if (!$cid) {
        return array("status" => "error", "error" => "access-denied");
    }
    $cmp = $core->cpa->get("comp", $cid);
    if ($cmp["comp_block"] && $ud["user_cash"] < $cmp["comp_block"]) {
        return array("status" => "error", "error" => "no-money");
    }
    $goods = array();
    $offer = $core->db->data("SELECT offer_id, offer_name, offer_text, offer_prt, offer_vars, offer_country FROM " . DB_OFFER . " WHERE offer_active = 1");
    foreach ($offer as $o) {
        $id = (int) $o["offer_id"];
        if (!$core->offer->auth($id, $user)) {
            continue;
        }
        $goods[$id] = array("id" => $id, "name" => $o["offer_text"] ? $o["offer_text"] : $o["offer_name"], "short" => $o["offer_name"], "price" => array());
        $geo = explode(",", $o["offer_country"]);
        $prt = unserialize($o["offer_prt"]);
        foreach ($geo as $g) {
            $goods[$id]["price"][$g] = $prt[$core->currency->country($g)];
        }
        if ($o["offer_vars"]) {
            $goods[$id]["vars"] = array();
            $vars = $core->cpa->get("vars", $id);
            foreach ($vars as $v) {
                $vid = (int) $v["var_id"];
                $goods[$id]["vars"][$vid] = array("id" => $vid, "name" => $v["var_name"], "price" => array());
                $prt = unserialize($v["var_price"]);
                foreach ($geo as $g) {
                    $goods[$id]["vars"][$vid]["price"][$g] = $prt[$core->currency->country($g)];
                }
            }
        }
    }
    return $goods;
}
function api_ext_add($core, $user)
{
    $ud = $core->user->get($user);
    $ext = $core->cpa->get("ext", $ud["user_ext"]);
    if (!$ext) {
        return array("status" => "error", "error" => "no-ext");
    }
    $fields = array("offer", "country", "name", "phone", "email", "index", "area", "city", "street", "addr", "ip", "ua", "count", "discount", "comm", "more", "promo", "currency", "mobile", "bad", "meta", "base", "delivery", "delpr", "total", "us", "uc", "um", "un", "ut", "params", "accept", "calling", "exto");
    $data = array();
    foreach ($fields as $f) {
        if (isset($core->post[$f])) {
            $data[$f] = $core->post[$f];
        }
    }
    $data["exti"] = $ud["user_ext"];
    $data["extu"] = (int) $core->post["id"];
    $data["exts"] = (int) $core->post["wm"];
    if (!$data["offer"]) {
        return array("status" => "error", "error" => "nooffer");
    }
    if (!$data["extu"]) {
        return array("status" => "error", "error" => "noid");
    }
    if (!$data["phone"]) {
        return array("status" => "error", "error" => "nophone");
    }
    if (isset($data["currency"]) && !is_numeric($data["currency"])) {
        $cur = strtolower($data["currency"]);
        if ($core->currency->id($cur)) {
            $data["currency"] = $core->currency->id($cur);
        } else {
            if ($data["country"]) {
                $data["currency"] = $core->currency->country($data["country"]);
            }
        }
    } else {
        if (!isset($data["currency"]) && $data["country"]) {
            $data["currency"] = $core->currency->country($data["country"]);
        }
    }
    require_once PATH_MODS . "order-add.php";
    $oid = neworder($core, $data);
    if (is_numeric($oid)) {
        return array("status" => "ok", "id" => $oid);
    }
    return array("status" => "error", "error" => $oid);
}
function api_ext_list($core, $user)
{
    $ud = $core->user->get($user);
    $ext = $core->cpa->get("ext", $ud["user_ext"]);
    if (!$ext) {
        return array("status" => "error", "error" => "no-ext");
    }
    $where = array();
    $nouid = isset($core->get["nouid"]) ? true : false;
    $idsg = $core->post["ids"] ? explode(",", $core->post["ids"]) : ($core->get["ids"] ? explode(",", $core->get["ids"]) : array());
    if ($idsg) {
        $ids = array();
        foreach ($idsg as $i) {
            if ($i = (int) $i) {
                $ids[] = $i;
            }
        }
        $idsl = implode(",", $ids);
        $where[] = "ext_uid IN ( " . $idsl . " )";
    }
    $idso = $core->post["oid"] ? explode(",", $core->post["oid"]) : ($core->get["oid"] ? explode(",", $core->get["oid"]) : array());
    if ($idso) {
        $ids = array();
        foreach ($idso as $i) {
            if ($i = (int) $i) {
                $ids[] = $i;
            }
        }
        $idsl = implode(",", $ids);
        $where[] = "order_id IN ( " . $idsl . " )";
    }
    if ($ff = (int) $core->get["from"]) {
        $where[] = "order_id > " . $ff;
    }
    if ($fu = (int) $core->get["fuid"]) {
        $where[] = "ext_uid > " . $fu;
    }
    if (!$where) {
        return array();
    }
    $where = implode("AND", $where);
    $orders = $core->db->data("SELECT order_id, order_webstat, order_status, order_calls, order_reason, order_comment, order_count, order_bad, ext_uid, ext_src, cash_wm FROM " . DB_ORDER . " WHERE ext_id = '" . $ud["user_ext"] . "' AND " . $where);
    $result = array();
    foreach ($orders as $o) {
        $rr = array("id" => $o["ext_uid"], "src" => $o["ext_src"], "uid" => (int) $o["order_id"], "status" => (int) $o["order_webstat"], "reason" => (int) $o["order_reason"], "count" => (int) $o["order_count"], "calls" => (int) $o["order_calls"], "bad" => (int) $o["order_bad"], "cash" => $o["cash_wm"], "comment" => $o["order_status"] == $o["order_webstat"] ? $o["order_comment"] : "");
        if ($nouid) {
            $result[] = $rr;
        } else {
            $result[$o["ext_uid"]] = $rr;
        }
    }
    return $result;
}
function api_ext_info($core, $user)
{
    $ud = $core->user->get($user);
    $ext = $core->cpa->get("ext", $ud["user_ext"]);
    if (!$ext) {
        return array("status" => "error", "error" => "no-ext");
    }
    $oid = isset($core->post["oid"]) ? (int) $core->post["oid"] : (int) $core->get["oid"];
    $eid = isset($core->post["eid"]) ? (int) $core->post["eid"] : (int) $core->get["eid"];
    if (!$eid) {
        $eid = isset($core->post["ext"]) ? (int) $core->post["ext"] : (int) $core->get["ext"];
    }
    if ($eid) {
        $o = $core->db->row("SELECT * FROM " . DB_ORDER . " WHERE ext_id = '" . $ud["user_ext"] . "' AND ext_uid = '" . $eid . "' LIMIT 1");
    } else {
        if ($oid) {
            $o = $core->db->row("SELECT * FROM " . DB_ORDER . " WHERE ext_id = '" . $ud["user_ext"] . "' AND order_id = '" . $oid . "' LIMIT 1");
        } else {
            return array("status" => "error", "error" => "no-id");
        }
    }
    if (!$o["order_id"]) {
        return array("status" => "error", "error" => "no-order");
    }
    return array("id" => (int) $o["order_id"], "ext" => (int) $o["ext_uid"], "src" => (int) $o["ext_src"], "status" => (int) $o["order_webstat"], "reason" => (int) $o["order_reason"], "time" => (int) $o["order_time"], "mobile" => $o["order_mobile"] ? true : false, "bad" => $o["order_bad"] ? true : false, "check" => $o["order_check"] ? true : false, "offer" => (int) $o["offer_id"], "offername" => $core->cpa->get("offer", $o["offer_id"], "offer_name"), "ip" => int2ip($o["order_ip"]), "name" => $o["order_name"], "phone" => $o["order_phone"], "comment" => $o["order_status"] == $o["order_webstat"] ? $o["order_comment"] : "", "country" => $o["order_country"], "index" => $o["order_index"], "area" => $o["order_area"], "city" => $o["order_city"], "street" => $o["order_street"], "address" => $o["order_addr"], "delivery" => (int) $o["order_delivery"], "count" => (int) $o["order_count"], "currency" => (int) $o["price_cur"], "curcode" => strtoupper($core->currency->code($o["price_cur"])), "price" => (int) $o["price_total"], "base" => (int) $o["price_base"], "delpr" => (int) $o["price_delivery"], "more" => (int) $o["price_more"], "discount" => (int) $o["order_discount"], "promo" => $o["promo_code"], "track" => $o["track_code"], "items" => $o["order_items"] ? unserialize($o["order_items"]) : false, "meta" => $o["order_meta"] ? unserialize($o["order_meta"]) : false);
}

?>