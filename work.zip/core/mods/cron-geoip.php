<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function cronupdate_geoip($core)
{
    if (defined("IPDB_RU")) {
        loadipgeodb($core);
    } else {
        loadipgeodb($core, true);
    }
    if ($core->cando("cronupdate_geoip")) {
        $core->process("cronupdate_geoip");
    }
    $core->db->query("ALTER TABLE " . DB_GEOIP . " ORDER BY `ip` DESC");
    $core->db->query("ALTER TABLE " . DB_GEOCITY . " ORDER BY `id` ASC");
    $core->db->query("OPTIMIZE TABLE " . DB_GEOIP);
    $core->db->query("OPTIMIZE TABLE " . DB_GEOCITY);
    if (defined("GEOCODE")) {
        updategeocode($core, GEOCODE);
    }
    return time() + 1350000 + rand(0, 86400);
}
function updategeocode($core, $path)
{
    file_put_contents($path, "");
    $st = $oi = $ic = 0;
    $sh = 5000;
    $mx = 14283838;
    $db = $core->db;
    $ipc = $db->field("SELECT COUNT(*) FROM `" . DB_GEOIP . "`");
    while (true) {
        $cc = "";
        $ipl = $db->icol("SELECT ( `ip` >> 8 ) AS `newip`, `country` FROM `" . DB_GEOIP . "` ORDER BY `ip` ASC LIMIT " . $st . ", " . $sh);
        if ($ipl) {
            foreach ($ipl as $ip => $nc) {
                if ($oi) {
                    $ic = $ip - $oi;
                }
                if ($ic) {
                    $cc .= str_repeat($cn, $ic);
                }
                $cn = $nc;
                $oi = $ip;
            }
            $st += $sh;
            file_put_contents($path, $cc, FILE_APPEND);
        } else {
            break;
        }
    }
    $ic = $mx - $ip;
    $cc = str_repeat($nc, $ic);
    file_put_contents($path, $cc, FILE_APPEND);
}
function loadipgeodb($core, $small = false)
{
    if (!defined("WORKPATH")) {
        define("WORKPATH", PATH . "data/work/");
    }
    file_put_contents(WORKPATH . "ipgeodb.zip", file_get_contents("http://ipgeobase.ru/files/db/Main/geo_files.zip"));
    $mdf = md5_file(WORKPATH . "ipgeodb.zip");
    $mdc = @file_get_contents(WORKPATH . "ipgeodb-md5.txt");
    if ($mdf == $mdc) {
        unlink(WORKPATH . "ipgeodb.zip");
        return false;
    }
    $zip = new ZipArchive();
    if ($zip->open(WORKPATH . "ipgeodb.zip")) {
        $zip->extractTo(WORKPATH);
        $zip->close();
        file_put_contents(WORKPATH . "ipgeodb-md5.txt", $mdf);
        $ip = fopen(WORKPATH . "cidr_optim.txt", "r");
        if ($ip) {
            $core->db->query("TRUNCATE `" . SQL_PREF . "geowork`");
            $oc = false;
            while ($line = fgets($ip)) {
                $ld = explode("\t", trim($line));
                $li = array("ip" => $ld[0], "last" => $ld[1], "country" => strtolower($ld[3]), "city" => $small ? 0 : (int) $ld[4]);
                if ($small) {
                    if ($oc == $li["country"]) {
                        continue;
                    }
                    $oc = $li["country"];
                }
                $core->db->add(SQL_PREF . "geowork", $li);
            }
            fclose($ip);
            $core->db->query("RENAME TABLE `" . DB_GEOIP . "` TO `" . SQL_PREF . "geoip2`");
            $core->db->query("RENAME TABLE `" . SQL_PREF . "geowork` TO `" . DB_GEOIP . "`");
            $core->db->query("TRUNCATE `" . SQL_PREF . "geoip2`");
            $core->db->query("RENAME TABLE `" . SQL_PREF . "geoip2` TO `" . SQL_PREF . "geowork`");
        }
        if (!$small) {
            $cf = fopen(WORKPATH . "cities.txt", "r");
            if ($cf) {
                $core->db->query("TRUNCATE `" . DB_GEOCITY . "`");
                while ($line = fgets($cf)) {
                    $line = iconv("windows-1251", "utf-8", trim($line));
                    $ld = explode("\t", $line);
                    $ll = array("id" => $ld[0], "city" => $ld[1], "region" => $ld[2], "district" => $ld[3]);
                    $core->db->add(DB_GEOCITY, $ll);
                }
                fclose($cf);
            }
        }
        unlink(WORKPATH . "ipgeodb.zip");
        unlink(WORKPATH . "cidr_optim.txt");
        unlink(WORKPATH . "cities.txt");
    } else {
        @unlink(WORKPATH . "ipgeodb.zip");
        return false;
    }
}

?>