<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function wm_domain($core)
{
    if ($core->config("hide", "domain")) {
        $core->go($core->u("", "message=access"));
    }
    $canuser = $core->user->level || $core->user->work == -2;
    $wm = isset($core->post["wm"]) ? (int) $core->post["wm"] : (int) $core->get["wm"];
    if ($canuser && $wm) {
        $user = $wm;
        $udt = $core->user->get($wm);
        $uinfo = sprintf($core->lang["stat_user"], $udt["user_name"], $udt["user_mail"]);
        $core->site->info("text", $uinfo);
    } else {
        $user = $core->user->id;
    }
    $core->site->bc($core->lang["menu_domain"], $core->u("domain"));
    wm_domain_page($core, array("page" => "domain", "user" => $user, "auth" => $canuser, "wm" => $canuser && $wm, "descr" => $core->lang["domain_t"]));
}
function wm_domain_page($core, $config)
{
    $message = isset($core->get["message"]) ? $core->text->link($core->get["message"]) : false;
    $action = isset($core->get["action"]) ? $core->text->link($core->get["action"]) : false;
    $id = isset($core->get["id"]) ? (int) $core->get["id"] : false;
    $canuser = $config["auth"];
    $user = $config["user"];
    $wm = $config["wm"] ? $config["user"] : NULL;
    switch ($message) {
        case "ok":
            $core->site->info("info", "done_basic");
            break;
        case "check":
            $core->site->info("info", "done_domain_check");
            break;
        case "error":
            $core->site->info("error", "error_basic");
            break;
        case "access":
            $core->site->info("error", "access_denied");
            break;
    }
    switch ($action) {
        case "add":
            $type = (int) $core->post["type"];
            $ud = parse_url($core->post["url"]);
            if ($ud["host"]) {
                $url = $ud["host"];
            } else {
                $url = $core->post["url"];
            }
            if ($core->domain->add($user, $url, $type)) {
                $core->go($core->u($config["page"], array("message" => "ok", "wm" => $wm)));
            } else {
                $core->go($core->u($config["page"], array("message" => "error", "wm" => $wm)));
            }
        case "del":
            $user = $canuser ? $user : -1;
            if ($core->domain->del($user, $id)) {
                $core->go($core->u($config["page"], array("message" => "ok", "wm" => $wm)));
            } else {
                $core->go($core->u($config["page"], array("message" => "error", "wm" => $wm)));
            }
        case "def":
            $user = $canuser ? $user : -1;
            if ($core->domain->def($user, $id)) {
                $core->go($core->u($config["page"], array("message" => "ok", "wm" => $wm)));
            } else {
                $core->go($core->u($config["page"], array("message" => "error", "wm" => $wm)));
            }
        case "check":
            if ($core->domain->check($id)) {
                $core->go($core->u($config["page"], array("message" => "ok", "wm" => $wm)));
            } else {
                $core->go($core->u($config["page"], array("message" => "error", "wm" => $wm)));
            }
    }
    $dt = array();
    $dz = array("red", "site", "space");
    $dx = array("redirect", "sites", "space");
    foreach ($dx as $i => $n) {
        if ($core->config($n, "park")) {
            $dt[$i] = $dz[$i];
        }
    }
    $dm = $core->domain->show($user);
    $core->site->header();
    $core->tpl->load("body", "domain", defined("HACK_TPL_DOMAIN") ? HACK : false);
    $core->tpl->vars("body", array("text" => $core->text->lines($config["descr"]), "add" => $core->lang["domain_add"], "u_add" => $core->u($config["page"], array("action" => "add")), "wm" => $wm, "url" => $core->lang["domain"], "status" => $core->lang["status"], "action" => $core->lang["action"], "check" => $core->lang["domain_check"], "default" => $core->lang["domain_default"], "del" => $core->lang["del"], "confirm" => $core->lang["confirm"], "nodomain" => $core->lang["nodomain"]));
    foreach ($dt as $t => $k) {
        $pip = $core->config($dx[$t], "ip");
        $core->tpl->block("body", "type", array("type" => $t, "name" => $core->lang["domain_b"][$t], "descr" => $pip ? sprintf($core->lang["domain_x"], $pip) : false));
        if ($dm[$k]) {
            foreach ($dm[$k] as $d) {
                $core->tpl->block("body", "type.one", array("url" => $d["url"], "status" => $core->lang["domain_status"][$d["status"]], "stcl" => $core->lang["domain_stcl"][$d["status"]], "stic" => $core->lang["domain_stic"][$d["status"]], "default" => $d["default"], "time" => $d["check"] ? $core->text->smartdate($d["check"]) : $core->lang["domain_status"][0], "def" => $user ? $core->u(array($config["page"], $d["id"]), array("action" => "def", "wm" => $wm)) : false, "check" => $core->u(array($config["page"], $d["id"]), array("action" => "check", "wm" => $wm)), "del" => $core->u(array($config["page"], $d["id"]), array("action" => "del", "wm" => $wm))));
            }
        } else {
            $core->tpl->block("body", "type.noitem");
        }
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}

?>