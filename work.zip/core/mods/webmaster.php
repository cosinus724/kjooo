<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function webmaster_menu($core, $menu)
{
    if (!$core->config("hide", "offers")) {
        $menu[] = "offers";
    }
    $flow = array();
    if (!$core->config("hide", "flows")) {
        $flow[] = "flow";
    }
    if (!$core->config("hide", "split")) {
        $flow[] = "split";
    }
    if (!$core->config("hide", "domain")) {
        $flow[] = "domain";
    }
    if (!$core->config("hide", "postback")) {
        $flow[] = "postback";
    }
    if ($flow) {
        $menu["flow"] = $flow;
    }
    $stats = array();
    if ($core->user->work == 0) {
        if (!$core->config("hide", "lead")) {
            $menu[] = "leads";
        }
    } else {
        if (!$core->config("hide", "lead")) {
            $stats[] = "leads";
        }
    }
    if (!$core->config("hide", "date")) {
        $stats[] = "stats";
    }
    if (!$core->config("hide", "hour")) {
        $stats[] = "hourstat";
    }
    if (!$core->config("hide", "offer")) {
        $stats[] = "offerstat";
    }
    if (!$core->config("hide", "flow")) {
        $stats[] = "flowstat";
    }
    if (!$core->config("hide", "site")) {
        $stats[] = "site";
    }
    if (!$core->config("hide", "geo")) {
        $stats[] = "geostat";
    }
    if (!$core->config("hide", "utm")) {
        $stats[] = "utm";
    }
    if (!$core->config("hide", "click")) {
        $stats[] = "click";
    }
    if ($stats) {
        $menu["stats"] = $stats;
    }
    if (!($core->config("register", "noref") || $core->config("register", "hideref")) && ($core->user->work == 0 || $core->user->work == 2)) {
        $menu[] = "referal";
    }
    return $menu;
}
function webmaster_module($core)
{
    $module = isset($core->get["m"]) ? $core->text->link($core->get["m"]) : NULL;
    $action = isset($core->get["action"]) ? $core->text->link($core->get["action"]) : NULL;
    $id = isset($core->post["id"]) ? (int) $core->post["id"] : (isset($core->get["id"]) ? (int) $core->get["id"] : 0);
    $page = 0 < $core->get["page"] ? (int) $core->get["page"] : 1;
    $message = isset($core->get["message"]) ? $core->text->link($core->get["message"]) : NULL;
    switch ($module) {
        case "split":
        case "split-test":
        case "split-edit":
            require_once PATH_MODS . "wm-split.php";
            wm_split($core);
        case "leads":
            require_once PATH_MODS . "wm-stats.php";
            wm_stats_leads($core);
        case "stats":
            require_once PATH_MODS . "wm-stats.php";
            wm_stats_date($core);
        case "hourstat":
            require_once PATH_MODS . "wm-stats.php";
            wm_stats_hour($core);
        case "utm":
            require_once PATH_MODS . "wm-stats.php";
            wm_stats_utm($core);
        case "exti":
            require_once PATH_MODS . "wm-stats.php";
            wm_stats_ext($core);
        case "site":
            require_once PATH_MODS . "wm-stats.php";
            wm_stats_site($core);
        case "flowstat":
            require_once PATH_MODS . "wm-stats.php";
            wm_stats_flows($core);
        case "offerstat":
            require_once PATH_MODS . "wm-stats.php";
            wm_stats_offer($core);
        case "geostat":
            require_once PATH_MODS . "wm-stats.php";
            wm_stats_geo($core);
        case "click":
            require_once PATH_MODS . "wm-stats.php";
            wm_stats_click($core);
        case "domain":
            require_once PATH_MODS . "wm-domain.php";
            wm_domain($core);
        case "postback":
            require_once PATH_MODS . "wm-postback.php";
            wm_postback($core);
        case "flow":
        default:
            require_once PATH_MODS . "wm-flow.php";
            wm_flow($core);
    }
    return false;
}

?>