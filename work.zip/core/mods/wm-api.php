<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function wm_stats_cl($core)
{
    $c = $core->config("statcol");
    return array("space" => $c["spaces"] || $c["suni"] || $c["sbad"] || $c["stime"], "suni" => $c["suni"] || $c["per"], "sgood" => $c["sbad"], "stm" => $c["stime"], "click" => $c["clicks"] || $c["unique"] || $c["bad"] || $c["time"], "unique" => $c["unique"] || $c["epc"] || $c["cr"] || $c["per"], "good" => $c["bad"], "tm" => $c["time"], "lead" => $c["epc"] || $c["cr"] || $c["app"] || $c["ca"] || $c["cw"] || $c["ct"] || $c["cc"] || $c["cx"] || $c["ba"] || $c["bb"] || $c["ma"] || $c["mw"] || $c["mc"] || $c["mt"]);
}
function wm_stats_daily($core, $from, $to, $where, $params = array())
{
    $stats = array();
    $cl = wm_stats_cl($core);
    $where0 = $where1 = $where;
    $where2 = str_replace("user_id", "wm_id", $where);
    $gdc = ceil($core->config("clicks", "good") / 5);
    if (count($params)) {
        if (!empty($param["w"])) {
            $where0 .= " AND site_sib = '" . $param["w"] . "'";
            $where1 .= " AND site_id = '" . $param["w"] . "'";
            $where2 .= " AND site_id = '" . $param["w"] . "'";
        }
        if (!empty($param["s"])) {
            $where0 .= " AND site_id = '" . $param["s"] . "'";
            $where1 .= " AND site_sib = '" . $param["s"] . "'";
            $where2 .= " AND space_id = '" . $param["s"] . "'";
        }
        $spaces = $cl["space"] ? $core->db->icol("SELECT click_date, COUNT(*) FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where0 . " AND click_space = 1 GROUP BY click_date") : array();
        $suni = $cl["suni"] ? $core->db->icol("SELECT click_date, COUNT(*) FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where0 . " AND click_space = 1 AND click_unique = 1 GROUP BY click_date") : array();
        $sgood = $cl["sgood"] ? $core->db->icol("SELECT click_date, COUNT(*) FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where0 . " AND click_space = 1 AND click_good >= " . $gdc . " GROUP BY click_date") : array();
        $stm = $cl["stm"] ? $core->db->icol("SELECT click_date, AVG(click_good) FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where0 . " AND click_space = 1 GROUP BY click_date") : array();
        $clicks = $cl["click"] ? $core->db->icol("SELECT click_date, COUNT(*) FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where1 . " AND click_space = 0 GROUP BY click_date") : array();
        $unique = $cl["unique"] ? $core->db->icol("SELECT click_date, COUNT(*) FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where1 . " AND click_space = 0 AND click_unique = 1 GROUP BY click_date") : array();
        $good = $cl["good"] ? $core->db->icol("SELECT click_date, COUNT(*) FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where1 . " AND click_space = 0 AND click_good >= " . $gdc . " GROUP BY click_date") : array();
        $tm = $cl["tm"] ? $core->db->icol("SELECT click_date, AVG(click_good) FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where1 . " AND click_space = 0 GROUP BY click_date") : array();
        $ids = array_unique(array_merge(array_keys($spaces), array_keys($clicks)));
        foreach ($ids as $i) {
            $stats[$i] = array("id" => $i, "space" => $spaces[$i], "suni" => $suni[$i], "sgood" => $sgood[$i], "stime" => $stm[$i], "clicks" => $clicks[$i], "unique" => $unique[$i], "good" => $good[$i], "time" => $tm[$i]);
        }
    } else {
        $today = date("Ymd");
        if ($to == $today) {
            $stats[$today] = $core->db->row("SELECT COUNT(*) AS `clicks`, SUM(click_unique) AS `unique`, AVG(click_good) AS `time` FROM " . DB_CLICK . " WHERE " . $where . " AND click_date = '" . $today . "' AND click_space = 0");
            $stats[$today]["id"] = $today;
            $stats[$today]["good"] = $cl["good"] ? $core->db->field("SELECT COUNT(*) FROM " . DB_CLICK . " WHERE " . $where . " AND click_date = '" . $today . "' AND click_space = 0 AND click_good >= " . $gdc) : array();
            $stats[$today]["space"] = $cl["space"] ? $core->db->field("SELECT COUNT(*) FROM " . DB_CLICK . " WHERE " . $where . " AND click_date = '" . $today . "' AND click_space = 1") : array();
            $stats[$today]["suni"] = $cl["suni"] ? $core->db->field("SELECT COUNT(*) FROM " . DB_CLICK . " WHERE " . $where . " AND click_date = '" . $today . "' AND click_space = 1 AND click_unique = 1") : array();
            $stats[$today]["sgood"] = $cl["sgood"] ? $core->db->field("SELECT COUNT(*) FROM " . DB_CLICK . " WHERE " . $where . " AND click_date = '" . $today . "' AND click_space = 1 AND click_good >= " . $gdc) : array();
            $stats[$today]["stime"] = $cl["stm"] ? $core->db->field("SELECT AVG(click_good) FROM " . DB_CLICK . " WHERE " . $where . " AND click_date = '" . $today . "' AND click_space = 1") : array();
        }
        if ($from < $today) {
            $sts = $core->db->data("SELECT stat_date AS `id`, SUM(stat_space) AS `space`, SUM(stat_suni) AS `suni`, SUM(stat_sgood) AS `sgood`, SUM(stat_stime) AS `stime`, SUM(stat_click) AS `clicks`, SUM(stat_unique) AS `unique`, SUM(stat_good) AS `good`, SUM(stat_time) AS `time` FROM " . DB_STATS . " WHERE " . $where . " AND stat_date BETWEEN '" . $from . "' AND '" . $to . "' GROUP BY stat_date");
            foreach ($sts as $s) {
                $stats[$s["id"]] = $s;
                $stats[$s["id"]]["time"] /= max($s["click"], $s["unique"], 1);
                $stats[$s["id"]]["stime"] /= max($s["space"], $s["suni"], 1);
            }
            unset($sts);
            unset($s);
        }
    }
    $ff = strtotime(date2form($from) . " 00:00:00");
    $tt = strtotime(date2form($to) . " 23:59:59");
    if ($cl["lead"]) {
        $orders = $core->db->start("SELECT order_id, order_webstat, order_reason, order_time, cash_wm FROM " . DB_ORDER . " WHERE " . $where2 . " AND order_time BETWEEN '" . $ff . "' AND '" . $tt . "'");
        while ($oo = $core->db->one($orders)) {
            if (isapprove($oo["order_webstat"])) {
                $l = "a";
            } else {
                if ($oo["order_webstat"] < 5) {
                    $l = "w";
                } else {
                    if (istrash($oo["order_webstat"], $oo["order_reason"])) {
                        $l = "x";
                    } else {
                        $l = "c";
                    }
                }
            }
            $d = date("Ymd", $oo["order_time"]);
            if (empty($stats[$d])) {
                $stats[$d] = array("id" => $d);
            }
            if ($oo["order_webstat"] == 10) {
                if ($stats[$d]["cb"]) {
                    $stats[$d]["cb"] += 1;
                } else {
                    $stats[$d]["cb"] = 1;
                }
            }
            if ($oo["order_webstat"] == 11) {
                if ($stats[$d]["cr"]) {
                    $stats[$d]["cr"] += 1;
                } else {
                    $stats[$d]["cr"] = 1;
                }
            }
            if ($stats[$d]["c" . $l]) {
                $stats[$d]["c" . $l] += 1;
            } else {
                $stats[$d]["c" . $l] = 1;
            }
            if ($stats[$d]["m" . $l]) {
                $stats[$d]["m" . $l] += $oo["cash_wm"];
            } else {
                $stats[$d]["m" . $l] = $oo["cash_wm"];
            }
            if ($l != "x") {
                if ($stats[$d]["ct"]) {
                    $stats[$d]["ct"] += 1;
                } else {
                    $stats[$d]["ct"] = 1;
                }
                if ($stats[$d]["mt"]) {
                    $stats[$d]["mt"] += $oo["cash_wm"];
                } else {
                    $stats[$d]["mt"] = $oo["cash_wm"];
                }
            }
        }
        $core->db->stop($orders);
    }
    krsort($stats);
    return $stats;
}
function wm_stats_load($core, $item, $from, $to, $where, $param = array())
{
    $cl = wm_stats_cl($core);
    $where0 = $where1 = $where;
    $oitem = $item;
    $where2 = str_replace("user_id", "wm_id", $where);
    $gdc = ceil($core->config("clicks", "good") / 5);
    if (!empty($param["w"])) {
        $where0 .= " AND site_sib = '" . $param["w"] . "'";
        $where1 .= " AND site_id = '" . $param["w"] . "'";
        $where2 .= " AND site_id = '" . $param["w"] . "'";
    }
    if (!empty($param["s"])) {
        $where0 .= " AND site_id = '" . $param["s"] . "'";
        $where1 .= " AND site_sib = '" . $param["s"] . "'";
        $where2 .= " AND space_id = '" . $param["s"] . "'";
    }
    if ($item == "site_id") {
        $wsi = "site_id";
        $wss = "site_sib";
    } else {
        if ($item == "space_id") {
            $wss = "site_id";
            $wsi = "site_sib";
        } else {
            $wss = $wsi = $item;
        }
    }
    $namelist = $param["namelist"] ? $param["namelist"] : array();
    if ($param["name"]) {
        $nn = $param["name"];
        $inspaces = $cl["space"] ? $core->db->data("SELECT `" . $wss . "`, COUNT(*) AS `c`, `" . $nn . "` FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where0 . " AND click_space = 1 GROUP BY `" . $wsg . "`") : array();
        $insuni = $cl["suni"] ? $core->db->data("SELECT `" . $wss . "`, COUNT(*) AS `c`, `" . $nn . "` FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where0 . " AND click_space = 1 AND click_unique = 1 GROUP BY `" . $wss . "`") : array();
        $insgood = $cl["sgood"] ? $core->db->data("SELECT `" . $wss . "`, COUNT(*) AS `c`, `" . $nn . "` FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where0 . " AND click_space = 1 AND click_good >= " . $gdc . " GROUP BY `" . $wss . "`") : array();
        $instm = $cl["stm"] ? $core->db->data("SELECT `" . $wss . "`, AVG(click_good) AS `c`, `" . $nn . "` FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where0 . " AND click_space = 1 GROUP BY `" . $wss . "`") : array();
        $inclicks = $cl["click"] ? $core->db->data("SELECT `" . $wsi . "`, COUNT(*), `" . $nn . "` FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where1 . " AND click_space = 0 GROUP BY `" . $wsi . "`") : array();
        $inunique = $cl["unique"] ? $core->db->data("SELECT `" . $wsi . "`, COUNT(*) AS `c`, `" . $nn . "` FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where1 . " AND click_space = 0 AND click_unique = 1 GROUP BY `" . $wsi . "`") : array();
        $ingood = $cl["good"] ? $core->db->data("SELECT `" . $wsi . "`, COUNT(*) AS `c`, `" . $nn . "` FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where1 . " AND click_space = 0 AND click_good >= " . $gdc . " GROUP BY `" . $wsi . "`") : array();
        $intm = $cl["tm"] ? $core->db->data("SELECT `" . $wsi . "`, AVG(click_good) AS `c`, `" . $nn . "` FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where1 . " AND click_space = 0 GROUP BY `" . $wsi . "`") : array();
        $toprocess = array("spaces", "suni", "sgood", "stm", "clicks", "unique", "good", "tm");
        foreach ($toprocess as $t) {
            $in = "in" . $t;
            ${$t} = array();
            foreach (${$in} as $r) {
                ${$t[$r[$item]]} = $r["c"];
                $namelist[$r[$item]] = $r[$nn];
            }
            unset($in);
        }
    } else {
        $spaces = $cl["space"] ? $core->db->icol("SELECT `" . $wss . "`, COUNT(*) FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where0 . " AND click_space = 1 GROUP BY `" . $wss . "`") : array();
        $suni = $cl["suni"] ? $core->db->icol("SELECT `" . $wss . "`, COUNT(*) FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where0 . " AND click_space = 1 AND click_unique = 1 GROUP BY `" . $wss . "`") : array();
        $sgood = $cl["sgood"] ? $core->db->icol("SELECT `" . $wss . "`, COUNT(*) FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where0 . " AND click_space = 1 AND click_good >= " . $gdc . " GROUP BY `" . $wss . "`") : array();
        $stm = $cl["stm"] ? $core->db->icol("SELECT `" . $wss . "`, AVG(click_good) FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where0 . " AND click_space = 1 GROUP BY `" . $wss . "`") : array();
        $clicks = $cl["click"] ? $core->db->icol("SELECT `" . $wsi . "`, COUNT(*) FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where1 . " AND click_space = 0 GROUP BY `" . $wsi . "`") : array();
        $unique = $cl["unique"] ? $core->db->icol("SELECT `" . $wsi . "`, COUNT(*) FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where1 . " AND click_space = 0 AND click_unique = 1 GROUP BY `" . $wsi . "`") : array();
        $good = $cl["good"] ? $core->db->icol("SELECT `" . $wsi . "`, COUNT(*) FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where1 . " AND click_space = 0 AND click_good >= " . $gdc . " GROUP BY `" . $wsi . "`") : array();
        $tm = $cl["tm"] ? $core->db->icol("SELECT `" . $wsi . "`, AVG(click_good) FROM " . DB_CLICK . " WHERE ( click_date BETWEEN '" . $from . "' AND '" . $to . "' ) AND " . $where1 . " AND click_space = 0 GROUP BY `" . $wsi . "`") : array();
    }
    $stats = array();
    $ids = array_unique(array_merge(array_keys($spaces), array_keys($clicks)));
    foreach ($ids as $i) {
        $stats[$i] = array("id" => $i, "name" => $namelist[$i], "space" => $spaces[$i], "suni" => $suni[$i], "sgood" => $sgood[$i], "stime" => $stm[$i], "clicks" => $clicks[$i], "unique" => $unique[$i], "good" => $good[$i], "time" => $tm[$i]);
    }
    if ($oitem == "click_geo") {
        $oitem = "order_country";
    }
    if ($oitem == "click_hour") {
        $oitem = "order_time";
    }
    if ($cl["lead"]) {
        $ff = strtotime(date2form($from) . " 00:00:00");
        $tt = strtotime(date2form($to) . " 23:59:59");
        $orders = $core->db->start("SELECT order_id, order_webstat, order_reason, `" . $oitem . "`, cash_wm FROM " . DB_ORDER . " WHERE order_time BETWEEN '" . $ff . "' AND '" . $tt . "' AND " . $where2);
        while ($oo = $core->db->one($orders)) {
            $ui = $oo[$oitem];
            if ($param["transform"] == "hour") {
                $ui = (int) date("H", $ui);
            }
            if (!isset($stats[$ui])) {
                $stats[$ui] = array("id" => $ui, "name" => $namelist[$i], "space" => 0, "suni" => 0, "sgood" => 0, "stime" => 0, "clicks" => 0, "unique" => 0, "good" => 0, "time" => 0);
            }
            if (isapprove($oo["order_webstat"])) {
                $l = "a";
            } else {
                if ($oo["order_webstat"] < 5) {
                    $l = "w";
                } else {
                    if (istrash($oo["order_webstat"], $oo["order_reason"])) {
                        $l = "x";
                    } else {
                        $l = "c";
                    }
                }
            }
            if ($oo["order_webstat"] == 10) {
                if ($stats[$ui]["cb"]) {
                    $stats[$ui]["cb"] += 1;
                } else {
                    $stats[$ui]["cb"] = 1;
                }
            }
            if ($oo["order_webstat"] == 11) {
                if ($stats[$ui]["cr"]) {
                    $stats[$ui]["cr"] += 1;
                } else {
                    $stats[$ui]["cr"] = 1;
                }
            }
            if ($stats[$ui]["c" . $l]) {
                $stats[$ui]["c" . $l] += 1;
            } else {
                $stats[$ui]["c" . $l] = 1;
            }
            if ($stats[$ui]["m" . $l]) {
                $stats[$ui]["m" . $l] += $oo["cash_wm"];
            } else {
                $stats[$ui]["m" . $l] = $oo["cash_wm"];
            }
            if ($l != "x") {
                if ($stats[$ui]["ct"]) {
                    $stats[$ui]["ct"] += 1;
                } else {
                    $stats[$ui]["ct"] = 1;
                }
                if ($stats[$ui]["mt"]) {
                    $stats[$ui]["mt"] += $oo["cash_wm"];
                } else {
                    $stats[$ui]["mt"] = $oo["cash_wm"];
                }
            }
        }
        $core->db->stop($orders);
    }
    if ($param["names"]) {
        foreach ($stats as $i => $s) {
            if (!isset($param["names"][$i])) {
                unset($stats[$i]);
            }
        }
        foreach ($param["names"] as $i => $n) {
            if (!isset($stats[$i])) {
                $stats[$i] = array("id" => $i, "name" => $n, "space" => 0, "suni" => 0, "sgood" => 0, "stime" => 0, "clicks" => 0, "unique" => 0, "good" => 0, "time" => 0);
            } else {
                $stats[$i]["name"] = $n;
            }
        }
    }
    return $stats;
}

?>