<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function manager_menu($core, $menu)
{
    $menu["analytics"] = array("analytics", "analytics-calls", "analytics-delivery");
    $menu[] = "users";
    $menu[] = "supporthq";
    return $menu;
}
function manager_module($core)
{
    $module = $core->get["m"] ? $core->get["m"] : NULL;
    switch ($module) {
        case "users":
            require_once PATH_MODS . "admin-users.php";
            admin_users($core, array("manager" => $core->user->id, "vip" => $core->user->vip));
        case "supporthq":
            require_once PATH_MODS . "admin-support.php";
            admin_support($core, array("manager" => $core->user->id, "vip" => $core->user->vip));
        case "analytics":
            require_once PATH_MODS . "analytics-order.php";
            analytics_order($core, "analytics", array("manager" => $core->user->id, "vip" => $core->user->vip));
        case "analytics-calls":
            require_once PATH_MODS . "analytics-calls.php";
            analytics_calls($core, "analytics-calls", array("manager" => $core->user->id, "vip" => $core->user->vip));
        case "analytics-delivery":
            require_once PATH_MODS . "analytics-delivery.php";
            analytics_delivery($core, "analytics-delivery", array("manager" => $core->user->id, "vip" => $core->user->vip));
    }
    return false;
}

?>