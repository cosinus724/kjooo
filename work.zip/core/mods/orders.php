<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function order_take($core, $id = 0)
{
    $id = (int) $id;
    require_once PATH_MODS . "order-edit.php";
    $a = $core->cpa->team();
    if (!$id) {
        $c = $core->user->comp;
        if (!$c) {
            return false;
        }
        $tm = time();
        $mt = $tm - 60;
        $u = $core->user->id;
        $ofl = $a["offer"] ? " AND offer_id IN ( " . implode(",", $a["offer"]) . " )" : "";
        switch ($a["call"]) {
            case 1:
                $qu = array("SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = '" . $u . "' AND order_status = 2 AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) LIMIT 1", "SELECT order_id, order_status FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = 0 AND order_status = 1 AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) LIMIT 1", "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = '" . $u . "' AND order_status = 3 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1", "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND order_status = 3 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1", "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND order_status = 2 AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1");
                break;
            case 2:
                $qu = array("SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = '" . $u . "' AND order_status = 2 AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) LIMIT 1", "SELECT order_id, order_status FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = 0 AND order_status = 1 AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) LIMIT 1", "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = '" . $u . "' AND order_status = 3 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1", "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND order_status = 3 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1", "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = '" . $u . "' AND order_status = 4 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1", "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND order_status = 4 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1", "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND order_status = 2 AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1");
                break;
            case 3:
                $qu = array("SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = '" . $u . "' AND order_status = 2 AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) LIMIT 1", "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = '" . $u . "' AND order_status = 3 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1", "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND order_status = 3 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1", "SELECT order_id, order_status FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = 0 AND order_status = 1 AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) LIMIT 1", "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND order_status = 2 AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1");
                break;
            case 4:
                $qu = array("SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = '" . $u . "' AND order_status = 2 AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) LIMIT 1", "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = '" . $u . "' AND order_status = 4 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1", "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND order_status = 4 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1", "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = '" . $u . "' AND order_status = 3 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1", "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND order_status = 3 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1", "SELECT order_id, order_status FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = 0 AND order_status = 1 AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) LIMIT 1", "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND order_status = 2 AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1");
                break;
            case 5:
                $qu = array("SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = '" . $u . "' AND order_status = 2 AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) LIMIT 1", "SELECT order_id, order_status FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = 0 AND order_status = 1 AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) LIMIT 1", "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND order_status = 2 AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1");
                break;
            case 6:
                $qu = array("SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = '" . $u . "' AND order_status = 3 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1", "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND order_status = 3 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1");
                break;
            case 7:
                $qu = array("SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = '" . $u . "' AND order_status = 4 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1", "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND order_status = 4 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1");
                break;
            default:
                $qu = array();
        }
        if ($a["pack"] == 2) {
            $qu[] = "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = '" . $u . "' AND order_status = 6 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1";
            $qu[] = "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND order_status = 6 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1";
        }
        if ($a["send"] == 2) {
            $qu[] = "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = '" . $u . "' AND order_status = 7 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1";
            $qu[] = "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND order_status = 7 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1";
        }
        if ($a["delivery"] == 2) {
            $qu[] = "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = '" . $u . "' AND order_status = 9 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1";
            $qu[] = "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND order_status = 9 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1";
            $qu[] = "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND user_id = '" . $u . "' AND order_status = 8 AND track_warn = 1 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1";
            $qu[] = "SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c . "' " . $ofl . " AND order_status = 8 AND track_warn = 1 AND order_recall < '" . $tm . "' AND ( mark_time < '" . $mt . "' OR mark_id = '" . $u . "' ) ORDER BY RAND() LIMIT 1";
        }
        foreach ($qu as $q) {
            if ($o = $core->db->row($q)) {
                if (isset($o["order_status"]) && $o["order_status"] == 1) {
                    order_edit($core, $o["order_id"], array("user" => $u, "status" => 2));
                }
                return $o["order_id"];
            }
        }
        return false;
    } else {
        $o = $core->db->row("SELECT user_id, comp_id, offer_id, order_status FROM " . DB_ORDER . " WHERE order_id = '" . $id . "' LIMIT 1");
        if ($o["user_id"]) {
            return false;
        }
        $canmove = $core->order->canmove($o["order_status"], $o["offer_id"]);
        if (!$canmove[2]) {
            return false;
        }
        if ($o["order_status"] == 1) {
            order_edit($core, $id, array("user" => $core->user->id, "status" => 2));
        }
        return $id;
    }
}
function order_footer($core)
{
    $core->tpl->load("notify", "notify", defined("HACК_TPL_NOTIFY") ? HACK : false);
    $core->tpl->vars("notify", array("url" => $core->url("ma", "order", "notify") . "&prev=", "ourl" => $core->url("m", "orders"), "prev" => time(), "text" => $core->lang["order_notify"], "text2" => $core->lang["order_notify2"]));
    $core->tpl->output("notify");
}
function order_menu($core, $menu)
{
    if ($core->user->work == 1) {
        $core->site->css("notifIt");
        $core->site->js("jquery");
        $core->site->js("notifIt");
        $core->handle("footer", "order_footer");
    }
    $menu[] = "order";
    return $menu;
}
function order_module($core)
{
    $module = $core->get["m"] ? $core->get["m"] : NULL;
    $id = $core->post["id"] ? (int) $core->post["id"] : ($core->get["id"] ? (int) $core->get["id"] : 0);
    $page = 0 < $core->get["page"] ? (int) $core->get["page"] : 1;
    $message = $core->get["message"] ? $core->get["message"] : NULL;
    if ($core->user->comp) {
        $c = $core->cpa->get("comp", $core->user->comp);
        if ($c["comp_block"] && $c["user_id"]) {
            $uc = $core->user->get($c["user_id"], "user_cash");
            if ($uc < $c["comp_block"]) {
                $core->site->bc($core->lang["orders_h"]);
                $core->site->info("error", "error_comps_block");
                $core->site->header();
                $core->site->footer();
                $core->stop();
            }
        }
    }
    if ($module == "offers") {
        require_once PATH_MODS . "offers.php";
        offers($core);
    }
    if ($module && $module != "order") {
        return false;
    }
    switch ($message) {
        case "save":
            $core->site->info("info", "done_order_save");
            break;
        case "send":
            $core->site->info("info", "done_order_send");
            break;
        case "pack":
            $core->site->info("info", "done_order_pack");
            break;
        case "done":
            $core->site->info("info", "done_order_done");
            break;
        case "arrive":
            $core->site->info("info", "done_order_arrive");
            break;
        case "del":
            $core->site->info("info", "done_order_del");
            break;
        case "pickup":
            $core->site->info("error", "error_order_pickup");
            break;
        case "nocode":
            $core->site->info("error", "error_order_nocode");
            break;
        case "error":
            $core->site->info("error", "error_order_smth");
            break;
        case "oerror":
            $core->site->info("error", "error_order_save");
            break;
        case "access":
            $core->site->info("error", "access_denied");
            break;
    }
    if ($core->get["action"] == "pickup") {
        if ($oid = order_take($core, $id)) {
            $core->go($core->url("i", "order", $oid));
        } else {
            $core->go($core->url("m", "order", "pickup"));
        }
    }
    if ($id) {
        require_once PATH_MODS . "order-one.php";
        order_module_one($core, $id);
    } else {
        require_once PATH_MODS . "order-list.php";
        order_module_list($core, $page);
    }
    $core->stop();
}

?>