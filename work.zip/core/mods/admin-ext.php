<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function admin_ext($core)
{
    $action = isset($core->get["action"]) ? $core->text->link($core->get["action"]) : NULL;
    $id = isset($core->get["id"]) ? (int) $core->get["id"] : 0;
    switch ($action) {
        case "add":
            $name = $core->text->line($core->post["name"]);
            $mail = $core->text->link($core->post["name"]) . "@" . $core->server["HTTP_HOST"];
            if ($core->db->add(DB_EXT, array("ext_name" => $name))) {
                $id = $core->db->lastid();
                $ud = array("user_name" => $name, "user_mail" => $mail, "user_pass" => $core->user->pass(md5(microtime())), "user_work" => -1, "user_ext" => $id, "user_api" => md5(microtime() . rand()));
                if ($core->db->add(DB_USER, $ud)) {
                    $uid = $core->db->lastid();
                    $core->db->edit(DB_EXT, array("user_id" => $uid), array("ext_id" => $id));
                }
                $core->cpa->clear("exts");
                $core->go($core->url("im", "ext", $id, "add-ok"));
            } else {
                $core->go($core->url("mm", "ext", "add-e"));
            }
        case "edit":
            $edit = array("user_id" => (int) $core->post["user"], "ext_name" => $core->text->line($core->post["name"]), "url_new" => str_replace("&amp;", "&", $core->text->line($core->post["url_new"])), "url_nc" => str_replace("&amp;", "&", $core->text->line($core->post["url_nc"])), "url_rc" => str_replace("&amp;", "&", $core->text->line($core->post["url_rc"])), "url_acc" => str_replace("&amp;", "&", $core->text->line($core->post["url_acc"])), "url_dec" => str_replace("&amp;", "&", $core->text->line($core->post["url_dec"])), "url_pay" => str_replace("&amp;", "&", $core->text->line($core->post["url_pay"])), "url_ret" => str_replace("&amp;", "&", $core->text->line($core->post["url_ret"])), "url_del" => str_replace("&amp;", "&", $core->text->line($core->post["url_del"])));
            if ($core->db->edit(DB_EXT, $edit, "ext_id = '" . $id . "'")) {
                $core->cpa->clear("ext", $id);
                $core->cpa->clear("exts");
                $core->go($core->url("mm", "ext", "edit-ok"));
            } else {
                $core->go($core->url("mm", "ext", "edit-e"));
            }
        case "del":
            if ($core->db->query("DELETE FROM " . DB_EXT . " WHERE ext_id = '" . $id . "' LIMIT 1")) {
                $core->db->query("DELETE FROM " . DB_USER . " WHERE user_ext = '" . $id . "'");
                $core->db->query("UPDATE " . DB_ORDER . " SET ext_id = 0, ext_uid = 0, ext_src = 0 WHERE ext_id = '" . $id . "'");
                $core->cpa->clear("ext", $id);
                $core->cpa->clear("exts");
                $core->go($core->url("mm", "ext", "del-ok"));
            } else {
                $core->go($core->url("mm", "ext", "del-e"));
            }
    }
    $message = isset($core->get["message"]) ? $core->text->link($core->get["message"]) : NULL;
    switch ($message) {
        case "add-ok":
            $core->site->info("info", "done_add");
            break;
        case "edit-ok":
            $core->site->info("info", "done_edit");
            break;
        case "del-ok":
            $core->site->info("info", "done_del");
            break;
        case "add-e":
            $core->site->info("error", "error_add");
            break;
        case "edit-e":
            $core->site->info("error", "error_edit");
            break;
        case "del-e":
            $core->site->info("error", "error_del");
            break;
    }
    if ($id) {
        $ext = $core->db->row("SELECT * FROM " . DB_EXT . " WHERE ext_id = '" . $id . "' LIMIT 1");
        $user = array(array("name" => "&mdash; " . $core->lang["comp_free"] . " &mdash;", "value" => 0));
        $users = $core->db->icol("SELECT user_id, user_name FROM " . DB_USER . " WHERE user_ext = '" . $id . "' ORDER BY user_name ASC");
        foreach ($users as $u => $n) {
            $user[] = array("name" => $n, "value" => $u, "select" => $u == $ext["user_id"]);
        }
        $core->site->bc($core->lang["admin_ext_h"], $core->url("m", "ext"));
        $core->site->bc($ext["ext_name"]);
        $core->site->header();
        $field = array(array("type" => "text", "length" => 100, "name" => "name", "head" => $core->lang["name"], "value" => $ext["ext_name"]), array("type" => "select", "name" => "user", "head" => $core->lang["ext_user"], "descr" => $core->lang["ext_user_d"], "value" => $user), array("type" => "head", "value" => $core->lang["ext_url"]), array("type" => "line", "value" => $core->lang["ext_url_d"]), array("type" => "text", "length" => 200, "name" => "url_new", "head" => $core->lang["ext_new"], "value" => $ext["url_new"]), array("type" => "text", "length" => 200, "name" => "url_nc", "head" => $core->lang["ext_nc"], "value" => $ext["url_nc"]), array("type" => "text", "length" => 200, "name" => "url_rc", "head" => $core->lang["ext_rc"], "value" => $ext["url_rc"]), array("type" => "text", "length" => 200, "name" => "url_acc", "head" => $core->lang["ext_acc"], "value" => $ext["url_acc"]), array("type" => "text", "length" => 200, "name" => "url_dec", "head" => $core->lang["ext_dec"], "value" => $ext["url_dec"]), array("type" => "text", "length" => 200, "name" => "url_pay", "head" => $core->lang["ext_pay"], "value" => $ext["url_pay"]), array("type" => "text", "length" => 200, "name" => "url_ret", "head" => $core->lang["ext_ret"], "value" => $ext["url_ret"]), array("type" => "text", "length" => 200, "name" => "url_del", "head" => $core->lang["ext_del"], "value" => $ext["url_del"]));
        $core->site->form("ext", $core->url("ia", "ext", $id, "edit"), $core->lang["ext_edit"], $field);
        $core->site->footer();
    } else {
        $exts = $core->db->data("SELECT ext_id, ext_name, user_id FROM " . DB_EXT . " ORDER BY ext_name ASC");
        $core->site->bc($core->lang["admin_ext_h"], $core->url("m", "ext"));
        $core->site->header();
        $core->tpl->load("body", "safelist", defined("HACK_TPL_LIST") ? HACK : false);
        $core->tpl->vars("body", array("title" => $core->lang["admin_ext_h"], "name" => $core->lang["name"], "info" => $core->lang["cash"], "action" => $core->lang["action"], "edit" => $core->lang["edit"], "del" => $core->lang["del"], "confirm" => $core->lang["confirms"], "noitems" => $core->lang["noitems"], "u_add" => $core->url("ma", "ext", "add"), "add" => $core->lang["add"]));
        if ($exts) {
            foreach ($exts as $i) {
                $core->tpl->block("body", "item", array("id" => $i["ext_id"], "name" => $i["ext_name"], "info" => $i["user_id"] ? $core->currency->money($core->user->get($i["user_id"], "user_cash")) : $core->lang["ext_free"], "url" => $core->url("i", "ext", $i["ext_id"]), "edit" => $core->url("i", "ext", $i["ext_id"]), "del" => $core->url("ia", "ext", $i["ext_id"], "del")));
            }
        } else {
            $core->tpl->block("body", "noitem");
        }
        $core->tpl->output("body");
        $core->site->footer();
    }
    $core->stop();
}

?>