<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function admin_offer_sites($core, $id)
{
    $action = isset($core->get["action"]) ? $core->text->link($core->get["action"]) : NULL;
    $id = isset($core->get["id"]) ? (int) $core->get["id"] : 0;
    switch ($action) {
        case "add":
            $type = (int) $core->post["type"];
            $url = $core->text->line($core->post["url"]);
            $key = md5(microtime());
            if (strpos("://", $uu) === false) {
                $url = "http://" . $url;
            }
            $ud = parse_url($url);
            $url = $ud["host"] . rtrim($ud["path"], "/");
            $slug = $type == 2 ? trim($ud["path"], "/") : false;
            $data = array("offer_id" => $id, "site_type" => $type, "site_url" => $url, "site_key" => $key, "site_slug" => $slug);
            if ($core->db->add(DB_SITE, $data)) {
                $sid = $core->db->lastid();
                $core->cpa->clear("sites", $id);
                $core->cpa->clear("lands", $id);
                $core->cpa->clear("space", $id);
                curl("http://" . $core->config("space", "domain") . "/renew.php?id=" . $id);
                $core->go($core->url("im", "offer-site", $sid, "add-ok"));
            } else {
                $core->go($core->url("im", "offer-sites", $id, "add-e"));
            }
        case "renew":
            curl("http://" . $core->config("space", "domain") . "/renew.php?id=" . $id);
            $core->go($core->url("im", "offer-sites", $id, "ok"));
        case "upload":
            $fn = strtolower($core->files["import"]["name"]);
            if (substr($fn, 0, -5) == ".zip") {
                $data = array();
                $zip = new ZipArchive();
                if ($zip->open($core->files["import"]["tmp_name"])) {
                    for ($i = 0; $i < $zip->numFiles; $i++) {
                        $stat = $zip->statIndex($i);
                        $name = $stat["name"];
                        $data[$name] = base64_encode($zip->getFromIndex($i));
                    }
                    $zip->close();
                } else {
                    $core->go($core->url("im", "offer-sites", $id, "error"));
                }
                $dd = json_encode($data);
            } else {
                if (substr($fn, 0, -5) == ".json") {
                    $dd = file_get_contents($core->files["import"]["tmp_name"]);
                } else {
                    $core->go($core->url("im", "offer-sites", $id, "error"));
                }
            }
            $site = (int) $core->post["site"];
            $s = $core->db->row("SELECT * FROM " . DB_SITE . " WHERE site_id = '" . $site . "' LIMIT 1");
            if (strpos($s["site_url"], "/") !== false) {
                $np = explode("/", $s["site_url"], 2);
                $np = $np[1];
            } else {
                $np = $s["site_url"];
            }
            $url = $s["site_type"] == 1 ? $core->config("sites", "control") : $core->config("space", "control");
            $key = $s["site_type"] == 1 ? $core->config("sites", "key") : $core->config("space", "key");
            curl($url, array("key" => $key, "action" => "update", "site" => $np, "data" => $dd));
            $core->go($core->url("im", "offer-sites", $id, "ok"));
    }
    $message = isset($core->get["message"]) ? $core->text->link($core->get["message"]) : NULL;
    switch ($message) {
        case "edit-ok":
            $core->site->info("info", "done_offer_site_edit");
            break;
        case "del-ok":
            $core->site->info("info", "done_offer_site_del");
            break;
        case "add-e":
            $core->site->info("error", "error_offer_site_add");
            break;
        case "edit-e":
            $core->site->info("error", "error_offer_site_edit");
            break;
        case "del-e":
            $core->site->info("error", "error_offer_site_del");
            break;
    }
    if (!$id) {
        $core->go($core->url("m", "offer"));
    }
    $offer = $core->cpa->get("offer", $id);
    $comp = $core->cpa->get("comps");
    $sites = $core->db->data("SELECT * FROM " . DB_SITE . " WHERE offer_id = '" . $id . "' ORDER BY site_type, site_url ASC");
    $core->site->bc($core->lang["offers_h"], $core->url("m", "offer"));
    $core->site->bc(sprintf($core->lang["offer_sites_h"], $offer["offer_name"]));
    $core->site->header();
    $core->tpl->load("body", "sites", defined("HACK_TPL_SITES") ? HACK : false);
    $core->tpl->vars("body", array("text" => $core->text->lines($core->lang["offer_sites_t"]), "url" => $core->lang["url"], "name" => $core->lang["name"], "add" => $core->lang["add"], "type" => $core->lang["type"], "download" => $core->lang["download"], "comp" => $core->lang["company"], "action" => $core->lang["action"], "edit" => $core->lang["edit"], "del" => $core->lang["del"], "erase" => $core->lang["erase"], "confirm" => $core->lang["confirm"], "load" => $core->lang["sites_load"], "list" => $core->lang["sites_list"], "renew" => $core->lang["sites_renew"], "u_add" => $core->url("ia", "offer-sites", $id, "add"), "u_load" => $core->url("ia", "offer-sites", $id, "upload"), "u_renew" => $core->url("ia", "offer-sites", $id, "renew")));
    foreach ($core->lang["site_types"] as $v => $n) {
        $core->tpl->block("body", "type", array("v" => $v, "n" => $n));
    }
    foreach ($sites as &$i) {
        if ($i["site_default"]) {
            $act .= "<span class=\"icon sm rf isok\"></span>";
        }
        $sx = $i["site_type"] == 1 ? "space" : "sites";
        $core->tpl->block("body", "item", array("id" => $i["site_id"], "url" => $i["site_url"], "name" => $i["site_name"], "tid" => $i["site_type"], "type" => $core->lang["site_types"][$i["site_type"]], "default" => $i["site_default"], "mi" => $i["site_mobile"], "mt" => $core->lang["site_mobiles"][$i["site_mobile"]], "comp" => $comp[$i["comp_id"]], "json" => $core->config($sx, "key") ? "http://" . $i["site_url"] . "/?load=" . $core->config($sx, "key") : false, "zip" => $core->config($sx, "key") ? "http://" . $i["site_url"] . "/?format=zip&load=" . $core->config($sx, "key") : false, "edit" => $core->url("i", "offer-site", $i["site_id"]), "del" => $core->url("ia", "offer-site", $i["site_id"], "del"), "erase" => $core->config($sx, "key") ? $core->url("ia", "offer-site", $i["site_id"], "erase") : false));
    }
    unset($d);
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}
function admin_offer_site($core, $id)
{
    $action = isset($core->get["action"]) ? $core->text->link($core->get["action"]) : NULL;
    switch ($action) {
        case "edit":
            $s = $core->db->row("SELECT * FROM " . DB_SITE . " WHERE site_id = '" . $id . "' LIMIT 1");
            $type = $s["site_type"];
            $url = $core->text->line($core->post["url"]);
            $slug = $core->text->link($core->post["slug"]);
            $key = $core->text->link($core->post["key"]);
            if (!$key) {
                $key = md5(microtime());
            }
            if (strpos("://", $uu) === false) {
                $url = "http://" . $url;
            }
            $ud = parse_url($url);
            $url = $ud["host"] . rtrim($ud["path"], "/");
            if ($type == 2) {
                if (!$slug) {
                    $slug = trim($ud["path"], "/");
                }
            } else {
                $slug = false;
            }
            $default = $core->post["default"] ? 1 : 0;
            if ($default) {
                $core->db->query("UPDATE " . DB_SITE . " SET site_default = 0 WHERE offer_id = '" . $offer . "' AND site_type IN ( 0, 2 )");
            }
            $data = array("site_url" => $url, "site_name" => $core->text->line($core->post["name"]), "site_key" => $key, "site_slug" => $slug, "site_go" => $core->text->line($core->post["go"]), "comp_id" => (int) $core->post["comp"], "site_comp" => $core->post["comph"] ? 1 : 0, "site_mobile" => (int) $core->post["mobile"], "site_default" => $default);
            if ($core->db->edit(DB_SITE, $data, array("site_id" => $id))) {
                $core->uncache("site.uid-" . $slug);
                $core->cpa->clear("site", $id);
                $core->cpa->clear("sites", $s["offer_id"]);
                $core->cpa->clear("lands", $s["offer_id"]);
                $core->cpa->clear("space", $s["offer_id"]);
                $aurl = $s["site_type"] == 1 ? $core->config("space", "control") : $core->config("sites", "control");
                $akey = $s["site_type"] == 1 ? $core->config("space", "key") : $core->config("sites", "key");
                if ($url != $s["site_url"] && $core->post["rename"] && $aurl && $akey) {
                    if (strpos($s["site_url"], "/") !== false) {
                        $op = explode("/", $s["site_url"], 2);
                        $op = $op[1];
                    } else {
                        $op = $s["site_url"];
                    }
                    if (strpos($url, "/") !== false) {
                        $np = explode("/", $url, 2);
                        $np = $np[1];
                    } else {
                        $np = $url;
                    }
                    curl($aurl, array("key" => $akey, "action" => "rename", "from" => $op, "to" => $np));
                }
                curl("http://" . $core->config("space", "domain") . "/renew.php?id=" . $s["offer_id"]);
                $core->go($core->url("im", "offer-sites", $s["offer_id"], "edit-ok"));
            } else {
                $core->go($core->url("im", "offer-sites", $s["offer_id"], "edit-e"));
            }
        case "del":
            $offer = $core->db->field("SELECT offer_id FROM " . DB_SITE . " WHERE site_id = '" . $id . "' LIMIT 1");
            if ($core->db->query("DELETE FROM " . DB_SITE . " WHERE site_id = '" . $id . "'")) {
                $core->cpa->clear("site", $id);
                $core->cpa->clear("sites", $offer);
                $core->cpa->clear("lands", $offer);
                $core->cpa->clear("space", $offer);
                curl("http://" . $core->config("space", "domain") . "/renew.php?id=" . $offer);
                $core->go($core->url("im", "offer-sites", $offer, "del-ok"));
            } else {
                $core->go($core->url("im", "offer-sites", $offer, "del-e"));
            }
        case "erase":
            $s = $core->db->row("SELECT * FROM " . DB_SITE . " WHERE site_id = '" . $id . "' LIMIT 1");
            if ($core->db->query("DELETE FROM " . DB_SITE . " WHERE site_id = '" . $id . "'")) {
                $core->cpa->clear("site", $id);
                $core->cpa->clear("sites", $s["offer_id"]);
                $core->cpa->clear("lands", $s["offer_id"]);
                $core->cpa->clear("space", $s["offer_id"]);
                $aurl = $s["site_type"] == 1 ? $core->config("space", "control") : $core->config("sites", "control");
                $akey = $s["site_type"] == 1 ? $core->config("space", "key") : $core->config("sites", "key");
                if ($aurl && $akey) {
                    if (strpos($s["site_url"], "/") !== false) {
                        $np = explode("/", $s["site_url"], 2);
                        $np = $np[1];
                    } else {
                        $np = $s["site_url"];
                    }
                    curl($aurl, array("key" => $akey, "action" => "remove", "site" => $np));
                }
                curl("http://" . $core->config("space", "domain") . "/renew.php?id=" . $s["offer_id"]);
                $core->go($core->url("im", "offer-sites", $s["offer_id"], "del-ok"));
            } else {
                $core->go($core->url("im", "offer-sites", $s["offer_id"], "del-e"));
            }
    }
    $message = isset($core->get["message"]) ? $core->text->link($core->get["message"]) : NULL;
    switch ($message) {
        case "add-ok":
            $core->site->info("info", "done_offer_site_add");
            break;
        case "add-e":
            $core->site->info("error", "error_offer_site_add");
            break;
    }
    if (!$id) {
        $core->go($core->url("m", "offer"));
    }
    $site = $core->cpa->get("site", $id);
    $offer = $core->cpa->get("offer", $site["offer_id"]);
    $core->site->bc($core->lang["offers_h"], $core->url("m", "offer"));
    $core->site->bc(sprintf($core->lang["offer_sites_h"], $offer["offer_name"]), $core->url("i", "offer-sites", $offer["offer_id"]));
    $core->site->bc($site["site_url"]);
    $core->site->header();
    $comp = array("&mdash;");
    $comps = $core->cpa->get("compa");
    if ($comps) {
        $comp += $comps;
    }
    $mobs = array();
    foreach ($core->lang["site_mobiles"] as $mi => $mv) {
        $mobs[] = array("name" => $mv, "value" => $mi, "select" => $mi == $site["site_mobile"]);
    }
    if ($site["site_type"] == 1) {
        $code = sprintf($core->lang["site_code_p"], $site["offer_id"]);
    } else {
        $code = sprintf($core->lang["site_code_l"], $site["offer_id"], $site["site_id"], $site["site_key"]);
    }
    $aurl = $site["site_type"] == 1 ? $core->config("space", "control") : $core->config("sites", "control");
    $akey = $site["site_type"] == 1 ? $core->config("space", "key") : $core->config("sites", "key");
    $pbuc = $core->config("url", "base") . "api/site/click.json?token=" . $site["site_id"] . "-" . $site["site_key"] . "&click={subid}";
    $pbus = $core->config("url", "base") . "api/site/status.json?token=" . $site["site_id"] . "-" . $site["site_key"] . "&click={subid}&status={status}";
    $t = (int) $site["site_type"];
    switch ($t) {
        case 0:
            $field = array(array("type" => "line", "value" => $core->text->lines($core->lang["offer_site_edit_t"])), array("type" => "text", "length" => 100, "name" => "name", "head" => $core->lang["name"], "value" => $site["site_name"]), array("type" => "text", "length" => 100, "name" => "url", "head" => $core->lang["site_url"], "value" => $site["site_url"]), array("type" => "text", "length" => 100, "name" => "key", "head" => $core->lang["site_key"], "value" => $site["site_key"]), array("type" => "select", "name" => "mobile", "head" => $core->lang["site_mobile"], "value" => $site["site_mobile"], "options" => $core->lang["site_mobiles"]), array("type" => "checkbox", "name" => "default", "head" => $core->lang["site_default"], "descr" => $core->lang["site_default_d"], "checked" => $site["site_default"]), array("type" => "checkbox", "name" => "comph", "head" => $core->lang["site_comp"], "checked" => $site["site_comp"]), array("type" => "select", "name" => "comp", "head" => $core->lang["company"], "value" => $site["comp_id"], "options" => $comp), array("type" => "code", "lang" => "clike,php", "mime" => "application/x-httpd-php-open", "name" => "dummy", "head" => $core->lang["site_code"], "descr" => $core->lang["site_code_d"], "value" => $code));
            if ($aurl && $akey) {
                $field[] = array("type" => "checkbox", "name" => "rename", "head" => $core->lang["site_rename"], "descr" => $core->lang["site_rename_d"]);
            }
            break;
        case 1:
            $field = array(array("type" => "line", "value" => $core->text->lines($core->lang["offer_site_edit_t"])), array("type" => "text", "length" => 100, "name" => "name", "head" => $core->lang["name"], "value" => $site["site_name"]), array("type" => "text", "length" => 100, "name" => "url", "head" => $core->lang["site_url"], "value" => $site["site_url"]), array("type" => "text", "length" => 100, "name" => "key", "head" => $core->lang["site_key"], "value" => $site["site_key"]), array("type" => "select", "name" => "mobile", "head" => $core->lang["site_mobile"], "value" => $site["site_mobile"], "options" => $core->lang["site_mobiles"]), array("type" => "code", "lang" => "clike,php", "mime" => "application/x-httpd-php-open", "name" => "dummy", "head" => $core->lang["site_code"], "descr" => $core->lang["site_code_d"], "value" => $code));
            if ($aurl && $akey) {
                $field[] = array("type" => "checkbox", "name" => "rename", "head" => $core->lang["site_rename"], "descr" => $core->lang["site_rename_d"]);
            }
            break;
        case 2:
            $field = array(array("type" => "line", "value" => $core->text->lines($core->lang["offer_site_edit_t"])), array("type" => "text", "length" => 100, "name" => "name", "head" => $core->lang["name"], "value" => $site["site_name"]), array("type" => "text", "length" => 100, "name" => "url", "head" => $core->lang["site_url"], "value" => $site["site_url"]), array("type" => "text", "length" => 100, "name" => "key", "head" => $core->lang["site_key"], "value" => $site["site_key"]), array("type" => "text", "length" => 100, "name" => "slug", "head" => $core->lang["site_slug"], "descr" => $core->lang["site_slug_d"], "value" => $site["site_slug"]), array("type" => "text", "length" => 500, "name" => "go", "head" => $core->lang["site_go"], "descr" => $core->lang["site_go_d"], "value" => $site["site_go"]), array("type" => "select", "name" => "mobile", "head" => $core->lang["site_mobile"], "value" => $site["site_mobile"], "options" => $core->lang["site_mobiles"]), array("type" => "checkbox", "name" => "default", "head" => $core->lang["site_default"], "descr" => $core->lang["site_default_d"], "checked" => $site["site_default"]), array("type" => "checkbox", "name" => "comph", "head" => $core->lang["site_comp"], "checked" => $site["site_comp"]), array("type" => "select", "name" => "comp", "head" => $core->lang["company"], "value" => $site["comp_id"], "options" => $comp), array("type" => "head", "value" => $core->lang["site_pb_h"]), array("type" => "line", "value" => $core->lang["site_pb_t"]), array("type" => "text", "head" => $core->lang["site_pb_new"], "ro" => 1, "value" => $pbuc), array("type" => "text", "head" => $core->lang["site_pb_uid"], "ro" => 1, "value" => $pbuc . "&exto={id}"), array("type" => "text", "head" => $core->lang["site_pb_nwac"], "ro" => 1, "value" => $pbuc . "&accept=1"), array("type" => "text", "head" => $core->lang["site_pb_status"], "ro" => 1, "value" => $pbus), array("type" => "text", "head" => $core->lang["site_pb_price"], "ro" => 1, "value" => $pbus . "&base={cash}&currency=usd"));
            break;
    }
    $core->site->form("offeredit", $core->url("ia", "offer-site", $id, "edit"), $core->lang["offer_site_edit_h"], $field);
    $core->site->footer();
    $core->stop();
}

?>