<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function callstat($core, $url, $tm = false)
{
    $page = 0 < $core->get["page"] ? (int) $core->get["page"] : 1;
    $today = date("Ymd");
    $yest = date("Ymd", strtotime("-1 day"));
    $week1 = date("Ymd", strtotime("-6 days"));
    $month = date("Ymd", strtotime("-1 month"));
    $month3 = date("Ymd", strtotime("-3 months"));
    extract(params($core, array("to" => "date", "from" => "date", "t", "u")));
    if (!$to || $today < $to) {
        $to = $today;
    }
    if ($to < $from) {
        $from = $to;
    }
    if (!$from) {
        $from = $today;
    }
    $ff = strtotime(date2form($from) . " 00:00:00");
    $tt = strtotime(date2form($to) . " 23:59:59");
    $param = $where = array();
    $param["from"] = date2form($from);
    $param["to"] = date2form($to);
    $where[] = "call_time BETWEEN '" . $ff . "' AND '" . $tt . "'";
    if ($o = (int) $core->get["o"]) {
        $param["o"] = $o;
        $where[] = "offer_id = '" . $o . "'";
    } else {
        $o = false;
    }
    if ($u) {
        $param["u"] = $u;
        $users = array($core->user->get($u));
    } else {
        if ($t || $tm) {
            if ($t) {
                $param["t"] = $t;
            }
            $ti = $tm ? $tm : $t;
            $tc = $core->cpa->get("team", $ti, "comp_id");
            if ($tc != $core->user->comp) {
                $core->go("mm", $url, "access");
            }
            $users = $core->db->data("SELECT user_id, user_name, user_team FROM " . DB_USER . " WHERE user_team = '" . $ti . "'");
        } else {
            $users = $core->db->data("SELECT user_id, user_name, user_team FROM " . DB_USER . " WHERE user_comp = '" . $core->user->comp . "'");
        }
    }
    $ut = $un = array();
    foreach ($users as $uu) {
        $ut[$uu["user_id"]] = (int) $uu["user_team"];
        $un[$uu["user_id"]] = $uu["user_name"];
    }
    $oname = $core->cpa->get("offersa");
    $offer = $core->offer->names($core->user->id);
    $teams = $core->cpa->get("teams", $core->user->comp);
    $ui = array_keys($ut);
    if ($ui) {
        $where[] = "user_id IN ( " . implode(",", $ui) . " )";
        $where = implode(" AND ", $where);
        if ($page == 1) {
            $comp = $core->cpa->get("comp", $core->user->comp);
            $csd = $core->db->data("SELECT order_id, user_id, call_time, call_status, call_reason, call_count, call_accept, call_cur, call_price FROM " . DB_CALL . " WHERE " . $where);
            $cc = count($csd);
            $ccpu = array();
            $cq = explode(",", $comp["ccp_upsale"]);
            foreach ($cq as $cqi => $cqv) {
                $ccpu[$cqi + 1] = (int) $cqv;
            }
            $pays = array(array("ccpd" => $comp["ccp_day"], "ccpn" => $comp["ccp_night"], "ccps" => $comp["ccp_sale"], "ccpu" => $ccpu, "ccpm" => end($ccpu)));
            foreach ($teams as $ti => $tn) {
                $tmd = $core->cpa->get("team", $ti);
                if ($tmd["pay_use"]) {
                    $ccpu = array();
                    $cq = explode(",", $tmd["pay_upsale"]);
                    foreach ($cq as $cqi => $cqv) {
                        $ccpu[$cqi + 1] = (int) $cqv;
                    }
                    $pays[$ti] = array("ccpd" => $tmd["pay_day"], "ccpn" => $tmd["pay_night"], "ccps" => $tmd["pay_sale"], "ccpu" => $ccpu, "ccpm" => end($ccpu));
                } else {
                    $pays[$ti] = $pays[0];
                }
            }
            $stat = $team = array();
            $total = $line = array("ort" => array(), "orc" => array(), "ord" => array(), "ups" => 0, "st2" => 0, "st3" => 0, "st4" => 0, "st5" => 0, "st6" => 0, "st7" => 0, "st8" => 0, "st9" => 0, "st10" => 0, "st11" => 0, "st12" => 0, "smd" => array(), "smn" => array(), "smu" => 0, "ac" => 0, "as" => array(), "mc" => array(), "ma" => array());
            $total["name"] = $core->lang["total"];
            foreach ($csd as $c) {
                $us = $c["user_id"];
                $oi = $c["order_id"];
                $ti = $ut[$us];
                extract($pays[$ti]);
                if (!isset($team[$ti])) {
                    $team[$ti] = $line;
                    $team[$ti]["name"] = $ti ? $teams[$ti] : $core->lang["noteam"];
                }
                if (!isset($stat[$ti][$us])) {
                    $stat[$ti][$us] = $line;
                    $stat[$ti][$us]["url"] = $core->url("m", $url) . "?" . parset($param, "u", $us);
                    $stat[$ti][$us]["name"] = $un[$us];
                }
                $ss = $c["call_status"];
                if ($ss == 5 && istrash(0, $c["call_reason"])) {
                    $ss = 12;
                }
                $total["ort"][$oi] = 1;
                $team[$ti]["ort"][$oi] = 1;
                $stat[$ti][$us]["ort"][$oi] = 1;
                $total["st" . $ss] += 1;
                $team[$ti]["st" . $ss] += 1;
                $stat[$ti][$us]["st" . $ss] += 1;
                if ($ss < 7) {
                    $total["orc"][$oi] = 1;
                    $team[$ti]["orc"][$oi] = 1;
                    $stat[$ti][$us]["orc"][$oi] = 1;
                }
                if (8 < $ss && $ss < 12) {
                    $total["ord"][$oi] = 1;
                    $team[$ti]["ord"][$oi] = 1;
                    $stat[$ti][$us]["ord"][$oi] = 1;
                }
                if ($c["call_accept"] || $ss == 2 || $ss == 5) {
                    $total["ora"][$oi] = 1;
                    $team[$ti]["ora"][$oi] = 1;
                    $stat[$ti][$us]["ora"][$oi] = 1;
                }
                $ups = $c["call_count"] - 1;
                if (0 < $ups) {
                    $total["ups"] += $ups;
                    $team[$ti]["ups"] += $ups;
                    $stat[$ti][$us]["ups"] += $ups;
                    $upp = isset($ccpu[$ups]) ? $ccpu[$ups] : $ccpm;
                    $total["smu"] += $upp;
                    $team[$ti]["smu"] += $upp;
                    $stat[$ti][$us]["smu"] += $upp;
                }
                if ($c["call_accept"]) {
                    $total["ac"] += 1;
                    $team[$ti]["ac"] += 1;
                    $stat[$ti][$us]["ac"] += 1;
                    $total["as"][$ccps] += 1;
                    $team[$ti]["as"][$ccps] += 1;
                    $stat[$ti][$us]["as"][$ccps] += 1;
                    $total["mc"][$c["call_cur"]] += 1;
                    $team[$ti]["mc"][$c["call_cur"]] += 1;
                    $stat[$ti][$us]["mc"][$c["call_cur"]] += 1;
                    $total["ma"][$c["call_cur"]] += $c["call_price"];
                    $team[$ti]["ma"][$c["call_cur"]] += $c["call_price"];
                    $stat[$ti][$us]["ma"][$c["call_cur"]] += $c["call_price"];
                }
                $ch = (int) date("Hi", $c["call_time"]);
                $dd = date("Ymd", $c["call_time"]);
                $d1 = date("Ymd", strtotime("-1 day", $c["call_time"]));
                if ($ch < 700 && $from <= $d1) {
                    $total["smn"][$ccpn][$d1] = 1;
                    $team[$ti]["smn"][$ccpn][$d1] = 1;
                    $stat[$ti][$us]["smn"][$ccpn][$d1] = 1;
                } else {
                    if (930 < $ch && $ch < 1830) {
                        $total["smd"][$ccpd][$dd] = 1;
                        $team[$ti]["smd"][$ccpd][$dd] = 1;
                        $stat[$ti][$us]["smd"][$ccpd][$dd] = 1;
                    } else {
                        if (2130 < $ch) {
                            $total["smn"][$ccpn][$dd] = 1;
                            $team[$ti]["smn"][$ccpn][$dd] = 1;
                            $stat[$ti][$us]["smn"][$ccpn][$dd] = 1;
                        }
                    }
                }
            }
        } else {
            $stat = false;
            $cc = $core->db->field("SELECT COUNT(*) FROM " . DB_CALL . " WHERE " . $where);
        }
        $sh = 30;
        $st = ($page - 1) * $sh;
        $call = $cc ? $core->db->data("SELECT * FROM " . DB_CALL . " WHERE " . $where . " ORDER BY call_id DESC LIMIT " . $st . ", " . $sh) : array();
    } else {
        $stat = $cc = $call = false;
    }
    $core->site->bc($core->lang[$url], $core->url("m", $url));
    $core->site->set("select2");
    $core->site->header();
    $core->tpl->load("body", "callstat", defined("HACK_TPL_CALLSTAT") ? HACK : false);
    $core->tpl->vars("body", array("from" => date2form($from), "to" => date2form($to), "pages" => pages($core->url("m", $url) . "?" . http_build_query($param), $cc, $sh, $page, sprintf($core->lang["shown"], $st + 1, min($st + $sh, $cc), $cc)), "shown" => sprintf($core->lang["shown"], $st + 1, min($st + $sh, $cc), $cc), "offer" => $core->lang["offer"], "order" => $core->lang["order"], "user" => $core->lang["user"], "status" => $core->lang["status"], "time" => $core->lang["date"], "next" => $core->lang["log_next"], "length" => $core->lang["log_length"], "who" => $core->lang["anal_who"], "count" => $core->lang["anal_count"], "total" => $core->lang["anal_total"], "callcenter" => $core->lang["anal_callcenter"], "store" => $core->lang["anal_store"], "upsale" => $core->lang["anal_upsale"], "approve" => $core->lang["anal_approve"], "orders" => $core->lang["anal_orders"], "taken" => $core->lang["anal_taken"], "call" => $core->lang["anal_call"], "hold" => $core->lang["anal_hold"], "cancel" => $core->lang["anal_cancel"], "trash" => $core->lang["anal_trash"], "accept" => $core->lang["anal_accept"], "delivery" => $core->lang["anal_delivery"], "return" => $core->lang["anal_return"], "buy" => $core->lang["anal_buy"], "packing" => $core->lang["statuso"][6], "send" => $core->lang["statuso"][7], "indelivery" => $core->lang["statuso"][8], "delivered" => $core->lang["statuso"][9], "finance" => $core->lang["anal_finance"], "bill" => $core->lang["anal_bill"], "salary" => $core->lang["anal_salary"], "bonus" => $core->lang["anal_bonus"], "lfrom" => $core->lang["anal_from"], "lto" => $core->lang["anal_to"], "offer" => $core->lang["offer"], "show" => $core->lang["show"], "noitem" => $core->lang["anal_noitem"], "today" => $core->lang["anal_today"], "yest" => $core->lang["anal_yest"], "day7" => $core->lang["anal_day7"], "day30" => $core->lang["anal_day30"], "day90" => $core->lang["anal_day90"], "u_search" => $core->url("m", $url), "u_today" => $core->url("m", $url) . "?" . parmult($param, array("from" => date2form($today), "to" => date2form($today))), "u_yest" => $core->url("m", $url) . "?" . parmult($param, array("from" => date2form($yest), "to" => date2form($yest))), "u_day7" => $core->url("m", $url) . "?" . parmult($param, array("from" => date2form($week1), "to" => date2form($today))), "u_day30" => $core->url("m", $url) . "?" . parmult($param, array("from" => date2form($month), "to" => date2form($today))), "u_day90" => $core->url("m", $url) . "?" . parmult($param, array("from" => date2form($month3), "to" => date2form($today)))));
    foreach ($offer as $i => $of) {
        $core->tpl->block("body", "offer", array("name" => $of, "value" => $i, "select" => $o == $i ? "selected=\"selected\"" : ""));
    }
    if ($stat) {
        $core->tpl->block("body", "stat");
        $ust = $teams && !$tm && !$t ? true : false;
        uasort($team, "callstatsort");
        foreach ($team as $t => $d) {
            if (!$stat[$t]) {
                continue;
            }
            if ($ust) {
                callstatline($core, $d, 1);
            }
            uasort($stat[$t], "callstatsort");
            foreach ($stat[$t] as $s) {
                callstatline($core, $s);
            }
        }
        callstatline($core, $total, 1);
    }
    if ($call) {
        foreach ($call as $l) {
            if ($l["call_length"]) {
                if (60 < $l["call_length"]) {
                    $mm = floor($l["call_length"] / 60);
                    $ss = $l["call_length"] % 60;
                    $cl = sprintf($core->lang["log_ms"], $mm, $ss);
                } else {
                    $cl = sprintf($core->lang["log_sec"], $l["call_length"]);
                }
            } else {
                $cl = false;
            }
            $core->tpl->block("body", "log", array("user" => $un[$l["user_id"]], "u_user" => $core->url("m", $url) . "?" . parset($param, "u", $l["user_id"]), "offer" => $oname[$l["offer_id"]], "u_offer" => $core->url("m", $url) . "?" . parset($param, "o", $l["offer_id"]), "order" => $l["order_id"], "u_order" => $core->url("i", "order", $l["order_id"]), "type" => $u ? "boss" : "robot", "time" => smartdate($l["call_time"]), "next" => $l["call_next"] ? smartdate($l["call_next"]) : ($l["call_reason"] ? "<small class=\"red\">" . $core->lang["reasono"][$l["call_reason"]] . "</small>" : false), "status" => $core->lang["statuso"][$l["call_status"]], "sclass" => $l["call_status"], "length" => $cl));
        }
    } else {
        $core->tpl->block("body", "nolog");
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}
function callstatsort($a, $b)
{
    return strcmp($a["name"], $b["name"]);
}
function callstatline($core, $l, $b = false)
{
    $ll = array("name" => $l["name"], "url" => $l["url"], "head" => $b);
    for ($i = 2; $i < 13; $i++) {
        $ll["st" . $i] = $l["st" . $i];
    }
    $ll["ups"] = (int) $l["ups"];
    $ll["tt"] = count($l["ort"]);
    $ll["cc"] = count($l["orc"]);
    $ll["dd"] = count($l["ord"]);
    $ll["aa"] = count($l["ora"]);
    $sd = $sn = $tt = 0;
    foreach ($l["smd"] as $ss => $sa) {
        $qq = count($sa);
        $sd += $qq;
        $tt += $ss * $qq;
    }
    foreach ($l["smn"] as $ss => $sa) {
        $qq = count($sa);
        $sn += $qq;
        $tt += $ss * $qq;
    }
    foreach ($l["as"] as $ss => $sa) {
        $tt += $ss * $sa;
    }
    $smi = sprintf("%d дневных + %d ночных", $sd, $sn);
    $ll["sm"] = $core->currency->money($tt);
    $ll["sm"] = "<abbr title=\"" . $smi . "\">" . $ll["sm"] . "</abbr>";
    $ll["su"] = $core->currency->money($l["smu"]);
    $ll["st"] = $core->currency->money($tt + $l["smu"]);
    $ll["ac"] = sprintf("%0.1f", $l["ac"] ? $l["ac"] * 100 / $ll["aa"] : 0);
    $ll["mm"] = $core->currency->money($l["ac"] ? $l["mm"] / $l["ac"] : 0);
    $core->tpl->block("body", "stat.row", $ll);
    foreach ($l["mc"] as $cu => $cc) {
        $core->tpl->block("body", "stat.row.mn", array("c" => $core->currency->code($cu), "m" => ceil($l["ma"][$cu] / $cc)));
    }
}

?>