<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

if (!function_exists("downloadsite")) {
    function downloadsite($url, $dst, $proxy = false)
    {
        if (defined("HTTRACK")) {
            $command = HTTRACK . " \"" . $url . "\" -O ";
            $command .= $dst;
            $command .= " -F \"Mozilla/5.0 (Windows NT 10.0; WOW64; rv:59.0) Gecko/20100101 Firefox/59.0\" -C0 -N1004 -n -I0";
            if ($proxy) {
                $command .= " -P " . $proxy;
            }
            exec($command);
            @unlink($dst . "/cookies.txt");
            @unlink($dst . "/hts-log.txt");
            $qs = parse_url($url, PHP_URL_QUERY);
            $pt = parse_url($url, PHP_URL_PATH);
            if ($pt) {
                if (substr($pt, -1) != "/") {
                    $pt = explode("/", $pt);
                    $pt = end($pt);
                } else {
                    $pt = false;
                }
            }
            if ($qs) {
                if ($pt) {
                    @rename($dst . "/" . $pt . @substr(@md5($qs), 0, 4) . ".html", $dst . "/index.html");
                } else {
                    @rename($dst . "/index" . @substr(@md5($qs), 0, 4) . ".html", $dst . "/index.html");
                }
            } else {
                if ($pt) {
                    @rename($dst . "/" . $pt . "html", $dst . "/index.html");
                } else {
                    @rename($dst . "/index-2.html", $dst . "/index.html");
                }
            }
        } else {
            if (!defined("WGET")) {
                define("WGET", "/usr/bin/wget");
            }
            $sp = trim(parse_url($url, PHP_URL_PATH), "/");
            $cut = $sp ? count(explode("/", $sp)) : 0;
            $command = "cd " . $dst . " && ";
            $command .= WGET . " -q -r -k -l 9 -p -E -nH --user-agent=\"Mozilla/5.0 (Windows NT 10.0; WOW64; rv:59.0) Gecko/20100101 Firefox/59.0\" ";
            if ($proxy) {
                $command .= "-e use_proxy=yes -e http_proxy=" . $proxy . " ";
            }
            if ($cut) {
                $command .= "--cut-dirs=" . $cut . " ";
            }
            $command .= $url;
            exec($command);
        }
    }
}
function loadsites($core, $lwid)
{
    $core->db->query("UPDATE " . DB_LOAD . " SET load_mark = 0 WHERE load_mark = " . $lwid);
    $sites = 0;
    while (true) {
        $tm = time();
        $ltm = $tm - 600;
        $core->db->query("UPDATE " . DB_LOAD . " SET load_mark = " . $lwid . " WHERE load_status < 3 AND ( load_mark = 0 OR load_last < " . $tm . " ) LIMIT 1");
        $s = $core->db->row("SELECT * FROM " . DB_LOAD . " WHERE load_mark = " . $lwid . " LIMIT 1");
        if ($s) {
            set_time_limit(1800);
            $core->db->edit(DB_LOAD, array("load_status" => 1, "load_last" => time()), array("load_id" => $s["load_id"]));
            $dst = defined("LWID") ? DIR_LOAD . LWID : DIR_LOAD;
            if (is_dir($dst)) {
                cleandir($dst);
            } else {
                mkdir($dst, 511, true);
            }
            $curl = curl_init($s["load_url"]);
            curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:59.0) Gecko/20100101 Firefox/59.0");
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 0);
            curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($curl, CURLOPT_FAILONERROR, false);
            curl_setopt($curl, CURLOPT_HEADER, 1);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array("Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "Connection: keep-alive", "Accept-Language: ru", "Accept-Encoding: gzip, deflate"));
            if ($s["load_proxy"]) {
                curl_setopt($curl, CURLOPT_PROXY, $s["load_proxy"]);
            }
            $result = curl_exec($curl);
            $url = curl_getinfo($curl, CURLINFO_EFFECTIVE_URL);
            curl_close($curl);
            downloadsite($url, $dst, $s["load_proxy"]);
            $site = $s["load_type"] ? $core->config("space", "control") : $core->config("sites", "control");
            $scnk = $s["load_type"] ? $core->config("space", "key") : $core->config("sites", "key");
            if ($s["site_id"]) {
                $sd = $core->cpa->get("site", $s["site_id"]);
                $si = $s["site_id"];
            } else {
                $sn = strpos($s["load_site"], ".") ? $s["load_site"] : parse_url($site, PHP_URL_HOST) . "/" . $s["load_site"];
                $sd = array("offer_id" => $s["offer_id"], "site_type" => $s["load_type"], "site_url" => $sn, "site_key" => md5(microtime()));
                if (!$core->db->add(DB_SITE, $sd)) {
                    $core->db->edit(DB_LOAD, array("load_status" => 4, "load_last" => time(), "load_mark" => 0), array("load_id" => $s["load_id"]));
                    continue;
                }
                $sd["site_id"] = $core->db->lastid();
                $si = $sd["site_id"];
                $core->db->edit(DB_LOAD, array("site_id" => $si), array("load_id" => $s["load_id"]));
            }
            $core->cpa->clear("site", $si);
            $core->cpa->clear("sites", $s["offer_id"]);
            $core->cpa->clear("lands", $s["offer_id"]);
            $core->cpa->clear("space", $s["offer_id"]);
            $core->cpa->clear("siteurls");
            $core->cpa->clear("lands");
            $core->cpa->clear("space");
            $page = file_get_contents($dst . "/index.html");
            if (class_exists("Tidy")) {
                $pp = new Tidy();
                $tc = array("clean" => true, "hide-comments" => true, "output-html" => true);
                $pp->parseString($page, $tc);
                $pp->cleanRepair();
                $page = tidy_get_output($pp);
                unset($pp);
            }
            if (stripos($page, "</body>") !== false) {
                $page = str_ireplace("</body>", "<?php footer(); ?></body>", $page);
            } else {
                if (stripos($data, "</html>") !== false) {
                    $page = str_ireplace("</html>", "<?php footer(); ?></body></html>", $page);
                } else {
                    $page .= "<?php footer(); ?></body></html>";
                }
            }
            $page = str_replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "", $page);
            $page = str_replace("<style>body{display:none}</style>", "", $page);
            if ($s["load_type"]) {
                $page = "<?php include \"../offer" . $s["offer_id"] . ".php\"; \$url = ourl(); ?>" . $page;
                preg_match_all("#<a([^>]+)>#msi", $page, $ms);
                $ass = array_unique($ms[0]);
                $badtags = array("article", "aside");
                foreach ($ass as $a) {
                    $goodtag = true;
                    foreach ($badtags as $bb) {
                        if (strtolower(substr($a, 1, strlen($bb))) != $bb) {
                            $goodtag = false;
                        }
                    }
                    if ($goodtag && strpos($a, "href") === false) {
                        $page = str_replace($a, "<a href=\"\" " . substr($a, 2), $page);
                    }
                }
                $page = str_replace("href =", "href=", $page);
                $page = str_replace("href= ", "href=", $page);
                $page = preg_replace("#<a\\s+([^>]*)href=\"(.*?)\"#si", "<a \$1 href=\"<?=\$url;?>\"", $page);
                $page = preg_replace("#<a\\s+([^>]*)href='(.*?)'#si", "<a \$1 href='<?=\$url;?>'", $page);
                $page = preg_replace("#onclick=\"(.*?)\"#si", "", $page);
                $page = preg_replace("#<script(.*?)</script>#si", "", $page);
                $page = preg_replace("#<noscript(.*?)</noscript>#si", "", $page);
                $page = str_replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "", $page);
            } else {
                $page = "<?php \ndefine( 'OFFER', '" . $s["offer_id"] . "' );\ndefine( 'SITE', '" . $si . "' );\ndefine( 'SKEY', '" . $sd["site_key"] . "' );\nrequire_once '../cms.php';\t\t\t\t\n?>" . $page;
                if (preg_match_all("#<form[^>]+>#i", $page, $ms)) {
                    $mms = array_unique($ms[0]);
                    foreach ($mms as $m) {
                        $mm = str_ireplace("method=\"\"", "method=\"post\"", $m);
                        $mm = str_ireplace("method=''", "method=\"post\"", $mm);
                        $mm = preg_replace("#method=\"([a-z0-9]+)\"#i", "method=\"post\"", $mm);
                        $mm = preg_replace("#method='([a-z0-9]+)'#i", "method=\"post\"", $mm);
                        if (strpos($mm, "method") === false) {
                            $mm = str_ireplace("<form", "<form method=\"post\"", $mm);
                        }
                        $mm = preg_replace("#action=\"([^\\\"]+)\"#i", "action=\"\"", $mm);
                        if (strpos($mm, "action") === false) {
                            $mm = str_ireplace("<form", "<form action=\"\"", $mm);
                        }
                        $mm = $mm . "<?=\$params;?>";
                        $page = str_replace($m, $mm, $page);
                    }
                }
                $lcl = unserialize($s["load_clean"]);
                foreach ($lcl as $cl) {
                    $page = preg_replace($cl[0], $cl[1], $page);
                }
                $page = str_replace("index.html", "", $page);
            }
            file_put_contents($dst . "/index.php", $page);
            @unlink($dst . "/index.html");
            $data = array();
            scanfiles($data, $dst . "/", "");
            $data = json_encode($data);
            $core->db->edit(DB_LOAD, array("load_status" => 2, "load_last" => time()), array("load_id" => $s["load_id"]));
            $res = curl($site, array("key" => $scnk, "action" => "create", "site" => $s["load_site"], "force" => $s["site_id"] ? 1 : 0, "data" => $data));
            $core->db->edit(DB_LOAD, array("load_status" => $res == "ok" ? 3 : 4, "load_last" => time(), "load_mark" => 0), array("load_id" => $s["load_id"]));
            curl("http://" . $core->config("space", "domain") . "/renew.php?id=" . $s["offer_id"]);
            cleandir($dst);
            $sites += 1;
            if (100 < $sites) {
                return true;
            }
        } else {
            return false;
        }
    }
}
function scanfiles(&$data, $base, $path)
{
    $d = opendir($base . $path);
    while ($f = readdir($d)) {
        if ($f == "." || $f == "..") {
            continue;
        }
        $fn = $path ? $path . "/" . $f : $f;
        if (!is_dir($base . $fn)) {
            $data[$fn] = base64_encode(file_get_contents($base . $fn));
        } else {
            scanfiles($data, $base, $fn);
        }
    }
    closedir($d);
}

?>