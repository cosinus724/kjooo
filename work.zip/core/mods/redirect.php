<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

if (isset($_GET["checkdomain"])) {
    exit("ok");
}
$fid = isset($_GET["flow"]) ? (int) $_GET["flow"] : false;
if (!$fid) {
    $fid = isset($_GET["flid"]) ? (int) $_GET["flid"] : false;
}
$tid = isset($_GET["test"]) ? (int) $_GET["test"] : false;
$ssi = isset($_GET["site"]) ? filter_var($_GET["site"], FILTER_SANITIZE_STRING) : false;
if (!($fid || $tid || $ssi)) {
    exit("oups");
}
require_once PATH . "core/start.php";
if ($tid) {
    $test = $core->cpa->get("split", $tid);
    if (!$test) {
        exit("oups!");
    }
    $mobile = preg_match("/mobile|ip(hone|od|ad)|android|blackberry|iemobile|kindle|netfront|(hpw|web)os|fennec|minimo|opera m(obi|ini)|blazer|dolfin|dolphin|skyfire|zune|tablet|silk|playbook/i", $_SERVER["HTTP_USER_AGENT"]) ? 1 : 0;
    $ios = preg_match("/iphone|ipod|ipad/i", $_SERVER["HTTP_USER_AGENT"]) ? 1 : 0;
    $freepos = 1000;
    $nopos = 0;
    foreach ($test as $i => $t) {
        $bad = false;
        if ($t["mobile"] == 1 && !$mobile) {
            $bad = true;
        }
        if ($t["mobile"] == 2 && $mobile) {
            $bad = true;
        }
        if ($t["mobile"] == 3 && !$mobile && !$ios) {
            $bad = true;
        }
        if ($t["mobile"] == 4 && !$mobile && $ios) {
            $bad = true;
        }
        if ($t["geo"] && !geo($core->db, $t["geo"])) {
            $bad = true;
        }
        if ($t["nogeo"] && geo($core->db, $t["nogeo"])) {
            $bad = true;
        }
        if (!$bad) {
            if ($t["pos"]) {
                $freepos -= ceil($t["pos"] * 10);
            } else {
                $nopos += 1;
            }
        } else {
            unset($test[$i]);
        }
    }
    unset($i);
    unset($t);
    if (!count($test)) {
        exit("oups!!");
    }
    $da = array();
    foreach ($test as $i => $t) {
        $da[$i] = ceil($t["pos"] ? $t["pos"] * 10 : $freepos / $nopos);
    }
    $tc = isset($_COOKIE["test" . $tid]) ? (int) $_COOKIE["test" . $tid] : false;
    if (!($tc && $da[$tc])) {
        $tt = wrand($da);
        setcookie("test" . $tid, $tt, time() + 600, "/");
    } else {
        $tt = $tc;
    }
    if (!$test[$tt]["url"]) {
        $url = false;
        $fid = $test[$tt]["flow"];
    } else {
        $url = $test[$tt]["url"];
    }
} else {
    $url = $tt = false;
}
if (!$url && $fid) {
    $flow = $core->flow->get($fid);
    if (!$flow["id"]) {
        exit("oups!!!");
    }
    if ($flow["url"]) {
        $offer = $core->cpa->get("offer", $flow["offer"]);
        $cntr = $offer["offer_country"] ? $offer["offer_country"] : "ru";
        $cntr = preg_split("/[\\,]+/", $cntr, -1, PREG_SPLIT_NO_EMPTY);
        $url = geo($core->db, $cntr) ? false : $flow["url"];
    } else {
        $url = false;
    }
    if (!$url) {
        $st = $core->cpa->get("site", $flow["site"], "site_type");
        if ($st == 2) {
            $sid = $flow["site"];
        } else {
            $url = $core->flow->makeurl($flow, true);
        }
    }
}
if (!$url && ($sid || $ssi)) {
    if (!$sid) {
        $ssi = $core->text->link($ssi);
        $sid = $core->cache("site.uid-" . $ssi);
        if (!$sid) {
            $sid = $core->db->field("SELECT site_id FROM " . DB_SITE . " WHERE site_slug = '" . $ssi . "' LIMIT 1");
            if (!$sid) {
                $sid = -1;
            }
            $core->cache("site.uid-" . $ssi, $sid);
        }
        if ($sid < 0) {
            $sid = 0;
        }
    }
    if ($sid) {
        $s = $core->cpa->get("site", $sid);
        $url = html_entity_decode($s["site_go"]);
        if ($flow) {
            $u = $core->user->get($flow["user"]);
            if ($u["user_ban"]) {
                exit("banned");
            }
            if (!$core->offer->auth($s["offer_id"], $flow["user"])) {
                exit("ooops!");
            }
            $click = array("flow_id" => $flow["id"], "user_id" => $flow["user"], "utms" => $flow["utms"], "utmc" => $flow["utmc"], "utmn" => $flow["utmn"], "utmt" => $flow["utmt"], "utmm" => $flow["utmm"]);
        } else {
            $click = $flow = array();
        }
        if (isset($core->get["utm_source"])) {
            $click["utms"] = $core->text->anum($core->get["utm_source"]);
        }
        if (isset($core->get["utm_content"])) {
            $click["utmn"] = $core->text->anum($core->get["utm_content"]);
        }
        if (isset($core->get["utm_campaign"])) {
            $click["utmc"] = $core->text->anum($core->get["utm_campaign"]);
        }
        if (isset($core->get["utm_medium"])) {
            $click["utmm"] = $core->text->anum($core->get["utm_medium"]);
        }
        if (isset($core->get["utm_term"])) {
            $click["utmt"] = $core->text->anum($core->get["utm_term"]);
        }
        $wfid = isset($core->cookie["site" . $sid]) ? (int) $core->cookie["site" . $sid] : false;
        $unique = $fid && $wfid == $fid ? 0 : 1;
        setcookie("site" . $sid, $fid, 86400, "/");
        $click["offer_id"] = $s["offer_id"];
        $click["site_id"] = $sid;
        $click["test_id"] = $tt ? $tt : 0;
        $click["site_sib"] = isset($core->get["from"]) ? (int) $core->get["from"] : 0;
        $click["ext_id"] = isset($core->get["exti"]) ? (int) $core->get["exti"] : 0;
        $click["ext_uid"] = isset($core->get["extu"]) ? $core->text->anum($core->get["extu"]) : "";
        $click["ext_src"] = isset($core->get["exts"]) ? $core->text->anum($core->get["exts"]) : "";
        $click["click_space"] = 0;
        $click["click_unique"] = $unique;
        $click["click_date"] = date("Ymd");
        $click["click_time"] = time();
        $click["click_hour"] = date("H");
        $click["click_ip"] = ip2int(ip());
        $click["click_geo"] = getgeo($core->db);
        $click["utms32"] = sprintf("%u", crc32($click["utms"]));
        $click["utmc32"] = sprintf("%u", crc32($click["utmc"]));
        $click["utmn32"] = sprintf("%u", crc32($click["utmn"]));
        $click["utmt32"] = sprintf("%u", crc32($click["utmt"]));
        $click["utmm32"] = sprintf("%u", crc32($click["utmm"]));
        if ($click["ext_id"] && !$core->offer->auth($s["offer_id"], -1, $click["ext_id"], $click["ext_src"])) {
            exit("ooops!");
        }
        $url = str_replace("{wm}", $flow["user"], $url);
        $url = str_replace("{uid}", randstr(16), $url);
        $ofp = $core->cpa->get("ofp", $s["offer_id"]);
        foreach ($ofp as $n => $v) {
            $url = str_replace("{ofp:" . $n . "}", $v, $url);
        }
        if ($core->db->add(DB_CLICK, $click)) {
            $cid = $core->db->lastid();
            $url = str_replace("{id}", $cid, $url);
        } else {
            $url = false;
        }
    }
}
if (!$url) {
    $url = "/";
}
if ($tt) {
    $url .= (strpos($url, "?") ? "&t=" : "?t=") . $tt;
}
if (isset($_GET["site"])) {
    unset($_GET["site"]);
}
if (isset($_GET["flow"])) {
    unset($_GET["flow"]);
}
if (isset($_GET["flid"])) {
    unset($_GET["flid"]);
}
if (isset($_GET["test"])) {
    unset($_GET["test"]);
}
if (isset($_GET["exti"])) {
    unset($_GET["exti"]);
}
if (isset($_GET["extu"])) {
    unset($_GET["extu"]);
}
if (isset($_GET["exts"])) {
    unset($_GET["exts"]);
}
if (count($_GET)) {
    $url .= (strpos($url, "?") ? "&" : "?") . http_build_query($_GET);
}
header("Location: " . $url);
function ip()
{
    static $ip = NULL;
    if (isset($ip)) {
        return $ip;
    }
    if ($_SERVER["HTTP_X_FORWARDED_FOR"]) {
        if (strpos($_SERVER["HTTP_X_FORWARDED_FOR"], ",") !== false) {
            $xffd = explode(",", $_SERVER["HTTP_X_FORWARDED_FOR"]);
            foreach ($xffd as $xff) {
                $xff = trim($xff);
                $ip = filter_var($xff, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
                if ($ip) {
                    break;
                }
            }
        } else {
            $ip = filter_var($_SERVER["HTTP_X_FORWARDED_FOR"], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
        }
    }
    if (!$ip) {
        $ip = filter_var($_SERVER["HTTP_CLIENT_IP"], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
    }
    if (!$ip) {
        $ip = $_SERVER["REMOTE_ADDR"];
    }
    return $ip;
}
function getgeo($db)
{
    static $geo = NULL;
    if (!$geo) {
        $ip = ip();
        $ipi = sprintf("%u", ip2long($ip));
        $geo = $db->field("SELECT `country` FROM `" . DB_GEOIP . "` WHERE `ip` < '" . $ipi . "' ORDER BY `ip` DESC LIMIT 1");
    }
    return $geo;
}
function geo($db, $cntr)
{
    static $geo = NULL;
    if (!$geo) {
        $geo = getgeo($db);
    }
    return in_array($geo, $cntr) ? true : false;
}

?>