<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function analytics_delivery($core, $url, $cfg = array())
{
    $cmp = isset($cfg["cmp"]) ? $cfg["cmp"] : false;
    $mgr = isset($cfg["manager"]) ? $cfg["manager"] : false;
    $vip = isset($cfg["vip"]) ? $cfg["vip"] : false;
    $csv = $core->get["show"] == "csv" ? 1 : 0;
    $today = date("Ymd");
    $yest = date("Ymd", strtotime("-1 day"));
    $week1 = date("Ymd", strtotime("-6 days"));
    $month = date("Ymd", strtotime("-1 month"));
    $month3 = date("Ymd", strtotime("-3 months"));
    $param = $where1 = $where2 = array();
    $where1[] = "order_status BETWEEN 6 AND 11";
    $where2[] = "call_status IN ( 6, 7, 8 )";
    extract(params($core, array("to" => "date", "from" => "date")));
    if (!$to || $today < $to) {
        $to = $today;
    }
    if ($to < $from) {
        $from = $to;
    }
    if (!$from) {
        $from = $today;
    }
    $ff = strtotime(date2form($from) . " 00:00:00");
    $tt = strtotime(date2form($to) . " 23:59:59");
    $param["from"] = date2form($from);
    $param["to"] = date2form($to);
    $where1[] = "order_time BETWEEN '" . $ff . "' AND '" . $tt . "'";
    $where2[] = "call_time BETWEEN '" . $ff . "' AND '" . $tt . "'";
    if ($o = (int) $core->get["o"]) {
        $param["o"] = $o;
        $where1[] = "offer_id = '" . $o . "'";
        $where2[] = "offer_id = '" . $o . "'";
    } else {
        $o = false;
    }
    if ($geo = $core->text->link($core->get["geo"])) {
        $param["geo"] = $geo;
        $where1[] = "order_country = '" . $geo . "'";
        $where2[] = "call_geo = '" . $geo . "'";
    } else {
        $geo = false;
    }
    if ($mgr && !$vip) {
        $wml = $core->db->col("SELECT user_id FROM " . DB_USER . " WHERE user_man = '" . $mgr . "'");
        if ($wml) {
            $wm = (int) $core->get["wm"];
            if ($wm && in_array($wm, $wml)) {
                $param["wm"] = $wm;
                $where1[] = "wm_id = '" . $wm . "'";
                $where2[] = "wm_id = '" . $wm . "'";
            } else {
                $where1[] = "wm_id IN ( " . implode(",", $wml) . " )";
                $where2[] = "wm_id IN ( " . implode(",", $wml) . " )";
            }
        } else {
            $where[] = "wm_id = -1";
        }
    } else {
        if ($wm = (int) $core->get["wm"]) {
            $param["wm"] = $wm;
            $where1[] = "wm_id = '" . $wm . "'";
            $where2[] = "wm_id = '" . $wm . "'";
        } else {
            $wm = false;
        }
    }
    if ($cmp || ($cc = (int) $core->get["c"])) {
        if (!$cmp) {
            $param["c"] = $cc;
        }
        $where1[] = $cmp ? "comp_id = '" . $cmp . "'" : "comp_id = '" . $cc . "'";
        $where2[] = $cmp ? "comp_id = '" . $cmp . "'" : "comp_id = '" . $cc . "'";
    } else {
        $cc = false;
    }
    if (isset($core->get["d"]) && $core->get["d"] != "") {
        $dd = (int) $core->get["d"];
        $param["d"] = $dd;
        $where1[] = "order_delivery = '" . $dd . "'";
        $where2[] = "call_delivery = '" . $dd . "'";
    } else {
        $dd = NULL;
    }
    if ($src = (int) $core->get["src"]) {
        $param["src"] = $src;
        $where1[] = "ext_src = '" . $src . "'";
        $where2[] = "0";
    } else {
        $src = false;
    }
    $where1 = implode(" AND ", $where1);
    $where2 = implode(" AND ", $where2);
    $oname = $core->cpa->get("offersa");
    $offer = $cmp ? $core->offer->names($core->user->id) : $oname;
    $comps = $core->cpa->get("compa");
    $bc = $bw = $bo = $bd = $bg = array();
    $total = $line = array("total" => 0, "in6" => 0, "in7" => 0, "in8" => 0, "st6" => 0, "st7" => 0, "st8" => 0, "st9" => 0, "st10" => 0, "st11" => 0, "ma" => array(), "mc" => array());
    $total["name"] = $core->lang["anal_total"];
    $st = 0;
    $sh = 1000;
    while (true) {
        $csd = $core->db->data("SELECT offer_id, wm_id, comp_id, order_time, order_status, order_reason, order_delivery, order_country, price_total, price_cur, cash_wm, cash_pay FROM " . DB_ORDER . " WHERE " . $where1 . " LIMIT " . $st . ", " . $sh);
        $oc = count($csd);
        if (!$oc) {
            break;
        }
        foreach ($csd as $c) {
            $ic = (int) $c["comp_id"];
            $iw = (int) $c["wm_id"];
            $io = (int) $c["offer_id"];
            $id = (int) $c["order_delivery"];
            $ig = $c["order_country"];
            if (!isset($bc[$ic])) {
                $bc[$ic] = $line;
                $bc[$ic]["name"] = $comps[$ic];
                $bc[$ic]["u"] = $core->url("m", "order?") . parset($param, "c", $ic);
            }
            if (!isset($bw[$iw])) {
                $bw[$iw] = $line;
                $bw[$iw]["name"] = $iw ? $cmp ? $iw : $core->user->get($iw, "user_name") : $core->lang["anal_search"];
                $bw[$iw]["u"] = $core->url("m", "order?") . parset($param, "wm", $iw);
            }
            if (!isset($bo[$io])) {
                $bo[$io] = $line;
                $bo[$io]["name"] = $oname[$io];
                $bo[$io]["u"] = $core->url("m", "order?") . parset($param, "o", $io);
            }
            if (!isset($bd[$id])) {
                $bd[$id] = $line;
                $bd[$id]["name"] = $core->lang["delivery"][$id];
            }
            if (!isset($bg[$ig])) {
                $bg[$ig] = $line;
                $bg[$ig]["name"] = $core->lang["country"][$ig];
                $bg[$ig]["u"] = $core->url("m", "order?") . parset($param, "geo", $ig);
            }
            $total["total"] += 1;
            $bc[$ic]["total"] += 1;
            $bw[$iw]["total"] += 1;
            $bo[$io]["total"] += 1;
            $bd[$id]["total"] += 1;
            $bg[$ig]["total"] += 1;
            $total["st" . $c["order_status"]] += 1;
            $bc[$ic]["st" . $c["order_status"]] += 1;
            $bw[$iw]["st" . $c["order_status"]] += 1;
            $bo[$io]["st" . $c["order_status"]] += 1;
            $bd[$id]["st" . $c["order_status"]] += 1;
            $bg[$ig]["st" . $c["order_status"]] += 1;
            if ($c["order_status"] == 10) {
                $total["ma"][$c["price_cur"]] += $c["price_total"];
                $bc[$ic]["ma"][$c["price_cur"]] += $c["price_total"];
                $bw[$iw]["ma"][$c["price_cur"]] += $c["price_total"];
                $bo[$io]["ma"][$c["price_cur"]] += $c["price_total"];
                $bd[$id]["ma"][$c["price_cur"]] += $c["price_total"];
                $bg[$ig]["ma"][$c["price_cur"]] += $c["price_total"];
            }
            if ($c["order_status"] == 11) {
                $total["mc"][$c["price_cur"]] += $c["price_total"];
                $bc[$ic]["mc"][$c["price_cur"]] += $c["price_total"];
                $bw[$iw]["mc"][$c["price_cur"]] += $c["price_total"];
                $bo[$io]["mc"][$c["price_cur"]] += $c["price_total"];
                $bd[$id]["mc"][$c["price_cur"]] += $c["price_total"];
                $bg[$ig]["mc"][$c["price_cur"]] += $c["price_total"];
            }
        }
        if ($oc == $sh) {
            $st += $sh;
        } else {
            break;
        }
    }
    $st = 0;
    $sh = 1000;
    while (true) {
        $csd = $core->db->data("SELECT offer_id, wm_id, comp_id, call_status, call_delivery, call_geo FROM " . DB_CALL . " WHERE " . $where2 . " LIMIT " . $st . ", " . $sh);
        $oc = $csd ? count($csd) : 0;
        if (!$oc) {
            break;
        }
        foreach ($csd as $c) {
            $ic = (int) $c["comp_id"];
            $iw = (int) $c["wm_id"];
            $io = (int) $c["offer_id"];
            $id = (int) $c["call_delivery"];
            $ig = $c["call_geo"];
            if (!isset($bc[$ic])) {
                $bc[$ic] = $line;
                $bc[$ic]["name"] = $comps[$ic];
                $bc[$ic]["u"] = $core->url("m", "order?") . parset($param, "c", $ic);
            }
            if (!isset($bw[$iw])) {
                $bw[$iw] = $line;
                $bw[$iw]["name"] = $iw ? $cmp ? $iw : $core->user->get($iw, "user_name") : $core->lang["anal_search"];
                $bw[$iw]["u"] = $core->url("m", "order?") . parset($param, "wm", $iw);
            }
            if (!isset($bo[$io])) {
                $bo[$io] = $line;
                $bo[$io]["name"] = $offer[$io];
                $bo[$io]["u"] = $core->url("m", "order?") . parset($param, "o", $io);
            }
            if (!isset($bd[$id])) {
                $bd[$id] = $line;
                $bd[$id]["name"] = $core->lang["delivery"][$id];
            }
            if (!isset($bg[$ig])) {
                $bg[$ig] = $line;
                $bg[$ig]["name"] = $core->lang["country"][$ig];
                $bg[$ig]["u"] = $core->url("m", "order?") . parset($param, "geo", $ig);
            }
            $total["in" . $c["call_status"]] += 1;
            $bc[$ic]["in" . $c["call_status"]] += 1;
            $bw[$iw]["in" . $c["call_status"]] += 1;
            $bo[$io]["in" . $c["call_status"]] += 1;
            $bd[$id]["in" . $c["call_status"]] += 1;
            $bg[$ig]["in" . $c["call_status"]] += 1;
        }
        if ($oc == $sh) {
            $st += $sh;
        } else {
            break;
        }
    }
    $core->site->bc($core->lang["menu_sub_" . $url] ? $core->lang["menu_sub_" . $url] : $core->lang["menu_" . $url], $core->url("m", $url));
    $core->site->set("select2");
    if ($csv) {
        header("Content-type: text/csv");
        header("Content-disposition: attachment;filename=analytics-delivery.csv");
    } else {
        $core->site->header();
    }
    if ($csv) {
        $core->tpl->load("body", "csv-analytics-delivery");
    } else {
        $core->tpl->load("body", "analytics-delivery", defined("HACK_TPL_ANALDELIV") ? HACK : false);
    }
    $core->tpl->vars("body", array("descr" => $core->lang["descr"], "who" => $core->lang["anal_who"], "packing" => $core->lang["statuso"][6], "send" => $core->lang["statuso"][7], "indelivery" => $core->lang["statuso"][8], "delivered" => $core->lang["statuso"][9], "count" => $core->lang["anal_count"], "got" => $core->lang["anal_got"], "process" => $core->lang["anal_process"], "delivery" => $core->lang["anal_delivery"], "wait" => $core->lang["anal_wait"], "accept" => $core->lang["anal_accept"], "return" => $core->lang["anal_return"], "buy" => $core->lang["anal_buy"], "finance" => $core->lang["anal_finance"], "from" => date2form($from), "to" => date2form($to), "admin" => $cmp ? false : true, "wm" => $wm, "src" => $src, "lfrom" => $core->lang["anal_from"], "lto" => $core->lang["anal_to"], "offer" => $core->lang["offer"], "comp" => $core->lang["company"], "country" => $core->lang["order_country"], "show" => $core->lang["show"], "noitem" => $core->lang["anal_noitem"], "today" => $core->lang["anal_today"], "yest" => $core->lang["anal_yest"], "day7" => $core->lang["anal_day7"], "day30" => $core->lang["anal_day30"], "day90" => $core->lang["anal_day90"], "u_search" => $core->url("m", $url), "u_csv" => $core->url("m", $url) . "?" . parset($param, "show", "csv"), "u_today" => $core->url("m", $url) . "?" . parmult($param, array("from" => date2form($today), "to" => date2form($today))), "u_yest" => $core->url("m", $url) . "?" . parmult($param, array("from" => date2form($yest), "to" => date2form($yest))), "u_day7" => $core->url("m", $url) . "?" . parmult($param, array("from" => date2form($week1), "to" => date2form($today))), "u_day30" => $core->url("m", $url) . "?" . parmult($param, array("from" => date2form($month), "to" => date2form($today))), "u_day90" => $core->url("m", $url) . "?" . parmult($param, array("from" => date2form($month3), "to" => date2form($today)))));
    foreach ($offer as $i => $of) {
        $core->tpl->block("body", "offer", array("name" => $of, "value" => $i, "select" => $o == $i ? "selected=\"selected\"" : ""));
    }
    foreach ($comps as $i => $of) {
        $core->tpl->block("body", "comp", array("name" => $of, "value" => $i, "select" => $cc == $i ? "selected=\"selected\"" : ""));
    }
    foreach ($core->lang["delivery"] as $i => $of) {
        $core->tpl->block("body", "deliv", array("name" => $of, "value" => $i, "select" => isset($dd) && $dd == $i ? "selected=\"selected\"" : ""));
    }
    foreach ($core->lang["country"] as $i => $of) {
        $core->tpl->block("body", "country", array("name" => $of, "value" => $i, "select" => $geo == $i ? "selected=\"selected\"" : ""));
    }
    if ($total["total"]) {
        $core->tpl->block("body", "block");
        deliveryanalyticline($core, $total);
        if (!($cmp || $cc)) {
            usort($bc, "deliveryanalyticsort");
            $core->tpl->block("body", "block", array("head" => $core->lang["anal_comps"]));
            foreach ($bc as $l) {
                deliveryanalyticline($core, $l);
            }
        }
        if (!$dd) {
            usort($bd, "deliveryanalyticsort");
            $core->tpl->block("body", "block", array("head" => $core->lang["anal_deliveries"]));
            foreach ($bd as $l) {
                deliveryanalyticline($core, $l);
            }
        }
        if (!$wm) {
            usort($bw, "deliveryanalyticsort");
            $core->tpl->block("body", "block", array("head" => $core->lang["anal_users"]));
            foreach ($bw as $l) {
                deliveryanalyticline($core, $l);
            }
        }
        if (!$o) {
            usort($bo, "deliveryanalyticsort");
            $core->tpl->block("body", "block", array("head" => $core->lang["anal_offer"]));
            foreach ($bo as $l) {
                deliveryanalyticline($core, $l);
            }
        }
        if (!$geo) {
            usort($bg, "deliveryanalyticsort");
            $core->tpl->block("body", "block", array("head" => $core->lang["anal_geo"]));
            foreach ($bg as $l) {
                deliveryanalyticline($core, $l);
            }
        }
    } else {
        $core->tpl->block("body", "no");
    }
    $core->tpl->output("body", $csv ? "windows-1251" : false);
    if (!$csv) {
        $core->site->footer();
    }
    $core->stop();
}
function deliveryanalyticsort($a, $b)
{
    return strcmp($a["name"], $b["name"]);
}
function deliveryanalyticline($core, $l)
{
    $core->tpl->block("body", "block.row", array("name" => $l["name"], "u" => $l["u"], "total" => $l["total"], "in6" => $l["in6"], "in7" => $l["in7"], "in8" => $l["in8"], "st6" => $l["st6"], "st7" => $l["st7"], "st8" => $l["st8"], "st9" => $l["st9"], "st10" => $l["st10"], "st11" => $l["st11"]));
    ksort($l["ma"]);
    foreach ($l["ma"] as $cu => $cc) {
        $core->tpl->block("body", "block.row.ma", array("c" => $core->currency->code($cu), "t" => round($cc, 2)));
    }
    ksort($l["mc"]);
    foreach ($l["mc"] as $cu => $cc) {
        $core->tpl->block("body", "block.row.mc", array("c" => $core->currency->code($cu), "t" => round($cc, 2)));
    }
}

?>