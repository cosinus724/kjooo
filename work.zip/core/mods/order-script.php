<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function order_script($script, $tp)
{
    $cts = 0;
    $scr = explode("\n", $script);
    $hm = (int) date("Hi");
    $dw = (int) date("N");
    foreach ($scr as $sc) {
        $iid = $iit = false;
        $sc = trim($sc);
        if (!$sc) {
            continue;
        }
        if (preg_match("/time\\(([0-9]+)\\-([0-9]+)\\)/i", $sc, $ms)) {
            $tmf = strlen($ms[1]) < 3 ? 100 * (int) $ms[1] : (int) $ms[1];
            $tmt = strlen($ms[2]) < 3 ? 100 * (int) $ms[2] : (int) $ms[2];
            if ($tmt < $tmf) {
                if ($hm < $tmf && $tmt < $hm) {
                    continue;
                }
            } else {
                if ($hm < $tmf || $tmt < $hm) {
                    continue;
                }
            }
        }
        if (preg_match("/dow\\(([0-9]+)\\-([0-9]+)\\)/i", $sc, $ms)) {
            $dwf = (int) $ms[1];
            $dwt = (int) $ms[2];
            if ($dwt < $dwf) {
                if ($dw < $dwf && $dwt < $dw) {
                    continue;
                }
            } else {
                if ($dw < $dwf || $dwt < $dw) {
                    continue;
                }
            }
        } else {
            if (preg_match("/dow\\(([0-9]+)\\)/i", $sc, $ms)) {
                $dow = (int) $ms[1];
                if ($dow != $dw) {
                    continue;
                }
            }
        }
        if (preg_match("/#([0-9]+)/si", $sc, $ms)) {
            $cms = $ms[1];
            if (preg_match("/(([0-9]*[.])?[0-9]+)\\%/si", $sc, $ms)) {
                $pos = $ms[1];
                $pos = ceil($pos * 100);
                if ($pos < 10000) {
                    $rnd = ceil(rand(0, 10000));
                    if ($pos < $rnd) {
                        continue;
                    }
                }
            } else {
                $pos = false;
            }
            $tests = array();
            if (preg_match_all("#([a-z]+)\\:([0-9a-z]+)#si", $sc, $ms)) {
                foreach ($ms[1] as $mi => $mo) {
                    if ($mo && $ms[2][$mi]) {
                        $tests[$mo] = $ms[2][$mi];
                    }
                }
            }
            if (preg_match_all("#([a-z]+)\\:\\[(.+)\\]#si", $sc, $ms)) {
                foreach ($ms[1] as $mi => $mo) {
                    if ($mo && $ms[2][$mi]) {
                        $tests[$mo] = mb_strtolower($ms[2][$mi], "UTF-8");
                    }
                }
            }
            if (count($tests)) {
                $isok = true;
                foreach ($tests as $t => $v) {
                    if (is_string($v) && $v[0] == "?") {
                        $vv = substr($v, 1);
                        if (mb_stripos($tp[$t], $vv, 0, "UTF-8") === false) {
                            $isok = false;
                        }
                    } else {
                        if ($tp[$t] != $v) {
                            $isok = false;
                        }
                    }
                }
                if ($isok) {
                    $cts = $cms;
                }
            } else {
                if ($pos) {
                    $cts = $cms;
                } else {
                    continue;
                }
            }
            if ($cts) {
                break;
            }
        } else {
            continue;
        }
    }
    return $cts;
}

?>