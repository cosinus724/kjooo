<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function configpage_banph($core)
{
    $message = isset($core->get["message"]) ? $core->text->link($core->get["message"]) : false;
    $action = isset($core->get["action"]) ? $core->text->link($core->get["action"]) : false;
    $id = isset($core->get["id"]) ? $core->text->number($core->get["id"]) : false;
    switch ($action) {
        case "add":
            $phone = $core->text->number($core->post["name"]);
            if ($core->db->add(DB_BAN_PH, array("phone" => $phone))) {
                $core->go($core->u("config-banph", "message=ok"));
            } else {
                $core->go($core->u("config-banph", "message=error"));
            }
        case "del":
            if ($core->db->del(DB_BAN_PH, array("phone" => $id))) {
                $core->go($core->u("config-banph", "message=ok"));
            } else {
                $core->go($core->u("config-banph", "message=error"));
            }
    }
    switch ($message) {
        case "ok":
            $core->site->info("info", "done_basic");
            break;
        case "error":
            $core->site->info("error", "error_basic");
            break;
    }
    $where = $param = array();
    if (isset($core->get["s"]) && $core->get["s"]) {
        require_once PATH_CORE . "search.php";
        $search = new SearchWords($core->get["s"]);
        if ($s = $search->get()) {
            $where[] = $search->field(array("phone"));
        } else {
            $s = false;
        }
    } else {
        $s = false;
    }
    $where = $where ? " WHERE " . implode(" AND ", $where) : "";
    $page = 0 < $core->get["page"] ? (int) $core->get["page"] : 1;
    $sh = 30;
    $st = $sh * ($page - 1);
    $ic = $core->db->field("SELECT COUNT(*) FROM " . DB_BAN_PH . $where);
    $item = $ic ? $core->db->col("SELECT `phone` FROM " . DB_BAN_PH . " " . $where . " ORDER BY phone ASC LIMIT " . $st . ", " . $sh) : array();
    $core->site->bc($core->lang["configs_h"], $core->u("config"));
    $core->site->bc($core->lang["config_banph"]);
    $core->site->pt($core->lang["config_banph_t"]);
    $core->site->header();
    $core->tpl->load("body", "config-bl", defined("HACК_TPL_CONFIGBL") ? HACK : false);
    $core->tpl->vars("body", array("u_search" => $core->u("config-banph"), "u_add" => $core->u("config-banph", "action=add"), "s" => $s, "pages" => $ic ? pages($core->u("config-banph", $param), $ic, $sh, $page, sprintf($core->lang["shown"], $st + 1, min($st + $sh, $ic), $ic)) : false, "name" => $core->lang["phone"], "search" => $core->lang["search"], "find" => $core->lang["find"], "add" => $core->lang["add"], "action" => $core->lang["action"], "del" => $core->lang["del"], "confirm" => $core->lang["confirm"], "noitem" => $core->lang["noitems"]));
    if ($item) {
        foreach ($item as $i) {
            $core->tpl->block("body", "item", array("name" => $search ? $search->highlight($i) : $i, "del" => $core->u(array("config-banph", $i), "action=del")));
        }
    } else {
        $core->tpl->block("body", "noitem");
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}
function configpage_banip($core)
{
    $message = isset($core->get["message"]) ? $core->text->link($core->get["message"]) : false;
    $action = isset($core->get["action"]) ? $core->text->link($core->get["action"]) : false;
    $id = isset($core->get["id"]) ? $core->text->number($core->get["id"]) : false;
    switch ($action) {
        case "add":
            $ip = ip2int($core->post["name"]);
            if ($core->db->add(DB_BAN_IP, array("ip" => $ip))) {
                $core->go($core->u("config-banip", "message=ok"));
            } else {
                $core->go($core->u("config-banip", "message=error"));
            }
        case "del":
            if ($core->db->del(DB_BAN_IP, array("ip" => $id))) {
                $core->go($core->u("config-banip", "message=ok"));
            } else {
                $core->go($core->u("config-banip", "message=error"));
            }
    }
    switch ($message) {
        case "ok":
            $core->site->info("info", "done_basic");
            break;
        case "error":
            $core->site->info("error", "error_basic");
            break;
    }
    $where = $param = array();
    if ($core->get["s"]) {
        $s = ip2int($core->get["s"]);
        if ($s) {
            $where[] = "`ip` = '" . $s . "'";
            $param["s"] = $s;
        } else {
            $s = false;
        }
    } else {
        $s = false;
    }
    $where = $where ? " WHERE " . implode(" AND ", $where) : "";
    $page = 0 < $core->get["page"] ? (int) $core->get["page"] : 1;
    $sh = 30;
    $st = $sh * ($page - 1);
    $ic = $core->db->field("SELECT COUNT(*) FROM " . DB_BAN_IP . $where);
    $item = $ic ? $core->db->col("SELECT `ip` FROM " . DB_BAN_IP . " " . $where . " ORDER BY `ip` ASC LIMIT " . $st . ", " . $sh) : array();
    $core->site->bc($core->lang["configs_h"], $core->u("config"));
    $core->site->bc($core->lang["config_banip"]);
    $core->site->pt($core->lang["config_banip_t"]);
    $core->site->header();
    $core->tpl->load("body", "config-bl", defined("HACК_TPL_CONFIGBL") ? HACK : false);
    $core->tpl->vars("body", array("u_search" => $core->u("config-banip"), "u_add" => $core->u("config-banip", "action=add"), "s" => $s ? int2ip($s) : "", "pages" => $ic ? pages($core->u("config-banip", $param), $ic, $sh, $page, sprintf($core->lang["shown"], $st + 1, min($st + $sh, $ic), $ic)) : false, "name" => $core->lang["ip"], "search" => $core->lang["search"], "find" => $core->lang["find"], "add" => $core->lang["add"], "action" => $core->lang["action"], "del" => $core->lang["del"], "confirm" => $core->lang["confirm"], "noitem" => $core->lang["noitems"]));
    if ($item) {
        foreach ($item as $i) {
            $core->tpl->block("body", "item", array("name" => int2ip($i), "del" => $core->u(array("config-banip", $i), "action=del")));
        }
    } else {
        $core->tpl->block("body", "noitem");
    }
    $core->tpl->output("body");
    $core->site->footer();
    $core->stop();
}

?>