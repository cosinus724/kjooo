<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function admin_offer_test($core)
{
    $id = isset($core->get["id"]) ? (int) $core->get["id"] : NULL;
    if (!$id) {
        $core->go($core->url("m", "offer"));
    }
    if ($core->get["action"] == "make") {
        $data = array("offer" => $id, "name" => $core->post["name"], "phone" => $core->post["phone"], "ip" => remoteip($core->server), "ua" => $core->server["HTTP_USER_AGENT"]);
        $fid = (int) $core->post["flow"];
        if ($fid && ($f = $core->cpa->get("flow", $fid))) {
            $data["flow"] = $fid;
            $data["site"] = $f["flow_site"];
            $data["from"] = $f["flow_space"];
            $data["us"] = $f["flow_utms"];
            $data["uc"] = $f["flow_utmc"];
            $data["un"] = $f["flow_utmn"];
            $data["ut"] = $f["flow_utmt"];
            $data["um"] = $f["flow_utmm"];
        }
        require_once PATH_MODS . "order-add.php";
        $oid = neworder($core, $data);
        if ($oid) {
            $core->go($core->url("im", "offer-test", $id, "ok"));
        } else {
            $core->go($core->url("im", "offer-test", $id, "error"));
        }
    }
    switch ($message) {
        case "ok":
            $core->site->info("info", "done_basic");
            break;
        case "error":
            $core->site->info("error", "error_basic");
            break;
    }
    $core->site->bc($core->lang["offers_h"], $core->url("m", "offer"));
    $core->site->bc($core->cpa->get("offers", 0, $id));
    $core->site->bc($core->lang["offer_test"]);
    $core->site->page = $core->lang["offer_test_h"];
    $core->site->header();
    $flows = $core->db->icol("SELECT flow_id, flow_name FROM " . DB_FLOW . " WHERE user_id = '" . $core->user->id . "' AND offer_id = '" . $id . "'");
    if ($flows) {
        asort($flows);
    }
    $field = array(array("type" => "line", "value" => $core->text->lines($core->lang["offer_test_t"])), array("type" => "text", "name" => "name", "head" => $core->lang["username"], "value" => $core->lang["offer_test_name"]), array("type" => "text", "name" => "phone", "head" => $core->lang["phone"], "value" => $core->lang["offer_test_phone"]), $flows ? array("type" => "select", "name" => "flow", "head" => $core->lang["flow"], "options" => $flows) : NULL);
    $core->site->form("offertest", $core->url("ia", "offer-test", $id, "make"), $core->lang["offer_test_h"], $field);
    $core->site->footer();
    $core->stop();
}
function admin_offer_load($core)
{
    $id = isset($core->get["id"]) ? (int) $core->get["id"] : NULL;
    $page = max(1, (int) $core->get["page"]);
    if ($core->get["action"]) {
        switch ($core->get["action"]) {
            case "add":
                $tm = time();
                $oid = $core->post["offer"];
                $clean = explode("\n", $core->post["clean"]);
                $lands = explode("\n", $core->post["lands"]);
                $space = explode("\n", $core->post["space"]);
                $proxy = $core->text->line($core->post["proxy"]);
                $ca = array();
                foreach ($clean as $c) {
                    if ($c = trim($c)) {
                        $c = stripslashes($c);
                        $c = explode("|||", $c);
                        $ca[] = array(trim($c[0]), trim($c[1]));
                    }
                }
                foreach ($lands as $l) {
                    if ($l = trim($l)) {
                        $l = explode(" ", $l);
                        $lu = trim($l[0]);
                        $ld = trim($l[1]);
                        if (!$ld) {
                            $lp = parse_url($lu);
                            $ld = trim($lp["path"], "/");
                        }
                        if (!$ld) {
                            $ld = str_replace(".", "-", strtr($lp["host"], array("www." => "", ".com" => "", ".ru" => "", ".net" => "", ".biz" => "")));
                        }
                        $data = array("offer_id" => $oid, "load_status" => 0, "load_type" => 0, "load_url" => $lu, "load_site" => $ld, "load_add" => $tm, "load_last" => $tm, "load_clean" => $ca, "load_meta" => array(), "load_proxy" => $proxy);
                        if ($core->cando("offer_load_land")) {
                            $data = $core->filter("offer_load_land", $data);
                        }
                        $data["load_clean"] = addslashes(serialize($data["load_clean"]));
                        $data["load_meta"] = addslashes(serialize($data["load_meta"]));
                        $core->db->add(DB_LOAD, $data);
                    }
                }
                foreach ($space as $l) {
                    if ($l = trim($l)) {
                        $l = explode(" ", $l);
                        $lu = trim($l[0]);
                        $ld = trim($l[1]);
                        if (!$ld) {
                            $lp = parse_url($lu);
                            $ld = trim($lp["path"], "/");
                        }
                        if (!$ld) {
                            $ld = str_replace(".", "-", strtr($lp["host"], array("www." => "", ".com" => "", ".ru" => "", ".net" => "", ".biz" => "")));
                        }
                        $data = array("offer_id" => $oid, "load_status" => 0, "load_type" => 1, "load_url" => $lu, "load_site" => $ld, "load_add" => $tm, "load_last" => $tm, "load_meta" => array(), "load_proxy" => $proxy);
                        if ($core->cando("offer_load_space")) {
                            $data = $core->filter("offer_load_space", $data);
                        }
                        $data["load_meta"] = addslashes(serialize($data["load_meta"]));
                        $core->db->add(DB_LOAD, $data);
                    }
                }
                $core->go($core->url("m", "offer-load"));
            case "edit":
                $clean = explode("\n", $core->post["clean"]);
                $ca = array();
                foreach ($clean as $c) {
                    if ($c = trim($c)) {
                        $c = stripslashes($c);
                        $c = explode("|||", $c);
                        $ca[] = array(trim($c[0]), trim($c[1]));
                    }
                }
                $data = array("load_url" => $core->text->url($core->post["url"]), "load_site" => $core->text->line($core->post["site"]), "load_clean" => $ca ? addslashes(serialize($ca)) : "", "load_proxy" => $core->text->line($core->post["proxy"]));
                if ($core->db->edit(DB_LOAD, $data, "load_id = '" . $id . "'")) {
                    $core->go($core->url("mm", "offer-load", "ok"));
                } else {
                    $core->go($core->url("mm", "offer-load", "error"));
                }
            case "reload":
                $ids = array();
                foreach ($core->post["ids"] as $i) {
                    if ($i = (int) $i) {
                        $ids[] = $i;
                    }
                }
                $ids = implode(",", $ids);
                $data = array("load_status" => "0");
                if ($core->post["proxy"]) {
                    $data["load_proxy"] = $core->text->line($core->post["proxy"]);
                }
                if ($core->post["regexp"]) {
                    $clean = explode("\n", $core->post["clean"]);
                    $ca = array();
                    foreach ($clean as $c) {
                        if ($c = trim($c)) {
                            $c = stripslashes($c);
                            $c = explode("|||", $c);
                            $ca[] = array(trim($c[0]), trim($c[1]));
                        }
                    }
                    $data["load_clean"] = $ca ? addslashes(serialize($ca)) : "";
                }
                if ($ids && $core->db->edit(DB_LOAD, $data, "load_id IN ( " . $ids . " )")) {
                    $core->go($core->url("mm", "offer-load", "ok"));
                } else {
                    $core->go($core->url("mm", "offer-load", "error"));
                }
            case "delete":
                $lst = $core->db->field("SELECT load_status FROM " . DB_LOAD . " WHERE load_id = '" . $id . "' LIMIT 1");
                if ($lst < 1 || 2 < $lst) {
                    $core->db->del(DB_LOAD, "load_id = '" . $id . "'");
                    $core->go($core->url("mm", "offer-load", "ok"));
                } else {
                    $core->go($core->url("mm", "offer-load", "error"));
                }
        }
    }
    $core->site->bc($core->lang["offers_h"], $core->url("m", "offer"));
    $core->site->bc($core->lang["offer_load_h"], $core->url("m", "offer-load"));
    $offers = $core->cpa->get("offersa");
    switch ($message) {
        case "ok":
            $core->site->info("info", "done_basic");
            break;
        case "error":
            $core->site->info("error", "error_basic");
            break;
    }
    if ($id === 0) {
        $offer = array();
        $oid = (int) $core->get["offer"];
        foreach ($offers as $v => $n) {
            $offer[] = array("name" => $n, "value" => $v, "select" => $oid == $v);
        }
        $core->site->bc($core->lang["offer_load_a"]);
        $core->site->header();
        $field = array(array("type" => "line", "value" => $core->text->lines($core->lang["offer_load_t"])), array("type" => "select", "name" => "offer", "head" => $core->lang["offer"], "value" => $offer), array("type" => "textarea", "rows" => 6, "name" => "lands", "head" => $core->lang["ol_lands"], "descr" => $core->lang["ol_lands_d"]), array("type" => "textarea", "rows" => 6, "name" => "space", "head" => $core->lang["ol_space"], "descr" => $core->lang["ol_lands_d"]), array("type" => "textarea", "rows" => 6, "name" => "clean", "head" => $core->lang["ol_clean"], "descr" => $core->lang["ol_clean_d"]), array("type" => "text", "name" => "proxy", "head" => $core->lang["proxy"]));
        if ($core->cando("offer_load_fields")) {
            $field = $core->filter("offer_load_fields", $field);
        }
        $core->site->form("offeredit", $core->url("ma", "offer-load", "add"), $core->lang["offer_load_a"], $field, $core->lang["download"]);
        $core->site->footer();
    } else {
        if ($id) {
            $s = $core->db->row("SELECT * FROM " . DB_LOAD . " WHERE load_id = '" . $id . "' LIMIT 1");
            if ($s["load_clean"]) {
                $rl = unserialize($s["load_clean"]);
                $rx = array();
                foreach ($rl as $r) {
                    $rx[] = implode("|||", $r);
                }
                $rx = implode("\n", $rx);
            } else {
                $rx = "";
            }
            $core->site->bc($core->lang["offer_load_edit_h"]);
            $core->site->header();
            $field = array(array("type" => "line", "value" => $core->text->lines($core->lang["offer_load_edit_t"])), array("type" => "text", "name" => "url", "head" => $core->lang["url"], "value" => $s["load_url"]), array("type" => "text", "name" => "site", "head" => $core->lang["site"], "value" => $s["load_site"]), array("type" => "textarea", "rows" => 6, "name" => "clean", "head" => $core->lang["ol_clean"], "descr" => $core->lang["ol_clean_d"], "value" => $rx), array("type" => "text", "name" => "proxy", "head" => $core->lang["proxy"], "value" => $s["load_proxy"]));
            if ($core->cando("offer_load_fields")) {
                $field = $core->filter("offer_load_fields", $field);
            }
            $core->site->form("offeredit", $core->url("ia", "offer-load", $id, "edit"), $core->lang["offer_load_edit_h"], $field);
            $core->site->footer();
        } else {
            $where = $params = array();
            if ($core->get["sh"]) {
                $sh = max(10, (int) $core->get["sh"]);
                $params["sh"] = $sh;
            } else {
                $sh = 30;
            }
            if (isset($core->get["t"])) {
                $params["t"] = $t = (int) $core->get["t"];
                $where[] = "load_type = '" . $t . "'";
            }
            $st = $sh * ($page - 1);
            $where = $where ? " WHERE " . implode(" AND ", $where) : "";
            $sc = $core->db->field("SELECT COUNT(*) FROM " . DB_LOAD . $where);
            $sites = $sc ? $core->db->data("SELECT * FROM " . DB_LOAD . " " . $where . " ORDER BY load_last DESC LIMIT " . $st . ", " . $sh) : array();
            $core->site->header();
            $core->tpl->load("body", "offers-load", defined("HACK_TPL_OFLOAD") ? HACK : false);
            $core->tpl->vars("body", array("offer" => $core->lang["offer"], "url" => $core->lang["url"], "status" => $core->lang["status"], "time" => $core->lang["time"], "type" => $core->lang["type"], "folder" => $core->lang["folder"], "proxy" => $core->lang["proxy"], "edit" => $core->lang["edit"], "del" => $core->lang["del"], "confirm" => $core->lang["confirm"], "action" => $core->lang["action"], "noitems" => $core->lang["anal_noitem"], "add" => $core->lang["offer_load_a"], "u_add" => $core->url("i", "offer-load", 0), "pages" => pages($core->url("m", "offer-load?") . http_build_query($params), $sc, $sh, $page), "shown" => sprintf($core->lang["shown"], $st + 1, min($st + $sh, $sc), $sc), "u_reload" => $core->url("ma", "offer-load", "reload"), "reload" => $core->lang["offer_load_redo"], "more" => $core->lang["offer_load_more"], "regexp" => $core->lang["offer_load_regex"], "clean" => $core->lang["ol_clean_d"]));
            if ($sites) {
                foreach ($sites as $s) {
                    $core->tpl->block("body", "item", array("id" => $s["load_id"], "offer" => $offers[$s["offer_id"]], "u_offer" => $core->url("i", "offer-load", $s["offer_id"]), "url" => $s["load_url"], "site" => $s["load_site"], "goto" => $s["site_id"] ? $core->cpa->get("site", $s["site_id"], "site_url") : false, "last" => smartdate($s["load_last"]), "tid" => $s["load_type"], "type" => $core->lang["site_types"][$s["load_type"]], "u_type" => $core->url("m", "offer-load?") . parset($params, "t", $s["load_type"]), "stid" => $s["load_status"], "status" => $core->lang["ol_status"][$s["load_status"]], "edit" => $core->url("i", "offer-load", $s["load_id"]), "del" => 0 < $s["load_status"] && $s["load_status"] < 3 ? false : $core->url("ia", "offer-load", $s["load_id"], "delete")));
                }
            } else {
                $core->tpl->block("body", "noitem");
            }
            $core->tpl->output("body");
            $core->site->footer();
        }
    }
    $core->stop();
}
function admin_offer_import($core)
{
    if ($core->get["action"] == "process") {
        if (!$core->files["file"]["name"]) {
            $core->go($core->url("mm", "offer", "add-e"));
        }
        $data = json_decode(file_get_contents($core->files["file"]["tmp_name"]), 1);
        if (!$data) {
            $core->go($core->url("mm", "offer", "add-e"));
        }
        $id = $oid = (int) $core->post["offer"];
        set_time_limit(300);
        if ($core->post["basic"]) {
            $offer = array("cat_id" => $data["offer"]["cat_id"], "offer_name" => $data["offer"]["offer_name"], "offer_descr" => $data["offer"]["offer_descr"], "offer_text" => $data["offer"]["offer_text"], "offer_info" => $data["offer"]["offer_info"], "offer_delivery" => $data["offer"]["offer_delivery"], "offer_payment" => $data["offer"]["offer_payment"], "offer_paramurl" => $data["offer"]["offer_paramurl"]);
        } else {
            $offer = array();
        }
        if ($core->post["price"]) {
            $offer["offer_country"] = $data["offer"]["offer_country"];
        }
        if ($core->post["price"]) {
            $offer["offer_prt"] = $data["offer"]["offer_prt"];
        }
        if ($core->post["param"]) {
            $offer["offer_pars"] = $data["offer"]["offer_pars"];
        }
        if ($core->post["ccs"]) {
            $offer["offer_call"] = $data["offer"]["offer_call"];
        }
        if ($core->post["ccc"]) {
            $offer["offer_line"] = $data["offer"]["offer_line"];
        }
        if ($core->post["process"]) {
            $offer["in_default"] = $data["offer"]["in_default"];
            $offer["in_script"] = $data["offer"]["in_script"];
        }
        if ($core->post["cc"]) {
            $offer["out_default"] = $data["offer"]["out_default"];
            $offer["out_comps"] = $data["offer"]["out_comps"];
            $offer["out_script"] = $data["offer"]["out_script"];
        }
        if (!$id) {
            if (!$offer) {
                $core->go($core->url("mm", "offer", "add-e"));
            }
            if ($core->db->add(DB_OFFER, $offer)) {
                $id = $core->db->lastid();
            } else {
                $core->go($core->url("mm", "offer", "add-e"));
            }
        } else {
            $core->db->edit(DB_OFFER, $offer, array("offer_id" => $id));
        }
        if ($core->post["basic"]) {
            $img = curl("http://" . $data["source"] . "/data/offer/" . $data["offer"]["offer_id"] . ".jpg");
            if (($imgs = getimagesizefromstring($img)) && $imgs[2] == IMAGETYPE_JPEG) {
                file_put_contents(PATH . "/data/offer/" . $id . ".jpg", $img);
            }
        }
        if ($core->post["cash"]) {
            if ($oid) {
                $core->db->del(DB_PRICE, array("offer_id" => $oid));
            }
            foreach ($data["price"] as $p) {
                unset($p["price_id"]);
                $p["offer_id"] = $id;
                $core->db->add(DB_PRICE, $p);
            }
        }
        if ($core->post["vars"]) {
            if ($oid) {
                $core->db->del(DB_VARS, array("offer_id" => $oid));
            }
            foreach ($data["vars"] as $p) {
                unset($p["var_id"]);
                $p["offer_id"] = $id;
                $core->db->add(DB_VARS, $p);
            }
        }
        if ($core->post["site"] || $core->post["space"]) {
            if ($oid) {
                if ($core->post["site"]) {
                    $core->db->del(DB_SITE, array("offer_id" => $oid, "site_type" => 0));
                }
                if ($core->post["site"]) {
                    $core->db->del(DB_SITE, array("offer_id" => $oid, "site_type" => 2));
                }
                if ($core->post["space"]) {
                    $core->db->del(DB_SITE, array("offer_id" => $oid, "site_type" => 1));
                }
            }
            $landsbase = $core->config("sites", "domain");
            $spacebase = $core->config("space", "domain");
            $redirbase = $core->config("redirect", "domain");
            foreach ($data["sites"] as $s) {
                unset($s["site_id"]);
                $s["offer_id"] = $id;
                $s["comp_id"] = 0;
                if ($core->post["site"] && $s["site_type"] == 0) {
                    if ($core->post["siteurl"]) {
                        $ou = $s["site_url"];
                        if (strpos($ou, "/") !== false) {
                            $su = explode("/", $ou, 2);
                            $np = $su[1];
                        } else {
                            $np = strtr($s["site_url"], array(".ru" => "", ".com" => "", ".net" => "", ".org" => "", ".biz" => "", ".mobi" => "", ".me" => "", "." => "-"));
                        }
                        $s["site_url"] = $landsbase . "/" . $np;
                        $nu = $s["site_url"];
                    } else {
                        $ou = $nu = $s["site_url"];
                    }
                    $core->db->add(DB_SITE, $s);
                    $sid = $core->db->lastid();
                    if ($core->config("sites", "control") && $core->config("sites", "key") && $core->post["siteload"]) {
                        $np = explode("/", $nu, 2);
                        $np = $np[1];
                        $dd = curl("http://" . $ou . "?load=" . $core->post["sitekey"]);
                        $data = json_decode($dd, true);
                        $indf = base64_decode($data["index.php"]);
                        $indf = preg_replace("/'OFFER',\\s*'([0-9]+)'/i", "'OFFER', '" . $id . "'", $indf);
                        $indf = preg_replace("/'SITE',\\s*'([0-9]+)'/i", "'SITE', '" . $sid . "'", $indf);
                        $indf = preg_replace("/'OFFER',\\s*([0-9]+)/i", "'OFFER', '" . $id . "'", $indf);
                        $indf = preg_replace("/'SITE',\\s*([0-9]+)/i", "'SITE', '" . $sid . "'", $indf);
                        $data["index.php"] = base64_encode($indf);
                        $dd = json_encode($data);
                        curl($core->config("sites", "control"), array("key" => $core->config("sites", "key"), "action" => "create", "site" => $np, "data" => $dd));
                        unset($data);
                        unset($dd);
                        unset($indf);
                    }
                }
                if ($core->post["space"] && $s["site_type"] == 1) {
                    if ($core->post["spaceurl"]) {
                        $ou = $s["site_url"];
                        $su = explode("/", $ou, 2);
                        $s["site_url"] = $spacebase . "/" . $su[1];
                        $nu = $s["site_url"];
                    } else {
                        $ou = $nu = $s["site_url"];
                    }
                    $core->db->add(DB_SITE, $s);
                    if ($core->config("space", "control") && $core->config("space", "key") && $core->post["spaceload"]) {
                        $op = explode("/", $ou, 2);
                        $op = $op[1];
                        $np = explode("/", $nu, 2);
                        $np = $np[1];
                        $dd = curl("http://" . $ou . "?load=" . $core->post["sitekey"]);
                        $data = json_decode($dd, true);
                        $indf = base64_decode($data["index.php"]);
                        $indf = preg_replace("/offer([0-9]+)\\.php/i", "offer" . $id . ".php", $indf);
                        $data["index.php"] = base64_encode($indf);
                        $dd = json_encode($data);
                        curl($core->config("space", "control"), array("key" => $core->config("space", "key"), "action" => "create", "site" => $np, "data" => $dd));
                        unset($data);
                        unset($dd);
                        unset($indf);
                    }
                }
                if ($core->post["site"] && $s["site_type"] == 2) {
                    if ($core->post["siteurl"]) {
                        $ou = $s["site_url"];
                        if (strpos($ou, "/") !== false) {
                            $su = explode("/", $ou, 2);
                            $np = $su[1];
                        } else {
                            $np = strtr($s["site_url"], array(".ru" => "", ".com" => "", ".net" => "", ".org" => "", ".biz" => "", ".mobi" => "", ".me" => "", "." => "-"));
                        }
                        $s["site_url"] = $redirbase . "/" . $np;
                        $nu = $s["site_url"];
                    } else {
                        $ou = $nu = $s["site_url"];
                    }
                    $core->db->add(DB_SITE, $s);
                }
            }
            $core->cpa->clear("offers");
            $core->cpa->clear("offersa");
            $core->cpa->clear("offer", $id);
            $core->cpa->clear("vars", $id);
            $core->cpa->clear("prices", $id);
            $core->cpa->clear("sites", $id);
            $core->cpa->clear("lands", $id);
            $core->cpa->clear("space", $id);
            curl("http://" . $core->config("space", "domain") . "/renew.php?id=" . $id);
        }
        $core->go($core->url("mm", "offer", "add-ok"));
    }
    $core->site->bc($core->lang["offers_h"], $core->url("m", "offer"));
    $core->site->bc($core->lang["offer_import_h"]);
    $core->site->header();
    $offers = $core->cpa->get("offersa");
    $id = (int) $core->get["id"];
    $offer = array(array("value" => 0, "name" => $core->lang["oi_offer_n"]));
    foreach ($offers as $v => $n) {
        $offer[] = array("name" => $n, "value" => $v, "select" => $id == $v);
    }
    $field = array(array("type" => "line", "value" => $core->text->lines($core->lang["offer_import_t"])), array("type" => "file", "name" => "file", "head" => $core->lang["file"]), array("type" => "select", "name" => "offer", "head" => $core->lang["oi_offer"], "descr" => $core->lang["oi_offer_d"], "value" => $offer), array("type" => "checkbox", "name" => "basic", "head" => $core->lang["oi_basic"], "descr" => $core->lang["oi_basic_d"], "checked" => 1), array("type" => "checkbox", "name" => "price", "head" => $core->lang["oi_price"], "descr" => $core->lang["oi_price_d"], "checked" => 1), array("type" => "checkbox", "name" => "cash", "head" => $core->lang["oi_cash"], "descr" => $core->lang["oi_cash_d"], "checked" => 1), array("type" => "checkbox", "name" => "param", "head" => $core->lang["oi_param"], "descr" => $core->lang["oi_param_d"], "checked" => 1), array("type" => "checkbox", "name" => "vars", "head" => $core->lang["oi_vars"], "descr" => $core->lang["oi_vars_d"], "checked" => 1), array("type" => "checkbox", "name" => "process", "head" => $core->lang["oi_process"], "descr" => $core->lang["oi_process_d"], "checked" => 1), array("type" => "checkbox", "name" => "cc", "head" => $core->lang["oi_cc"], "descr" => $core->lang["oi_cc_d"], "checked" => 1), array("type" => "checkbox", "name" => "ccs", "head" => $core->lang["oi_ccs"], "descr" => $core->lang["oi_ccs_d"], "checked" => 1), array("type" => "checkbox", "name" => "ccc", "head" => $core->lang["oi_ccc"], "descr" => $core->lang["oi_ccc_d"], "checked" => 1), array("type" => "checkbox", "name" => "site", "head" => $core->lang["oi_site"], "descr" => $core->lang["oi_site_d"], "checked" => 1), array("type" => "checkbox", "name" => "siteurl", "head" => $core->lang["oi_siteurl"], "descr" => $core->lang["oi_siteurl_d"], "checked" => 0), array("type" => "checkbox", "name" => "siteload", "head" => $core->lang["oi_siteload"], "descr" => $core->lang["oi_siteload_d"], "checked" => 0), array("type" => "checkbox", "name" => "space", "head" => $core->lang["oi_space"], "descr" => $core->lang["oi_space_d"], "checked" => 1), array("type" => "checkbox", "name" => "spaceurl", "head" => $core->lang["oi_spaceurl"], "descr" => $core->lang["oi_spaceurl_d"], "checked" => 1), array("type" => "checkbox", "name" => "spaceload", "head" => $core->lang["oi_spaceload"], "descr" => $core->lang["oi_spaceload_d"], "checked" => 0), array("type" => "text", "length" => 100, "name" => "sitekey", "head" => $core->lang["oi_sitekey"], "descr" => $core->lang["oi_sitekey_d"]));
    $core->site->form("offeredit", $core->url("ma", "offer-import", "process"), $core->lang["offer_import_h"], $field, $core->lang["import"]);
    $core->site->footer();
    $core->stop();
}

?>