<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function cron1min($core)
{
    set_time_limit(300);
    $tm = time();
    if (!$core->config("clicks", "server")) {
        $cd = date("Ymd", $tm - 86400);
        $core->db->query("UPDATE " . DB_CLICK . " SET user_id = ( SELECT user_id FROM " . DB_FLOW . " WHERE " . DB_FLOW . ".flow_id = " . DB_CLICK . ".flow_id LIMIT 1 ) WHERE flow_id != 0 AND user_id = 0 AND click_date >= '" . $cd . "'");
    } else {
        clickserver($core);
    }
    $mt = $tm - 75;
    $core->db->query("UPDATE " . DB_ORDER . " SET mark_id = 0, mark_time = 0 WHERE mark_time BETWEEN 1 AND " . $mt);
    require_once PATH_MODS . "cron-int.php";
    require_once PATH_MODS . "order-edit.php";
    $comps = $core->db->data("SELECT comp_id, int_add_url, int_add_pre, int_add_field, int_add_code FROM " . DB_COMP . " WHERE int_add = 1");
    foreach ($comps as $c) {
        integration_add($core, $c);
    }
    unset($comps);
    $comps = $core->db->data("SELECT comp_id, autoaccept, int_acc_url, int_acc_pre, int_acc_field, int_acc_code FROM " . DB_COMP . " WHERE int_acc = 1");
    foreach ($comps as $c) {
        integration_acc($core, $c);
    }
    unset($comps);
    $comps = $core->db->data("SELECT comp_id, int_dlv, int_dlv_url, int_dlv_pre, int_dlv_field, int_dlv_code FROM " . DB_COMP . " WHERE int_dlv > 0");
    foreach ($comps as $c) {
        integration_dlv($core, $c);
    }
    unset($comps);
    if (!defined("DONTTOUCHMYDB")) {
        $dbv = $core->config("dbversion");
        if ($dbv < DBVER) {
            require_once PATH . "core/setup/db.php";
            require_once PATH . "core/setup/cdb.php";
            if (checkdatabase($core->db)) {
                $core->reconf("dbversion", DBVER);
            }
            checksystemconfigs($core->db, $core);
            updatedatabase($core->db, $dbv);
        }
    }
}
function clickserver($core)
{
    if (PHP_OS == "Linux") {
        $arch = php_uname("m");
        switch ($arch) {
            case "arm":
                $server = "click_linux_arm";
                break;
            case "arm64":
                $server = "click_linux_arm";
                break;
            case "amd64":
                $server = "click_linux_x64";
                break;
            case "x86_64":
                $server = "click_linux_x64";
                break;
            case "i386":
                $server = "click_linux_x86";
                break;
            case "i486":
                $server = "click_linux_x86";
                break;
            case "i586":
                $server = "click_linux_x86";
                break;
            case "i686":
                $server = "click_linux_x86";
                break;
            default:
                return false;
        }
    } else {
        if (PHP_OS == "Darwin") {
            $server = "click_macos";
        } else {
            if (PHP_OS == "WIN32" || PHP_OS == "WINNT" || PHP_OS == "Windows") {
                return false;
            }
            return false;
        }
    }
    $path = PATH . "core/click/" . $server;
    $pidfile = sprintf(PIDFILE, "click");
    $pid = @file_get_contents($pidfile);
    if (is_dir("/proc/")) {
        if ($pid && is_dir("/proc/" . $pid)) {
            $cmdline = file_get_contents("/proc/" . $pid . "/cmdline");
            if (strpos($cmdline, $path) !== false) {
                return false;
            }
        }
    } else {
        if ($pid) {
            exec("ps -a " . $pid, $oo);
            $sub = strrpos($oo[0], "CMD");
            $oo = end($oo);
            $cmdline = trim(substr($oo, $sub));
            if (strpos($cmdline, $path) !== false) {
                return false;
            }
        }
    }
    $launch = $path . " -pid=" . $pidfile;
    if ($core->config("clicks", "host")) {
        $launch .= " -host=" . $core->config("clicks", "host");
    }
    if ($core->config("clicks", "port")) {
        $launch .= " -port=" . $core->config("clicks", "port");
    }
    if ($core->config("clicks", "key")) {
        $launch .= " -key=" . $core->config("clicks", "key");
    }
    if (defined("SQL_SOCK")) {
        $launch .= " -dbtype=true";
    }
    if (defined("SQL_SOCK")) {
        $launch .= " -dbsock=" . SQL_SOCK;
    }
    if (defined("SQL_HOST")) {
        $launch .= " -dbhost=" . SQL_HOST;
    }
    if (defined("SQL_PORT")) {
        $launch .= " -dbport=" . SQL_PORT;
    }
    if (defined("SQL_USER")) {
        $launch .= " -dbuser=" . SQL_USER;
    }
    if (defined("SQL_PASS")) {
        $launch .= " -dbpass=\"" . SQL_PASS . "\"";
    }
    if (defined("SQL_BASE")) {
        $launch .= " -dbbase=" . SQL_BASE;
    }
    if (defined("SQL_PREF")) {
        $launch .= " -dbpref=" . SQL_PREF;
    }
    $launch .= " >/dev/null 2>/dev/null &";
    exec($launch);
}

?>