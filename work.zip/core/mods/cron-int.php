<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function integration_add($core, $c)
{
    if ($c["comp_block"] && $c["user_id"]) {
        $uc = $core->user->get($c["user_id"], "user_cash");
        if ($uc < $c["comp_block"]) {
            return false;
        }
    }
    $flds = unserialize($c["int_add_field"]);
    $ngo = $core->db->data("SELECT * FROM " . DB_ORDER . " WHERE comp_id = '" . $c["comp_id"] . "' AND order_status = '1'");
    foreach ($ngo as $o) {
        $ofps = $core->cpa->get("ofp", $o["offer_id"]);
        $vars = $core->cpa->get("vars", $o["offer_id"]);
        $addr = $o["order_addr"];
        if ($o["order_street"]) {
            $addr = $o["order_street"] . ", " . $addr;
        }
        if ($o["order_city"]) {
            $addr = $o["order_city"] . ", " . $addr;
        }
        if ($o["order_area"]) {
            $addr = $o["order_area"] . ", " . $addr;
        }
        $fulladdr = $addr = trim($addr, ", ");
        if ($o["order_index"]) {
            $fulladdr = $o["order_index"] . ", " . $fulladdr;
        }
        $fulladdr = trim($fulladdr, ", ");
        if ($flds) {
            $post = array();
            foreach ($flds as $k => $v) {
                if (substr($v, 0, 5) == "{ofp:") {
                    $v = $core->cpa->get("ofp", $o["offer_id"], substr($v, 5, -1));
                }
                if (substr($v, 0, 7) == "{offer:") {
                    $v = $core->cpa->get("offer", $o["offer_id"], substr($v, 7, -1));
                }
                if ($v == "{id}") {
                    $v = $o["order_id"];
                }
                if ($v == "{ip}") {
                    $v = int2ip($o["order_ip"]);
                }
                if ($v == "{wm}") {
                    $v = $o["wm_id"];
                }
                if ($v == "{wmi}") {
                    $v = $o["ext_id"] ? $o["ext_id"] . "-" . ($o["ext_src"] ? $o["ext_src"] : $o["wm_id"]) : $o["wm_id"];
                }
                if ($v == "{name}") {
                    $v = $o["order_name"];
                }
                if ($v == "{email}") {
                    $v = $o["order_email"];
                }
                if ($v == "{phone}") {
                    $v = $o["order_phone"];
                }
                if ($v == "{promo}") {
                    $v = $o["promo_code"];
                }
                if ($v == "{index}") {
                    $v = $o["order_index"];
                }
                if ($v == "{area}") {
                    $v = $o["order_area"];
                }
                if ($v == "{city}") {
                    $v = $o["order_city"];
                }
                if ($v == "{street}") {
                    $v = $o["order_street"];
                }
                if ($v == "{house}") {
                    $v = $o["order_addr"];
                }
                if ($v == "{geo}") {
                    $v = $o["order_country"];
                }
                if ($v == "{geoup}") {
                    $v = strtoupper($o["order_country"]);
                }
                if ($v == "{country}") {
                    $v = $o["order_country"];
                }
                if ($v == "{addr}") {
                    $v = $addr;
                }
                if ($v == "{fulladdr}") {
                    $v = $fulladdr;
                }
                if ($v == "{discount}") {
                    $v = $o["order_discount"];
                }
                if ($v == "{delivery}") {
                    $v = $o["order_delivery"];
                }
                if ($v == "{count}") {
                    $v = $o["order_count"];
                }
                if ($v == "{currency}") {
                    $v = $o["price_cur"];
                }
                if ($v == "{curr}") {
                    $v = $core->currency->code($o["price_cur"]);
                }
                if ($v == "{base}") {
                    $v = $o["price_base"];
                }
                if ($v == "{price}") {
                    $v = $o["price_total"];
                }
                if ($v == "{delpr}") {
                    $v = $o["price_delivery"];
                }
                if ($v == "{more}") {
                    $v = $o["price_more"];
                }
                if ($v == "{ua}") {
                    $v = $o["order_ua"];
                }
                if ($v == "{offer}") {
                    $v = $o["offer_id"];
                }
                if ($v == "{mobile}") {
                    $v = $o["order_mobile"];
                }
                if ($v == "{bad}") {
                    $v = $o["order_bad"];
                }
                if ($v == "{comment}") {
                    $v = $o["order_comment"];
                }
                if ($v == "{time}") {
                    $v = $o["order_time"];
                }
                if ($v == "{date}") {
                    $v = date("Y-m-d H:i:s", $o["order_time"]);
                }
                if ($v == "{siteurl}") {
                    $v = $o["site_id"] ? $core->cpa->get("site", $o["site_id"], "site_url") : "";
                }
                $post[$k] = $v;
            }
        } else {
            $post = false;
        }
        $cc = array();
        $url = $c["int_add_url"];
        if ($c["int_add_pre"]) {
            eval($c["int_add_pre"]);
        }
        if ($url) {
            $url = str_replace("{id}", $o["order_id"], $url);
            $url = str_replace("{ip}", int2ip($o["order_ip"]), $url);
            $url = str_replace("{wm}", $o["wm_id"], $url);
            $url = str_replace("{name}", strtr($o["order_name"], " ", "+"), $url);
            $url = str_replace("{phone}", $o["order_phone"], $url);
            $url = str_replace("{addr}", strtr($addr, " ", "+"), $url);
            $url = str_replace("{count}", $o["order_count"], $url);
            foreach ($ofps as $k => $v) {
                $url = str_replace("{ofp:" . $k . "}", $v, $url);
            }
            $result = curl($url, $post, $cc);
        } else {
            $result = true;
        }
        if ($result) {
            $lr = $result;
            $rid = eval($c["int_add_code"]);
            if (is_numeric($rid) && $rid < 0) {
                order_edit($core, $o["order_id"], array("status" => 5, "reason" => abs($rid)));
            } else {
                if ($rid) {
                    order_edit($core, $o["order_id"], array("status" => 2, "exto" => $rid));
                }
            }
        }
        integration_log($core, $c["comp_id"], $o["order_id"], 1, $url, $post, $lr, $rid);
    }
    unset($o);
    unset($ngo);
}
function integration_acc($core, $c)
{
    if ($c["comp_block"] && $c["user_id"]) {
        $uc = $core->user->get($c["user_id"], "user_cash");
        if ($uc < $c["comp_block"]) {
            return false;
        }
    }
    $flds = unserialize($c["int_acc_field"]);
    $acs = $c["autoaccept"] ? 10 : 6;
    $ngo = $core->db->data("SELECT * FROM " . DB_ORDER . " WHERE comp_id = '" . $c["comp_id"] . "' AND order_status = " . $acs . " AND ext_oid = 0");
    foreach ($ngo as $o) {
        $ofps = $core->cpa->get("ofp", $o["offer_id"]);
        $vars = $core->cpa->get("vars", $o["offer_id"]);
        $addr = $o["order_addr"];
        if ($o["order_street"]) {
            $addr = $o["order_street"] . ", " . $addr;
        }
        if ($o["order_city"]) {
            $addr = $o["order_city"] . ", " . $addr;
        }
        if ($o["order_area"]) {
            $addr = $o["order_area"] . ", " . $addr;
        }
        $fulladdr = $addr = trim($addr, ", ");
        if ($o["order_index"]) {
            $fulladdr = $o["order_index"] . ", " . $fulladdr;
        }
        $fulladdr = trim($fulladdr, ", ");
        if ($flds) {
            $post = array();
            foreach ($flds as $k => $v) {
                if (substr($v, 0, 5) == "{ofp:") {
                    $v = $core->cpa->get("ofp", $o["offer_id"], substr($v, 5, -1));
                }
                if (substr($v, 0, 7) == "{offer:") {
                    $v = $core->cpa->get("offer", $o["offer_id"], substr($v, 7, -1));
                }
                if ($v == "{id}") {
                    $v = $o["order_id"];
                }
                if ($v == "{ip}") {
                    $v = int2ip($o["order_ip"]);
                }
                if ($v == "{wm}") {
                    $v = $o["wm_id"];
                }
                if ($v == "{wmi}") {
                    $v = $o["ext_id"] ? $o["ext_id"] . "-" . ($o["ext_src"] ? $o["ext_src"] : $o["wm_id"]) : $o["wm_id"];
                }
                if ($v == "{name}") {
                    $v = $o["order_name"];
                }
                if ($v == "{email}") {
                    $v = $o["order_email"];
                }
                if ($v == "{phone}") {
                    $v = $o["order_phone"];
                }
                if ($v == "{promo}") {
                    $v = $o["promo_code"];
                }
                if ($v == "{index}") {
                    $v = $o["order_index"];
                }
                if ($v == "{area}") {
                    $v = $o["order_area"];
                }
                if ($v == "{city}") {
                    $v = $o["order_city"];
                }
                if ($v == "{street}") {
                    $v = $o["order_street"];
                }
                if ($v == "{house}") {
                    $v = $o["order_addr"];
                }
                if ($v == "{geo}") {
                    $v = $o["order_country"];
                }
                if ($v == "{geoup}") {
                    $v = strtoupper($o["order_country"]);
                }
                if ($v == "{country}") {
                    $v = $o["order_country"];
                }
                if ($v == "{addr}") {
                    $v = $addr;
                }
                if ($v == "{fulladdr}") {
                    $v = $fulladdr;
                }
                if ($v == "{delivery}") {
                    $v = $o["order_delivery"];
                }
                if ($v == "{discount}") {
                    $v = $o["order_discount"];
                }
                if ($v == "{count}") {
                    $v = $o["order_count"];
                }
                if ($v == "{curr}") {
                    $v = $core->currency->code($o["price_cur"]);
                }
                if ($v == "{currency}") {
                    $v = $o["price_cur"];
                }
                if ($v == "{base}") {
                    $v = $o["price_base"];
                }
                if ($v == "{price}") {
                    $v = $o["price_total"];
                }
                if ($v == "{delpr}") {
                    $v = $o["price_delivery"];
                }
                if ($v == "{more}") {
                    $v = $o["price_more"];
                }
                if ($v == "{ua}") {
                    $v = $o["order_ua"];
                }
                if ($v == "{offer}") {
                    $v = $o["offer_id"];
                }
                if ($v == "{mobile}") {
                    $v = $o["order_mobile"];
                }
                if ($v == "{bad}") {
                    $v = $o["order_bad"];
                }
                if ($v == "{comment}") {
                    $v = $o["order_comment"];
                }
                if ($v == "{time}") {
                    $v = $o["order_time"];
                }
                if ($v == "{date}") {
                    $v = date("Y-m-d H:i:s", $o["order_time"]);
                }
                if ($v == "{siteurl}") {
                    $v = $o["site_id"] ? $core->cpa->get("site", $o["site_id"], "site_url") : "";
                }
                $post[$k] = $v;
            }
        } else {
            $post = false;
        }
        $cc = array();
        $url = $c["int_acc_url"];
        if ($c["int_acc_pre"]) {
            eval($c["int_acc_pre"]);
        }
        if ($url) {
            $url = str_replace("{id}", $o["order_id"], $url);
            $url = str_replace("{ip}", int2ip($o["order_ip"]), $url);
            $url = str_replace("{wm}", $o["wm_id"], $url);
            $url = str_replace("{name}", strtr($o["order_name"], " ", "+"), $url);
            $url = str_replace("{phone}", $o["order_phone"], $url);
            $url = str_replace("{addr}", strtr($addr, " ", "+"), $url);
            $url = str_replace("{count}", $o["order_count"], $url);
            if ($ofps) {
                foreach ($ofps as $k => $v) {
                    $url = str_replace("{ofp:" . $k . "}", $v, $url);
                }
            }
            $result = curl($url, $post, $cc);
        } else {
            $result = true;
        }
        if ($result) {
            $lr = $result;
            $rid = eval($c["int_acc_code"]);
            if ($rid) {
                order_edit($core, $o["order_id"], array("exto" => $rid));
            }
        }
        integration_log($core, $c["comp_id"], $o["order_id"], 2, $url, $post, $lr, $rid);
    }
    unset($o);
    unset($ngo);
}
function integration_dlv($core, $c)
{
    if ($c["comp_block"] && $c["user_id"]) {
        $uc = $core->user->get($c["user_id"], "user_cash");
        if ($uc < $c["comp_block"]) {
            return false;
        }
    }
    $flds = unserialize($c["int_dlv_field"]);
    $dvls = $c["int_dlv"] == 2 ? "AND track_warn = 1" : "";
    $ngo = $core->db->data("SELECT * FROM " . DB_ORDER . " WHERE comp_id = '" . $c["comp_id"] . "' AND order_status IN ( 8, 9 ) " . $dlvs . " AND ext_dlid = 0");
    foreach ($ngo as $o) {
        $ofps = $core->cpa->get("ofp", $o["offer_id"]);
        $vars = $core->cpa->get("vars", $o["offer_id"]);
        $addr = $o["order_addr"];
        if ($o["order_street"]) {
            $addr = $o["order_street"] . ", " . $addr;
        }
        if ($o["order_city"]) {
            $addr = $o["order_city"] . ", " . $addr;
        }
        if ($o["order_area"]) {
            $addr = $o["order_area"] . ", " . $addr;
        }
        $fulladdr = $addr = trim($addr, ", ");
        if ($o["order_index"]) {
            $fulladdr = $o["order_index"] . ", " . $fulladdr;
        }
        $fulladdr = trim($fulladdr, ", ");
        if ($flds) {
            $post = array();
            foreach ($flds as $k => $v) {
                if (substr($v, 0, 5) == "{ofp:") {
                    $v = $core->cpa->get("ofp", $o["offer_id"], substr($v, 5, -1));
                }
                if (substr($v, 0, 7) == "{offer:") {
                    $v = $core->cpa->get("offer", $o["offer_id"], substr($v, 7, -1));
                }
                if ($v == "{id}") {
                    $v = $o["order_id"];
                }
                if ($v == "{ip}") {
                    $v = int2ip($o["order_ip"]);
                }
                if ($v == "{wm}") {
                    $v = $o["wm_id"];
                }
                if ($v == "{wmi}") {
                    $v = $o["ext_id"] ? $o["ext_id"] . "-" . ($o["ext_src"] ? $o["ext_src"] : $o["wm_id"]) : $o["wm_id"];
                }
                if ($v == "{name}") {
                    $v = $o["order_name"];
                }
                if ($v == "{email}") {
                    $v = $o["order_email"];
                }
                if ($v == "{phone}") {
                    $v = $o["order_phone"];
                }
                if ($v == "{promo}") {
                    $v = $o["promo_code"];
                }
                if ($v == "{index}") {
                    $v = $o["order_index"];
                }
                if ($v == "{area}") {
                    $v = $o["order_area"];
                }
                if ($v == "{city}") {
                    $v = $o["order_city"];
                }
                if ($v == "{street}") {
                    $v = $o["order_street"];
                }
                if ($v == "{house}") {
                    $v = $o["order_addr"];
                }
                if ($v == "{geo}") {
                    $v = $o["order_country"];
                }
                if ($v == "{geoup}") {
                    $v = strtoupper($o["order_country"]);
                }
                if ($v == "{country}") {
                    $v = $o["order_country"];
                }
                if ($v == "{addr}") {
                    $v = $addr;
                }
                if ($v == "{fulladdr}") {
                    $v = $fulladdr;
                }
                if ($v == "{delivery}") {
                    $v = $o["order_delivery"];
                }
                if ($v == "{discount}") {
                    $v = $o["order_discount"];
                }
                if ($v == "{count}") {
                    $v = $o["order_count"];
                }
                if ($v == "{curr}") {
                    $v = $core->currency->code($o["price_cur"]);
                }
                if ($v == "{currency}") {
                    $v = $o["price_cur"];
                }
                if ($v == "{base}") {
                    $v = $o["price_base"];
                }
                if ($v == "{price}") {
                    $v = $o["price_total"];
                }
                if ($v == "{delpr}") {
                    $v = $o["price_delivery"];
                }
                if ($v == "{more}") {
                    $v = $o["price_more"];
                }
                if ($v == "{ua}") {
                    $v = $o["order_ua"];
                }
                if ($v == "{offer}") {
                    $v = $o["offer_id"];
                }
                if ($v == "{mobile}") {
                    $v = $o["order_mobile"];
                }
                if ($v == "{bad}") {
                    $v = $o["order_bad"];
                }
                if ($v == "{comment}") {
                    $v = $o["order_comment"];
                }
                if ($v == "{time}") {
                    $v = $o["order_time"];
                }
                if ($v == "{date}") {
                    $v = date("Y-m-d H:i:s", $o["order_time"]);
                }
                if ($v == "{siteurl}") {
                    $v = $o["site_id"] ? $core->cpa->get("site", $o["site_id"], "site_url") : "";
                }
                $post[$k] = $v;
            }
        } else {
            $post = false;
        }
        $cc = array();
        $url = $c["int_dlv_url"];
        if ($c["int_dlv_pre"]) {
            eval($c["int_dlv_pre"]);
        }
        $url = str_replace("{id}", $o["order_id"], $url);
        $url = str_replace("{ip}", int2ip($o["order_ip"]), $url);
        $url = str_replace("{wm}", $o["wm_id"], $url);
        $url = str_replace("{name}", strtr($o["order_name"], " ", "+"), $url);
        $url = str_replace("{phone}", $o["order_phone"], $url);
        $url = str_replace("{addr}", strtr($addr, " ", "+"), $url);
        $url = str_replace("{count}", $o["order_count"], $url);
        foreach ($ofps as $k => $v) {
            $url = str_replace("{ofp:" . $k . "}", $v, $url);
        }
        if ($result = curl($url, $post, $cc)) {
            $lr = $result;
            $rid = eval($c["int_dlv_code"]);
            if ($rid) {
                order_edit($core, $o["order_id"], array("extd" => $rid));
            }
        }
        integration_log($core, $c["comp_id"], $o["order_id"], 5, $url, $post, $lr, $rid);
    }
    unset($o);
    unset($ngo);
}
function integration_check($core, $c)
{
    if ($c["comp_block"] && $c["user_id"]) {
        $uc = $core->user->get($c["user_id"], "user_cash");
        if ($uc < $c["comp_block"]) {
            return false;
        }
    }
    $flds = unserialize($c["int_chk_field"]);
    $offers = $core->db->col("SELECT DISTINCT offer_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c["comp_id"] . "' AND order_status BETWEEN 2 AND 4");
    foreach ($offers as $off) {
        $ofps = $core->cpa->get("ofp", $off);
        $idsw = $idew = $e2i = array();
        $q = $core->db->start("SELECT order_id, ext_oid, order_status FROM " . DB_ORDER . " WHERE offer_id = '" . $off . "' AND comp_id = '" . $c["comp_id"] . "' AND order_status BETWEEN 2 AND 4");
        while ($r = $core->db->one($q)) {
            $idsw[$r["order_id"]] = $r["order_status"];
            $idew[$r["order_id"]] = $r["ext_oid"];
            $e2i[$r["ext_oid"]] = $r["order_id"];
        }
        $core->db->stop($q);
        $ideq = array_chunk($idew, $c["int_chk_count"], true);
        $idsq = array_chunk($idsw, $c["int_chk_count"], true);
        unset($idsw);
        unset($idew);
        foreach ($idsq as $ii => $ids) {
            $cc = array();
            $ide = $ideq[$ii];
            $idl = array_keys($ids);
            $idsl = implode(",", $idl);
            $idel = implode(",", $ide);
            if ($flds) {
                $post = array();
                foreach ($flds as $k => $v) {
                    if (!$k) {
                        continue;
                    }
                    $v = str_replace("{idsl}", $idsl, $v);
                    $v = str_replace("{idel}", $idel, $v);
                    if (substr($v, 0, 6) == "{eval:") {
                        $v = eval(substr($v, 6, -1));
                    }
                    if ($v == "{ids}") {
                        $v = $idl;
                    }
                    if ($v == "{ide}") {
                        $v = $ide;
                    }
                    $post[$k] = $v;
                }
            } else {
                $post = false;
            }
            $inid = $idl[0];
            $exid = $ide[$inid];
            $url = $c["int_chk_url"];
            if ($c["int_chk_pre"]) {
                eval($c["int_chk_pre"]);
            }
            $url = str_replace("{id}", $inid, $url);
            $url = str_replace("{ext}", $exid, $url);
            $url = str_replace("{idsl}", $idsl, $url);
            $url = str_replace("{idel}", $idel, $url);
            foreach ($ofps as $k => $v) {
                $url = str_replace("{ofp:" . $k . "}", $v, $url);
            }
            if (!count($post)) {
                $post = false;
            }
            if ($raw = curl($url, $post, $cc)) {
                switch ($c["int_chk_format"]) {
                    case 1:
                        $data = json_decode($raw, true);
                        break;
                    case 2:
                        $data = unserialize($raw);
                        break;
                    case 3:
                        $data = simplexml_load_string($raw);
                        break;
                    default:
                        $data = $raw;
                }
                eval($c["int_chk_code"]);
            }
            integration_log($core, $c["comp_id"], $c["int_chk_count"] == 1 ? $inid : 0, 3, $url, $post, $raw, $c["int_chk_format"]);
        }
    }
    unset($offers);
}
function integration_long($core, $c)
{
    if ($c["comp_block"] && $c["user_id"]) {
        $uc = $core->user->get($c["user_id"], "user_cash");
        if ($uc < $c["comp_block"]) {
            return false;
        }
    }
    $lnmxt = time() - 86400;
    $flds = unserialize($c["int_lng_field"]);
    $offers = $core->db->col("SELECT DISTINCT offer_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c["comp_id"] . "' AND ext_check < '" . $lnmxt . "' AND order_status BETWEEN 6 AND 9");
    foreach ($offers as $off) {
        $ofps = $core->cpa->get("ofp", $off);
        $idsw = $idew = $e2i = array();
        $q = $core->db->start("SELECT order_id, ext_oid, order_status FROM " . DB_ORDER . " WHERE offer_id = '" . $off . "' AND ext_check < '" . $lnmxt . "' AND comp_id = '" . $c["comp_id"] . "' AND order_status BETWEEN 6 AND 9");
        while ($r = $core->db->one($q)) {
            $idsw[$r["order_id"]] = $r["order_status"];
            $idew[$r["order_id"]] = $r["ext_oid"];
            $e2i[$r["ext_oid"]] = $r["order_id"];
        }
        $core->db->stop($q);
        $ideq = array_chunk($idew, $c["int_lng_count"], true);
        $idsq = array_chunk($idsw, $c["int_lng_count"], true);
        unset($idsw);
        unset($idew);
        foreach ($idsq as $ii => $ids) {
            $cc = array();
            $ide = $ideq[$ii];
            $idl = array_keys($ids);
            $idsl = implode(",", $idl);
            $idel = implode(",", $ide);
            if ($flds) {
                $post = array();
                foreach ($flds as $k => $v) {
                    if (!$k) {
                        continue;
                    }
                    if (substr($v, 0, 6) == "{eval:") {
                        $v = eval(substr($v, 6, -1));
                    }
                    $v = str_replace("{idsl}", $idsl, $v);
                    $v = str_replace("{idel}", $idel, $v);
                    if ($v == "{ids}") {
                        $v = $idl;
                    }
                    if ($v == "{ide}") {
                        $v = $ide;
                    }
                    $post[$k] = $v;
                }
            } else {
                $post = false;
            }
            $inid = $idl[0];
            $exid = $ide[$inid];
            $url = $c["int_lng_url"];
            if ($c["int_lng_pre"]) {
                eval($c["int_lng_pre"]);
            }
            $url = str_replace("{id}", $inid, $url);
            $url = str_replace("{ext}", $exid, $url);
            $url = str_replace("{idsl}", $idsl, $url);
            $url = str_replace("{idel}", $idel, $url);
            foreach ($ofps as $k => $v) {
                $url = str_replace("{ofp:" . $k . "}", $v, $url);
            }
            if (!count($post)) {
                $post = false;
            }
            if ($raw = curl($url, $post, $cc)) {
                switch ($c["int_lng_format"]) {
                    case 1:
                        $data = json_decode($raw, true);
                        break;
                    case 2:
                        $data = unserialize($raw);
                        break;
                    case 3:
                        $data = simplexml_load_string($raw);
                        break;
                    default:
                        $data = $raw;
                }
                eval($c["int_lng_code"]);
            }
            $core->db->query("UPDATE " . DB_ORDER . " SET ext_check = '" . time() . "' WHERE order_id IN ( " . $idsl . " )");
            integration_log($core, $c["comp_id"], $c["int_chk_count"] == 1 ? $inid : 0, 4, $url, $post, $raw, $c["int_lng_format"]);
        }
    }
    unset($offers);
}
function integration_dlc($core, $c)
{
    if ($c["comp_block"] && $c["user_id"]) {
        $uc = $core->user->get($c["user_id"], "user_cash");
        if ($uc < $c["comp_block"]) {
            return false;
        }
    }
    $lnmxt = time() - 10000;
    $flds = unserialize($c["int_dlc_field"]);
    $offers = $core->db->col("SELECT DISTINCT offer_id FROM " . DB_ORDER . " WHERE comp_id = '" . $c["comp_id"] . "' AND ext_track != 0 AND ext_track < '" . $lnmxt . "' AND order_status IN ( 8, 9 )");
    foreach ($offers as $off) {
        $ofps = $core->cpa->get("ofp", $off);
        $idsw = $idew = $e2i = array();
        $q = $core->db->start("SELECT order_id, ext_oid, order_status FROM " . DB_ORDER . " WHERE offer_id = '" . $off . "' AND ext_track != 0 AND ext_track < '" . $lnmxt . "' AND order_status IN ( 8, 9 )");
        while ($r = $core->db->one($q)) {
            $idsw[$r["order_id"]] = $r["order_status"];
            $idew[$r["order_id"]] = $r["ext_oid"];
            $e2i[$r["ext_oid"]] = $r["order_id"];
        }
        $core->db->stop($q);
        $ideq = array_chunk($idew, $c["int_dlc_count"], true);
        $idsq = array_chunk($idsw, $c["int_dlc_count"], true);
        unset($idsw);
        unset($idew);
        foreach ($idsq as $ii => $ids) {
            $cc = array();
            $ide = $ideq[$ii];
            $idl = array_keys($ids);
            $idsl = implode(",", $idl);
            $idel = implode(",", $ide);
            if ($flds) {
                $post = array();
                foreach ($flds as $k => $v) {
                    if (!$k) {
                        continue;
                    }
                    if (substr($v, 0, 6) == "{eval:") {
                        $v = eval(substr($v, 6, -1));
                    }
                    $v = str_replace("{idsl}", $idsl, $v);
                    $v = str_replace("{idel}", $idel, $v);
                    if ($v == "{ids}") {
                        $v = $idl;
                    }
                    if ($v == "{ide}") {
                        $v = $ide;
                    }
                    $post[$k] = $v;
                }
            } else {
                $post = false;
            }
            $inid = $idl[0];
            $exid = $ide[$inid];
            $url = $c["int_dlc_url"];
            if ($c["int_dlc_pre"]) {
                eval($c["int_dlc_pre"]);
            }
            $url = str_replace("{id}", $inid, $url);
            $url = str_replace("{ext}", $exid, $url);
            $url = str_replace("{idsl}", $idsl, $url);
            $url = str_replace("{idel}", $idel, $url);
            foreach ($ofps as $k => $v) {
                $url = str_replace("{ofp:" . $k . "}", $v, $url);
            }
            if (!count($post)) {
                $post = false;
            }
            if ($raw = curl($url, $post, $cc)) {
                switch ($c["int_dlc_format"]) {
                    case 1:
                        $data = json_decode($raw, true);
                        break;
                    case 2:
                        $data = unserialize($raw);
                        break;
                    case 3:
                        $data = simplexml_load_string($raw);
                        break;
                    default:
                        $data = $raw;
                }
                eval($c["int_dlc_code"]);
            }
            $core->db->query("UPDATE " . DB_ORDER . " SET ext_track = '" . time() . "' WHERE order_id IN ( " . $idsl . " )");
            integration_log($core, $c["comp_id"], $c["int_chk_count"] == 1 ? $inid : 0, 6, $url, $post, $raw, $c["int_dlc_format"]);
        }
    }
    unset($offers);
}
function integration_log($core, $comp, $order, $type, $url, $post, $reply, $result)
{
    $core->db->add(DB_LOG_INT, array("comp_id" => (int) $comp, "order_id" => (int) $order, "log_type" => (int) $type, "log_time" => time(), "log_url" => addslashes($url), "log_post" => addslashes(is_array($post) ? var_export($post, true) : $post), "log_reply" => addslashes($reply), "log_result" => addslashes($result)));
}

?>