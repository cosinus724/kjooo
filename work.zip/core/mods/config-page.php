<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function configs_actions($core, $configs, $options)
{
    if ($core->get["action"] == "save") {
        if (!$core->post) {
            $core->go($core->u($options["page"], "message=error"));
        }
        foreach ($configs as $og => &$opts) {
            $conf = array();
            foreach ($opts as $on => &$o) {
                $name = $og . "_" . $on;
                switch ($o[1]) {
                    case "bool":
                        $conf[$on] = $core->post[$name] ? true : false;
                        break;
                    case "int":
                        $conf[$on] = (int) $core->post[$name];
                        break;
                    case "link":
                        $conf[$on] = $core->text->link($core->post[$name]);
                        break;
                    case "email":
                        $conf[$on] = $core->text->email($core->post[$name]);
                        break;
                    case "code":
                        $conf[$on] = $core->text->code(stripslashes($core->post[$name]));
                        break;
                    case "ints":
                        $conf[$on] = $core->text->intline($core->post[$name]);
                        break;
                    case "codes":
                        $conf[$on] = $core->text->codeline($core->post[$name]);
                        break;
                    default:
                        $conf[$on] = $core->text->line(stripslashes($core->post[$name]));
                        break;
                }
            }
            unset($o);
            $core->reconf($og, $conf);
        }
        unset($opts);
        unset($conf);
        $core->go($core->u($options["page"], "message=save"));
    }
    if ($core->get["message"] == "save") {
        $core->site->info("info", "done_control_config");
    }
    if ($core->get["message"] == "error") {
        $core->site->info("error", "error_basic");
    }
}
function configs_form($core, $configs, $options)
{
    $fields = $options["descr"] ? array(array("type" => "line", "value" => $options["descr"])) : array();
    foreach ($configs as $og => &$opts) {
        if ($core->lang["confg_" . $og]) {
            $fields[] = array("type" => "head", "value" => $core->lang["confg_" . $og]);
        }
        if ($core->lang["confg_" . $og . "_d"]) {
            $fields[] = array("type" => "line", "value" => $core->text->lines($core->lang["confg_" . $og . "_d"]));
        }
        $cf = $core->config($og);
        foreach ($opts as $on => &$o) {
            $n = $og . "_" . $on;
            $h = $core->lang["conf_" . $og . "_" . $on];
            $d = $core->lang["conf_" . $og . "_" . $on . "_d"];
            $v = isset($cf[$on]) ? $cf[$on] : $o[2];
            $ff = $o[3];
            $op = is_string($ff) && function_exists($ff) ? $ff($core) : $ff;
            switch ($o[0]) {
                case "text":
                case "email":
                case "number":
                case "date":
                case "color":
                case "file":
                    $fields[] = array("type" => $o[0], "name" => $n, "head" => $h, "descr" => $d, "value" => str_replace("\"", "&quot;", $v));
                    break;
                case "textarea":
                case "mcea":
                case "mces":
                case "code":
                    $fields[] = array("type" => $o[0], "name" => $n, "rows" => 4, "head" => $h, "descr" => $d, "value" => $v);
                    break;
                case "checkbox":
                    $fields[] = array("type" => "checkbox", "name" => $n, "head" => $h, "descr" => $d, "checked" => $v);
                    break;
                case "radio":
                case "radioline":
                case "select":
                case "mselect":
                    $fields[] = array("type" => $o[0], "name" => $n, "head" => $h, "descr" => $d, "value" => $v, "options" => $op);
                    break;
            }
        }
        unset($o);
    }
    unset($opts);
    $core->site->form("configs", $core->u($options["page"], "action=save"), $options["formtitle"], $fields);
}
function configs_page($core, $configs, $options)
{
    configs_actions($core, $configs, $options);
    $core->site->bc($core->lang["configs_h"], $core->u("config"));
    $core->site->bc($options["title"]);
    if ($options["pagetitle"]) {
        $core->site->pt($options["pagetitle"]);
    }
    $core->site->header();
    configs_form($core, $configs, $options);
    $core->site->footer();
    $core->stop();
}

?>