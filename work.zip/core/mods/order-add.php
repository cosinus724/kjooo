<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function neworder($core, $data, $file = false)
{
    $sid = (int) $data["site"];
    $spc = (int) $data["from"];
    $fid = (int) $data["flow"];
    $tid = (int) $data["test"];
    $oid = (int) $data["offer"];
    $cid = (int) $data["click"];
    $iptext = $data["ip"];
    $ip = ip2int($iptext);
    $timer = isset($data["ordertime"]) ? $core->text->number($data["ordertime"]) : time();
    $name = $core->text->anum($data["name"]);
    if (!$name) {
        $name = $core->lang["noname"];
    }
    $gender = min(max(0, (int) $data["gender"]), 2);
    $email = $core->text->email($data["email"]);
    $ind = (int) $data["index"];
    $area = $core->text->anum($data["area"]);
    $city = $core->text->anum($data["city"]);
    $street = $core->text->anum($data["street"]);
    $addr = $core->text->anum($data["addr"]);
    $comm = $core->text->line($data["comm"]);
    $phone = (string) trim(preg_replace("#[^0-9]+#i", "", $data["phone"]));
    $promo = (string) trim(preg_replace("#[^0-9]+#i", "", $data["promo"]));
    $cnt = 0 < $data["count"] ? (int) $data["count"] : 1;
    $more = 0 < $data["more"] ? (int) $data["more"] : 0;
    $dsc = -100 < $data["discount"] && $data["discount"] < 100 ? (int) $data["discount"] : 0;
    $cntr = $data["country"] ? strtolower(substr($core->text->link($data["country"]), 0, 2)) : false;
    $dlvr = 0 < $data["delivery"] ? (int) $data["delivery"] : 1;
    $exti = (int) $data["exti"];
    $extu = $exti ? addslashes(preg_replace("#[^0-9A-Za-z\\_\\-\\.]+#i", "", stripslashes($data["extu"]))) : 0;
    $exts = $exti ? addslashes(preg_replace("#[^0-9A-Za-z\\_\\-\\.]+#i", "", stripslashes($data["exts"]))) : 0;
    $exto = $data["exto"] ? addslashes(preg_replace("#[^0-9A-Za-z\\_\\-\\.]+#i", "", stripslashes($data["exto"]))) : "";
    $ua = addslashes(filter_var(stripslashes($data["ua"]), FILTER_SANITIZE_STRING));
    $us = addslashes(mb_substr(filter_var(stripslashes($data["us"]), FILTER_SANITIZE_STRING), 0, 250));
    $uc = addslashes(mb_substr(filter_var(stripslashes($data["uc"]), FILTER_SANITIZE_STRING), 0, 250));
    $un = addslashes(mb_substr(filter_var(stripslashes($data["un"]), FILTER_SANITIZE_STRING), 0, 250));
    $ut = addslashes(mb_substr(filter_var(stripslashes($data["ut"]), FILTER_SANITIZE_STRING), 0, 250));
    $um = addslashes(mb_substr(filter_var(stripslashes($data["um"]), FILTER_SANITIZE_STRING), 0, 250));
    $curr = isset($data["currency"]) ? (int) $data["currency"] : false;
    $mobile = $data["mobile"] ? 1 : 0;
    $bad = $data["bad"] ? 1 : 0;
    $items = is_array($data["items"]) ? serialize($data["items"]) : "";
    $base = isset($data["base"]) ? $core->text->float($data["base"]) : false;
    $delpr = isset($data["delpr"]) ? $core->text->float($data["delpr"]) : false;
    $total = isset($data["total"]) ? $core->text->float($data["total"]) : false;
    $accept = $data["accept"] || $data["status"] == 6 || $data["status"] == 10 ? true : false;
    $status = $accept ? 2 : 1;
    $meta = $data["meta"] ? unserialize(stripslashes($data["meta"])) : array();
    if (is_array($data["params"])) {
        foreach ($data["params"] as $k => $v) {
            $meta[filter_var(stripslashes($k), FILTER_SANITIZE_STRING)] = filter_var(stripslashes($v), FILTER_SANITIZE_STRING);
        }
    }
    $meta = count($meta) ? addslashes(serialize($meta)) : "";
    $site = $sid ? $core->cpa->get("site", $sid) : false;
    $flow = $fid ? $core->cpa->get("flow", $fid) : false;
    $ext = $exti ? $core->cpa->get("ext", $exti) : false;
    $userid = $flow ? $flow["user_id"] : ($ext ? $ext["user_id"] : false);
    if ($userid && $core->user->get($userid, "user_ban")) {
        return "security";
    }
    if (!($oid && ($offer = $core->cpa->get("offer", $oid)))) {
        return "offer";
    }
    if (!$core->offer->auth($oid, $userid, $exti, $exts)) {
        return "traffic";
    }
    if ($phone) {
        $name = mb_convert_case($name, MB_CASE_TITLE, "UTF-8");
        if (!$ind) {
            if (preg_match("#^([0-9]+)#i", $addr, $ind)) {
                $ind = $ind[1];
                $ad = preg_split("#[\\s,\\.]+#i", $addr, 2);
                $addr = trim($ad[1], " ,");
            } else {
                $ind = "";
            }
        }
        if ($phone[0] == "9" && strlen($phone) == 10) {
            $phone = "7" . $phone;
        }
        if ($phone[0] == "8" && strlen($phone) == 11) {
            $phone = "7" . substr($phone, 1);
        }
        if (!$cntr) {
            $pl = strlen($phone);
            $p2 = (int) substr($phone, 0, 2);
            $p3 = (int) substr($phone, 0, 3);
            if ($pl == 11 && ($p2 == 73 || $p2 == 74 || $p2 == 75 || $p2 == 78 || $p2 == 79)) {
                $cntr = "ru";
            }
            if ($pl == 11 && ($p2 == 77 || $p2 == 76)) {
                $cntr = "kz";
            }
            if ($pl == 12 && $p3 == 380) {
                $cntr = "ua";
            }
            if ($pl == 12 && $p3 == 375) {
                $cntr = "by";
            }
            if ($pl == 12 && $p3 == 374) {
                $cntr = "am";
            }
            if ($pl == 12 && $p3 == 995) {
                $cntr = "ge";
            }
            if ($pl == 12 && $p3 == 996) {
                $cntr = "kg";
            }
            if ($pl == 12 && $p3 == 998) {
                $cntr = "uz";
            }
            if ($pl == 12 && $p3 == 373) {
                $cntr = "md";
            }
        }
        $geoipdata = geoip($core, $iptext);
        if ($geoipdata) {
            $geoip = array("geoip_country" => $geoipdata["country"], "geoip_city" => $geoipdata["city"], "geoip_region" => $geoipdata["region"], "geoip_district" => $geoipdata["district"]);
            $geocntr = $geoip["geoip_country"];
            if (!$cntr) {
                $cntr = $geoip["geoip_country"];
            }
            if ($offer["offer_delivery"]) {
                if (!$addr && !$city) {
                    $city = $geoip["geoip_city"];
                }
                if (!$addr && !$area) {
                    $area = $geoip["geoip_region"];
                }
            }
        } else {
            $geoip = $geocntr = false;
        }
        $phs = $core->db->field("SELECT `phone` FROM " . DB_BAN_PH . " WHERE `phone` = '" . $phone . "' LIMIT 1");
        $ips = $core->db->field("SELECT `ip` FROM " . DB_BAN_IP . " WHERE `ip` = '" . $ip . "' LIMIT 1");
        if ($phs || $ips) {
            return "ban";
        }
        if (defined("DUPLICATECATCH")) {
            $mxt = time() - 86400;
            $dol = $core->db->icol("SELECT order_id, order_name FROM " . DB_ORDER . " WHERE wm_id = '" . $userid . "' AND offer_id = '" . $oid . "' AND order_phone = '" . $phone . "' AND order_status < 5 AND order_time > '" . $mxt . "'");
            if ($dol) {
                foreach ($dol as $doi => $don) {
                    if ($don == $name) {
                        return defined("DUPLICATEBAD") || $exti ? "duplicate" : (int) $doi;
                    }
                }
            }
        }
        if ($offer["in_script"]) {
            $tp = array("user" => $flow["user_id"], "flow" => $fid, "site" => $sid, "space" => $spc, "ext" => $exti, "exts" => $exts, "geo" => $cntr, "geoip" => $geocntr, "city" => mb_strtolower($city, "UTF-8"), "area" => mb_strtolower($area, "UTF-8"), "bad" => $bad, "mobile" => $mobile);
            require_once PATH_MODS . "order-script.php";
            $comp = order_script($offer["in_script"], $tp);
        } else {
            $comp = 0;
        }
        if (!$comp) {
            if ($offer["in_default"] && !$site["site_comp"]) {
                $comp = $offer["in_default"];
            } else {
                $comp = $site["comp_id"];
            }
        }
        if ($curr === false) {
            $curr = $core->currency->country($cntr);
        }
        if ($data["items"]) {
            $price = $cnt = $xcnt = $base = 0;
            $vars = $core->cpa->get("vars", $offer["offer_id"]);
            foreach ($vars as &$v) {
                if ($data["items"][$v["var_id"]]) {
                    $vpr = $v["var_price"] ? unserialize($v["var_price"]) : array();
                    $price += $data["items"][$v["var_id"]] * $vpr[$curr];
                    if (!$v["var_nc"]) {
                        if ($v["var_type"]) {
                            $xcnt += $data["items"][$v["var_id"]];
                        } else {
                            $cnt += $data["items"][$v["var_id"]];
                        }
                    }
                }
            }
            unset($v);
            unset($vpr);
            unset($vars);
        } else {
            $xcnt = 0;
            if (!$base) {
                $prt = $offer["offer_prt"] ? unserialize($offer["offer_prt"]) : array();
                $base = $prt[$curr];
            }
            $price = $cnt * $base;
        }
        if ($dsc) {
            $price = round($price * (100 - $dsc) / 100, 2);
        }
        if ($total !== false) {
            $more = $total - $price;
            if ($offer["offer_delivery"]) {
                $delpr = $more;
                $more = 0;
            } else {
                $dlvr = $delpr = 0;
            }
        } else {
            if ($offer["offer_delivery"]) {
                if ($delpr === false) {
                    $dlo = $core->cpa->dltypes($comp, $dlvr);
                    $delpr = $dlo["fail"] ? $core->lang["deliverbase"][$curr] : $dlo["price"];
                }
                $price += $delpr;
            } else {
                $dlvr = $delpr = 0;
            }
        }
        if ($more) {
            $price += $more;
        }
        if ($exto) {
            $extoid = $core->db->field("SELECT order_id FROM " . DB_ORDER . " WHERE comp_id = '" . $comp . "' AND offer_id = '" . $oid . "' AND ext_oid = '" . $exto . "'");
            if ($extoid) {
                return "exto";
            }
        }
        $data = array("offer_id" => $oid, "comp_id" => $comp, "wm_id" => $userid, "flow_id" => $fid, "test_id" => $tid, "site_id" => $sid, "space_id" => $spc, "click_id" => $cid, "utms" => $us, "utmc" => $uc, "utmn" => $un, "utmt" => $ut, "utmm" => $um, "utms32" => sprintf("%u", crc32($us)), "utmc32" => sprintf("%u", crc32($uc)), "utmn32" => sprintf("%u", crc32($un)), "utmt32" => sprintf("%u", crc32($ut)), "utmm32" => sprintf("%u", crc32($um)), "ext_id" => $exti, "ext_uid" => $extu, "ext_src" => $exts, "ext_oid" => $exto, "order_time" => $timer, "order_mobile" => $mobile, "order_bad" => $bad, "order_ip" => $ip, "order_country" => $cntr, "order_name" => $name, "order_gender" => $gender, "order_phone" => $phone, "order_email" => $email, "order_pin" => rand(100000, 999999), "order_index" => $ind, "order_area" => $area, "order_city" => $city, "order_street" => $street, "order_addr" => $addr, "order_comment" => $comm, "order_items" => $items, "order_meta" => $meta, "order_ua" => $ua, "order_count" => $cnt, "order_xcnt" => $xcnt, "order_discount" => $dsc, "order_delivery" => $dlvr, "order_status" => $status, "order_webstat" => $status, "price_cur" => $curr, "price_base" => $base, "price_more" => $more, "price_delivery" => $delpr, "price_total" => $price, "promo_code" => $promo);
        if ($geoip) {
            $data += $geoip;
        }
        if (!$accept) {
            require_once PATH_MODS . "order-cash.php";
            $mm = order_cash($core, $data);
            $data["cash_wm"] = $mm["uw"] ? $mm["wmp"] : 0;
            $data["cash_pay"] = $mm["up"] ? $mm["pay"] : 0;
            $data["cash_etc"] = $mm["uc"] ? $mm["cpp"] : 0;
            if ($mm["ur"] && $mm["rep"]) {
                $data["cash_etc"] += $mm["rep"];
            }
        }
        if ($core->db->add(DB_ORDER, $data)) {
            $id = $core->db->lastid();
            $data["order_id"] = $id;
            $core->order->notify($data);
            if ($file && is_uploaded_file($file["tmp_name"])) {
                $dot = strrpos($file["name"], ".");
                $ext = strtolower(substr($file["name"], $dot + 1));
                $name = $id . "-" . substr($core->text->link(substr($file["name"], 0, $dot)), 0, 90) . "." . $ext;
                $goodext = array("jpg", "jpeg", "gif", "png", "zip", "rar", "rar5", "7z", "cdr", "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx");
                if (in_array($ext, $goodext)) {
                    move_uploaded_file($file["tmp_name"], sprintf(FILENAME, $name));
                    $core->db->edit(DB_ORDER, array("order_file" => $name), "order_id = '" . $id . "'");
                }
            }
            $chd = array();
            $cfs = array("order_name", "order_email", "order_phone", "comp_id", "order_country", "order_index", "order_area", "order_city", "order_street", "order_addr", "order_comment", "order_count", "order_discount", "order_delivery", "price_cur", "price_base", "price_more", "price_delivery");
            foreach ($cfs as $c) {
                if (isset($data[$c]) && $data[$c]) {
                    $chd[$c] = stripslashes($data[$c]);
                }
            }
            if ($chd) {
                $core->db->add(DB_CHANGE, array("order_id" => $id, "change_time" => time(), "change_data" => addslashes(serialize($chd))));
            }
            if ($accept) {
                require_once PATH_MODS . "order-edit.php";
                if (!defined("INTHEWORK")) {
                    define("INTHEWORK", true);
                }
                $ota = array("accept" => 1);
                if ($data["calling"]) {
                    $ota["calling"] = addslashes(mb_substr(filter_var(stripslashes($data["calling"]), FILTER_SANITIZE_STRING), 0, 250));
                }
                order_edit($core, $id, $ota);
            } else {
                $core->postback->make($data);
            }
            return (int) $id;
        } else {
            return "db";
        }
    } else {
        return "data";
    }
}
function makeneworder($core)
{
    $action = $core->get["neworder"] ? $core->text->link($core->get["neworder"]) : NULL;
    if ($action == "add") {
        $sid = (int) $core->post["site"];
        $key = $core->text->link($core->get["key"]);
        if (!($sid && ($site = $core->cpa->get("site", $sid)))) {
            echo "e:site";
            $core->stop();
        }
        if ($site["site_key"] != $key && hash_hmac("sha1", http_build_query($core->post), $site["site_key"]) != $key) {
            echo "e:key";
            $core->stop();
        }
        unset($core->post["status"]);
        unset($core->post["items"]);
        $oid = neworder($core, $core->post, $core->files["file"] ? $core->files["file"] : false);
        echo is_numeric($oid) ? "ok:" . $oid : "e:" . $oid;
        $core->stop();
    }
    if (defined("HACK_ADD")) {
        include PATH . HACK . "hack/add.php";
    }
    header("HTTP/1.0 404 Not Found");
}

?>