<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

function order_edit($core, $id, $info, $order = NULL)
{
    if (!$order) {
        $order = $core->db->row("SELECT * FROM " . DB_ORDER . " WHERE order_id = '" . $id . "' LIMIT 1");
    }
    $offer = $core->cpa->get("offer", $order["offer_id"]);
    $ofps = $core->cpa->get("ofp", $order["offer_id"]);
    $comp = $core->cpa->get("comp", $order["comp_id"]);
    $cc = $comp["comp_type"] ? true : false;
    $changes = array();
    $canmove = $core->order->canmove($order["order_status"], $order["offer_id"]);
    if (!(defined("INTHEWORK") || $core->user->level)) {
        if ($order["comp_id"] != $core->user->comp) {
            return false;
        }
        $cando = $core->order->cando($order["order_status"], $order["offer_id"]);
        if (!$cando) {
            return false;
        }
        $canedit = $core->order->canedit($order["order_status"], $order["offer_id"]);
        $canitem = $core->order->canitem($order["order_status"], $order["offer_id"]);
    } else {
        $cando = $canedit = $canitem = true;
        $canmove = array_flip(array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 100));
    }
    if (isset($info["status"]) && $info["status"] != $order["order_status"]) {
        $changes["order_status"] = $info["status"];
    }
    if (isset($info["reason"]) && $info["reason"] != $order["order_reason"]) {
        $changes["order_reason"] = $info["reason"];
    }
    if ($changes["order_status"] && !$canmove[$changes["order_status"]]) {
        unset($changes["order_status"]);
        unset($changes["order_reason"]);
    }
    if ($info["accept"] && !$canmove[100]) {
        unset($info["accept"]);
    }
    if ($info["hold"] && !($canmove[4] || $canmove[100])) {
        unset($info["accept"]);
    }
    if ($canedit) {
        if (isset($info["comp"]) && $info["comp"] != $order["comp_id"]) {
            $changes["comp_id"] = $info["comp"];
        }
        if (isset($info["name"]) && $info["name"] != $order["order_name"]) {
            $changes["order_name"] = $info["name"];
        }
        if (isset($info["email"]) && $info["email"] != $order["order_email"]) {
            $changes["order_email"] = $info["email"];
        }
        if (isset($info["addr"]) && $info["addr"] != $order["order_addr"]) {
            $changes["order_addr"] = $info["addr"];
        }
        if (isset($info["country"]) && $info["country"] != $order["order_country"]) {
            $changes["order_country"] = $info["country"];
        }
        if (isset($info["area"]) && $info["area"] != $order["order_area"]) {
            $changes["order_area"] = $info["area"];
        }
        if (isset($info["city"]) && $info["city"] != $order["order_city"]) {
            $changes["order_city"] = $info["city"];
        }
        if (isset($info["street"]) && $info["street"] != $order["order_street"]) {
            $changes["order_street"] = $info["street"];
        }
        if (isset($info["index"]) && $info["index"] != $order["order_index"]) {
            $changes["order_index"] = $info["index"];
        }
        if (isset($info["phone"]) && $info["phone"] != $order["order_phone"]) {
            $changes["order_phone"] = $info["phone"];
        }
        if (isset($info["comment"]) && $info["comment"] != $order["order_comment"]) {
            $changes["order_comment"] = $info["comment"];
        }
    }
    if (isset($info["user"]) && $info["user"] != $order["user_id"]) {
        $changes["user_id"] = $info["user"];
    }
    if (isset($info["rec"]) && $info["rec"] != $order["order_recall"]) {
        $changes["order_recall"] = $info["rec"];
    }
    if (isset($info["curr"]) && $info["curr"] != $order["price_cur"]) {
        $changes["price_cur"] = $info["curr"];
    }
    if (isset($info["exto"]) && $info["exto"] != $order["ext_oid"]) {
        $changes["ext_oid"] = $info["exto"];
    }
    if (isset($info["extd"]) && $info["extd"] != $order["ext_dlid"]) {
        $changes["ext_dlid"] = $info["extd"];
    }
    if (isset($info["check"]) && $info["check"] != $order["order_check"]) {
        $changes["order_check"] = $info["check"];
    }
    if (isset($info["bad"]) && $info["bad"] != $order["order_bad"]) {
        $changes["order_bad"] = $info["bad"];
    }
    if (isset($info["paid"]) && $info["paid"] != $order["paid_ok"]) {
        $changes["paid_ok"] = $info["paid"];
    }
    if (isset($changes["paid_ok"])) {
        $changes["paid_time"] = time();
    }
    if (isset($info["paidfrom"]) && $info["paidfrom"] != $order["paid_from"]) {
        $changes["paid_from"] = $info["paidfrom"];
    }
    if (isset($info["trackon"]) && $info["trackon"] != $order["track_on"]) {
        $changes["track_on"] = $info["trackon"];
    }
    if (isset($info["track"]) && $info["track"] != $order["track_code"]) {
        $changes["track_code"] = $info["track"];
    }
    if (isset($info["trcheck"]) && $info["trcheck"] != $order["track_check"]) {
        $changes["track_check"] = $info["trcheck"];
    }
    if (isset($info["trdate"]) && $info["trdate"] != $order["track_date"]) {
        $changes["track_date"] = $info["trdate"];
    }
    if (isset($info["trst"]) && $info["trst"] != $order["track_status"]) {
        $changes["track_status"] = $info["trst"];
    }
    if (isset($info["trwarn"]) && $info["trwarn"] != $order["track_warn"]) {
        $changes["track_warn"] = $info["trwarn"];
    }
    if (isset($info["meta"])) {
        ksort($info["meta"]);
        $mm = serialize($info["meta"]);
        $ometa = $info["meta"];
        if ($mm != $order["order_meta"]) {
            $changes["order_meta"] = addslashes($mm);
        }
    } else {
        $ometa = $order["order_meta"] ? unserialize($order["order_meta"]) : array();
    }
    if ($info["hold"] || $changes["order_status"] == 4) {
        if (!isset($info["hold"]) && $changes["order_status"] == 4) {
            $info["hold"] = true;
        }
        if ($info["hold"] === true) {
            if (isset($ofps["hold-wm" . $order["wm_id"]])) {
                $info["hold"] = (int) $ofps["hold-wm" . $order["wm_id"]];
            } else {
                $info["hold"] = $offer["offer_hold"];
            }
        }
        $hold = (int) $info["hold"];
        if ($hold) {
            $info["accept"] = 0;
            $changes["order_auto"] = ceil((time() + 86400 * $hold) / 600) * 600;
            $changes["order_webstat"] = 4;
            $changes["order_status"] = $changes["order_webstat"];
        } else {
            $info["accept"] = 1;
        }
    }
    if ($info["accept"]) {
        if ($cc) {
            $changes["cc_id"] = $order["comp_id"];
            if ($changes["comp_id"]) {
                $acmp = preg_split("/[\\s\\,]+/", $offer["out_comps"], -1, PREG_SPLIT_NO_EMPTY);
                if (!in_array($changes["comp_id"], $acmp)) {
                    unset($changes["comp_id"]);
                }
            }
            if (!$changes["comp_id"]) {
                if ($offer["out_script"]) {
                    $tp = array("user" => $order["wm_id"], "comp" => $order["comp_id"], "flow" => $order["flow_id"], "site" => $order["site_id"], "space" => $order["space_id"], "ext" => $order["ext_id"], "exts" => $order["ext_src"], "bad" => $changes["order_bad"] ? $changes["order_bad"] : $order["order_bad"], "mobile" => $order["order_mobile"], "geo" => $changes["order_country"] ? $changes["order_country"] : $order["order_country"], "geoip" => $order["geoip_country"], "city" => mb_strtolower($changes["order_city"] ? $changes["order_city"] : $order["order_city"], "UTF-8"), "area" => mb_strtolower($changes["order_area"] ? $changes["order_area"] : $order["order_area"], "UTF-8"));
                    require_once PATH_MODS . "order-script.php";
                    $cts = order_script($offer["out_script"], $tp);
                    $changes["comp_id"] = $cts ? $cts : $offer["out_default"];
                } else {
                    $changes["comp_id"] = $offer["out_default"];
                }
                if (!$changes["comp_id"]) {
                    return false;
                }
            }
        }
        $newcomp = $changes["comp_id"] ? $core->cpa->get("comp", $changes["comp_id"]) : $comp;
        $changes["order_status"] = $newcomp["autoaccept"] ? 10 : 6;
        if (!$info["shave"]) {
            $sh1 = (int) $ofps["shave"];
            $sh2 = (int) $ofps["shave-comp" . $newcomp["comp_id"]];
            $sh3 = (int) $ofps["shave-wm" . $order["wm_id"]];
            $sh4 = (int) $ofps["shave-flow" . $order["flow_id"]];
            $sh = max($sh1, $sh2, $sh3, $sh4);
            if ($sh) {
                $info["shave"] = rand(0, 100) <= $sh ? 1 : 0;
            }
        }
    } else {
        if (($order["order_status"] == 5 || 7 < $order["order_status"]) && $changes["order_status"] < 6 && $changes["order_status"] != 2) {
            unset($changes["order_status"]);
        }
        if (5 < $order["order_status"] && $order["order_status"] < 8 && $changes["order_status"] < 5) {
            unset($changes["order_status"]);
        }
    }
    if ($changes["order_status"]) {
        $shave = $info["shave"] ? 1 : 0;
        if (4 < $changes["order_status"]) {
            if ($shave) {
                $changes["order_webstat"] = 5;
                $changes["order_reason"] = rand(0, 7) ? 3 : 2;
                $changes["order_shave"] = $shave;
            } else {
                if ($order["order_status"] == $order["order_webstat"]) {
                    $changes["order_webstat"] = $changes["order_status"];
                }
            }
        } else {
            $changes["order_webstat"] = $changes["order_status"];
        }
    }
    if ($info["calls"]) {
        $changes["order_calls"] = (int) $order["order_calls"] + $info["calls"];
    }
    if ($changes["ext_dlid"]) {
        $changes["ext_track"] = 1;
    }
    if ($changes["track_code"]) {
        $changes["track_on"] = $info["track_on"] ? $info["track_on"] : ($changes["track_code"] ? 1 : 0);
        $changes["track_check"] = $info["track_check"] ? $info["track_check"] : 0;
        $changes["track_date"] = 0;
        $changes["track_status"] = 0;
    }
    if ($canitem && (isset($info["base"]) || isset($info["counts"]) || isset($info["delivery"]) || isset($info["delpr"]) || isset($info["discount"]) || isset($info["more"]))) {
        if ($offer["offer_vars"]) {
            $items = $order["order_items"] ? unserialize($order["order_items"]) : array();
            if (isset($info["base"]) || isset($info["counts"])) {
                if (isset($info["base"]) && isset($info["counts"])) {
                    $items = array();
                    foreach ($info["counts"] as $i => $c) {
                        if (($i = (int) $i) && ($c = (int) $c)) {
                            $items[$i] = array($c, $core->text->float($info["base"][$i]));
                        }
                    }
                } else {
                    if (isset($info["counts"])) {
                        $oi = $items;
                        $items = array();
                        foreach ($info["counts"] as $i => $c) {
                            if (($i = (int) $i) && ($c = (int) $c)) {
                                $items[$i] = array($c, $core->text->float($oi[$i][1]));
                            }
                        }
                    } else {
                        foreach ($items as $i => $c) {
                            $items[$i][1] = $core->text->float($info["base"][$i]);
                        }
                    }
                }
            }
            $counts = $xcnts = $price = 0;
            $vars = $core->cpa->get("vars", $order["offer_id"]);
            foreach ($items as $ix => $it) {
                $price += $it[0] * $it[1];
                if (!$vars[$ix]["var_nc"]) {
                    if ($vars[$ix]["var_type"]) {
                        $xcnts += $it[0];
                    } else {
                        $counts += $it[0];
                    }
                }
            }
            unset($it);
            $changes["order_items"] = serialize($items);
            $changes["price_base"] = 0;
        } else {
            $changes["price_base"] = $base = isset($info["base"]) ? $info["base"] : $order["price_base"];
            $counts = isset($info["counts"]) ? $info["counts"] : $order["order_count"];
            $xcnts = 0;
            $price = $base * $counts;
        }
        $changes["order_discount"] = $discount = isset($info["discount"]) ? $info["discount"] : $order["order_discount"];
        $changes["price_more"] = $more = isset($info["more"]) ? $info["more"] : $order["price_more"];
        if (-100 < $discount && $discount < 100) {
            $price = round($price * (100 - $discount) / 100, 2);
        }
        if ($more != 0) {
            $price += $more;
        }
        if ($offer["offer_delivery"]) {
            $changes["order_delivery"] = $delivery = isset($info["delivery"]) ? $info["delivery"] : $order["order_delivery"];
            $changes["price_delivery"] = $delpr = isset($info["delpr"]) ? $info["delpr"] : $order["price_delivery"];
            $price += $delpr;
        }
        $changes["order_count"] = $counts;
        $changes["order_xcnt"] = $xcnts;
        $changes["price_total"] = $price;
    }
    if ((3 < $changes["order_status"] || 3 < $order["order_status"]) && $order["order_recall"]) {
        $changes["order_recall"] = 0;
    }
    if ((9 < $changes["order_status"] || 9 < $order["order_status"]) && $order["track_on"]) {
        $changes["ext_check"] = 0;
        $changes["ext_track"] = $changes["ext_check"];
        $changes["track_warn"] = $changes["ext_track"];
        $changes["track_check"] = $changes["track_warn"];
        $changes["track_on"] = $changes["track_check"];
    }
    if ($changes["order_status"]) {
        if ($changes["order_status"] != 4 && $order["order_auto"]) {
            $changes["order_auto"] = 0;
        }
    } else {
        if ($order["order_status"] != 4 && $order["order_auto"]) {
            $changes["order_auto"] = 0;
        }
    }
    if ($changes["order_status"] == 5 || 9 < $changes["order_status"]) {
        $changes["order_check"] = 0;
    }
    if ($order["order_check"] && 10 < $changes["order_status"]) {
        if (!($order["ext_id"] || $order["order_shave"])) {
            $fins = $core->db->col("SELECT cash_id FROM " . DB_CASH . " WHERE order_id = '" . $id . "'");
            if ($order["flow_id"]) {
                $core->db->query("UPDATE " . DB_FLOW . " SET flow_total = ( SELECT SUM(cash_wm) FROM " . DB_ORDER . " WHERE flow_id = '" . $order["flow_id"] . "' AND order_webstat IN ( " . implode(",", approvestatus()) . " ) ) WHERE flow_id = '" . $order["flow_id"] . "' LIMIT 1");
            }
            foreach ($fins as $fn) {
                $core->finance->del($fn);
            }
            unset($f);
        }
        $changes["order_status"] = 12;
        if ($order["order_status"] == $order["order_webstat"]) {
            $changes["order_webstat"] = 12;
        }
    } else {
        if ($changes["order_status"] == 12) {
            $fins = $core->db->col("SELECT cash_id FROM " . DB_CASH . " WHERE order_id = '" . $id . "'");
            if ($order["flow_id"]) {
                $core->db->query("UPDATE " . DB_FLOW . " SET flow_total = ( SELECT SUM(cash_wm) FROM " . DB_ORDER . " WHERE flow_id = '" . $order["flow_id"] . "' AND order_webstat IN ( " . implode(",", approvestatus()) . " ) ) WHERE flow_id = '" . $order["flow_id"] . "' LIMIT 1");
            }
            foreach ($fins as $fn) {
                $core->finance->del($fn);
            }
            unset($f);
        } else {
            if (5 < $order["order_status"] && $order["order_status"] < 8 && $changes["order_status"] == 5) {
                if (!($order["ext_id"] || $order["order_shave"])) {
                    $fins = $core->db->col("SELECT cash_id FROM " . DB_CASH . " WHERE order_id = '" . $id . "'");
                    if ($order["flow_id"]) {
                        $core->db->query("UPDATE " . DB_FLOW . " SET flow_total = ( SELECT SUM(cash_wm) FROM " . DB_ORDER . " WHERE flow_id = '" . $order["flow_id"] . "' AND order_webstat IN ( " . implode(",", approvestatus()) . " ) ) WHERE flow_id = '" . $order["flow_id"] . "' LIMIT 1");
                    }
                    foreach ($fins as $fn) {
                        $core->finance->del($fn);
                    }
                    unset($f);
                }
                $changes["order_reason"] = 2;
                if ($order["order_status"] == $order["order_webstat"]) {
                    $changes["order_webstat"] = 5;
                }
            }
        }
    }
    if ($changes["order_status"] && $core->user->id && $order["comp_id"] == $core->user->comp) {
        if ($order["mark_time"]) {
            $changes["mark_time"] = 0;
        }
        if ($order["user_id"] != $core->user->id) {
            $changes["user_id"] = $core->user->id;
        }
    }
    if ($info["accept"] || $changes["price_total"] || $changes["order_count"] || $changes["order_xcnt"] || $changes["order_delivery"] || $changes["comp_id"] || $changes["order_country"] || $changes["order_bad"] || $changes["order_mobile"]) {
        require_once PATH_MODS . "order-cash.php";
        $od = array_merge($order, $changes);
        $mm = order_cash($core, $od);
        extract($mm);
        $changes["cash_wm"] = $uw ? $wmp : 0;
        $changes["cash_pay"] = $up ? $pay : 0;
        $changes["cash_etc"] = $uc ? $ccp : 0;
        if ($ur && $rep && !$shave) {
            $changes["cash_etc"] += $rep;
        }
    } else {
        $od = $uc = $uw = $ur = $up = $wmp = $wmu = $wml = $pay = $pyu = $pyl = $ccp = $ccu = $ccl = $rep = 0;
    }
    if ($info["stage"]) {
        $avs = $core->cpa->stages($changes["comp_id"] ? $changes["comp_id"] : $order["comp_id"], $changes["order_status"] ? $changes["order_status"] : $order["order_status"], true);
        if (isset($avs[$info["stage"]])) {
            $changes["order_stage"] = $info["stage"];
        }
    }
    if ($changes["order_status"] && !$changes["order_stage"]) {
        $avs = $core->cpa->stages($changes["comp_id"] ? $changes["comp_id"] : $order["comp_id"], $changes["order_status"], true);
        if (isset($avs[$order["order_stage"]])) {
            $changes["order_stage"] = 0;
        }
    }
    if (!isset($changes["order_stage"])) {
        $ssc = $core->cpa->stagescript($changes["comp_id"] ? $changes["comp_id"] : $order["comp_id"]);
        if ($ssc) {
            $neworder = array_merge($order, $changes);
            $ofp = $core->cpa->get("ofp", $offer["offer_id"]);
            $stage = order_stage($ssc, $order, $neworder, $offer, $ofp);
            if ($stage) {
                $changes["order_stage"] = $stage;
            }
        }
    }
    if ($core->cando("order_edit_changes")) {
        $changes = $core->filter("order_edit_changes", $changes, $order);
    }
    if (count($changes)) {
        $sqls = array();
        foreach ($changes as $k => &$v) {
            $sqls[] = " " . $k . " = '" . $v . "' ";
        }
        $commonsql = "UPDATE " . DB_ORDER . " SET " . implode(",", $sqls) . " WHERE order_id = '" . $id . "'";
        $result = $core->db->query($commonsql);
        unset($sql);
        unset($k);
        unset($v);
        if ($result) {
            if ($changes["comp_id"]) {
                $chd = array_merge($order, $changes);
                $core->order->notify($chd);
            }
            $chd = array();
            $cfs = array("order_reason", "order_stage", "order_name", "order_email", "order_phone", "comp_id", "order_country", "order_index", "order_area", "order_city", "order_street", "order_addr", "order_comment", "order_count", "order_discount", "order_delivery", "price_cur", "price_base", "price_more", "price_delivery");
            foreach ($cfs as $c) {
                if (isset($changes[$c]) && $changes[$c] != $order[$c]) {
                    $chd[$c] = stripslashes($changes[$c]);
                }
            }
            if ($info["message"]) {
                $chd["message"] = $info["message"];
            }
            if ($info["calling"]) {
                $chd["calling"] = $info["calling"];
            }
            if ($chd) {
                $core->db->add(DB_CHANGE, array("order_id" => $id, "user_id" => $core->user->id, "change_warn" => $chd["order_phone"] ? 1 : 0, "change_time" => time(), "change_data" => addslashes(serialize($chd))));
            }
            if ($info["accept"]) {
                $comment = sprintf("%s - %s", $offer["offer_name"], $id);
                if ($up && $pay) {
                    $core->finance->add($up, $id, 0 - $pay, 2, $comment);
                }
                if ($uc && $ccp) {
                    $core->finance->add($uc, $id, $ccp, 8, $comment);
                }
                if ($uw && $wmp && !$shave) {
                    $core->finance->add($uw, $id, $wmp, 3, $comment);
                    $core->db->query("UPDATE " . DB_FLOW . " SET flow_total = flow_total + " . $wmp . " WHERE flow_id = '" . $order["flow_id"] . "'");
                    if ($ur && $rep) {
                        $core->finance->add($ur, $id, $rep, 7, $comment);
                        $core->db->query("UPDATE " . DB_USER . " SET user_got = user_got + '" . $rep . "' WHERE user_id = '" . $uw . "'");
                    }
                }
            } else {
                $pay = $ccp = $rep = $wmp = 0;
            }
            if (($changes["order_status"] == 4 || $order["order_status"] == 4) && $order["wm_id"]) {
                $hold = $core->db->field("SELECT SUM(cash_wm) FROM " . DB_ORDER . " WHERE order_webstat = 4 AND wm_id = '" . $order["wm_id"] . "'");
                $core->user->meta($order["wm_id"], array("hold" => $hold));
            }
            $st = $changes["order_status"];
            if ($st || $changes["order_recall"]) {
                $core->db->add(DB_CALL, array("order_id" => $id, "offer_id" => $order["offer_id"], "comp_id" => $changes["comp_id"] ? $changes["comp_id"] : $order["comp_id"], "cc_id" => $changes["cc_id"], "user_id" => $core->user->id, "wm_id" => $order["wm_id"], "call_status" => $st ? $st : $order["order_status"], "call_reason" => $changes["order_reason"], "call_time" => time(), "call_next" => $changes["order_recall"], "call_length" => (int) $info["length"], "call_count" => $info["accept"] ? $changes["order_count"] ? $changes["order_count"] : $order["order_count"] : 0, "call_accept" => $info["accept"] ? 1 : 0, "call_price" => $info["accept"] ? $changes["price_total"] ? $changes["price_total"] : $order["price_total"] : 0, "call_delivery" => $changes["order_delivery"] ? $changes["order_delivery"] : $order["order_delivery"], "call_cur" => $info["accept"] ? $changes["price_cur"] ? $changes["price_cur"] : $order["price_cur"] : 0, "call_geo" => $changes["order_country"] ? $changes["order_country"] : $order["order_country"], "call_in" => $pay, "call_out" => $shave ? $uc ? $ccp : 0 : ($uw ? $wmp : 0) + ($uc ? $ccp : 0) + ($ur ? $rep : 0)));
            }
            if ($changes["order_webstat"] && $order["order_webstat"] < 5) {
                $otp = array_merge($order, $changes);
                $core->postback->make($otp, $info["accept"]);
            }
            if ($changes["order_status"] == 5 && $offer["bad_script"]) {
                $tp = array("user" => $order["wm_id"], "comp" => $changes["comp_id"] ? $changes["comp_id"] : $order["comp_id"], "flow" => $order["flow_id"], "site" => $order["site_id"], "space" => $order["space_id"], "ext" => $order["ext_id"], "exts" => $order["ext_src"], "bad" => $changes["order_bad"] ? $changes["order_bad"] : $order["order_bad"], "mobile" => $order["order_mobile"], "geo" => $changes["order_country"] ? $changes["order_country"] : $order["order_country"], "geoip" => $order["geoip_country"], "city" => mb_strtolower($changes["order_city"] ? $changes["order_city"] : $order["order_city"], "UTF-8"), "area" => mb_strtolower($changes["order_area"] ? $changes["order_area"] : $order["order_area"], "UTF-8"));
                require_once PATH_MODS . "order-script.php";
                $cts = order_script($offer["bad_script"], $tp);
                if ($cts) {
                    $cch = array("comp_id" => $cts, "user_id" => 0, "order_status" => 1, "order_stage" => 0, "ext_oid" => 0, "ext_check" => 0);
                    if ($changes["order_status"] == $changes["order_status"]) {
                        $cch["order_webstat"] = 1;
                    }
                    $core->db->edit(DB_ORDER, $cch, array("order_id" => $id));
                    $core->db->add(DB_CHANGE, array("order_id" => $id, "user_id" => 0, "change_warn" => 0, "change_time" => time(), "change_data" => addslashes(serialize(array("comp_id" => $cts)))));
                }
            }
            if ($core->cando("order_edit_saved")) {
                $changes = $core->filter("order_edit_saved", $changes, $order);
            }
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}
function order_stage($script, $f, $t, $o, $p)
{
    $stage = 0;
    $sg = array(1, 1, 1, 1, 1, 2, 3, 4, 5, 5, 6, 7, 2);
    foreach ($script as $s) {
        if ($sg[$t["order_status"]] != $s["group"]) {
            continue;
        }
        $isok = true;
        foreach ($s["why"] as $w) {
            list($wn, $ww, , $wv) = $w;
            switch ($w[2]) {
                case "=":
                    if (${$wn[$ww]} != $wv) {
                        $isok = false;
                    }
                    break;
                case "!":
                    if (${$wn[$ww]} == $wv) {
                        $isok = false;
                    }
                    break;
                case ">":
                    if (${$wn[$ww]} <= $wv) {
                        $isok = false;
                    }
                    break;
                case "<":
                    if ($wv <= ${$wn[$ww]}) {
                        $isok = false;
                    }
                    break;
                case "+":
                    if (!${$wn[$ww]}) {
                        $isok = false;
                    }
                    break;
                case "-":
                    if (${$wn[$ww]}) {
                        $isok = false;
                    }
                    break;
                case "?":
                    if (mb_stripos(${$wn[$ww]}, $wv) === false) {
                        $isok = false;
                    }
                    break;
            }
        }
        if ($isok) {
            $stage = $s["stage"];
        }
    }
    return $stage;
}

?>