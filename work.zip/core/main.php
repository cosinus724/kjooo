<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

require_once PATH . "core/start.php";
if (defined("NOTINSTALLED")) {
    require_once PATH . "core/setup/config.php";
    installconfig($core);
}
if (!$core->config("setup")) {
    require_once PATH . "core/setup/system.php";
    setupsystem($core);
}
if ($core->get["api"]) {
    require_once PATH_MODS . "api.php";
    api($core, $core->get["api"], $core->get["f"], $core->get["t"], isset($core->post["authid"]) ? $core->post["authid"] : $core->get["id"]);
    $core->stop();
} else {
    if ($core->server["REQUEST_URI"] == "/?wm" || $core->get["m"] == "wm") {
        require_once PATH_LIB . "webmoney.php";
    }
}
if ($core->get["neworder"]) {
    require_once PATH_MODS . "order-add.php";
    makeneworder($core);
    $core->stop();
}
if (defined("STRICT_HTTPS") && $core->server["HTTPS"] != "on") {
    $core->go("https://" . (defined("STRICT_HOST") ? STRICT_HOST : $core->server["HTTP_HOST"]) . $core->server["REQUEST_URI"]);
} else {
    if (defined("STRICT_HOST") && $core->server["HTTP_HOST"] != STRICT_HOST) {
        $core->go(($core->server["HTTPS"] == "on" ? "https" : "http") . "://" . STRICT_HOST . $core->server["REQUEST_URI"]);
    }
}
if ($core->user->auth == false) {
    require_once PATH_MODS . "register.php";
    $core->stop();
} else {
    if ($core->get["recoverpass"]) {
        $core->go("/profile");
    }
}
if ($core->user->ban) {
    $core->tpl->load("body", "ban", defined("HACK_TPL_BAN") ? HACK : false);
    $core->tpl->vars("body", array("title" => $core->lang["ban_title"], "reason" => $core->lang["ban_reason"], "footer" => $core->lang["ban_footer"]));
    $core->tpl->output("body");
    $core->stop();
}
if (isset($core->get["a"]) || isset($core->get["action"])) {
    if ($core->server["HTTP_REFERER"]) {
        $rfh = parse_url($core->server["HTTP_REFERER"], PHP_URL_HOST);
        $refisok = $rfh == $core->server["HTTP_HOST"] ? true : false;
    } else {
        $refisok = false;
    }
    if (!$refisok) {
        unset($core->get["a"]);
        unset($core->get["action"]);
        $core->post = array();
    }
}
$core->process("libraries");
require_once PATH_MODS . "base.php";
if ($core->user->work == -1) {
    require_once PATH_MODS . "wm-ext.php";
}
if ($core->user->work == 0 || $core->user->work == 2 || $core->user->work == -2) {
    require_once PATH_MODS . "webmaster.php";
}
if (1 <= $core->user->work) {
    require_once PATH_MODS . "orders.php";
    if ($core->user->comp && $core->cpa->team("admin")) {
        require_once PATH_MODS . "company.php";
    }
    if ($core->user->comp && $core->cpa->team("team")) {
        require_once PATH_MODS . "comp-team.php";
    }
}
if ($core->user->level == 1) {
    require_once PATH_MODS . "admin.php";
} else {
    if ($core->user->work == -2) {
        require_once PATH_MODS . "admin-manager.php";
    }
}
$menu = array();
if ($core->user->work == -1) {
    $menu = external_menu($core, $menu);
}
if (1 <= $core->user->work) {
    $menu = order_menu($core, $menu);
}
if ($core->user->work == 0 || $core->user->work == 2 || $core->user->work == -2) {
    $menu = webmaster_menu($core, $menu);
}
if (1 <= $core->user->work && $core->user->comp) {
    if ($core->cpa->team("admin")) {
        $menu = company_menu($core, $menu);
    }
    if ($core->cpa->team("team")) {
        $menu = team_menu($core, $menu);
    }
}
if ($core->user->level == 1) {
    $menu = admin_menu($core, $menu);
} else {
    if ($core->user->work == -2) {
        $menu = manager_menu($core, $menu);
    }
}
$menu = base_menu($core, $menu);
$menu = $core->filter("menu", $menu);
$newmenu = array();
foreach ($menu as $n => &$m) {
    if (is_array($m)) {
        $sub = array();
        foreach ($m as $mm) {
            $sub[] = array("div" => $mm, "link" => $core->url("m", $mm), "name" => $core->lang["menu_sub_" . $mm] ? $core->lang["menu_sub_" . $mm] : $core->lang["menu_" . $mm]);
        }
        $newmenu[] = array("div" => $n, "link" => $core->url("m", $n), "name" => $core->lang["menu_" . $n], "sub" => $sub);
    } else {
        $newmenu[] = array("div" => $m, "link" => $core->url("m", $m), "name" => $core->lang["menu_" . $m]);
    }
}
$newmenu = $core->filter("newmenu", $newmenu);
$core->site->menu = $newmenu;
unset($m);
unset($menu);
unset($newmenu);
$core->process("actions");
if (1 <= $core->user->work && $core->user->comp) {
    if ($core->cpa->team("admin")) {
        company_action($core);
    }
    if ($core->cpa->team("team")) {
        team_action($core);
    }
}
if ($core->user->work == 0 && $core->config("register", "contact")) {
    $cnok = false;
    if ($core->user->meta["vk"]) {
        $cnok = true;
    }
    if ($core->user->meta["skype"]) {
        $cnok = true;
    }
    if ($core->user->meta["telegram"]) {
        $cnok = true;
    }
    if ($core->user->meta["whatsapp"]) {
        $cnok = true;
    }
    if (!$cnok && $core->get["m"] != "profile") {
        $core->go($core->url("m", "profile"));
    }
}
$core->process("modules");
if ($core->user->level == 1) {
    admin_module($core);
} else {
    if ($core->user->work == -2) {
        manager_module($core);
    }
}
base_module($core);
if (1 <= $core->user->work) {
    if ($core->user->comp && $core->cpa->team("admin")) {
        company_module($core);
    }
    if ($core->user->comp && $core->cpa->team("team")) {
        team_module($core);
    }
    order_module($core);
}
if ($core->user->work == 0 || $core->user->work == 2 || $core->user->work == -2) {
    webmaster_module($core);
}
if ($core->user->work == -1) {
    external_module($core);
}
base_404($core);
$core->stop();

?>