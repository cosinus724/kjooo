<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

if (!defined("IN_ALTERCMS_CORE_ONE")) {
    exit("Hacking attempt");
}
error_reporting(0);
if (isset($_REQUEST["GLOBALS"])) {
    exit("GLOBALS overwrite attempt detected");
}
$noUnset = array("GLOBALS", "_GET", "_POST", "_COOKIE", "_REQUEST", "_SERVER", "_ENV", "_FILES");
$input = array_merge($_GET, $_POST, $_COOKIE, $_SERVER, $_ENV, $_FILES, isset($_SESSION) && is_array($_SESSION) ? $_SESSION : array());
foreach ($input as $k => $v) {
    if (!in_array($k, $noUnset) && isset($GLOBALS[$k])) {
        $GLOBALS[$k] = NULL;
        unset($GLOBALS[$k]);
    }
}
define("PATH_ROOT", PATH);
define("PATH_CORE", PATH . "core/base/");
define("PATH_LIB", PATH . "core/lib/");
define("PATH_MODS", PATH . "core/mods/");
define("PATH_CACHE", PATH . "data/cache/%s.txt");
define("PATH_NEWS", "/data/news/%s");
define("DIR_CACHE", PATH . "data/cache/");
define("DIR_SESSION", PATH . "data/session/");
define("DIR_LOAD", PATH . "data/load/");
define("DIR_WORK", PATH . "data/work/");
define("DIR_TPLS", PATH . "data/tpls/");
define("DIR_NEWS", PATH . "data/news/");
if (!file_exists(PATH . "config.php")) {
    if (http_response_code()) {
        define("NOTINSTALLED", true);
    } else {
        exit("Please install the script");
    }
} else {
    require_once PATH . "config.php";
}
require_once PATH . "core/version.php";
require_once PATH_CORE . "common.php";
require_once PATH_CORE . "core.php";
require_once PATH_CORE . "settings.php";
$configs = array("get" => $_GET, "post" => $_POST, "files" => $_FILES, "cookie" => $_COOKIE, "server" => $_SERVER, "dbhost" => SQL_HOST, "dbuser" => SQL_USER, "dbpass" => SQL_PASS, "dbbase" => SQL_BASE, "dbchar" => defined("SQL_CHRS") ? SQL_CHRS : (defined("SQL_CHARSET") ? SQL_CHARSET : false), "dbcoll" => defined("SQL_COLL") ? SQL_COLL : (defined("SQL_COLLATE") ? SQL_COLLATE : false), "tplpath" => PATH . "core/tpl/%s.tpl", "tplmod" => PATH . "%s/tpl/%s.tpl", "tplcache" => PATH . "data/tpls/%s.php", "cache" => PATH_CACHE, "session" => PATH . "data/session/%s.txt", "lang" => defined("LANG") ? LANG : "ru", "lang_path" => PATH . "core/lang/%s.php", "lang_mods" => PATH . "%s/lang/%s.php");
$core = new Core($configs);
if (!$core) {
    exit("The Worst Error: Core was not created ...");
}
register_shutdown_function("altercms_exit_procedure");
$contenttype = defined("RAWDEBUG") ? "text/plain" : "text/html";
header("Content-Type: " . $contenttype . "; charset=utf-8");
if (defined("DEBUG") || defined("RAWDEBUG")) {
    error_reporting(32767 & ~8);
    ini_set("display_errors", true);
}
if (function_exists("initmyhacks")) {
    initmyhacks($core);
}
function altercms_exit_procedure()
{
    global $core;
    if (isset($core)) {
        unset($core);
    }
}

?>